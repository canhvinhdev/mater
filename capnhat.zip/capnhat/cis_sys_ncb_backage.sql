--------------------------------------------------------
--  File created - Tuesday-February-20-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package PCK_CLIENT_TOKEN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PCK_CLIENT_TOKEN" AS 

/**
    Kh?i t?o client token m?i
**/
 PROCEDURE PR_CREATE_CLIENT_TOKEN(P_ID VARCHAR2,
                            P_APPLICATION_ID	VARCHAR2,
                            P_USER_NAME	VARCHAR2,
                            P_CLIENT_TOKEN	VARCHAR2,
                            P_STATUS	VARCHAR2,
                            p_out OUT types.ref_cursor);

/**
    Ki?m tra xem th�ng tin token th? n�o
**/
 PROCEDURE PR_CHECK_CLIENT_TOKEN( P_APPLICATION_ID	VARCHAR2,
                            P_CLIENT_TOKEN	VARCHAR2,
                            p_out OUT types.ref_cursor);

/**
    C?p nh?t tr?ng th�i token
**/
 PROCEDURE PR_UPDATE_CLIENT_TOKEN( P_APPLICATION_ID	VARCHAR2,
                            P_CLIENT_TOKEN	VARCHAR2,
                            p_status VARCHAR2,
                            p_out OUT types.ref_cursor);
                            
END PCK_CLIENT_TOKEN;

/
--------------------------------------------------------
--  DDL for Package PCK_SYSTEM_PRICE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PCK_SYSTEM_PRICE" AS

  PROCEDURE pr_list_price(p_price_code SYS_PRICE.PRICE_CODE%TYPE,
                            p_channel SYS_PRICE.CHANNEL%TYPE,
                            p_effective_date SYS_PRICE.EFFECTIVE_DATE%TYPE,
                            p_expiration_date SYS_PRICE.EXPIRATION_DATE%TYPE,
                            p_normal_price SYS_PRICE.NORMAL_PRICE%TYPE,
                            p_non_normal_price SYS_PRICE.NON_NORMAL_PRICE%TYPE,
                            p_description SYS_PRICE.DESCRIPTION%TYPE,
                            p_creater_date SYS_PRICE.CREATER_DATE%TYPE,
                            p_user_creater SYS_PRICE.USER_CREATER%TYPE,
                            p_update_date SYS_PRICE.UPDATE_DATE%TYPE,
                            p_user_update SYS_PRICE.USER_UPDATE%TYPE,
                            p_out OUT types.ref_cursor);

    PROCEDURE pr_price_info(p_id number,
                               p_out OUT types.ref_cursor);
                               
    PROCEDURE pr_create_price(p_price_code SYS_PRICE.PRICE_CODE%TYPE,
                                p_channel SYS_PRICE.CHANNEL%TYPE,
                                p_effective_date SYS_PRICE.EFFECTIVE_DATE%TYPE,
                                p_expiration_date SYS_PRICE.EXPIRATION_DATE%TYPE,
                                p_normal_price SYS_PRICE.NORMAL_PRICE%TYPE,
                                p_non_normal_price SYS_PRICE.NON_NORMAL_PRICE%TYPE,
                                p_description SYS_PRICE.DESCRIPTION%TYPE,
                                p_creater_date SYS_PRICE.CREATER_DATE%TYPE,
                                p_user_creater SYS_PRICE.USER_CREATER%TYPE,
                                p_update_date SYS_PRICE.UPDATE_DATE%TYPE,
                                p_user_update SYS_PRICE.USER_UPDATE%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_out OUT types.ref_cursor);
                                
    PROCEDURE pr_update_price(
                                p_price_code SYS_PRICE.PRICE_CODE%TYPE,
                                p_channel SYS_PRICE.CHANNEL%TYPE,
                                p_effective_date SYS_PRICE.EFFECTIVE_DATE%TYPE,
                                p_expiration_date SYS_PRICE.EXPIRATION_DATE%TYPE,
                                p_normal_price SYS_PRICE.NORMAL_PRICE%TYPE,
                                p_non_normal_price SYS_PRICE.NON_NORMAL_PRICE%TYPE,
                                p_description SYS_PRICE.DESCRIPTION%TYPE,
                                p_creater_date SYS_PRICE.CREATER_DATE%TYPE,
                                p_user_creater SYS_PRICE.USER_CREATER%TYPE,
                                p_update_date SYS_PRICE.UPDATE_DATE%TYPE,
                                p_user_update SYS_PRICE.USER_UPDATE%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_id number,
                                p_out OUT types.ref_cursor);
    PROCEDURE pr_delete_price(p_id number);

END PCK_SYSTEM_PRICE;

/
--------------------------------------------------------
--  DDL for Package PCK_SYSTEM_SECURITY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PCK_SYSTEM_SECURITY" is

  -- Author  : ANHCUONG
  -- Created : 4/1/2015 2:19:03 AM
  -- Purpose : Xu ly cac tac vu lien quan den he thong

  -- Danh sach cac Application cua user
  PROCEDURE FN_GET_APPLICATION(p_out   OUT TYPES.ref_cursor,
                               p_user  IN VARCHAR2,
                               p_group IN VARCHAR2);

  -- Danh sach cac Rescource cua user
  PROCEDURE FN_GET_RES(p_user  IN VARCHAR2,
                       p_group IN OUT VARCHAR2,
                       p_appid IN VARCHAR2,p_out   OUT TYPES.ref_cursor);

  -- Danh sach cac Rescource cua user
  PROCEDURE FN_GET_RES_ACTION(p_user  IN VARCHAR2,
                           p_group_ IN  VARCHAR2,
                           p_res_id IN VARCHAR2,
                           p_appid IN VARCHAR2,
                           p_out   OUT TYPES.ref_cursor);

  -- Danh sach cac Rescource cua user
  PROCEDURE FN_GET_RES_NEW(p_user  IN VARCHAR2,
                       p_group IN VARCHAR2,
                       p_appid IN VARCHAR2,p_out   OUT TYPES.ref_cursor);

  -- Danh sach cac Rescource cua user
  PROCEDURE FN_GET_RES_DENIED(p_user  IN VARCHAR2,
                           p_group_  IN   VARCHAR2,
                           p_res_id IN VARCHAR2,
                           p_appid IN VARCHAR2,
                           p_out   OUT TYPES.ref_cursor);

  -- Gan thong tin cau hinh LDAP cho Application
  PROCEDURE FN_LDAP_CONFIG_APPLICATION(p_user  IN VARCHAR2,
                                       p_appid IN VARCHAR2,
                                       p_ldapType IN VARCHAR2);

  -- Thuc hien xoa quyen User
  PROCEDURE FN_DEL_ACTION_USER(p_user  IN VARCHAR2,
                               p_ResActionID IN VARCHAR2,
                               p_user_del    IN VARCHAR2);

  -- Thuc hien xoa quyen Group
  PROCEDURE FN_DEL_ACTION_GROUP(p_group  IN VARCHAR2,
                               p_ResActionID IN VARCHAR2,
                               p_group_del    IN VARCHAR2);

  PROCEDURE PR_LOG_USER_ACTIVITY(p_user_name  IN VARCHAR2,
                                 p_user_type IN VARCHAR2,
                                 p_activity_type    IN VARCHAR2,
                                 p_description    IN VARCHAR2,
                                 p_status    IN VARCHAR2,
                                 p_client_ip    IN VARCHAR2,
                                 p_user_agent    IN VARCHAR2);

  PROCEDURE PR_AUTHEN_USER(p_user_name  IN VARCHAR2,
                           p_pass VARCHAR2,
                           p_client_ip VARCHAR2,
                           p_user_agent VARCHAR2,
                           p_out   OUT TYPES.ref_cursor );

  PROCEDURE PR_AUTO_UNLOCK_USER;
end PCK_SYSTEM_SECURITY;


/
--------------------------------------------------------
--  DDL for Package PCK_TOKEN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PCK_TOKEN" AS 

PROCEDURE PR_GET_TOKEN (p_out    OUT SYS_REFCURSOR);

END PCK_TOKEN;

/
--------------------------------------------------------
--  DDL for Package PKG_REF_CODE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PKG_REF_CODE" AS
    PROCEDURE pr_list_category(p_status sys_refcode.status%TYPE ,
                                p_ref_group sys_refcode.ref_group%TYPE,
                                p_ref_code sys_refcode.ref_code%TYPE,
                                p_ref_name_vn sys_refcode.ref_name_vn%TYPE,
                                p_ref_name_en sys_refcode.ref_name_en%TYPE,
                                p_description sys_refcode.description%TYPE,
                                p_par1 sys_refcode.par1%TYPE,
                                p_par2 sys_refcode.par2%TYPE,
                                p_par3 sys_refcode.par3%TYPE,
                                p_par4 sys_refcode.par4%TYPE,
                                p_par5 sys_refcode.par5%TYPE,
                                p_par6 sys_refcode.par6%TYPE,
                                p_par7 sys_refcode.par7%TYPE,
                                p_par8 sys_refcode.par8%TYPE,
                                p_par9 sys_refcode.par9%TYPE,
                                p_user varchar2,
                               p_out OUT types.ref_cursor);

    PROCEDURE pr_category_info(p_ref_code sys_refcode.ref_code%TYPE,
                               p_ref_group sys_refcode.ref_group%TYPE,
                               p_out OUT types.ref_cursor);
                               
    PROCEDURE pr_create_category(p_application_id SYS_REFCODE.APPLICATION_ID%TYPE,
                                    p_creater_date SYS_REFCODE.CREATER_DATE%TYPE,
                                    p_ref_code SYS_REFCODE.REF_CODE%TYPE,
                                    p_ref_group SYS_REFCODE.REF_GROUP%TYPE,
                                    p_ref_name_en SYS_REFCODE.REF_NAME_EN%TYPE,
                                    p_ref_name_vn SYS_REFCODE.REF_NAME_VN%TYPE,
                                    p_update_date SYS_REFCODE.UPDATE_DATE%TYPE,
                                    p_user_creater SYS_REFCODE.USER_CREATER%TYPE,
                                    p_user_update SYS_REFCODE.USER_UPDATE%TYPE,
                                    p_priority SYS_REFCODE.PRIORITY%TYPE,
                                    p_description SYS_REFCODE.DESCRIPTION%TYPE,
                                    p_par1 SYS_REFCODE.PAR1%TYPE,
                                    p_par2 SYS_REFCODE.PAR2%TYPE,
                                    p_par3 SYS_REFCODE.PAR3%TYPE,
                                    p_par4 SYS_REFCODE.PAR4%TYPE,
                                    p_par5 SYS_REFCODE.PAR5%TYPE,
                                    p_par6 SYS_REFCODE.PAR6%TYPE,
                                    p_par7 SYS_REFCODE.PAR7%TYPE,
                                    p_par8 SYS_REFCODE.PAR8%TYPE,
                                    p_par9 SYS_REFCODE.PAR9%TYPE,
                                    p_allowdelete SYS_REFCODE.ALLOWDELETE%TYPE,
                                    p_update_reason SYS_REFCODE.UPDATE_REASON%TYPE,
                                    p_status SYS_REFCODE.STATUS%TYPE,
                                    p_create_reason SYS_REFCODE.CREATE_REASON%TYPE,
                                    p_user                         IN     VARCHAR2,
                                    p_client_ip                    IN     VARCHAR2,
                                    p_user_agent                   IN     VARCHAR2,
                                    p_out OUT types.ref_cursor);
                                
    PROCEDURE pr_update_category(p_application_id SYS_REFCODE.APPLICATION_ID%TYPE,
                                    p_creater_date SYS_REFCODE.CREATER_DATE%TYPE,
                                    p_ref_code SYS_REFCODE.REF_CODE%TYPE,
                                    p_ref_group SYS_REFCODE.REF_GROUP%TYPE,
                                    p_ref_name_en SYS_REFCODE.REF_NAME_EN%TYPE,
                                    p_ref_name_vn SYS_REFCODE.REF_NAME_VN%TYPE,
                                    p_update_date SYS_REFCODE.UPDATE_DATE%TYPE,
                                    p_user_creater SYS_REFCODE.USER_CREATER%TYPE,
                                    p_user_update SYS_REFCODE.USER_UPDATE%TYPE,
                                    p_priority SYS_REFCODE.PRIORITY%TYPE,
                                    p_description SYS_REFCODE.DESCRIPTION%TYPE,
                                    p_par1 SYS_REFCODE.PAR1%TYPE,
                                    p_par2 SYS_REFCODE.PAR2%TYPE,
                                    p_par3 SYS_REFCODE.PAR3%TYPE,
                                    p_par4 SYS_REFCODE.PAR4%TYPE,
                                    p_par5 SYS_REFCODE.PAR5%TYPE,
                                    p_par6 SYS_REFCODE.PAR6%TYPE,
                                    p_par7 SYS_REFCODE.PAR7%TYPE,
                                    p_par8 SYS_REFCODE.PAR8%TYPE,
                                    p_par9 SYS_REFCODE.PAR9%TYPE,
                                    p_allowdelete SYS_REFCODE.ALLOWDELETE%TYPE,
                                    p_update_reason SYS_REFCODE.UPDATE_REASON%TYPE,
                                    p_status SYS_REFCODE.STATUS%TYPE,
                                    p_create_reason SYS_REFCODE.CREATE_REASON%TYPE,
                                    p_user                         IN     VARCHAR2,
                                    p_client_ip                    IN     VARCHAR2,
                                    p_user_agent                   IN     VARCHAR2,
                                    p_out OUT types.ref_cursor);
                                    
        PROCEDURE pr_list_product_category(p_status sys_refcode.status%TYPE ,
                                p_ref_group sys_refcode.ref_group%TYPE,
                                p_ref_code sys_refcode.ref_code%TYPE,
                                p_ref_name_vn sys_refcode.ref_name_vn%TYPE,
                                p_ref_name_en sys_refcode.ref_name_en%TYPE,
                                p_description sys_refcode.description%TYPE,
                                p_par1 sys_refcode.par1%TYPE,
                                p_par2 sys_refcode.par2%TYPE,
                                p_par3 sys_refcode.par3%TYPE,
                                p_par4 sys_refcode.par4%TYPE,
                                p_par5 sys_refcode.par5%TYPE,
                                p_par6 sys_refcode.par6%TYPE,
                                p_par7 sys_refcode.par7%TYPE,
                                p_par8 sys_refcode.par8%TYPE,
                                p_par9 sys_refcode.par9%TYPE,
                               p_out OUT types.ref_cursor);
                               
                               
        PROCEDURE pr_category_his   (  p_ref_group sys_refcode.ref_group%TYPE,
                                p_ref_code sys_refcode.ref_code%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_out                             OUT types.ref_cursor);                       
                               
END PKG_REF_CODE;

/
--------------------------------------------------------
--  DDL for Package PKG_SYS_EMAIL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PKG_SYS_EMAIL" 
AS
    /******************************************************************************
       NAME:       PKG_SYS_EMAIL
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        5/3/2018      admin       1. Created this package.
    ******************************************************************************/

    PROCEDURE pr_create_sys_email (
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        --p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        --p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        --p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        --p_status                   SYS_EMAIL.STATUS%TYPE,
        --p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        --p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        --p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor);

    PROCEDURE pr_get_list_sys_email (
        p_text_search              VARCHAR2,
        p_status              VARCHAR2,
        p_from_date                DATE,
        p_to_date                  DATE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor);

    PROCEDURE pr_get_list_sys_email_to_send (
        p_text_search              VARCHAR2,
        p_status              VARCHAR2,
        p_from_date                DATE,
        p_to_date                  DATE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor);

    PROCEDURE pr_update_sys_email (
        p_id                       SYS_EMAIL.ID%TYPE,
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        p_status                   SYS_EMAIL.STATUS%TYPE,
        p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor);

    PROCEDURE pr_get_sys_email_by_id (p_id                  SYS_EMAIL.ID%TYPE,
                                      p_user         IN     VARCHAR2,
                                      p_client_ip    IN     VARCHAR2,
                                      p_user_agent   IN     VARCHAR2,
                                      p_out             OUT types.ref_cursor);

--G?i email th�ng b�o kh?i t?o/di?u ch?nh user
PROCEDURE PR_SEND_EMAIL_USER (P_USER_ID                 VARCHAR2,
                              P_ACTION                  VARCHAR2);
     
--G?i email th�ng b�o nh?n b?n tin
PROCEDURE PR_SEND_EMAIL_RESPONSE (P_CIS_NO                  VARCHAR2);

--G?i email th�ng b�o ph� duy?t b?n tin
PROCEDURE PR_SEND_EMAIL_TASK(P_TASK_ID VARCHAR2, P_STATUS VARCHAR2, P_USER VARCHAR2, P_COMMENT VARCHAR2);

--G?i email th�ng b�o cho ng??i d�ng bi?t c� file m?i
PROCEDURE PR_SEND_EMAIL_NEW_FILE(P_FILE_NAME VARCHAR2, P_CHANNEL VARCHAR2, P_STATUS VARCHAR2);

END PKG_SYS_EMAIL;

/
--------------------------------------------------------
--  DDL for Package PKG_SYS_GROUP_ACTIONS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PKG_SYS_GROUP_ACTIONS" 
  -- Author  : DONB
  -- Created : 17/06/2019 4:01:04 PM
  -- Purpose :
IS
    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: Th�m m?i SYS_GROUP_ACTIONS
    Parameter:
                p_group_id: 
                p_res_action_id: 
                p_update_dt: 
                p_create_dt: 
                p_create_usr: 
                p_update_usr: 
                p_user:
                p_client_ip:
                p_user_agent:

    */
    PROCEDURE pr_create_sys_group_actions (p_group_id SYS_GROUP_ACTIONS.GROUP_ID%TYPE,
                                            p_res_action_id SYS_GROUP_ACTIONS.RES_ACTION_ID%TYPE,
                                            p_update_dt SYS_GROUP_ACTIONS.UPDATE_DT%TYPE,
                                            p_create_dt SYS_GROUP_ACTIONS.CREATE_DT%TYPE,
                                            p_create_usr SYS_GROUP_ACTIONS.CREATE_USR%TYPE,
                                            p_update_usr SYS_GROUP_ACTIONS.UPDATE_USR%TYPE,
                                            p_user               IN     VARCHAR2,
                                            p_client_ip          IN     VARCHAR2,
                                            p_user_agent         IN     VARCHAR2,
                                            p_out                   OUT types.ref_cursor);
    
    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: C?p nh?t SYS_GROUP_ACTIONS
    Parameter:
                p_group_id: 
                p_res_action_id: 
                p_id: 
                p_update_dt: 
                p_create_dt: 
                p_create_usr: 
                p_update_usr: 
                p_user:
                p_client_ip:
                p_user_agent:

    */
    PROCEDURE pr_update_sys_group_actions (p_group_id SYS_GROUP_ACTIONS.GROUP_ID%TYPE,
                                            p_res_action_id SYS_GROUP_ACTIONS.RES_ACTION_ID%TYPE,
                                            p_id SYS_GROUP_ACTIONS.ID%TYPE,
                                            p_update_dt SYS_GROUP_ACTIONS.UPDATE_DT%TYPE,
                                            p_create_dt SYS_GROUP_ACTIONS.CREATE_DT%TYPE,
                                            p_create_usr SYS_GROUP_ACTIONS.CREATE_USR%TYPE,
                                            p_update_usr SYS_GROUP_ACTIONS.UPDATE_USR%TYPE,
                                            p_user               IN     VARCHAR2,
                                            p_client_ip          IN     VARCHAR2,
                                            p_user_agent         IN     VARCHAR2,
                                            p_out                   OUT types.ref_cursor);
    
    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y danh s�ch SYS_GROUP_ACTIONS
    Parameter:
                p_group_id: 
                p_res_action_id: 
                p_id: 
                p_user:
                p_client_ip:
                p_user_agent:

    */
    PROCEDURE pr_get_list_sys_group_actions (p_group_id SYS_GROUP_ACTIONS.GROUP_ID%TYPE,
                                                p_res_action_id SYS_GROUP_ACTIONS.RES_ACTION_ID%TYPE,
                                                p_id SYS_GROUP_ACTIONS.ID%TYPE,
                                                p_user               IN     VARCHAR2,
                                                p_client_ip          IN     VARCHAR2,
                                                p_user_agent         IN     VARCHAR2,
                                                p_out                   OUT types.ref_cursor);

    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: x�a danh s�ch SYS_GROUP_ACTIONS theo p_group_id
    Parameter:
                p_group_id: 
                p_user:
                p_client_ip:
                p_user_agent:

    */
     PROCEDURE pr_delete_sys_group_actions (p_group_id SYS_GROUP_ACTIONS.GROUP_ID%TYPE,
                                            p_user         IN VARCHAR2,
                                            p_client_ip    IN VARCHAR2,
                                            p_user_agent   IN VARCHAR2);
END;

/
--------------------------------------------------------
--  DDL for Package PKG_SYS_RESOURCES
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PKG_SYS_RESOURCES" 
  -- Author  : DONB
  -- Created : 17/06/2019 4:01:04 PM
  -- Purpose :
IS
    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y danh s�ch nh�m ng??i d�ng (Application: BO) => th?c ra l� l?y g�i ch?c n?ng
    Parameter:
                 p_group_name:
                 p_description:
                 p_user:
                 p_client_ip:
                 p_user_agent:

    */
    PROCEDURE pr_get_list_sys_group (p_group_name   SYS_GROUPS.GROUP_NAME%TYPE,
                                         p_description          SYS_GROUPS.DESCRIPTION%TYPE,
                                         p_status               SYS_GROUPS.Status%TYPE,
                                         p_user               IN     VARCHAR2,
                                         p_client_ip          IN     VARCHAR2,
                                         p_user_agent         IN     VARCHAR2,
                                         p_out                   OUT types.ref_cursor);

    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y danh s�ch menu h? th?ng
    Parameter:
                 p_user:
                 p_client_ip:
                 p_user_agent:
    */
    PROCEDURE pr_get_list_sys_resources (p_application_id          SYS_RESOURCES.APPLICATION_ID%TYPE,
                                            p_status               SYS_RESOURCES.Status%TYPE,
                                            p_user         IN     VARCHAR2,
                                            p_client_ip    IN     VARCHAR2,
                                            p_user_agent   IN     VARCHAR2,
                                            p_out             OUT types.ref_cursor);

    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L�y th�ng tin chi ti?t nh�m ng??i d�ng (Nh�m ch?c n?ng)
    Parameter:
                 p_group_name:
                 p_description:
                 p_user:
                 p_client_ip:
                 p_user_agent:


    */
    PROCEDURE pr_get_sys_group_info (p_group_name   SYS_GROUPS.GROUP_NAME%TYPE,
                                         p_description          SYS_GROUPS.DESCRIPTION%TYPE,
                                         p_status               SYS_GROUPS.Status%TYPE,
                                         p_user         IN     VARCHAR2,
                                         p_client_ip    IN     VARCHAR2,
                                         p_user_agent   IN     VARCHAR2,
                                         p_out             OUT types.ref_cursor);



    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: C?p nh?t th�ng tin chi ti?t nh�m ng??i d�ng
    Parameter:
                p_group_type: 
                p_group_name: 
                p_description: 
                p_create_user: 
                p_update_user: 
                p_create_date: 
                p_update_date: 
                p_status: 
                p_par1: 
                p_par2: 
                p_par3: 
                p_par4: 
                p_par5: 
                p_user:
                p_client_ip:
                p_user_agent:
    */
    PROCEDURE pr_update_sys_group (p_group_type SYS_GROUPS.GROUP_TYPE%TYPE,
                                    p_group_name SYS_GROUPS.GROUP_NAME%TYPE,
                                    p_description SYS_GROUPS.DESCRIPTION%TYPE,
                                    p_create_user SYS_GROUPS.CREATE_USER%TYPE,
                                    p_update_user SYS_GROUPS.UPDATE_USER%TYPE,
                                    p_create_date SYS_GROUPS.CREATE_DATE%TYPE,
                                    p_update_date SYS_GROUPS.UPDATE_DATE%TYPE,
                                    p_status SYS_GROUPS.STATUS%TYPE,
                                    p_par1 SYS_GROUPS.PAR1%TYPE,
                                    p_par2 SYS_GROUPS.PAR2%TYPE,
                                    p_par3 SYS_GROUPS.PAR3%TYPE,
                                    p_par4 SYS_GROUPS.PAR4%TYPE,
                                    p_par5 SYS_GROUPS.PAR5%TYPE,
                                    p_user                   IN     VARCHAR2,
                                    p_client_ip              IN     VARCHAR2,
                                    p_user_agent             IN     VARCHAR2,
                                    p_out                       OUT types.ref_cursor);
    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: Th�m m?i th�ng tin chi ti?t nh�m ng??i d�ng
    Parameter:
                p_group_type: 
                p_group_name: 
                p_description: 
                p_create_user: 
                p_update_user: 
                p_create_date: 
                p_update_date: 
                p_status: 
                p_par1: 
                p_par2: 
                p_par3: 
                p_par4: 
                p_par5: 
                p_user:
                p_client_ip:
                p_user_agent:


    */
    PROCEDURE pr_create_sys_group (p_group_type SYS_GROUPS.GROUP_TYPE%TYPE,
                                    p_group_name SYS_GROUPS.GROUP_NAME%TYPE,
                                    p_description SYS_GROUPS.DESCRIPTION%TYPE,
                                    p_create_user SYS_GROUPS.CREATE_USER%TYPE,
                                    p_update_user SYS_GROUPS.UPDATE_USER%TYPE,
                                    p_create_date SYS_GROUPS.CREATE_DATE%TYPE,
                                    p_update_date SYS_GROUPS.UPDATE_DATE%TYPE,
                                    p_status SYS_GROUPS.STATUS%TYPE,
                                    p_par1 SYS_GROUPS.PAR1%TYPE,
                                    p_par2 SYS_GROUPS.PAR2%TYPE,
                                    p_par3 SYS_GROUPS.PAR3%TYPE,
                                    p_par4 SYS_GROUPS.PAR4%TYPE,
                                    p_par5 SYS_GROUPS.PAR5%TYPE,
                                    p_user                   IN     VARCHAR2,
                                    p_client_ip              IN     VARCHAR2,
                                    p_user_agent             IN     VARCHAR2,
                                    p_out                       OUT types.ref_cursor);


    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: check trung ma nguoi dung, ten nguoi dung
    Parameter:
               p_group_type:
               p_group_name:
               p_user:
               p_client_ip:
               p_user_agent:


    */
    PROCEDURE pr_check_sys_group (p_group_type SYS_GROUPS.GROUP_TYPE%TYPE,
                                    p_group_name SYS_GROUPS.GROUP_NAME%TYPE,
                                    p_user                   IN     VARCHAR2,
                                    p_client_ip              IN     VARCHAR2,
                                    p_user_agent             IN     VARCHAR2,
                                    p_out                       OUT types.ref_cursor);

    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y menu theo nh�m ng??i d�ng
    Parameter:
               p_group_name:
               p_user:
               p_client_ip:
               p_user_agent:


    */
    PROCEDURE pr_list_resources_by_sys_group (p_group_name SYS_GROUPS.GROUP_NAME%TYPE,
                                                p_status   SYS_RESOURCES.Status%TYPE,
                                                p_user         IN     VARCHAR2,
                                                p_client_ip    IN     VARCHAR2,
                                                p_user_agent   IN     VARCHAR2,
                                                p_out             OUT types.ref_cursor);
                                                
    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y action c?a menu
    Parameter:
               p_group_name:
               p_user:
               p_client_ip:
               p_user_agent:


    */                                     
    PROCEDURE pr_list_sys_resources_action (p_application_id SYS_RESOURCE_ACTIONS.APPLICATION_ID%TYPE,
                                            p_resource_id   SYS_RESOURCE_ACTIONS.RESOURCE_ID%TYPE,
                                            p_status SYS_ACTIONS.STATUS%TYPE,
                                            p_user         IN     VARCHAR2,
                                            p_client_ip    IN     VARCHAR2,
                                            p_user_agent   IN     VARCHAR2,
                                            p_out             OUT types.ref_cursor);
                                            
                                            
                                            
    PROCEDURE pr_list_sys_resources(p_application_id SYS_RESOURCES.APPLICATION_ID%TYPE,
                                            p_status SYS_RESOURCES.STATUS%TYPE,
                                            p_user         IN     VARCHAR2,
                                            p_client_ip    IN     VARCHAR2,
                                            p_user_agent   IN     VARCHAR2,
                                            p_out             OUT types.ref_cursor);
END;

/
--------------------------------------------------------
--  DDL for Package PKG_SYS_TASK_LIST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PKG_SYS_TASK_LIST" 
  -- Author  : DONB
  -- Created : 27/06/2019 4:01:04 PM
  -- Purpose :
AS
    /*
         Creater: DONB
         Created date: 27/06/2019 4:01:04 PM
         Description: Th�m m?i giao d?ch
         Parameter:
                  p_id:
                  p_task_id:
                  p_task_type:
                  p_task_date:
                  p_cif_no:
                  p_cust_name:
                  p_tax_id:
                  p_workflow_status:
                  p_maker:
                  p_approver:
                  p_approved_date:
                  p_branch_code:
                  p_external_data:
                  p_action:
                  p_text_1:
                  p_text_2:
                  p_text_3:
                  p_text_4:
                  p_text_5:
                  p_text_6:
                  p_text_7:
                  p_text_8:
                  p_text_9:
                  p_text_10:
                  p_date_1:
                  p_date_2:
                  p_date_3:
                  p_date_4:
                  p_date_5:
                  p_date_6:
                  p_date_7:
                  p_date_8:
                  p_date_9:
                  p_date_10:
                  p_number_1:
                  p_number_2:
                  p_number_3:
                  p_number_4:
                  p_number_5:
                  p_number_6:
                  p_number_7:
                  p_number_8:
                  p_number_9:
                  p_number_10:
                  p_user_name:
                  p_maker_branch_code:
                  p_status:
                  p_created_date:
                  p_approver_branch_code:
                  p_process_instance_id:
                  p_task_id:

       */
    PROCEDURE PR_CREATE_SYS_TASK_LIST (p_task_id                       SYS_TASK_LIST.TASK_ID%TYPE,
                                           p_task_type                     SYS_TASK_LIST.TASK_TYPE%TYPE,
                                           p_task_date                     SYS_TASK_LIST.TASK_DATE%TYPE,
                                           p_cif_no                        SYS_TASK_LIST.cif_no%TYPE,
                                           p_cust_name                     SYS_TASK_LIST.cust_name%TYPE,
                                           p_tax_id                        SYS_TASK_LIST.tax_id%TYPE,
                                           p_workflow_status               SYS_TASK_LIST.workflow_status%TYPE,
                                           p_maker                         SYS_TASK_LIST.maker%TYPE,
                                           p_approver                      SYS_TASK_LIST.approver%TYPE,
                                           p_approved_date                 SYS_TASK_LIST.approved_date%TYPE,
                                           p_branch_code                   SYS_TASK_LIST.branch_code%TYPE,
                                           p_external_data                 SYS_TASK_LIST.external_data%TYPE,
                                           p_action                        SYS_TASK_LIST.action%TYPE,
                                           p_text_1                        SYS_TASK_LIST.text_1%TYPE,
                                           p_text_2                        SYS_TASK_LIST.text_2%TYPE,
                                           p_text_3                        SYS_TASK_LIST.text_3%TYPE,
                                           p_text_4                        SYS_TASK_LIST.text_4%TYPE,
                                           p_text_5                        SYS_TASK_LIST.text_5%TYPE,
                                           p_text_6                        SYS_TASK_LIST.text_6%TYPE,
                                           p_text_7                        SYS_TASK_LIST.text_7%TYPE,
                                           p_text_8                        SYS_TASK_LIST.text_8%TYPE,
                                           p_text_9                        SYS_TASK_LIST.text_9%TYPE,
                                           p_text_10                       SYS_TASK_LIST.text_10%TYPE,
                                           p_date_1                        SYS_TASK_LIST.date_1%TYPE,
                                           p_date_2                        SYS_TASK_LIST.date_2%TYPE,
                                           p_date_3                        SYS_TASK_LIST.date_3%TYPE,
                                           p_date_4                        SYS_TASK_LIST.date_4%TYPE,
                                           p_date_5                        SYS_TASK_LIST.date_5%TYPE,
                                           p_date_6                        SYS_TASK_LIST.date_6%TYPE,
                                           p_date_7                        SYS_TASK_LIST.date_7%TYPE,
                                           p_date_8                        SYS_TASK_LIST.date_8%TYPE,
                                           p_date_9                        SYS_TASK_LIST.date_9%TYPE,
                                           p_date_10                       SYS_TASK_LIST.date_10%TYPE,
                                           p_number_1                      SYS_TASK_LIST.number_1%TYPE,
                                           p_number_2                      SYS_TASK_LIST.number_2%TYPE,
                                           p_number_3                      SYS_TASK_LIST.number_3%TYPE,
                                           p_number_4                      SYS_TASK_LIST.number_4%TYPE,
                                           p_number_5                      SYS_TASK_LIST.number_5%TYPE,
                                           p_number_6                      SYS_TASK_LIST.number_6%TYPE,
                                           p_number_7                      SYS_TASK_LIST.number_7%TYPE,
                                           p_number_8                      SYS_TASK_LIST.number_8%TYPE,
                                           p_number_9                      SYS_TASK_LIST.number_9%TYPE,
                                           p_number_10                     SYS_TASK_LIST.number_10%TYPE,
                                           p_user_name                     SYS_TASK_LIST.user_name%TYPE,
                                           p_maker_branch_code             SYS_TASK_LIST.maker_branch_code%TYPE,
                                           p_status                        SYS_TASK_LIST.status%TYPE,
                                           p_created_date                  SYS_TASK_LIST.created_date%TYPE,
                                           p_approver_branch_code          SYS_TASK_LIST.approver_branch_code%TYPE,
                                           p_process_instance_id           SYS_TASK_LIST.process_instance_id%TYPE,
                                           p_user                   IN     VARCHAR2,
                                           p_client_ip              IN     VARCHAR2,
                                           p_user_agent             IN     VARCHAR2,
                                           p_out                       OUT types.ref_cursor);
 /*
         Creater: DONB
         Created date: 27/06/2019 4:01:04 PM
         Description: update giao d?ch
         Parameter:
                  p_id:
                  p_task_id:
                  p_task_type:
                  p_task_date:
                  p_cif_no:
                  p_cust_name:
                  p_tax_id:
                  p_workflow_status:
                  p_maker:
                  p_approver:
                  p_approved_date:
                  p_branch_code:
                  p_external_data:
                  p_action:
                  p_text_1:
                  p_text_2:
                  p_text_3:
                  p_text_4:
                  p_text_5:
                  p_text_6:
                  p_text_7:
                  p_text_8:
                  p_text_9:
                  p_text_10:
                  p_date_1:
                  p_date_2:
                  p_date_3:
                  p_date_4:
                  p_date_5:
                  p_date_6:
                  p_date_7:
                  p_date_8:
                  p_date_9:
                  p_date_10:
                  p_number_1:
                  p_number_2:
                  p_number_3:
                  p_number_4:
                  p_number_5:
                  p_number_6:
                  p_number_7:
                  p_number_8:
                  p_number_9:
                  p_number_10:
                  p_user_name:
                  p_maker_branch_code:
                  p_status:
                  p_created_date:
                  p_approver_branch_code:
                  p_process_instance_id:
                  p_task_id:

       */

    PROCEDURE PR_UPDATE_SYS_TASK_LIST (p_id                            SYS_TASK_LIST.id%TYPE,
                                           p_task_id                       SYS_TASK_LIST.TASK_ID%TYPE,
                                           p_task_type                     SYS_TASK_LIST.TASK_TYPE%TYPE,
                                           p_task_date                     SYS_TASK_LIST.TASK_DATE%TYPE,
                                           p_cif_no                        SYS_TASK_LIST.cif_no%TYPE,
                                           p_cust_name                     SYS_TASK_LIST.cust_name%TYPE,
                                           p_tax_id                        SYS_TASK_LIST.tax_id%TYPE,
                                           p_workflow_status               SYS_TASK_LIST.workflow_status%TYPE,
                                           p_maker                         SYS_TASK_LIST.maker%TYPE,
                                           p_approver                      SYS_TASK_LIST.approver%TYPE,
                                           p_approved_date                 SYS_TASK_LIST.approved_date%TYPE,
                                           p_branch_code                   SYS_TASK_LIST.branch_code%TYPE,
                                           p_external_data                 SYS_TASK_LIST.external_data%TYPE,
                                           p_action                        SYS_TASK_LIST.action%TYPE,
                                           p_text_1                        SYS_TASK_LIST.text_1%TYPE,
                                           p_text_2                        SYS_TASK_LIST.text_2%TYPE,
                                           p_text_3                        SYS_TASK_LIST.text_3%TYPE,
                                           p_text_4                        SYS_TASK_LIST.text_4%TYPE,
                                           p_text_5                        SYS_TASK_LIST.text_5%TYPE,
                                           p_text_6                        SYS_TASK_LIST.text_6%TYPE,
                                           p_text_7                        SYS_TASK_LIST.text_7%TYPE,
                                           p_text_8                        SYS_TASK_LIST.text_8%TYPE,
                                           p_text_9                        SYS_TASK_LIST.text_9%TYPE,
                                           p_text_10                       SYS_TASK_LIST.text_10%TYPE,
                                           p_date_1                        SYS_TASK_LIST.date_1%TYPE,
                                           p_date_2                        SYS_TASK_LIST.date_2%TYPE,
                                           p_date_3                        SYS_TASK_LIST.date_3%TYPE,
                                           p_date_4                        SYS_TASK_LIST.date_4%TYPE,
                                           p_date_5                        SYS_TASK_LIST.date_5%TYPE,
                                           p_date_6                        SYS_TASK_LIST.date_6%TYPE,
                                           p_date_7                        SYS_TASK_LIST.date_7%TYPE,
                                           p_date_8                        SYS_TASK_LIST.date_8%TYPE,
                                           p_date_9                        SYS_TASK_LIST.date_9%TYPE,
                                           p_date_10                       SYS_TASK_LIST.date_10%TYPE,
                                           p_number_1                      SYS_TASK_LIST.number_1%TYPE,
                                           p_number_2                      SYS_TASK_LIST.number_2%TYPE,
                                           p_number_3                      SYS_TASK_LIST.number_3%TYPE,
                                           p_number_4                      SYS_TASK_LIST.number_4%TYPE,
                                           p_number_5                      SYS_TASK_LIST.number_5%TYPE,
                                           p_number_6                      SYS_TASK_LIST.number_6%TYPE,
                                           p_number_7                      SYS_TASK_LIST.number_7%TYPE,
                                           p_number_8                      SYS_TASK_LIST.number_8%TYPE,
                                           p_number_9                      SYS_TASK_LIST.number_9%TYPE,
                                           p_number_10                     SYS_TASK_LIST.number_10%TYPE,
                                           p_user_name                     SYS_TASK_LIST.user_name%TYPE,
                                           p_maker_branch_code             SYS_TASK_LIST.maker_branch_code%TYPE,
                                           p_status                        SYS_TASK_LIST.status%TYPE,
                                           p_created_date                  SYS_TASK_LIST.created_date%TYPE,
                                           p_approver_branch_code          SYS_TASK_LIST.approver_branch_code%TYPE,
                                           p_process_instance_id           SYS_TASK_LIST.process_instance_id%TYPE,
                                           p_user                   IN     VARCHAR2,
                                           p_client_ip              IN     VARCHAR2,
                                           p_user_agent             IN     VARCHAR2,
                                           p_out                       OUT types.ref_cursor);


    /*
        Creater: DONB
        Created date: 27/06/2019 4:01:04 PM
        Description: L?y danh s�ch giao d?ch
        Parameter:
               p_id:
               p_task_id:
               p_task_type:
               p_task_date:
               p_cif_no:
               p_cust_name:
               p_tax_id:
               p_workflow_status:
               p_maker:
               p_approver:
               p_approved_date:
               p_branch_code:
               p_external_data:
               p_action:
               p_text_1:
               p_text_2:
               p_text_3:
               p_text_4:
               p_text_5:
               p_text_6:
               p_text_7:
               p_text_8:
               p_text_9:
               p_text_10:
               p_date_1:
               p_date_2:
               p_date_3:
               p_date_4:
               p_date_5:
               p_date_6:
               p_date_7:
               p_date_8:
               p_date_9:
               p_date_10:
               p_number_1:
               p_number_2:
               p_number_3:
               p_number_4:
               p_number_5:
               p_number_6:
               p_number_7:
               p_number_8:
               p_number_9:
               p_number_10:
               p_user_name:
               p_maker_branch_code:
               p_status:
               p_created_date:
               p_approver_branch_code:
               p_process_instance_id:
               p_task_id:

    */
    PROCEDURE PR_GET_LIST_SYS_TASK_LIST (p_id                            SYS_TASK_LIST.id%TYPE,
                                             p_task_id                       SYS_TASK_LIST.TASK_ID%TYPE,
                                             p_task_type                     SYS_TASK_LIST.TASK_TYPE%TYPE,
                                             p_task_date                     SYS_TASK_LIST.TASK_DATE%TYPE,
                                             p_cif_no                        SYS_TASK_LIST.cif_no%TYPE,
                                             p_cust_name                     SYS_TASK_LIST.cust_name%TYPE,
                                             p_tax_id                        SYS_TASK_LIST.tax_id%TYPE,
                                             p_workflow_status               SYS_TASK_LIST.workflow_status%TYPE,
                                             p_maker                         SYS_TASK_LIST.maker%TYPE,
                                             p_approver                      SYS_TASK_LIST.approver%TYPE,
                                             p_approved_date                 SYS_TASK_LIST.approved_date%TYPE,
                                             p_branch_code                   SYS_TASK_LIST.branch_code%TYPE,
                                             p_external_data                 SYS_TASK_LIST.external_data%TYPE,
                                             p_action                        SYS_TASK_LIST.action%TYPE,
                                             p_text_1                        SYS_TASK_LIST.text_1%TYPE,
                                             p_text_2                        SYS_TASK_LIST.text_2%TYPE,
                                             p_text_3                        SYS_TASK_LIST.text_3%TYPE,
                                             p_text_4                        SYS_TASK_LIST.text_4%TYPE,
                                             p_text_5                        SYS_TASK_LIST.text_5%TYPE,
                                             p_text_6                        SYS_TASK_LIST.text_6%TYPE,
                                             p_text_7                        SYS_TASK_LIST.text_7%TYPE,
                                             p_text_8                        SYS_TASK_LIST.text_8%TYPE,
                                             p_text_9                        SYS_TASK_LIST.text_9%TYPE,
                                             p_text_10                       SYS_TASK_LIST.text_10%TYPE,
                                             p_date_1                        SYS_TASK_LIST.date_1%TYPE,
                                             p_date_2                        SYS_TASK_LIST.date_2%TYPE,
                                             p_date_3                        SYS_TASK_LIST.date_3%TYPE,
                                             p_date_4                        SYS_TASK_LIST.date_4%TYPE,
                                             p_date_5                        SYS_TASK_LIST.date_5%TYPE,
                                             p_date_6                        SYS_TASK_LIST.date_6%TYPE,
                                             p_date_7                        SYS_TASK_LIST.date_7%TYPE,
                                             p_date_8                        SYS_TASK_LIST.date_8%TYPE,
                                             p_date_9                        SYS_TASK_LIST.date_9%TYPE,
                                             p_date_10                       SYS_TASK_LIST.date_10%TYPE,
                                             p_number_1                      SYS_TASK_LIST.number_1%TYPE,
                                             p_number_2                      SYS_TASK_LIST.number_2%TYPE,
                                             p_number_3                      SYS_TASK_LIST.number_3%TYPE,
                                             p_number_4                      SYS_TASK_LIST.number_4%TYPE,
                                             p_number_5                      SYS_TASK_LIST.number_5%TYPE,
                                             p_number_6                      SYS_TASK_LIST.number_6%TYPE,
                                             p_number_7                      SYS_TASK_LIST.number_7%TYPE,
                                             p_number_8                      SYS_TASK_LIST.number_8%TYPE,
                                             p_number_9                      SYS_TASK_LIST.number_9%TYPE,
                                             p_number_10                     SYS_TASK_LIST.number_10%TYPE,
                                             p_user_name                     SYS_TASK_LIST.user_name%TYPE,
                                             p_maker_branch_code             SYS_TASK_LIST.maker_branch_code%TYPE,
                                             p_status                        SYS_TASK_LIST.status%TYPE,
                                             p_created_date                  SYS_TASK_LIST.created_date%TYPE,
                                             p_approver_branch_code          SYS_TASK_LIST.approver_branch_code%TYPE,
                                             p_process_instance_id           SYS_TASK_LIST.process_instance_id%TYPE,
                                             p_user                   IN     VARCHAR2,
                                             p_client_ip              IN     VARCHAR2,
                                             p_user_agent             IN     VARCHAR2,
                                             p_out                       OUT types.ref_cursor);

    /*
          Creater: DONB
          Created date: 27/06/2019 4:01:04 PM
          Description: L?y th�ng tin chi ti?t giao d?ch c?p nh?t BO theo TRAN_ID ?? hi?n th?
          Parameter:
                   p_task_id:

        */
    PROCEDURE PR_GET_SYS_TASK_LIST_INFO (p_task_id             SYS_TASK_LIST.TASK_ID%TYPE,
                                             p_user         IN     VARCHAR2,
                                             p_client_ip    IN     VARCHAR2,
                                             p_user_agent   IN     VARCHAR2,
                                             p_out             OUT types.ref_cursor);

    /*
          Creater: DONB
          Created date: 27/06/2019 4:01:04 PM
          Description: C?p nh?t danh s�ch c�c user/email ???c ??ng k�
          Parameter:
                   p_task_id: Giao dich thuc hien
                   p_user_email_reg: User/Email can kiem tra

        */
    PROCEDURE PR_GET_CREATE_USER_REGISTERED (p_task_id             SYS_TASK_LIST.TASK_ID%TYPE,
                                             p_user_email_reg         IN     VARCHAR2,
                                             p_user         IN     VARCHAR2,
                                             p_client_ip    IN     VARCHAR2,
                                             p_user_agent   IN     VARCHAR2);

        /*
          Creater: DONB
          Created date: 27/06/2019 4:01:04 PM
          Description: Kiem tra xem user/email nay da tung duoc dang ky chua
          Parameter:
                   p_user_email_reg: User/Email can kiem tra

        */
    PROCEDURE PR_GET_CHECK_USER_REGISTERED (p_user_email_reg         IN     VARCHAR2,
                                             p_user         IN     VARCHAR2,
                                             p_client_ip    IN     VARCHAR2,
                                             p_user_agent   IN     VARCHAR2,
                                             p_out             OUT types.ref_cursor);
       /*
          Creater: DONB
          Created date: 27/06/2019 4:01:04 PM
          Description: Xoa user/email
          Parameter:
                   p_user_email_reg: User/Email can kiem tra

        */
    PROCEDURE PR_DELETE_USER_REGISTERED (p_user_email_reg         IN     VARCHAR2,
                                        p_user         IN     VARCHAR2,
                                        p_client_ip    IN     VARCHAR2,
                                        p_user_agent   IN     VARCHAR2);
                                                                    
    /*
           Creater: DONB
           Created date: 27/06/2019 4:01:04 PM
           Description: Th?c hi?n upadte cac buoc duyet cua task list
           Parameter:
                    p_id:
                    p_TASK_ID:
                    p_workflow_status:
                    p_TASK_DATE:
                    p_comment:
                    p_maker:
           */
    PROCEDURE PR_CREATE_SYS_TASK_LIST_WF (p_task_id                  SYS_TASK_LIST_WF.TASK_ID%TYPE,
                                          p_workflow_status          SYS_TASK_LIST_WF.workflow_status%TYPE,
                                          p_task_wf_date             SYS_TASK_LIST_WF.TASK_WF_DATE%TYPE,
                                          p_comment                  SYS_TASK_LIST_WF.comment%TYPE,
                                          p_maker                    SYS_TASK_LIST_WF.maker%TYPE,
                                          p_user              IN     VARCHAR2,
                                          p_client_ip         IN     VARCHAR2,
                                          p_user_agent        IN     VARCHAR2,
                                          p_out                  OUT types.ref_cursor);
    /*
           Creater: DONB
           Created date: 27/06/2019 4:01:04 PM
           Description: Lay qua trinh duyet cua task list
           Parameter:
                    p_id:
                    p_TASK_ID:
                    p_workflow_status:
                    p_TASK_DATE:
                    p_comment:
                    p_maker:
           */
    PROCEDURE PR_GET_SYS_TASK_LIST_WF (p_task_id    SYS_TASK_LIST_WF.TASK_ID%TYPE,
                                      p_user              IN     VARCHAR2,
                                      p_client_ip         IN     VARCHAR2,
                                      p_user_agent        IN     VARCHAR2,
                                      p_out                  OUT types.ref_cursor);
END;

/
--------------------------------------------------------
--  DDL for Package PKG_SYS_USER
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PKG_SYS_USER" 
  -- Author  : DONB
  -- Created : 17/06/2019 4:01:04 PM
  -- Purpose :
IS
    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: Th�m m?i th�ng tin ng??i d�ng n?i b? 
    */
    PROCEDURE pr_create_user (p_full_name SYS_USER.FULL_NAME%TYPE,
                                p_user_name SYS_USER.USER_NAME%TYPE,
                                --p_cic_code SYS_USER.CIC_CODE%TYPE,
                                --p_contract_no SYS_USER.CONTRACT_NO%TYPE,
                                --p_fee SYS_USER.FEE%TYPE,
                                p_type SYS_USER.TYPE%TYPE,
                                p_status SYS_USER.STATUS%TYPE,
                                p_description SYS_USER.DESCRIPTION%TYPE,
                                p_address SYS_USER.ADDRESS%TYPE,
                                p_phone SYS_USER.PHONE%TYPE,
                                p_email_backup SYS_USER.EMAIL_BACKUP%TYPE,
                                p_job_title SYS_USER.JOB_TITLE%TYPE,
                                p_cic_department SYS_USER.CIC_DEPARTMENT%TYPE,
                                p_open_date SYS_USER.OPEN_DATE%TYPE,
                                p_active_date SYS_USER.ACTIVE_DATE%TYPE,
                                p_expire_date SYS_USER.EXPIRE_DATE%TYPE,
                                p_reason_expired SYS_USER.REASON_EXPIRED%TYPE,
                                --p_contract_date SYS_USER.CONTRACT_DATE%TYPE,
                                p_end_date_contract SYS_USER.END_DATE_CONTRACT%TYPE,
                                --p_province SYS_USER.PROVINCE%TYPE,
                                p_name_of_contract SYS_USER.NAME_OF_CONTRACT%TYPE,
                                p_address_contract SYS_USER.ADDRESS_CONTRACT%TYPE,
                                --p_group_sbv SYS_USER.GROUP_SBV%TYPE,
                                --p_sbv_code SYS_USER.SBV_CODE%TYPE,
                                --p_cic_work_time_from SYS_USER.CIC_WORK_TIME_FROM%TYPE,
                               -- p_cic_work_time_to SYS_USER.CIC_WORK_TIME_TO%TYPE,
                               -- p_ci_user_type SYS_USER.CI_USER_TYPE%TYPE,
                                p_member_code SYS_USER.MEMBER_CODE%TYPE,
                               -- p_member_name SYS_USER.MEMBER_NAME%TYPE,
                              --  p_member_code_ci SYS_USER.MEMBER_CODE_CI%TYPE,
                              --  p_type_contract SYS_USER.TYPE_CONTRACT%TYPE,
                                p_create_date SYS_USER.CREATE_DATE%TYPE,
                                p_create_user SYS_USER.CREATE_USER%TYPE,
                                p_last_update_user SYS_USER.LAST_UPDATE_USER%TYPE,
                                p_last_update_date SYS_USER.LAST_UPDATE_DATE%TYPE,
                                p_group_name SYS_USER.GROUP_NAME%TYPE,
                                p_eff_date_contract SYS_USER.EFF_DATE_CONTRACT%TYPE,
                              --  p_stt_contract SYS_USER.STT_CONTRACT%TYPE,
                              --  p_websites SYS_USER.WEBSITES%TYPE,
                                p_issyn SYS_USER.ISSYN%TYPE,
                                p_email SYS_USER.EMAIL%TYPE,
                                p_language SYS_USER.LANGUAGE%TYPE,
                                p_user_type SYS_USER.USER_TYPE%TYPE,
                             --   p_notification SYS_USER.NOTIFICATION%TYPE,
                             --   p_exp_dt_notification SYS_USER.EXP_DT_NOTIFICATION%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_member_view_report SYS_USER.MEMBER_VIEW_REPORT%TYPE,
                                p_out                             OUT types.ref_cursor);


    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: C?p nh?t th�ng tin ng??i d�ng n?i b?
 
*/
    PROCEDURE pr_update_user (p_full_name SYS_USER.FULL_NAME%TYPE,
                                p_user_name SYS_USER.USER_NAME%TYPE,
                                --p_cic_code SYS_USER.CIC_CODE%TYPE,
                                --p_contract_no SYS_USER.CONTRACT_NO%TYPE,
                                --p_fee SYS_USER.FEE%TYPE,
                                p_type SYS_USER.TYPE%TYPE,
                                p_status SYS_USER.STATUS%TYPE,
                                p_description SYS_USER.DESCRIPTION%TYPE,
                                p_address SYS_USER.ADDRESS%TYPE,
                                p_phone SYS_USER.PHONE%TYPE,
                                p_email_backup SYS_USER.EMAIL_BACKUP%TYPE,
                                p_job_title SYS_USER.JOB_TITLE%TYPE,
                                p_cic_department SYS_USER.CIC_DEPARTMENT%TYPE,
                                p_open_date SYS_USER.OPEN_DATE%TYPE,
                                p_active_date SYS_USER.ACTIVE_DATE%TYPE,
                                p_expire_date SYS_USER.EXPIRE_DATE%TYPE,
                                p_reason_expired SYS_USER.REASON_EXPIRED%TYPE,
                                --p_contract_date SYS_USER.CONTRACT_DATE%TYPE,
                                p_end_date_contract SYS_USER.END_DATE_CONTRACT%TYPE,
                                --p_province SYS_USER.PROVINCE%TYPE,
                                p_name_of_contract SYS_USER.NAME_OF_CONTRACT%TYPE,
                                p_address_contract SYS_USER.ADDRESS_CONTRACT%TYPE,
                                --p_group_sbv SYS_USER.GROUP_SBV%TYPE,
                                --p_sbv_code SYS_USER.SBV_CODE%TYPE,
                                --p_cic_work_time_from SYS_USER.CIC_WORK_TIME_FROM%TYPE,
                               -- p_cic_work_time_to SYS_USER.CIC_WORK_TIME_TO%TYPE,
                               -- p_ci_user_type SYS_USER.CI_USER_TYPE%TYPE,
                                p_member_code SYS_USER.MEMBER_CODE%TYPE,
                               -- p_member_name SYS_USER.MEMBER_NAME%TYPE,
                              --  p_member_code_ci SYS_USER.MEMBER_CODE_CI%TYPE,
                              --  p_type_contract SYS_USER.TYPE_CONTRACT%TYPE,
                                p_create_date SYS_USER.CREATE_DATE%TYPE,
                                p_create_user SYS_USER.CREATE_USER%TYPE,
                                p_last_update_user SYS_USER.LAST_UPDATE_USER%TYPE,
                                p_last_update_date SYS_USER.LAST_UPDATE_DATE%TYPE,
                                p_group_name SYS_USER.GROUP_NAME%TYPE,
                                p_eff_date_contract SYS_USER.EFF_DATE_CONTRACT%TYPE,
                              --  p_stt_contract SYS_USER.STT_CONTRACT%TYPE,
                              --  p_websites SYS_USER.WEBSITES%TYPE,
                                p_issyn SYS_USER.ISSYN%TYPE,
                                p_email SYS_USER.EMAIL%TYPE,
                                p_language SYS_USER.LANGUAGE%TYPE,
                                p_user_type SYS_USER.USER_TYPE%TYPE,
                             --   p_notification SYS_USER.NOTIFICATION%TYPE,
                             --   p_exp_dt_notification SYS_USER.EXP_DT_NOTIFICATION%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_member_view_report SYS_USER.MEMBER_VIEW_REPORT%TYPE,
                                p_out                             OUT types.ref_cursor);


 /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y th�ng tin chi ti?t ng??i d�ng n?i b? SHB
    Parameter:
           p_user_name:
*/
    PROCEDURE pr_user_info   (p_user_name SYS_USER.USER_NAME%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_out                             OUT types.ref_cursor);



/*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y danh s�ch ng??i d�ng n?i b? SHB
    Parameter:
           p_user_name:
*/
    PROCEDURE pr_list_user   (p_user_name SYS_USER.USER_NAME%TYPE,
                                p_full_name SYS_USER.FULL_NAME%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_out                             OUT types.ref_cursor);

    PROCEDURE pr_list_user_his   (p_user_name SYS_USER.USER_NAME%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_out                             OUT types.ref_cursor);
/*
    Creater: DONB
    Created date: 17/06/2019
    Description: M? kh�a t�i kho?n
    Parameter:
           p_user_name:
*/
    PROCEDURE pr_un_lock_user (p_user_name SYS_USER.USER_NAME%TYPE,
                                p_client_ip    IN     VARCHAR2,
                                p_user_agent   IN     VARCHAR2);
/*
    Creater: CuongNH2
    Created date: 20210520
    Description: L?y danh s�ch ng??i d�ng c?n ??ng b? liferay
    Parameter:
*/
    PROCEDURE pr_list_user_syn   (p_status                   IN     VARCHAR2,
                                  p_out                             OUT types.ref_cursor);

END;

/
--------------------------------------------------------
--  DDL for Package PKG_SYSTEM_LOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PKG_SYSTEM_LOG" is

  -- Author  : CuongNH
  -- Created : 1/9/2018 4:47:26 PM
  -- Purpose : Luu log he thong

  /*
  Creater: CuongNH2
  Created date: 9/1/2018
  Description: log INFO cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_Parameter: chi tiet cac parameter
  */
  Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob);

  /*
  Creater: CuongNH2
  Created date: 18/1/2018
  Description: log DEBUG cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_Parameter: chi tiet cac parameter
  */
  Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2);


  /*
  Creater: CuongNH2
  Created date: 18/1/2018
  Description: ghi nhan log EXCEPTION
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               p_ErrorMessage: chi tiet noi dung loi
  */
  Procedure PR_LOG_EXCEPTION(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_ErrorNumber varchar2, p_ErrorMessage varchar2);

  /*
  Creater: CuongNH2
  Created date: 22/1/2018
  Description: ghi nhan log EXCEPTION khong throw
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               p_ErrorMessage: chi tiet noi dung loi
  */
Procedure PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME varchar2,
                           P_STEP_NAME varchar2,
                           p_ErrorNumber varchar2,
                           p_ErrorMessage clob,
                           P_TASK_TYPE varchar2 );

  /*
  Creater: SonTA2
  Created date: 30/1/2018
  Description: log INFO cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               P_TASK_TYPE: kieu task
               P_IP_CLIENT: client ip
               P_MACHINE: ten machine
  */
  Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob, P_TASK_TYPE varchar2);

  /*
  Creater: CuongNH2
  Created date: 18/1/2018
  Description: log DEBUG cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_Parameter: chi tiet cac parameter
               P_TASK_TYPE: kieu task
               P_IP_CLIENT: client ip
               P_MACHINE: ten machine
  */
  Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2, P_TASK_TYPE varchar2);

  Procedure PR_LOG_ACTIVITY(P_APPLICATION_ID VARCHAR2,
                            P_RESOURCE_URL VARCHAR2,
                            P_ACCESS_USER VARCHAR2,
                            P_ACCESS_STATUS VARCHAR2,
                            P_LOG_MESSAGE CLOB,
                            P_RESOURCE_TYPE VARCHAR2,
                            P_RPT_CODE VARCHAR2,
                            P_RESOURCE_ACTION VARCHAR2,
                            P_CLIENT_IP VARCHAR2,
                            P_USER_AGENT VARCHAR2,
                            p_out OUT types.ref_cursor);

end PKG_SYSTEM_LOG;

/
--------------------------------------------------------
--  DDL for Package PKG_UTILITY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_SYS_NCB"."PKG_UTILITY" is
/*
Creater: CuongNH2
Create date: 19/4/2018
Description: Xoa dau va chuyen thanh chu thuong
*/
FUNCTION RemoveSignVietnamess(P_STR IN VARCHAR2) RETURN clob;

/*
Creater: CuongNH2
Create date: 11/7/2018
Description: Format number with comma
*/
FUNCTION FORMAT_NUMBER(P_STR IN VARCHAR2) RETURN VARCHAR2;

end PKG_UTILITY;

/
--------------------------------------------------------
--  DDL for Package Body PCK_CLIENT_TOKEN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PCK_CLIENT_TOKEN" AS
  PROCEDURE PR_CREATE_CLIENT_TOKEN(P_ID VARCHAR2,
                            P_APPLICATION_ID	VARCHAR2,
                            P_USER_NAME	VARCHAR2,
                            P_CLIENT_TOKEN	VARCHAR2,
                            P_STATUS	VARCHAR2,
                            p_out OUT types.ref_cursor)
AS    
V_ID NUMBER;
V_CLIENT_TOKEN_EXPIRI_TIME NUMBER;

BEGIN


SELECT COUNT(9) INTO V_ID
FROM SYS_USER A
WHERE USER_NAME=P_USER_NAME AND A.STATUS='1';
IF V_ID=0 THEN
    raise_application_error( -20000, '012' );
    RETURN;
END IF;


SELECT SEQ_SYS_CLIENT_TOKEN.NEXTVAL INTO V_ID FROM DUAL;
SELECT MAX(TO_NUMBER(PAR1)) INTO V_CLIENT_TOKEN_EXPIRI_TIME
FROM SYS_REFCODE WHERE REF_CODE='CLIENT_TOKEN_EXPIRI_TIME';

--Cap nhat invalid nh?ng token c�n hi?u l?c c?a user

UPDATE SYS_CLIENT_TOKEN
SET STATUS='INVALID', LAST_UPDATE_DATE=SYSDATE, NOTE='INVALID BY '||P_CLIENT_TOKEN
WHERE USER_NAME=P_USER_NAME
AND STATUS='VALID';

INSERT INTO SYS_CLIENT_TOKEN (ID, APPLICATION_ID, USER_NAME, CLIENT_TOKEN, STATUS, CREATED_DATE, EXPIRI_DATE)
VALUES (V_ID, P_APPLICATION_ID, P_USER_NAME, P_CLIENT_TOKEN, 'VALID', SYSDATE, SYSDATE + V_CLIENT_TOKEN_EXPIRI_TIME/24/60);


OPEN p_out FOR
SELECT A.*, B.FULL_NAME, B.EMAIL, B.PHONE, B.MEMBER_CODE, B.MEMBER_VIEW_REPORT, B.GROUP_NAME
FROM SYS_CLIENT_TOKEN  A
JOIN SYS_USER B ON A.USER_NAME=B.USER_NAME
WHERE CLIENT_TOKEN=P_CLIENT_TOKEN;

END ;

/**
    Ki?m tra xem th�ng tin token th? n�o
o	VALID: Token c�n hi?u l?c, v� c� th? s? d?ng ???c
o	INVALID: Token ?� h?t hi?u l?c
o	USED: Token ?� ???c s? d?ng
**/
 PROCEDURE PR_CHECK_CLIENT_TOKEN( P_APPLICATION_ID	VARCHAR2,
                            P_CLIENT_TOKEN	VARCHAR2,
                            p_out OUT types.ref_cursor)
AS    

BEGIN


UPDATE SYS_CLIENT_TOKEN
SET STATUS='INVALID', LAST_UPDATE_DATE=SYSDATE
WHERE STATUS='VALID' AND EXPIRI_DATE < SYSDATE;

OPEN p_out FOR
SELECT A.*, B.FULL_NAME, B.EMAIL, B.PHONE, B.MEMBER_CODE, B.MEMBER_VIEW_REPORT, B.GROUP_NAME
FROM SYS_CLIENT_TOKEN A
JOIN SYS_USER B ON A.USER_NAME=B.USER_NAME
WHERE CLIENT_TOKEN=P_CLIENT_TOKEN;-- AND APPLICATION_ID=P_APPLICATION_ID;

END ;


/**
    C?p nh?t tr?ng th�i token
o	VALID: Token c�n hi?u l?c, v� c� th? s? d?ng ???c
o	INVALID: Token ?� h?t hi?u l?c
o	USED: Token ?� ???c s? d?ng
**/
 PROCEDURE PR_UPDATE_CLIENT_TOKEN( P_APPLICATION_ID	VARCHAR2,
                            P_CLIENT_TOKEN	VARCHAR2,
                            p_status VARCHAR2,
                            p_out OUT types.ref_cursor)
AS    

BEGIN

--Ch? cho ph�p c?p nh?t tr?ng th�i n?u token NEW
UPDATE SYS_CLIENT_TOKEN
SET STATUS=P_STATUS, LAST_UPDATE_DATE=SYSDATE
WHERE CLIENT_TOKEN=P_CLIENT_TOKEN
    AND STATUS='VALID';

OPEN p_out FOR
SELECT * FROM SYS_CLIENT_TOKEN 
WHERE CLIENT_TOKEN=P_CLIENT_TOKEN and APPLICATION_ID=P_APPLICATION_ID;

END ;

END PCK_CLIENT_TOKEN;

/
--------------------------------------------------------
--  DDL for Package Body PCK_SYSTEM_PRICE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PCK_SYSTEM_PRICE" AS

  PROCEDURE pr_list_price(p_price_code SYS_PRICE.PRICE_CODE%TYPE,
                            p_channel SYS_PRICE.CHANNEL%TYPE,
                            p_effective_date SYS_PRICE.EFFECTIVE_DATE%TYPE,
                            p_expiration_date SYS_PRICE.EXPIRATION_DATE%TYPE,
                            p_normal_price SYS_PRICE.NORMAL_PRICE%TYPE,
                            p_non_normal_price SYS_PRICE.NON_NORMAL_PRICE%TYPE,
                            p_description SYS_PRICE.DESCRIPTION%TYPE,
                            p_creater_date SYS_PRICE.CREATER_DATE%TYPE,
                            p_user_creater SYS_PRICE.USER_CREATER%TYPE,
                            p_update_date SYS_PRICE.UPDATE_DATE%TYPE,
                            p_user_update SYS_PRICE.USER_UPDATE%TYPE,
                            p_out OUT types.ref_cursor) AS
  BEGIN
    OPEN p_out FOR 
        SELECT sysPrice.*
        FROM SYS_PRICE sysPrice
        WHERE (p_price_code is null or pkg_utility.removesignvietnamess(sysPrice.PRICE_CODE) LIKE '%' || pkg_utility.removesignvietnamess(p_price_code) || '%')
            AND (p_channel is null or sysPrice.CHANNEL = p_channel)
            AND (p_normal_price is null or sysPrice.NORMAL_PRICE = p_normal_price)
            AND (p_non_normal_price is null or sysPrice.NON_NORMAL_PRICE = p_non_normal_price)
            AND (p_description is null or sysPrice.DESCRIPTION LIKE '%' || p_description || '%')
            AND (p_user_creater is null or sysPrice.USER_CREATER LIKE '%' || p_user_creater || '%')
            AND (p_user_update is null or sysPrice.USER_UPDATE LIKE '%' || p_user_update || '%')
        order by EFFECTIVE_DATE desc;
  END pr_list_price;

  PROCEDURE pr_price_info(p_id number,
                               p_out OUT types.ref_cursor) AS
  BEGIN
     OPEN p_out FOR 
        SELECT sysPrice.*
        FROM SYS_PRICE sysPrice
        WHERE ID=p_id;
  END pr_price_info;

  PROCEDURE pr_create_price(p_price_code SYS_PRICE.PRICE_CODE%TYPE,
                                p_channel SYS_PRICE.CHANNEL%TYPE,
                                p_effective_date SYS_PRICE.EFFECTIVE_DATE%TYPE,
                                p_expiration_date SYS_PRICE.EXPIRATION_DATE%TYPE,
                                p_normal_price SYS_PRICE.NORMAL_PRICE%TYPE,
                                p_non_normal_price SYS_PRICE.NON_NORMAL_PRICE%TYPE,
                                p_description SYS_PRICE.DESCRIPTION%TYPE,
                                p_creater_date SYS_PRICE.CREATER_DATE%TYPE,
                                p_user_creater SYS_PRICE.USER_CREATER%TYPE,
                                p_update_date SYS_PRICE.UPDATE_DATE%TYPE,
                                p_user_update SYS_PRICE.USER_UPDATE%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_out OUT types.ref_cursor) AS
  v_channel varchar2(50);
  v_count number;
  BEGIN

  select count(9) into v_count from SYS_PRICE 
                       where price_code=p_price_code and (EFFECTIVE_DATE >= p_effective_date  or EXPIRATION_DATE > p_effective_date) ;
  if v_count>0 then
      Raise_Application_Error (-20000, 'Ngày hiệu lực của biểu giá phải lớn hoặc bằng Ngày hết hạn của biểu giá.');
      return;
  end if;
  
 
--   select count(9) into v_count from SYS_PRICE 
--                        where price_code=p_price_code and (EFFECTIVE_DATE between p_effective_date and nvl(p_expiration_date,sysdate+1) 
--                                            or nvl(EXPIRATION_DATE,sysdate+1000)  between p_effective_date and nvl(p_expiration_date,sysdate+1)
--                                            or p_effective_date  between EFFECTIVE_DATE and nvl(EXPIRATION_DATE,null)
--                                            or nvl(p_expiration_date,sysdate+1000)  between EFFECTIVE_DATE and nvl(EXPIRATION_DATE,sysdate)) ;
--     if v_count>0 then
--         Raise_Application_Error (-20000, 'Ngày hiệu lực và ngày hết hạn không được giao nhau.');
--         return;
--     end if;


  select max(par1) into v_channel
  from sys_refcode 
  where ref_group='LS_PRODUCT' and ref_code=p_price_code;
        
        UPDATE SYS_PRICE
        SET EXPIRATION_DATE = p_effective_date-1
        WHERE PRICE_CODE = p_price_code AND EXPIRATION_DATE IS NULL;
        
        INSERT INTO SYS_PRICE (ID,
                               PRICE_CODE, 
                                CHANNEL, 
                                EFFECTIVE_DATE, 
                                EXPIRATION_DATE, 
                                NORMAL_PRICE, 
                                NON_NORMAL_PRICE, 
                                DESCRIPTION, 
                                CREATER_DATE, 
                                USER_CREATER
                                --UPDATE_DATE, 
                                --USER_UPDATE
                                )
        VALUES(seq_sys_price.nextval, p_price_code , --PRICE_CODE
                v_channel , --CHANNEL
                p_effective_date , --EFFECTIVE_DATE
                p_expiration_date , --EXPIRATION_DATE
                p_normal_price , --NORMAL_PRICE
                p_non_normal_price , --NON_NORMAL_PRICE
                p_description , --DESCRIPTION
                sysdate , --CREATER_DATE
                p_user  --USER_CREATER
                --p_update_date , --UPDATE_DATE
                --p_user_update  --USER_UPDATE
                );
        OPEN p_out FOR 
        SELECT sysPrice.*
        FROM SYS_PRICE sysPrice
        WHERE sysPrice.PRICE_CODE = p_price_code;
  END pr_create_price;

  PROCEDURE pr_update_price(p_price_code SYS_PRICE.PRICE_CODE%TYPE,
                                p_channel SYS_PRICE.CHANNEL%TYPE,
                                p_effective_date SYS_PRICE.EFFECTIVE_DATE%TYPE,
                                p_expiration_date SYS_PRICE.EXPIRATION_DATE%TYPE,
                                p_normal_price SYS_PRICE.NORMAL_PRICE%TYPE,
                                p_non_normal_price SYS_PRICE.NON_NORMAL_PRICE%TYPE,
                                p_description SYS_PRICE.DESCRIPTION%TYPE,
                                p_creater_date SYS_PRICE.CREATER_DATE%TYPE,
                                p_user_creater SYS_PRICE.USER_CREATER%TYPE,
                                p_update_date SYS_PRICE.UPDATE_DATE%TYPE,
                                p_user_update SYS_PRICE.USER_UPDATE%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_id IN number,
                                p_out OUT types.ref_cursor) AS
  v_count number;
  BEGIN
 
   select count(9) into v_count from SYS_PRICE 
                        where id<>p_id and price_code=p_price_code and (EFFECTIVE_DATE between p_effective_date and nvl(p_expiration_date,sysdate+1) 
                                            or nvl(EXPIRATION_DATE,sysdate+1000)  between p_effective_date and nvl(p_expiration_date,sysdate+1)
                                            or p_effective_date  between EFFECTIVE_DATE and nvl(EXPIRATION_DATE, null)
                                            or nvl(p_expiration_date,sysdate+1000)  between EFFECTIVE_DATE and nvl(EXPIRATION_DATE,sysdate)) ;
     if v_count>0 then
         Raise_Application_Error (-20000, 'Ngày hiệu lực và ngày hết hạn không được giao nhau.');
         return;
     end if;

    UPDATE SYS_PRICE 
        SET EFFECTIVE_DATE=p_effective_date, 
            EXPIRATION_DATE=p_expiration_date, 
            NORMAL_PRICE=p_normal_price, 
            NON_NORMAL_PRICE=p_non_normal_price, 
            DESCRIPTION=p_description, 
            --CREATER_DATE=p_creater_date, 
            --USER_CREATER=p_user_creater, 
            UPDATE_DATE=sysdate, 
            USER_UPDATE=p_user
        WHERE id=p_id;
        
        OPEN p_out FOR 
        SELECT sysPrice.*
        FROM SYS_PRICE sysPrice
        WHERE sysPrice.ID = p_id;
  END pr_update_price;
  
  PROCEDURE pr_delete_price(p_id number) AS
  v_count number;
  BEGIN
        --Check di?u ki?n ng�y
        select count(9) into v_count
        from SYS_PRICE WHERE ID = p_id and EFFECTIVE_DATE<sysdate;
        if v_count>0 then
            Raise_Application_Error (-20000, 'Không được xóa bản ghi có ngày hiệu lực < ngày hiện tại.');
            return;
        end if;
        
        DELETE FROM SYS_PRICE sysPrice WHERE sysPrice.ID = p_id;
  END pr_delete_price;

END PCK_SYSTEM_PRICE;

/
--------------------------------------------------------
--  DDL for Package Body PCK_SYSTEM_SECURITY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PCK_SYSTEM_SECURITY" as


  -- Danh sach cac Application cua user
  PROCEDURE FN_GET_APPLICATION(p_out   OUT TYPES.ref_cursor,
                               p_user  IN VARCHAR2,
                               p_group IN VARCHAR2) IS
  v_is_opse number := 0;
  BEGIN
  select count(9) into v_is_opse from sys_user where user_name=p_user and type=2;
  if v_is_opse > 0 then
    OPEN p_out FOR
    select * from Sys_Application where 1=0;
  else
      OPEN p_out FOR
        select *
          from Sys_Application
         WHERE APPLICATION_ID IN
               (select APPLICATION_ID
          from sys_resources xx
          join (select *
                  from (SELECT A.RES_ID,
                               A.PARENT_ID
                          FROM SYS_RESOURCES A
                         WHERE A.STATUS = '1'
                           AND A.RES_ID IN
                               (SELECT BB.RESOURCE_ID
                                  FROM SYS_USER_ACTIONS AA
                                  JOIN SYS_RESOURCE_ACTIONS BB
                                    ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                 WHERE upper(AA.USER_ID) = upper(p_user)
                                   AND AA.DENIED = '0')
                        UNION ALL
                        SELECT A.RES_ID,
                               A.PARENT_ID
                          FROM SYS_RESOURCES A
                         WHERE A.STATUS = '1'
                           AND A.RES_ID IN
                               (SELECT BB.RESOURCE_ID
                                  FROM SYS_GROUP_ACTIONS AA
                                  JOIN SYS_RESOURCE_ACTIONS BB
                                    ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                 WHERE ',' || NVL(p_group, '') || ',' LIKE
                                       '%,' || AA.GROUP_ID || ',%')
                        ) AA) yy
            on xx.res_id = yy.res_id
       );
  end if;
  END FN_GET_APPLICATION;
  -- Danh sach cac Rescource cua user
  PROCEDURE FN_GET_RES(p_user  IN VARCHAR2,
                       p_group IN OUT VARCHAR2,
                       p_appid IN VARCHAR2,p_out   OUT TYPES.ref_cursor) IS
pIP_ADD            VARCHAR2(200);
pRowCount            int;
pDetail       varchar2(4000);
  BEGIN
SELECT SYS_CONTEXT('USERENV','IP_ADDRESS') INTO pIP_ADD FROM dual;
pDetail:='FromInput:'|| nvl(p_group,'N/A');

select to_char(group_name) into p_group from sys_user where user_name = p_user;

pDetail:=pDetail ||chr(13)||' FromDB:'|| nvl(p_group,'N/A');
select count(9) into pRowCount
        from sys_resources xx
        join (select *
                from (SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = p_appid
                         AND A.IS_GRANT = '1'
                         AND A.STATUS = '1'
                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      UNION
                      SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = p_appid
                         AND A.STATUS = '1'
                         AND A.RES_ID IN
                             (SELECT RESOURCE_ID FROM (
                                         (SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_USER_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB
                                              ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                           WHERE upper(AA.USER_ID) = upper(p_user)
                                             AND BB.APPLICATION_ID = p_appid
                                             AND AA.DENIED = '0'
                                           UNION
                                           SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_GROUP_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                            LEFT JOIN SYS_GROUPS GR ON AA.GROUP_ID = GR.GROUP_NAME
                                           WHERE ',' || NVL(upper(p_group), '') || ',' LIKE
                                                 '%,' || upper(AA.GROUP_ID) || ',%'
                                             AND BB.APPLICATION_ID = p_appid
                                             AND NVL(GR.STATUS,'1')='1'
                                           MINUS
                                           SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_USER_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB
                                              ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                           WHERE upper(AA.USER_ID) = upper(p_user)
                                             AND BB.APPLICATION_ID = p_appid
                                             AND AA.DENIED = '1')))

                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      ) AA) yy
          on path1 like '%/' || xx.res_id || '/%'
          where xx.status='1'
                and APPLICATION_ID = p_appid
          order by xx.priority, xx.res_nm;

insert into sys_logapplication (application_id,detail,summary,log_type,iplocal,create_usr,create_dt)
values (p_appid,pDetail, 'PCK_SYSTEM_SECURITY.FN_GET_RES: '|| nvl(p_user,'N/A') ||' in '|| nvl(p_group,'N/A') ||' rows '|| to_char(pRowCount), 'INF', pIP_ADD, p_user, sysdate);

    OPEN p_out FOR
      select distinct xx.*
        from sys_resources xx
        join (select *
                from (SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = p_appid
                         AND A.IS_GRANT = '1'
                         AND A.STATUS = '1'
                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      UNION
                      SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = p_appid
                         AND A.STATUS = '1'
                         AND A.RES_ID IN
                             (SELECT RESOURCE_ID FROM (
                                         (SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_USER_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB
                                              ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                           WHERE upper(AA.USER_ID) = upper(p_user)
                                             AND BB.APPLICATION_ID = p_appid
                                             AND AA.DENIED = '0'
                                           UNION
                                           SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_GROUP_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                            LEFT JOIN SYS_GROUPS GR ON AA.GROUP_ID = GR.GROUP_NAME
                                           WHERE ',' || NVL(upper(p_group), '') || ',' LIKE
                                                 '%,' || upper(AA.GROUP_ID) || ',%'
                                             AND BB.APPLICATION_ID = p_appid
                                             AND NVL(GR.STATUS,'1')='1'
                                           MINUS
                                           SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_USER_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB
                                              ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                           WHERE upper(AA.USER_ID) = upper(p_user)
                                             AND BB.APPLICATION_ID = p_appid
                                             AND AA.DENIED = '1')))

                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      ) AA) yy
          on path1 like '%/' || xx.res_id || '/%'
          where xx.status='1'
                and APPLICATION_ID = p_appid
          order by xx.priority, xx.res_nm;

  END FN_GET_RES;

  -- Danh sach cac Rescource cua user
PROCEDURE FN_GET_RES_ACTION(p_user  IN VARCHAR2,
                           p_group_ IN VARCHAR2,
                           p_res_id IN VARCHAR2,
                           p_appid IN VARCHAR2,
                           p_out   OUT TYPES.ref_cursor) IS
pIP_ADD            VARCHAR2(200);
pRowCount            int;
pDetail       varchar2(4000);
v_appid varchar2(50);
p_group varchar2(4000);
BEGIN
SELECT SYS_CONTEXT('USERENV','IP_ADDRESS') INTO pIP_ADD FROM dual;
pDetail:='FromInput:'|| nvl(p_group,'N/A');
v_appid:=nvl(p_appid,'CIS');

select max(to_char(group_name)) into p_group from sys_user where user_name = p_user;

pDetail:=pDetail ||chr(13)||' FromDB:'|| nvl(p_group,'N/A');
select count(9) into pRowCount
        from sys_resources xx
        join (select *
                from (SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = v_appid
                         AND A.IS_GRANT = '1'
                         AND A.STATUS = '1'
                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      UNION
                      SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = v_appid
                         AND A.STATUS = '1'
                         AND A.RES_ID IN
                             (SELECT RESOURCE_ID FROM (
                                         (SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_USER_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB
                                              ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                           WHERE upper(AA.USER_ID) = upper(p_user)
                                             AND BB.APPLICATION_ID = v_appid
                                             AND AA.DENIED = '0'
                                           UNION
                                           SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_GROUP_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                            LEFT JOIN SYS_GROUPS GR ON AA.GROUP_ID = GR.GROUP_NAME
                                           WHERE ',' || NVL(upper(p_group), '') || ',' LIKE
                                                 '%,' || upper(AA.GROUP_ID) || ',%'
                                             AND BB.APPLICATION_ID = v_appid
                                             AND NVL(GR.STATUS,'1')='1'
                                           MINUS
                                           SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_USER_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB
                                              ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                           WHERE upper(AA.USER_ID) = upper(p_user)
                                             AND BB.APPLICATION_ID = v_appid
                                             AND AA.DENIED = '1')))

                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      ) AA) yy
          on path1 like '%/' || xx.res_id || '/%'
          where xx.status='1'
                and APPLICATION_ID = v_appid
          order by xx.priority, xx.res_nm;

insert into sys_logapplication (application_id,detail,summary,log_type,iplocal,create_usr,create_dt)
values (v_appid,pDetail, 'PCK_SYSTEM_SECURITY.FN_GET_RES: '|| nvl(p_user,'N/A') ||' in '|| nvl(p_group,'N/A') ||' rows '|| to_char(pRowCount), 'INF', pIP_ADD, p_user, sysdate);

    OPEN p_out FOR
      select distinct  xx.APPLICATION_ID
                      , xx.RES_ID
                      , xx.PARENT_ID
                      , xx.RES_NM
                      , xx.RES_SHORT_NM
                      , xx.PRIORITY
                      , xx.STATUS
                      , xx.TASK_FLOW_ID
                      , xx.PAR1
                      , xx.PAR2
                      , xx.PAR3
                      , xx.PAR4
                      , xx.PAR5
                      , xx.PAR6
                      , xx.PAR7
                      , xx.PAR8
                      , xx.PAR9
                      , xx.RES_DESC
                      , xx.RES_TP
                      , xx.SIGNAL
                      , xx.TEMPLATE_SITE
                      , xx.CREATE_DT
                      , xx.UPDATE_DT
                      , xx.CREATE_USR
                      , xx.UPDATE_USR
                      , xx.URL
                      , xx.IS_GRANT
                      , xx.MODULE_ID 
                      ,aa.action_code par10
        from sys_resources xx
        join sys_resource_actions zz on xx.res_id=zz.resource_id
        join sys_actions aa on zz.action_id=aa.action_id
        join (select *
                from (SELECT A.RES_ID RES_ACTION_ID 
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = v_appid
                         AND A.IS_GRANT = '1'
                         AND A.STATUS = '1'
                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      UNION
                      SELECT A.RES_ACTION_ID 
                        FROM SYS_RESOURCE_ACTIONS A
                       WHERE A.APPLICATION_ID = v_appid
                         --AND A.STATUS = '1'
                         AND A.RES_ACTION_ID IN
                             (SELECT RES_ACTION_ID FROM (
                                         (SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_USER_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB
                                              ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                           WHERE upper(AA.USER_ID) = upper(p_user)
                                             AND BB.APPLICATION_ID = v_appid
                                             AND AA.DENIED = '0'
                                           UNION
                                           SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_GROUP_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                            LEFT JOIN SYS_GROUPS GR ON AA.GROUP_ID = GR.GROUP_NAME
                                           WHERE ',' || NVL(upper(p_group), '') || ',' LIKE
                                                 '%,' || upper(AA.GROUP_ID) || ',%'
                                             AND BB.APPLICATION_ID = v_appid
                                             AND NVL(GR.STATUS,'1')='1'
                                           MINUS
                                           SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_USER_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB
                                              ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                           WHERE upper(AA.USER_ID) = upper(p_user)
                                             AND BB.APPLICATION_ID = v_appid
                                             AND AA.DENIED = '1')))

                      ) AA) yy
          on yy.RES_ACTION_ID = zz.RES_ACTION_ID 
          where xx.status='1'
                and xx.APPLICATION_ID = v_appid
                and (p_res_id is null or p_res_id=xx.res_id)
          order by xx.priority, xx.res_nm;

  END FN_GET_RES_ACTION;

  PROCEDURE FN_GET_RES_NEW(
                       p_user  IN VARCHAR2,
                       p_group IN VARCHAR2,
                       p_appid IN VARCHAR2,
                       p_out   OUT TYPES.ref_cursor) IS
v_group varchar2(4000);
v_appid varchar2(50);
  BEGIN
select max(to_char(group_name)) into v_group from sys_user where user_name = p_user;
v_appid:='CIS';

    OPEN p_out FOR
      select distinct XX.APPLICATION_ID,
                        XX.RES_ID,
                        XX.PARENT_ID,
                        XX.RES_NM,
                        XX.RES_SHORT_NM,
                        XX.PRIORITY,
                        XX.STATUS,
                        XX.TASK_FLOW_ID,
                        XX.PAR1,
                        XX.PAR2,
                        XX.PAR3,
                        XX.PAR4,
                        XX.PAR5,
                        XX.PAR6,
                        XX.PAR7,
                        XX.PAR8,
                        XX.PAR9,
                        XX.RES_DESC,
                        XX.RES_TP,
                        XX.SIGNAL,
                        XX.TEMPLATE_SITE,
                        XX.CREATE_DT,
                        XX.UPDATE_DT,
                        XX.CREATE_USR,
                        XX.UPDATE_USR,
                        nvl(XX.URL,'home') URL,
                        XX.IS_GRANT,
                        XX.MODULE_ID,
                        XX.PAR10,
                        XX.ICON
        from sys_resources xx
        join (select *
                from (SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = v_appid
                         AND A.IS_GRANT = '1'
                         AND A.STATUS = '1'
                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      UNION
                      SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = v_appid
                         AND A.STATUS = '1'
                         AND A.RES_ID IN
                             (SELECT BB.RESOURCE_ID
                                FROM SYS_USER_ACTIONS AA
                                JOIN SYS_RESOURCE_ACTIONS BB
                                  ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                               WHERE upper(AA.USER_ID) = upper(p_user)
                                 AND BB.APPLICATION_ID = v_appid
                                 AND AA.DENIED = '0')

                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      UNION
                      SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = v_appid
                         AND A.STATUS = '1'
                         AND A.RES_ID IN
                             (SELECT BB.RESOURCE_ID
                                FROM SYS_GROUP_ACTIONS AA
                                JOIN SYS_RESOURCE_ACTIONS BB
                                  ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                               WHERE ',' || NVL(v_group, '') || ',' LIKE
                                     '%,' || AA.GROUP_ID || ',%'
                                 AND BB.APPLICATION_ID = v_appid)
                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      MINUS
                      SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = v_appid
                         AND A.STATUS = '1'
                         AND A.RES_ID IN
                             (SELECT BB.RESOURCE_ID
                                FROM SYS_USER_ACTIONS AA
                                JOIN SYS_RESOURCE_ACTIONS BB
                                  ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                               WHERE AA.USER_ID = p_user
                                 AND BB.APPLICATION_ID = v_appid
                                 AND AA.DENIED = '1')

                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID) AA) yy
          on path1 like '%/' || xx.res_id || '/%'
          where xx.status='1'
                and APPLICATION_ID = v_appid
          order by xx.priority, xx.res_nm
      /*minus
      select distinct xx.*
        from sys_resources xx
        join (select *
                from (SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = p_appid
                         AND A.STATUS = '1'
                         AND A.RES_ID IN
                             (SELECT BB.RESOURCE_ID
                                FROM SYS_USER_ACTIONS AA
                                JOIN SYS_RESOURCE_ACTIONS BB
                                  ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                               WHERE AA.USER_ID = p_user
                                 AND BB.APPLICATION_ID = p_appid
                                 AND AA.DENIED = '1')

                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID) AA) yy
          on path1 like '%/' || xx.res_id || '/%'*/;
  END FN_GET_RES_NEW;

PROCEDURE FN_GET_RES_DENIED(p_user  IN VARCHAR2,
                           p_group_  IN  VARCHAR2,
                           p_res_id IN VARCHAR2,
                           p_appid IN VARCHAR2,
                           p_out   OUT TYPES.ref_cursor) IS
pIP_ADD            VARCHAR2(200); 
pDetail       varchar2(4000);
v_appid varchar2(50);
p_group  VARCHAR2(50);
BEGIN



SELECT SYS_CONTEXT('USERENV','IP_ADDRESS') INTO pIP_ADD FROM dual;
pDetail:='FromInput:'|| nvl(p_group,'N/A');
v_appid:=nvl(p_appid,'CIS');

select max(to_char(group_name)) into p_group from sys_user where user_name = p_user;

pDetail:='p_user:'||p_user||';'|| pDetail ||chr(13)||' FromDB:'|| nvl(p_group,'N/A');

insert into sys_logapplication (application_id,detail,summary,log_type,iplocal,create_usr,create_dt)
values (v_appid,pDetail, 'PCK_SYSTEM_SECURITY.FN_GET_RES_DENIED: '|| nvl(p_user,'N/A') ||' in '|| nvl(p_group,'N/A'), 'INF', pIP_ADD, p_user, sysdate);

    OPEN p_out FOR
      select res_id, par1,task_flow_id from sys_resources a
      where a.res_id not in 
      (select distinct xx.res_id
        from sys_resources xx
        join sys_resource_actions zz on xx.res_id=zz.resource_id
        join (select *
                from (SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = v_appid
                         AND A.IS_GRANT = '1'
                         AND A.STATUS = '1'
                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      UNION
                      SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                             A.RES_ID,
                             A.PARENT_ID
                        FROM SYS_RESOURCES A
                       WHERE A.APPLICATION_ID = v_appid
                         AND A.STATUS = '1'
                         AND A.RES_ID IN
                             (SELECT RESOURCE_ID FROM (
                                         (SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_USER_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB
                                              ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                           WHERE upper(AA.USER_ID) = upper(p_user)
                                             AND BB.APPLICATION_ID = v_appid
                                             AND AA.DENIED = '0'
                                           UNION
                                           SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_GROUP_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                            LEFT JOIN SYS_GROUPS GR ON AA.GROUP_ID = GR.GROUP_NAME
                                           WHERE ',' || NVL(upper(p_group), '') || ',' LIKE
                                                 '%,' || upper(AA.GROUP_ID) || ',%'
                                             AND BB.APPLICATION_ID = v_appid
                                             AND NVL(GR.STATUS,'1')='1'
                                           MINUS
                                           SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                            FROM SYS_USER_ACTIONS AA
                                            JOIN SYS_RESOURCE_ACTIONS BB
                                              ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                           WHERE upper(AA.USER_ID) = upper(p_user)
                                             AND BB.APPLICATION_ID = v_appid
                                             AND AA.DENIED = '1')))

                       START WITH A.parent_id IS NULL
                      CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                      ) AA) yy
          on path1 like '%/' || xx.res_id || '/%'
          where xx.status='1'
                and xx.APPLICATION_ID = v_appid )
          union 
          select res_id, par1,task_flow_id from sys_resources a
          where parent_id is null and A.res_id not in 
          (select distinct XX.PARENT_ID
            from sys_resources xx
            join sys_resource_actions zz on xx.res_id=zz.resource_id
            join (select *
                    from (SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                                 A.RES_ID,
                                 A.PARENT_ID
                            FROM SYS_RESOURCES A
                           WHERE A.APPLICATION_ID = v_appid
                             AND A.IS_GRANT = '1'
                             AND A.STATUS = '1'
                           START WITH A.parent_id IS NULL
                          CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                          UNION
                          SELECT SYS_CONNECT_BY_PATH(a.res_id, '/') || '/' path1,
                                 A.RES_ID,
                                 A.PARENT_ID
                            FROM SYS_RESOURCES A
                           WHERE A.APPLICATION_ID = v_appid
                             AND A.STATUS = '1'
                             AND A.RES_ID IN
                                 (SELECT RESOURCE_ID FROM (
                                             (SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                                FROM SYS_USER_ACTIONS AA
                                                JOIN SYS_RESOURCE_ACTIONS BB
                                                  ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                               WHERE upper(AA.USER_ID) = upper(p_user)
                                                 AND BB.APPLICATION_ID = v_appid
                                                 AND AA.DENIED = '0'
                                               UNION
                                               SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                                FROM SYS_GROUP_ACTIONS AA
                                                JOIN SYS_RESOURCE_ACTIONS BB ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                                LEFT JOIN SYS_GROUPS GR ON AA.GROUP_ID = GR.GROUP_NAME
                                               WHERE ',' || NVL(upper(p_group), '') || ',' LIKE
                                                     '%,' || upper(AA.GROUP_ID) || ',%'
                                                 AND BB.APPLICATION_ID = v_appid
                                                 AND NVL(GR.STATUS,'1')='1'
                                               MINUS
                                               SELECT BB.RESOURCE_ID,BB.RES_ACTION_ID
                                                FROM SYS_USER_ACTIONS AA
                                                JOIN SYS_RESOURCE_ACTIONS BB
                                                  ON AA.RES_ACTION_ID = BB.RES_ACTION_ID
                                               WHERE upper(AA.USER_ID) = upper(p_user)
                                                 AND BB.APPLICATION_ID = v_appid
                                                 AND AA.DENIED = '1')))

                           START WITH A.parent_id IS NULL
                          CONNECT BY PRIOR A.RES_ID = A.PARENT_ID
                          ) AA) yy
              on path1 like '%/' || xx.res_id || '/%'
              where xx.status='1'
                    and xx.APPLICATION_ID = v_appid )
              union 
              select 0,'0','' from dual;

  END;
  -- Gan thong tin cau hinh LDAP cho Application
  PROCEDURE FN_LDAP_CONFIG_APPLICATION(p_user  IN VARCHAR2,
                                       p_appid IN VARCHAR2,
                                       p_ldapType IN VARCHAR2)IS
  BEGIN
--  return;
  merge into sys_bundle a
  using (select * from sys_refcode where ref_group=p_ldapType)b on (a.application_id||a.item_code=p_appid||b.ref_code and a.item_group='LDAP')
  when matched then
    update set a.item_value_vn=b.ref_name_vn
               , a.item_value_en=b.ref_name_en
               , a.update_dt=sysdate
               , a.update_usr=p_user
  when not matched then
    insert (a.application_id,a.item_code,a.item_group,a.item_value_vn,a.item_value_en,a.create_dt,a.create_usr)
    values (p_appid,b.ref_code,'LDAP',b.ref_name_vn,b.ref_name_en,sysdate,p_user);

commit;

  END FN_LDAP_CONFIG_APPLICATION;

  -- Thuc hien xoa quyen User
  PROCEDURE FN_DEL_ACTION_USER(p_user  IN VARCHAR2,
                               p_ResActionID IN VARCHAR2,
                               p_user_del    IN VARCHAR2) IS
  BEGIN
    -- Thuc hien xoa quyen user
    delete sys_user_actions a
    where a.user_id=p_user_del and a.res_action_id=p_ResActionID;
    commit;
  END FN_DEL_ACTION_USER;

  -- Thuc hien xoa quyen Group
  PROCEDURE FN_DEL_ACTION_GROUP(p_group  IN VARCHAR2,
                               p_ResActionID IN VARCHAR2,
                               p_group_del    IN VARCHAR2) IS
  BEGIN
    -- Thuc hien xoa quyen GROUP
    delete sys_group_actions a
    where a.group_id=p_group_del and a.res_action_id=p_ResActionID;
    commit;
  END FN_DEL_ACTION_GROUP;

PROCEDURE PR_LOG_USER_ACTIVITY(p_user_name  IN VARCHAR2,
                               p_user_type IN VARCHAR2,
                               p_activity_type    IN VARCHAR2,
                               p_description    IN VARCHAR2,
                               p_status    IN VARCHAR2,
                               p_client_ip    IN VARCHAR2,
                               p_user_agent    IN VARCHAR2) IS
V_FAILED_PASS_AT_TEMPT NUMBER;
V_MINUTE_LOCK NUMBER;
BEGIN
--L?i khi ??ng nh?p
IF p_status='ERROR' THEN
    SELECT MAX(PAR1) INTO V_FAILED_PASS_AT_TEMPT
    FROM SYS_REFCODE A
    WHERE A.REF_CODE='FAILED_PASS_AT_TEMPT';--

    UPDATE SYS_USER
    SET NUM_FAILED = NVL(NUM_FAILED,0)+1
        ,LAST_FAILED = SYSDATE
        ,STATUS = CASE WHEN NVL(NUM_FAILED,0)+1>=V_FAILED_PASS_AT_TEMPT AND STATUS='1' THEN '-1' ELSE STATUS END -- T? ??ng kh�a t�i kho?n
    WHERE USER_NAME=p_user_name;
END IF;
IF p_status='SUCCESS' THEN 
--    SELECT MAX(PAR1) INTO V_MINUTE_LOCK
--    FROM SYS_REFCODE A
--    WHERE A.REF_CODE='SELF_UNLOCK_TIME';--FAILED_PASS_AT_TEMPT
    --Ch? reset s? l??ng sai pas n?u user l� Active
    UPDATE SYS_USER
    SET NUM_FAILED = 0, LAST_FAILED = SYSDATE, STATUS = '1'
    WHERE USER_NAME=p_user_name;-- AND STATUS='1';
--    AND LAST_FAILED<SYSDATE+V_MINUTE_LOCK/60/24 AND STATUS=-1;
END IF;
IF p_status='LOCKED' THEN
   SELECT MAX(PAR1) INTO V_MINUTE_LOCK
   FROM SYS_REFCODE A
   WHERE A.REF_CODE='SELF_UNLOCK_TIME';--FAILED_PASS_AT_TEMPT
    --Ch? reset s? l??ng sai pas n?u user l� Active
    UPDATE SYS_USER
    SET NUM_FAILED = 0, LAST_FAILED = SYSDATE, STATUS = '1'
    WHERE USER_NAME=p_user_name
   AND LAST_FAILED+V_MINUTE_LOCK/24<SYSDATE AND STATUS='-1';
END IF;

   INSERT INTO SYS_RESOURCEACCESSMANAGEMENT
     (ID,
      APPLICATION_ID,
      RESOURCE_URL,
      ACCESS_USER,
      ACCESS_DATE,
      ACCESS_STATUS,
      LOG_MESSAGE,
      RESOURCE_TYPE,
      RPT_CODE,
      RESOURCE_ACTION,
      CLIENT_IP,
      USER_AGENT)
   VALUES
     (SEQ_SYS_RES_ACCESSMANAGEMENT.NEXTVAL,
      'CIS' ,
      'Login' ,
      p_user_name ,
      SYSDATE ,
      p_status ,
      p_description ,
      'LOGIN' ,
      '' ,
      p_activity_type ,
      P_CLIENT_IP ,
      P_USER_AGENT );
  commit;
END;

PROCEDURE PR_AUTHEN_USER(p_user_name  IN VARCHAR2,
                           p_pass VARCHAR2,
                           p_client_ip VARCHAR2,
                           p_user_agent VARCHAR2,
                           p_out   OUT TYPES.ref_cursor ) IS
V_FAILED_PASS_AT_TEMPT NUMBER;
V_MINUTE_LOCK NUMBER;
BEGIN 

    SELECT MAX(PAR1) INTO V_MINUTE_LOCK
   FROM SYS_REFCODE A
   WHERE A.REF_CODE='SELF_UNLOCK_TIME';

    SELECT MAX(PAR1) INTO V_FAILED_PASS_AT_TEMPT
    FROM SYS_REFCODE A
    WHERE A.REF_CODE='FAILED_PASS_AT_TEMPT';

    OPEN p_out FOR
    SELECT A.USER_NAME, A.FULL_NAME, --A.STATUS
    CASE
        WHEN A.NUM_FAILED>=V_FAILED_PASS_AT_TEMPT AND LAST_FAILED+V_MINUTE_LOCK/24<SYSDATE
            THEN '1'
        WHEN A.NUM_FAILED>=V_FAILED_PASS_AT_TEMPT AND LAST_FAILED+V_MINUTE_LOCK/24>SYSDATE
            THEN '-1'
        ELSE A.STATUS
    END STATUS
    FROM SYS_USER A
    WHERE A.USER_NAME=p_user_name;


END;
PROCEDURE PR_AUTO_UNLOCK_USER IS 
V_MINUTE_LOCK number := 0;
V_FAILED_PASS_AT_TEMPT NUMBER :=0;
BEGIN

    SELECT MAX(PAR1) INTO V_MINUTE_LOCK
    FROM SYS_REFCODE A
    WHERE A.REF_CODE='SELF_UNLOCK_TIME';--FAILED_PASS_AT_TEMPT

    SELECT MAX(PAR1) INTO V_FAILED_PASS_AT_TEMPT
    FROM SYS_REFCODE A
    WHERE A.REF_CODE='FAILED_PASS_AT_TEMPT';--

    -- M? kh�a t? ??ng sau x ph�t cho user n?u tr?ng th�i ?ang l� t?m kh�a v� ?? th?i gian
    UPDATE SYS_USER
    SET NUM_FAILED = 0, LAST_FAILED = SYSDATE, STATUS = 1
    WHERE SYSDATE>LAST_FAILED+V_MINUTE_LOCK/60/24 AND STATUS=-1 AND NUM_FAILED>=V_FAILED_PASS_AT_TEMPT;

    COMMIT;
END;
end PCK_SYSTEM_SECURITY;

/
--------------------------------------------------------
--  DDL for Package Body PCK_TOKEN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PCK_TOKEN" AS

  PROCEDURE PR_GET_TOKEN (p_out    OUT SYS_REFCURSOR) AS
  BEGIN
    -- TODO: Implementation required for PROCEDURE PCK_TOKEN.PR_GET_TOKEN
    OPEN P_OUT FOR
    SELECT * FROM SYS_TOKEN;

  END PR_GET_TOKEN;
END PCK_TOKEN;

/
--------------------------------------------------------
--  DDL for Package Body PKG_REF_CODE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PKG_REF_CODE" AS
v_parameter   NVARCHAR2 (1500);
  PROCEDURE pr_list_category (p_status sys_refcode.status%TYPE ,
                              p_ref_group sys_refcode.ref_group%TYPE,
                              p_ref_code sys_refcode.ref_code%TYPE,
                              p_ref_name_vn sys_refcode.ref_name_vn%TYPE,
                              p_ref_name_en sys_refcode.ref_name_en%TYPE,
                              p_description sys_refcode.description%TYPE,
                              p_par1 sys_refcode.par1%TYPE,
                              p_par2 sys_refcode.par2%TYPE,
                              p_par3 sys_refcode.par3%TYPE,
                              p_par4 sys_refcode.par4%TYPE,
                              p_par5 sys_refcode.par5%TYPE,
                              p_par6 sys_refcode.par6%TYPE,
                              p_par7 sys_refcode.par7%TYPE,
                              p_par8 sys_refcode.par8%TYPE,
                              p_par9 sys_refcode.par9%TYPE,
                              p_user varchar2,
                              p_out OUT types.ref_cursor)
    AS
    V_GROUP_NAME VARCHAR2(1000);
    V_PRODUCT_LIST VARCHAR2(1000);
    V_REF_GROUP VARCHAR2(100);
V_BRANCH_REPORT VARCHAR2(1000);
    BEGIN
v_parameter := 'p_user:'
            || p_user
            || '|V_BRANCH_REPORT:'
            || V_BRANCH_REPORT
            || '|p_ref_group:'
            || p_ref_group;
            
pkg_system_log.pr_log_info ('pr_list_category', 'BEGIN', v_parameter);

    if p_ref_group='LS_BRANCH' then --Danh sach Branch theo quyen du lieu
        SELECT MAX(NVL(A.MEMBER_VIEW_REPORT,'N/A')||','||A.MEMBER_CODE)
        INTO V_BRANCH_REPORT
        FROM SYS_USER A
        WHERE A.USER_NAME = lower(P_USER);
    v_parameter := 'p_user:'|| p_user ||'|V_BRANCH_REPORT:'|| V_BRANCH_REPORT ||'|p_ref_group:'|| p_ref_group;
    pkg_system_log.pr_log_info ('pr_list_category', 'BEGIN', v_parameter);

        OPEN p_out FOR
        WITH DATA_PERMISION AS(
            SELECT DISTINCT TRIM(REGEXP_SUBSTR(BRCODE, '[^,]+', 1, LEVEL)) BRANCH
              FROM (SELECT V_BRANCH_REPORT BRCODE FROM DUAL) T
            CONNECT BY INSTR(BRCODE, ',', 1, LEVEL - 1) > 0 )
        SELECT refCode.*, sysRef.REF_NAME_VN STATUS_STR
        FROM V_BRANCH refCode
        LEFT JOIN SYS_REFCODE sysRef on refCode.STATUS = sysRef.REF_CODE and sysRef.REF_GROUP = 'LS_STATUS'
        WHERE (p_status is null or refCode.status = p_status)
            AND (p_ref_code is null or (refCode.ref_code) LIKE '%' || (p_ref_code) || '%')-- 4/5/2021 Bo tinh nang tim kiem ko dau
            AND (p_ref_name_vn is null or refCode.ref_name_vn LIKE '%' || p_ref_name_vn || '%')
            AND (p_ref_name_en is null or refCode.ref_name_en LIKE '%' || p_ref_name_en || '%')
            AND (p_description is null or refCode.description LIKE '%' || p_description || '%')
            AND (p_par1 is null or refCode.par1 = p_par1)
            AND (p_par2 is null or refCode.par2 = p_par2)
            AND (p_par3 is null or refCode.par3 = p_par3)
            AND (p_par4 is null or refCode.par4 = p_par4)
            AND (p_par5 is null or refCode.par5 = p_par5)
            AND (p_par6 is null or refCode.par6 = p_par6)
            AND (p_par7 is null or refCode.par7 = p_par7)
            AND (p_par8 is null or refCode.par8 = p_par8)
            AND (p_par9 is null or refCode.par9 = p_par9)
            AND (EXISTS (SELECT * FROM DATA_PERMISION XX WHERE refCode.REF_CODE_PERMISSION LIKE '%,'||XX.BRANCH||',%') OR P_USER IS NULL)
            ;
    ELSIF p_ref_group='LS_BRANCH_ALL' then --Danh sach toan bo Branch
       
    v_parameter := 'p_user:'|| p_user ||'|V_BRANCH_REPORT:'|| V_BRANCH_REPORT ||'|p_ref_group:'|| p_ref_group;
    pkg_system_log.pr_log_info ('pr_list_category', 'BEGIN', v_parameter);

        OPEN p_out FOR
        SELECT refCode.*, sysRef.REF_NAME_VN STATUS_STR
        FROM V_BRANCH refCode
        LEFT JOIN SYS_REFCODE sysRef on refCode.STATUS = sysRef.REF_CODE and sysRef.REF_GROUP = 'LS_STATUS'
        WHERE (p_status is null or refCode.status = p_status)
            AND (p_ref_code is null or (refCode.ref_code) LIKE '%' || (p_ref_code) || '%')-- 4/5/2021 Bo tinh nang tim kiem ko dau
            AND (p_ref_name_vn is null or refCode.ref_name_vn LIKE '%' || p_ref_name_vn || '%')
            AND (p_ref_name_en is null or refCode.ref_name_en LIKE '%' || p_ref_name_en || '%')
            AND (p_description is null or refCode.description LIKE '%' || p_description || '%')
            AND (p_par1 is null or refCode.par1 = p_par1)
            AND (p_par2 is null or refCode.par2 = p_par2)
            AND (p_par3 is null or refCode.par3 = p_par3)
            AND (p_par4 is null or refCode.par4 = p_par4)
            AND (p_par5 is null or refCode.par5 = p_par5)
            AND (p_par6 is null or refCode.par6 = p_par6)
            AND (p_par7 is null or refCode.par7 = p_par7)
            AND (p_par8 is null or refCode.par8 = p_par8)
            AND (p_par9 is null or refCode.par9 = p_par9);
    else -- Cac du lieu khac
        V_REF_GROUP := p_ref_group;
        IF p_ref_group='LS_PRODUCT' THEN
          SELECT ','|| listagg(','||NVL(GROUP_NAME,'')||',',', ') within group(order by GROUP_NAME) ||','
          INTO V_GROUP_NAME
          FROM SYS_USER A
          WHERE A.USER_NAME = P_USER;

          SELECT ','|| listagg(','||NVL(PAR2,'')||',',', ') within group(order by PAR2) ||',' INTO  V_PRODUCT_LIST
          FROM SYS_GROUPS A
          WHERE V_GROUP_NAME LIKE '%,'|| A.GROUP_NAME ||',%';
        END IF;
        IF p_ref_group='LS_PRODUCT_ALL' THEN
          V_REF_GROUP:='LS_PRODUCT';
        END IF;

        OPEN p_out FOR
        SELECT refCode.*, sysRef.REF_NAME_VN STATUS_STR
        FROM SYS_REFCODE refCode
        LEFT JOIN SYS_REFCODE sysRef on refCode.STATUS = sysRef.REF_CODE and sysRef.REF_GROUP = 'LS_STATUS'
        WHERE (p_status is null or refCode.status = p_status)
            AND (V_REF_GROUP is null or refCode.ref_group = V_REF_GROUP)
            AND (p_ref_code is null or (refCode.ref_code) LIKE '%' || (p_ref_code) || '%') -- 4/5/2021 Bo tinh nang tim kiem ko dau
            AND (p_ref_name_vn is null or (refCode.ref_name_vn) LIKE '%' || (p_ref_name_vn) || '%')-- 4/5/2021 Bo tinh nang tim kiem ko dau
--            AND (p_ref_name_vn is null or refCode.ref_name_vn LIKE '%' || p_ref_name_vn || '%')
            AND (p_ref_name_en is null or refCode.ref_name_en LIKE '%' || p_ref_name_en || '%')
            AND (p_description is null or pkg_utility.removesignvietnamess(refCode.description) LIKE '%' || pkg_utility.removesignvietnamess(p_description) || '%')
            AND (p_par1 is null or refCode.par1 = p_par1)
            AND (p_par2 is null or refCode.par2 = p_par2)
            AND (p_par3 is null or refCode.par3 = p_par3)
            AND (p_par4 is null or refCode.par4 = p_par4)
            AND (p_par5 is null or refCode.par5 = p_par5)
            AND (p_par6 is null or refCode.par6 = p_par6)
            AND (p_par7 is null or refCode.par7 = p_par7)
            AND (p_par8 is null or refCode.par8 = p_par8)
            AND (p_par9 is null or refCode.par9 = p_par9)
            AND (V_PRODUCT_LIST like '%,'|| refCode.REF_CODE ||',%' OR V_REF_GROUP<>'LS_PRODUCT' OR p_ref_group='LS_PRODUCT_ALL')
        order by refCode.PRIORITY, refCode.REF_NAME_VN;

    end if;

    END pr_list_category;

    PROCEDURE pr_category_info(p_ref_code sys_refcode.ref_code%TYPE,
                               p_ref_group sys_refcode.ref_group%TYPE,
                               p_out OUT types.ref_cursor)
    AS
    BEGIN
        OPEN p_out FOR select * from SYS_REFCODE
        Where ref_code = p_ref_code and REF_GROUP = p_ref_group;
    END pr_category_info;

    PROCEDURE pr_create_category(p_application_id SYS_REFCODE.APPLICATION_ID%TYPE,
                                    p_creater_date SYS_REFCODE.CREATER_DATE%TYPE,
                                    p_ref_code SYS_REFCODE.REF_CODE%TYPE,
                                    p_ref_group SYS_REFCODE.REF_GROUP%TYPE,
                                    p_ref_name_en SYS_REFCODE.REF_NAME_EN%TYPE,
                                    p_ref_name_vn SYS_REFCODE.REF_NAME_VN%TYPE,
                                    p_update_date SYS_REFCODE.UPDATE_DATE%TYPE,
                                    p_user_creater SYS_REFCODE.USER_CREATER%TYPE,
                                    p_user_update SYS_REFCODE.USER_UPDATE%TYPE,
                                    p_priority SYS_REFCODE.PRIORITY%TYPE,
                                    p_description SYS_REFCODE.DESCRIPTION%TYPE,
                                    p_par1 SYS_REFCODE.PAR1%TYPE,
                                    p_par2 SYS_REFCODE.PAR2%TYPE,
                                    p_par3 SYS_REFCODE.PAR3%TYPE,
                                    p_par4 SYS_REFCODE.PAR4%TYPE,
                                    p_par5 SYS_REFCODE.PAR5%TYPE,
                                    p_par6 SYS_REFCODE.PAR6%TYPE,
                                    p_par7 SYS_REFCODE.PAR7%TYPE,
                                    p_par8 SYS_REFCODE.PAR8%TYPE,
                                    p_par9 SYS_REFCODE.PAR9%TYPE,
                                    p_allowdelete SYS_REFCODE.ALLOWDELETE%TYPE,
                                    p_update_reason SYS_REFCODE.UPDATE_REASON%TYPE,
                                    p_status SYS_REFCODE.STATUS%TYPE,
                                    p_create_reason SYS_REFCODE.CREATE_REASON%TYPE,
                                    p_user                         IN     VARCHAR2,
                                    p_client_ip                    IN     VARCHAR2,
                                    p_user_agent                   IN     VARCHAR2,
                                    p_out OUT types.ref_cursor)
    AS
    BEGIN
        INSERT INTO SYS_REFCODE (APPLICATION_ID,
                                CREATER_DATE,
                                REF_CODE,
                                REF_GROUP,
                                REF_NAME_EN,
                                REF_NAME_VN,
                                --UPDATE_DATE,
                                USER_CREATER,
                                --USER_UPDATE,
                                PRIORITY,
                                DESCRIPTION,
                                PAR1,
                                PAR2,
                                PAR3,
                                PAR4,
                                PAR5,
                                PAR6,
                                PAR7,
                                PAR8,
                                PAR9,
                                ALLOWDELETE,
                                UPDATE_REASON,
                                STATUS,
                                CREATE_REASON)
        VALUES(p_application_id , --APPLICATION_ID
                sysdate , --CREATER_DATE
                p_ref_code , --REF_CODE
                p_ref_group , --REF_GROUP
                p_ref_name_en , --REF_NAME_EN
                p_ref_name_vn , --REF_NAME_VN
                --p_update_date , --UPDATE_DATE
                p_user , --USER_CREATER
               -- p_user_update , --USER_UPDATE
                p_priority , --PRIORITY
                p_description , --DESCRIPTION
                p_par1 , --PAR1
                p_par2 , --PAR2
                p_par3 , --PAR3
                p_par4 , --PAR4
                p_par5 , --PAR5
                p_par6 , --PAR6
                p_par7 , --PAR7
                p_par8 , --PAR8
                p_par9 , --PAR9
                p_allowdelete , --ALLOWDELETE
                p_update_reason , --UPDATE_REASON
                p_status , --STATUS
                p_create_reason --CREATE_REASON
                );
        OPEN p_out FOR select * from SYS_REFCODE
        Where ref_code = p_ref_code and REF_GROUP = p_ref_group;
    END pr_create_category;

    PROCEDURE pr_update_category(p_application_id SYS_REFCODE.APPLICATION_ID%TYPE,
                                    p_creater_date SYS_REFCODE.CREATER_DATE%TYPE,
                                    p_ref_code SYS_REFCODE.REF_CODE%TYPE,
                                    p_ref_group SYS_REFCODE.REF_GROUP%TYPE,
                                    p_ref_name_en SYS_REFCODE.REF_NAME_EN%TYPE,
                                    p_ref_name_vn SYS_REFCODE.REF_NAME_VN%TYPE,
                                    p_update_date SYS_REFCODE.UPDATE_DATE%TYPE,
                                    p_user_creater SYS_REFCODE.USER_CREATER%TYPE,
                                    p_user_update SYS_REFCODE.USER_UPDATE%TYPE,
                                    p_priority SYS_REFCODE.PRIORITY%TYPE,
                                    p_description SYS_REFCODE.DESCRIPTION%TYPE,
                                    p_par1 SYS_REFCODE.PAR1%TYPE,
                                    p_par2 SYS_REFCODE.PAR2%TYPE,
                                    p_par3 SYS_REFCODE.PAR3%TYPE,
                                    p_par4 SYS_REFCODE.PAR4%TYPE,
                                    p_par5 SYS_REFCODE.PAR5%TYPE,
                                    p_par6 SYS_REFCODE.PAR6%TYPE,
                                    p_par7 SYS_REFCODE.PAR7%TYPE,
                                    p_par8 SYS_REFCODE.PAR8%TYPE,
                                    p_par9 SYS_REFCODE.PAR9%TYPE,
                                    p_allowdelete SYS_REFCODE.ALLOWDELETE%TYPE,
                                    p_update_reason SYS_REFCODE.UPDATE_REASON%TYPE,
                                    p_status SYS_REFCODE.STATUS%TYPE,
                                    p_create_reason SYS_REFCODE.CREATE_REASON%TYPE,
                                    p_user                         IN     VARCHAR2,
                                    p_client_ip                    IN     VARCHAR2,
                                    p_user_agent                   IN     VARCHAR2,
                                    p_out OUT types.ref_cursor)
    AS
    BEGIN
        UPDATE sys_refcode
        SET APPLICATION_ID=p_application_id,
            REF_NAME_EN=p_ref_name_en,
            REF_NAME_VN=p_ref_name_vn,
            UPDATE_DATE=sysdate,
            USER_UPDATE=p_user,
            PRIORITY=p_priority,
            DESCRIPTION=p_description,
            PAR1=p_par1,
            PAR2=p_par2,
            PAR3=p_par3,
            PAR4=p_par4,
            PAR5=p_par5,
            PAR6=p_par6,
            PAR7=p_par7,
            PAR8=p_par8,
            PAR9=p_par9,
            ALLOWDELETE=p_allowdelete,
            UPDATE_REASON=p_update_reason,
            STATUS=p_status,
            CREATE_REASON=p_create_reason
        WHERE ref_code = p_ref_code and ref_group = p_ref_group;
        OPEN p_out FOR select * from SYS_REFCODE
        Where ref_code = p_ref_code and REF_GROUP = p_ref_group;
    END pr_update_category;


    PROCEDURE pr_list_product_category (p_status sys_refcode.status%TYPE ,
                              p_ref_group sys_refcode.ref_group%TYPE,
                              p_ref_code sys_refcode.ref_code%TYPE,
                              p_ref_name_vn sys_refcode.ref_name_vn%TYPE,
                              p_ref_name_en sys_refcode.ref_name_en%TYPE,
                              p_description sys_refcode.description%TYPE,
                              p_par1 sys_refcode.par1%TYPE,
                              p_par2 sys_refcode.par2%TYPE,
                              p_par3 sys_refcode.par3%TYPE,
                              p_par4 sys_refcode.par4%TYPE,
                              p_par5 sys_refcode.par5%TYPE,
                              p_par6 sys_refcode.par6%TYPE,
                              p_par7 sys_refcode.par7%TYPE,
                              p_par8 sys_refcode.par8%TYPE,
                              p_par9 sys_refcode.par9%TYPE,
                              p_out OUT types.ref_cursor)
    AS
    BEGIN
        OPEN p_out FOR
        SELECT refCode.*, sysRef.REF_NAME_VN STATUS_STR, sysRefCusType.REF_NAME_VN CUSTOMER_TYPE_STR
        FROM SYS_REFCODE refCode
        LEFT JOIN SYS_REFCODE sysRef on refCode.STATUS = sysRef.REF_CODE and sysRef.REF_GROUP = 'LS_STATUS'
        LEFT JOIN SYS_REFCODE sysRefCusType on REFCODE.PAR2 = sysRefCusType.REF_CODE and sysRefCusType.REF_GROUP = 'LOAI_KH'
        WHERE (p_status is null or refCode.status = p_status)
            AND (p_ref_group is null or refCode.ref_group = p_ref_group)
            AND (p_ref_code is null or (refCode.ref_code) LIKE '%' || (p_ref_code) || '%') -- 4/5/2021 Bo tinh nang tim kiem ko dau
            AND (p_ref_name_vn is null or pkg_utility.removesignvietnamess(refCode.ref_name_vn) LIKE '%' || pkg_utility.removesignvietnamess(p_ref_name_vn) || '%')
            AND (p_ref_name_en is null or refCode.ref_name_en LIKE '%' || p_ref_name_en || '%')
            AND (p_description is null or refCode.description LIKE '%' || p_description || '%')
            AND (p_par1 is null or refCode.par1 = p_par1)
            AND (p_par2 is null or refCode.par2 = p_par2)
            AND (p_par3 is null or refCode.par3 = p_par3)
            AND (p_par4 is null or refCode.par4 = p_par4)
            AND (p_par5 is null or refCode.par5 = p_par5)
            AND (p_par6 is null or refCode.par6 = p_par6)
            AND (p_par7 is null or refCode.par7 = p_par7)
            AND (p_par8 is null or refCode.par8 = p_par8)
            AND (p_par9 is null or refCode.par9 = p_par9)
        order by refCode.par1, refCode.ref_code;
    END pr_list_product_category;

PROCEDURE pr_category_his (  p_ref_group sys_refcode.ref_group%TYPE,
                                p_ref_code sys_refcode.ref_code%TYPE,
                            p_user         IN     VARCHAR2,
                            p_client_ip    IN     VARCHAR2,
                            p_user_agent   IN     VARCHAR2,
                            p_out             OUT types.ref_cursor)
    AS
    BEGIN
    IF p_ref_group = 'CIS_PRICE' THEN
        OPEN p_out FOR
        SELECT A.PRICE_CODE REF_CODE
                ,TO_CHAR(A.EFFECTIVE_DATE,'DD/MM/YYYY') PAR1
                ,TO_CHAR(A.EXPIRATION_DATE,'DD/MM/YYYY') PAR2
                ,PKG_UTILITY.FORMAT_NUMBER(A.NORMAL_PRICE) PAR3
                ,PKG_UTILITY.FORMAT_NUMBER(A.NON_NORMAL_PRICE) PAR4
                ,A.UPDATE_DATE UPDATE_DATE
                ,A.USER_UPDATE USER_UPDATE
        FROM SYS_PRICE_HIS A
        WHERE A.ID=p_ref_code
        order by a.id_his desc;
    ELSE
        OPEN p_out FOR
            SELECT *
              FROM SYS_REFCODE_HIS
         WHERE  LOWER(ref_group) = LOWER(p_ref_group) AND LOWER(ref_code) = LOWER(p_ref_code)  order by ACTION_DT desc;
    END IF;
    END;
END PKG_REF_CODE;

/
--------------------------------------------------------
--  DDL for Package Body PKG_SYS_EMAIL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PKG_SYS_EMAIL" 
AS
    V_PARAMETER   NVARCHAR2 (4000);
    V_ERRORS      NUMBER (10);

    /******************************************************************************
       NAME:       PKG_SYS_EMAIL
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        5/3/2018      admin       1. Created this package body.
    ******************************************************************************/


    PROCEDURE pr_create_sys_email (
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        --p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        --p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        --p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        --p_status                   SYS_EMAIL.STATUS%TYPE,
        --p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        --p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        --p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
        v_id   SYS_EMAIL.id%TYPE;
    BEGIN
        v_parameter := ', p_channel:'
            || p_channel
            || ', p_subject:'
            || p_subject
            || ', p_email_bcc:'
            || p_email_bcc
            || ', p_email_cc:'
            || p_email_cc
            || ', p_email_to:'
            || p_email_to
            || ', p_email_sender:'
            || p_email_sender
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;
        v_id := seq_sys_email.NEXTVAL;
        pkg_system_log.pr_log_info ('pr_create_sys_email',
                                    'BEGIN',
                                    v_parameter); 

        INSERT INTO SYS_EMAIL (ID,
                               EMAIL_SENDER,
                               EMAIL_TO,
                               EMAIL_CC,
                               EMAIL_BCC,
                               SUBJECT,
                               BODY,
                               --SEND_TIME,
                               --NUMBER_RETRY,
                               --LAST_RETRY,
                               STATUS,
                               CREATED_DATE,
                               MAKER,
                               CHANNEL)
             VALUES (v_id,                                                --ID
                     p_email_sender,                            --EMAIL_SENDER
                     p_email_to,                                    --EMAIL_TO
                     p_email_cc,                                    --EMAIL_CC
                     p_email_bcc,                                  --EMAIL_BCC
                     p_subject,                                      --SUBJECT
                     p_body,                                            --BODY
                     --p_send_time,                                  --SEND_TIME
                     --p_number_retry,                            --NUMBER_RETRY
                     --p_last_retry,                                --LAST_RETRY
                     'NEW',                                        --STATUS
                     SYSDATE,                            --CREATED_DATE
                     p_user,                                          --MAKER
                     p_channel);

        OPEN p_out FOR SELECT ID,
                              EMAIL_SENDER,
                              EMAIL_TO,
                              EMAIL_CC,
                              EMAIL_BCC,
                              SUBJECT,
                              BODY
                         FROM SYS_EMAIL
                        WHERE id = v_id;

        pkg_system_log.pr_log_info ('pr_create_sys_email',
                                    'END',
                                    v_parameter); 

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_create_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;

            RAISE;
    END;


    PROCEDURE pr_get_list_sys_email (
        p_text_search              VARCHAR2,
        p_status              VARCHAR2,
        p_from_date                DATE,
        p_to_date                  DATE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
        v_text_search varchar2(4000);
    BEGIN
        v_parameter := ', p_text_search:'
            || p_text_search
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        pkg_system_log.pr_log_info ('pr_get_list_sys_email', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email', 'BEGIN', v_parameter);
        v_text_search := '%'||pkg_utility.removesignvietnamess(nvl(p_text_search,''))||'%';

        OPEN p_out FOR   SELECT ID,
                                EMAIL_SENDER,
                                EMAIL_TO,
                                EMAIL_CC,
                                EMAIL_BCC,
                                SUBJECT,
                                BODY,
                                SEND_TIME,
                                NUMBER_RETRY,
                                LAST_RETRY,
                                A.STATUS,
                                nvl(B.REF_NAME_VN,'N/A') STATUS_NAME,
                                CREATED_DATE,
                                MAKER,
                                CHANNEL,
                                case when a.status = 'SENT' then ' ' else substr(ERROR_MESSENGER,1,80) end ERROR_MESSENGER
                           FROM SYS_EMAIL A
                                LEFT JOIN SYS_refcode B ON A.STATUS=B.REF_CODE AND B.REF_GROUP ='EMAIL_STATUS'
                          WHERE (','||p_status||',' like '%,'||A.STATUS||',%' or p_status is null)
                                and pkg_utility.removesignvietnamess(nvl(maker,'')||','||nvl(EMAIL_TO,'')||','||nvl(SUBJECT,'')) like v_text_search
                                and trunc(nvl(SEND_TIME,CREATED_DATE)) between nvl(p_from_date,sysdate-100) and nvl(p_to_date,sysdate+1)
                          
                       ORDER BY CREATED_DATE DESC;


        pkg_system_log.pr_log_info ('pr_get_list_sys_email',
                                    'END',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email',
                                     'END',
                                     v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_get_list_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;
    END;

    PROCEDURE pr_update_sys_email (
        p_id                       SYS_EMAIL.ID%TYPE,
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        p_status                   SYS_EMAIL.STATUS%TYPE,
        p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
    BEGIN
        v_parameter :=
               ', p_error_messenger:'
            || p_error_messenger
            || ', p_channel:'
            || p_channel
            || ', p_maker:'
            || p_maker
            || ', p_created_date:'
            || p_created_date
            || ', p_status:'
            || p_status
            || ', p_last_retry:'
            || p_last_retry
            || ', p_number_retry:'
            || p_number_retry
            || ', p_send_time:'
            || p_send_time
            || ', p_subject:'
            || p_subject
            || ', p_email_bcc:'
            || p_email_bcc
            || ', p_email_cc:'
            || p_email_cc
            || ', p_email_to:'
            || p_email_to
            || ', p_email_sender:'
            || p_email_sender
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        pkg_system_log.pr_log_info ('pr_update_sys_email',
                                    'BEGIN',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_update_sys_email0',
                                     'BEGIN',
                                     v_parameter);

        UPDATE SYS_EMAIL
           SET --ID = p_id,
               --EMAIL_SENDER = p_email_sender,
               --EMAIL_TO = p_email_to,
               --EMAIL_CC = p_email_cc,
               --EMAIL_BCC = p_email_bcc,
               --SUBJECT = p_subject,
               --BODY = p_body,
               SEND_TIME = p_send_time,
               NUMBER_RETRY = p_number_retry,
               LAST_RETRY = sysdate,
               STATUS = case when p_status='SENDED' then 'SENT' else p_status end,
               --CREATED_DATE = p_created_date,
               --MAKER = p_maker,
               --CHANNEL = p_channel,
               ERROR_MESSENGER = p_error_messenger
         WHERE id = p_id;

        OPEN p_out FOR SELECT ID,
                              EMAIL_SENDER,
                              EMAIL_TO,
                              EMAIL_CC,
                              EMAIL_BCC,
                              SUBJECT,
                              BODY
                         FROM SYS_EMAIL
                        WHERE id = p_id;

        pkg_system_log.pr_log_info ('pr_create_sys_email',
                                    'END',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_create_sys_email',
                                     'END',
                                     v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_create_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;

            RAISE;
    END;

    PROCEDURE pr_get_sys_email_by_id (
        p_id                       SYS_EMAIL.ID%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
    BEGIN
        v_parameter :=

             'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        pkg_system_log.pr_log_info ('pr_get_list_sys_email',
                                    'BEGIN',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email',
                                     'BEGIN',
                                     v_parameter);

        OPEN p_out FOR   SELECT ID,
                                EMAIL_SENDER,
                                EMAIL_TO,
                                EMAIL_CC,
                                EMAIL_BCC,
                                SUBJECT,
                                BODY,
                                SEND_TIME,
                                NUMBER_RETRY,
                                LAST_RETRY,
                                STATUS,
                                CREATED_DATE,
                                MAKER,
                                CHANNEL,
                                ERROR_MESSENGER
                           FROM SYS_EMAIL
                          WHERE ID = p_id
                       ORDER BY CREATED_DATE ASC;


        pkg_system_log.pr_log_info ('pr_get_list_sys_email',
                                    'END',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email',
                                     'END',
                                     v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_get_list_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;
    END;

    

    PROCEDURE pr_create_sys_email_2 (
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        p_status                   SYS_EMAIL.STATUS%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2)
    AS
        v_id   SYS_EMAIL.id%TYPE;
    BEGIN
        v_parameter :=
            'p_status:'
            || p_status
            || ', p_body:'
            || p_body
            || ', p_subject:'
            || p_subject
            || ', p_email_to:'
            || p_email_to
            || ', p_email_sender:'
            || p_email_sender
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;
        v_id := seq_sys_email.NEXTVAL;
        pkg_system_log.pr_log_info ('pr_create_sys_email_2',
                                    'BEGIN',
                                    v_parameter);

        INSERT INTO SYS_EMAIL (ID,
                               EMAIL_SENDER,
                               EMAIL_TO,
                               SUBJECT,
                               BODY,
                               STATUS,
                               CREATED_DATE,
                               MAKER)
             VALUES (v_id,                                                --ID
                     p_email_sender,                            --EMAIL_SENDER
                     p_email_to,                                 --EMAIL_BCC
                     p_subject,                                      --SUBJECT
                     p_body,                              --LAST_RETRY
                     p_status,                                        --STATUS
                     SysDate,                            --CREATED_DATE
                     p_user);

        pkg_system_log.pr_log_info ('pr_create_sys_email_2',
                                    'END',
                                    v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_create_sys_email_2',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));
            END LOOP;

            RAISE;
    END;

--G?i email th�ng b�o kh?i t?o/di?u ch?nh user
PROCEDURE PR_SEND_EMAIL_USER (P_USER_ID                 VARCHAR2,
                              P_ACTION                  VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(100);
V_FULL_NAME VARCHAR2(100);
P_OUT TYPES.REF_CURSOR;
V_DOMAIN_ICREDIT VARCHAR2(1000); 
V_BODY CLOB;
BEGIN
  
--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t�i kho?n' ELSE 'T�i kho?n ???c c?p nh?t' END;

SELECT A.EMAIL
       ,CASE WHEN P_ACTION='CREATE' THEN A.CREATE_USER ELSE A.LAST_UPDATE_USER END USER_THUC_HIEN
       ,A.FULL_NAME 

INTO V_EMAIL_TO,V_USER,V_FULL_NAME
FROM SYS_USER A
WHERE A.USER_NAME=lower(P_USER_ID);

SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! '|| P_ACTION) INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_SYS_USER_BODY_'||P_ACTION;

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! '|| P_ACTION) INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_SYS_USER_SUB_'||P_ACTION;

SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';


V_BODY := REPLACE(REPLACE(V_BODY,'[FULL_NAME]',V_FULL_NAME),'[DOMAIN]',V_DOMAIN_ICREDIT);

PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('USER',
                                  V_EMAIL_TO,
                                  '',
                                  '',
                                  V_SUBJECT,
                                  V_BODY,--BODY
                                  'SYSTEM',
                                  V_USER,
                                  '',
                                  '',
                                  P_OUT);
--COMMIT;
END;

--G?i email th�ng b�o kh?i t?o/di?u ch?nh user
PROCEDURE PR_SEND_EMAIL_RESPONSE (P_CIS_NO                  VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(100);
V_FULL_NAME VARCHAR2(100); 
P_OUT TYPES.REF_CURSOR;
V_DOMAIN_ICREDIT VARCHAR2(1000); 
V_BODY CLOB;
BEGIN
  
--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t�i kho?n' ELSE 'T�i kho?n ???c c?p nh?t' END;
 
SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! ') INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_RESPONSE_BODY';

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! ') INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_RESPONSE_SUB';


SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';



FOR R_ROW IN (
                  SELECT B.EMAIL
                         ,B.FULL_NAME  
                         , A.CREATED_USER 
                         ,C.CHANNEL
                         ,NVL(D.REF_NAME_VN,C.STATUS) STATUS_NAME
                  --INTO V_EMAIL_TO,V_FULL_NAME, V_USER
                  FROM CIS_REQUEST_EMAIL A
                  LEFT JOIN SYS_USER B ON A.CREATED_USER=B.USER_NAME
                  LEFT JOIN CIS_REQUEST C ON A.CIS_NO=C.CIS_NO
                  LEFT JOIN sys_refcode D ON C.STATUS=D.REF_CODE AND D.REF_GROUP='STATUS_REQUEST'
                  WHERE A.CIS_NO=P_CIS_NO )
LOOP
 

    --V_BODY := REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME);

    PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('REQUEST',
                                      R_ROW.EMAIL,
                                      '',
                                      '',
                                      REPLACE(V_SUBJECT,'[CIS_NO]', P_CIS_NO),
                                      REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME),'[CIS_NO]', P_CIS_NO),'[CHANNEL]', R_ROW.CHANNEL),'[STATUS_NAME]', R_ROW.STATUS_NAME),'[DOMAIN]',V_DOMAIN_ICREDIT),--BODY
                                      'SYSTEM',
                                      R_ROW.CREATED_USER,
                                      '',
                                      '',
                                      P_OUT);
--COMMIT;
END LOOP;

END;

--G?i email th�ng b�o ph� duy?t b?n tin
PROCEDURE PR_SEND_EMAIL_TASK(P_TASK_ID VARCHAR2, P_STATUS VARCHAR2 , P_USER VARCHAR2, P_COMMENT VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(500);
V_FULL_NAME VARCHAR2(100); 
V_DOMAIN_ICREDIT VARCHAR2(1000); 
P_OUT TYPES.REF_CURSOR;
V_BODY CLOB; 
BEGIN
  
--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t�i kho?n' ELSE 'T�i kho?n ???c c?p nh?t' END;
 
SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! ') INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_TASK_'|| P_STATUS;

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! ') INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_TASK_'||P_STATUS||'_SUB';

SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';

FOR R_ROW IN (
                  SELECT A.ID, B.EMAIL
                         ,B.FULL_NAME  
                         , A.MAKER 
                         ,CASE WHEN P_STATUS='APPROVED' THEN 'B?n tin ???c ph� duy?t'
                               WHEN P_STATUS='REJECTED' THEN 'B?n tin b? t? ch?i'
                               ELSE 'N/A' END STATUS_NAME
                  --INTO V_EMAIL_TO,V_FULL_NAME, V_USER
                  FROM SYS_TASK_LIST A
                  LEFT JOIN SYS_USER B ON A.MAKER=B.USER_NAME 
                  WHERE A.TASK_ID=P_TASK_ID)
LOOP
 

    --V_BODY := REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME);

    PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('TASK',
                                      R_ROW.EMAIL,
                                      '',
                                      '',
                                      REPLACE(REPLACE(V_SUBJECT,'[TASK_ID]', 'LO'||P_TASK_ID),'[STATUS_NAME]', R_ROW.STATUS_NAME),
                                      REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME),'[TASK_ID]', 'LO'||R_ROW.ID),'[STATUS_NAME]', R_ROW.STATUS_NAME),'[COMMENT]',P_COMMENT),'[DOMAIN]',V_DOMAIN_ICREDIT),--BODY
                                      'SYSTEM',
                                      P_USER,
                                      '',
                                      '',
                                      P_OUT);
--COMMIT;
END LOOP;

END;


--G?i email th�ng b�o cho ng??i d�ng bi?t c� file m?i
PROCEDURE PR_SEND_EMAIL_NEW_FILE(P_FILE_NAME VARCHAR2, P_CHANNEL VARCHAR2, P_STATUS VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(500);
V_FULL_NAME VARCHAR2(100); 
V_DOMAIN_ICREDIT VARCHAR2(1000); 
P_OUT TYPES.REF_CURSOR;
V_BODY CLOB; 
BEGIN
  
--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t�i kho?n' ELSE 'T�i kho?n ???c c?p nh?t' END;
 
SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! ') INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_REPORT_'||P_CHANNEL||'_'||P_STATUS;

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! ') INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_REPORT_'||P_CHANNEL||'_'||P_STATUS||'_SUB';

SELECT NVL(MAX(A.PAR1),'') INTO V_EMAIL_TO
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_REPORT_'||P_CHANNEL||'_'||P_STATUS||'_EMAIL_TO';

SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';

IF V_EMAIL_TO IS NOT NULL THEN

    PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('REPORT_'||P_CHANNEL,
                                      V_EMAIL_TO,
                                      '',
                                      '',
                                      REPLACE(V_SUBJECT,'[FILE_NAME]', P_FILE_NAME),
                                      REPLACE(REPLACE(V_BODY,'[FILE_NAME]', P_FILE_NAME),'[DOMAIN]',V_DOMAIN_ICREDIT),--BODY
                                      'SYSTEM',
                                      'N/A',
                                      '',
                                      '',
                                      P_OUT);
--COMMIT;
END IF;

END;

    PROCEDURE pr_get_list_sys_email_to_send (
        p_text_search              VARCHAR2,
        p_status              VARCHAR2,
        p_from_date                DATE,
        p_to_date                  DATE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
        v_text_search varchar2(4000);
    BEGIN
        v_parameter := ', p_text_search:'
            || p_text_search
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        v_text_search := '%'||pkg_utility.removesignvietnamess(nvl(p_text_search,''))||'%';

        OPEN p_out FOR   SELECT ID,
                                EMAIL_SENDER,
                                EMAIL_TO,
                                EMAIL_CC,
                                EMAIL_BCC,
                                SUBJECT,
                                BODY,
                                SEND_TIME,
                                NUMBER_RETRY,
                                LAST_RETRY,
                                A.STATUS,
                                nvl(B.REF_NAME_VN,'N/A') STATUS_NAME,
                                CREATED_DATE,
                                MAKER,
                                CHANNEL,
                                substr(ERROR_MESSENGER,1,80) ERROR_MESSENGER
                           FROM SYS_EMAIL A
                                LEFT JOIN SYS_refcode B ON A.STATUS=B.REF_CODE AND B.REF_GROUP ='EMAIL_STATUS'
                          WHERE (','||p_status||',' like '%,'||A.STATUS||',%' or p_status is null)
                                and pkg_utility.removesignvietnamess(nvl(maker,'')||','||nvl(EMAIL_TO,'')||','||nvl(SUBJECT,'')) like v_text_search
                                and trunc(nvl(SEND_TIME,CREATED_DATE)) between nvl(p_from_date,sysdate-10) and nvl(p_to_date,sysdate+1)
                                and (NUMBER_RETRY IS NULL OR NUMBER_RETRY < 4)
                          
                       ORDER BY CREATED_DATE DESC;


    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_get_list_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;
    END;
END PKG_SYS_EMAIL;

/
--------------------------------------------------------
--  DDL for Package Body PKG_SYS_GROUP_ACTIONS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PKG_SYS_GROUP_ACTIONS" 
  -- Author  : DONB
  -- Created : 17/06/2019 4:01:04 PM
  -- Purpose :
IS
    v_parameter   NVARCHAR2 (4000);
    v_errors      NUMBER (10);
    
    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: Th�m m?i SYS_GROUP_ACTIONS
    Parameter:
                p_group_id: 
                p_res_action_id: 
                p_update_dt: 
                p_create_dt: 
                p_create_usr: 
                p_update_usr: 
                p_user:
                p_client_ip:
                p_user_agent:
    */
    PROCEDURE pr_create_sys_group_actions (p_group_id SYS_GROUP_ACTIONS.GROUP_ID%TYPE,
                                            p_res_action_id SYS_GROUP_ACTIONS.RES_ACTION_ID%TYPE,
                                            p_update_dt SYS_GROUP_ACTIONS.UPDATE_DT%TYPE,
                                            p_create_dt SYS_GROUP_ACTIONS.CREATE_DT%TYPE,
                                            p_create_usr SYS_GROUP_ACTIONS.CREATE_USR%TYPE,
                                            p_update_usr SYS_GROUP_ACTIONS.UPDATE_USR%TYPE,
                                            p_user               IN     VARCHAR2,
                                            p_client_ip          IN     VARCHAR2,
                                            p_user_agent         IN     VARCHAR2,
                                            p_out                   OUT types.ref_cursor)
    IS
        p_id   SYS_GROUP_ACTIONS.id%TYPE;
    BEGIN
        v_parameter :='p_update_usr:'|| p_update_usr
                        ||', p_create_usr:'|| p_create_usr
                        ||', p_create_dt:'|| p_create_dt
                        ||', p_update_dt:'|| p_update_dt
                        ||', p_res_action_id:'|| p_res_action_id
                        ||', p_group_id:'|| p_group_id
                        || 'p_user:'
                        || p_user
                        || '|p_client_ip:'
                        || p_client_ip
                        || '|p_user_agent:'
                        || p_user_agent;
        p_id := SEQ_SYS_GROUP_ACTIONS.NEXTVAL;
        --pkg_system_log.pr_log_info ('pr_create_mm_fp_fn', 'BEGIN', v_parameter);
        --pkg_system_log.pr_log_debug ('pr_create_mm_fp_fn', 'BEGIN', v_parameter);

        INSERT INTO SYS_GROUP_ACTIONS (GROUP_ID, 
                                        RES_ACTION_ID, 
                                        ID, 
                                        UPDATE_DT, 
                                        CREATE_DT, 
                                        CREATE_USR, 
                                        UPDATE_USR)
        VALUES (p_group_id , --GROUP_ID
                    p_res_action_id , --RES_ACTION_ID
                    p_id , --ID
                    p_update_dt , --UPDATE_DT
                    sysdate , --CREATE_DT
                    p_create_usr , --CREATE_USR
                    p_update_usr  --UPDATE_USR
                );

        --Them menu level cap 2
        INSERT INTO SYS_GROUP_ACTIONS (ID,
                                        GROUP_ID, 
                                        RES_ACTION_ID,
                                        CREATE_DT)
        select SEQ_SYS_GROUP_ACTIONS.NEXTVAL, GROUP_ID, RES_ACTION_ID, SYSDATE
        from (select distinct p_group_id GROUP_ID, RES_ID RES_ACTION_ID
                from SYS_RESOURCES A
                where RES_ID in (select PARENT_ID
                                        from SYS_RESOURCES
                                        where RES_ID=p_res_action_id)
                     and RES_ID not in (select RES_ACTION_ID from SYS_GROUP_ACTIONS where GROUP_ID=p_group_id));

        --Them menu level cap 1
        INSERT INTO SYS_GROUP_ACTIONS (ID,
                                        GROUP_ID, 
                                        RES_ACTION_ID,
                                        CREATE_DT)
        select SEQ_SYS_GROUP_ACTIONS.NEXTVAL,GROUP_ID, RES_ACTION_ID, SYSDATE
        from (select distinct p_group_id GROUP_ID, RES_ID RES_ACTION_ID
                from SYS_RESOURCES A
                where RES_ID in (select PARENT_ID
                                        from SYS_RESOURCES
                                        where RES_ID in (select PARENT_ID
                                                                from SYS_RESOURCES
                                                                where RES_ID=p_res_action_id))
                     and RES_ID not in (select RES_ACTION_ID from SYS_GROUP_ACTIONS where GROUP_ID=p_group_id));
--
        OPEN p_out FOR
            SELECT *
              FROM SYS_GROUP_ACTIONS
             WHERE id = p_id;

        --pkg_system_log.pr_log_info ('pr_create_mm_fp_fn', 'END', v_parameter);
        --pkg_system_log.pr_log_debug ('pr_create_mm_fp_fn', 'END', v_parameter);
--    EXCEPTION                                                                                                                                       -- exception handlers begin
--        WHEN OTHERS
--        THEN                                                                                                                                        -- handles all other errors
--            v_errors := SQL%BULK_EXCEPTIONS.COUNT;
--
--            FOR i IN 1 .. v_errors
--            LOOP
--                pkg_system_log.pr_log_exception ('pr_create_mm_fp_fn',
--                                                 'EXCEPTION',
--                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
--                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));
--
--
--            END LOOP;
--
--            RAISE;
    END;
    
    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: C?p nh?t SYS_GROUP_ACTIONS
    Parameter:
                p_group_id: 
                p_res_action_id: 
                p_id: 
                p_update_dt: 
                p_create_dt: 
                p_create_usr: 
                p_update_usr: 
                p_user:
                p_client_ip:
                p_user_agent:

    */
    PROCEDURE pr_update_sys_group_actions (p_group_id SYS_GROUP_ACTIONS.GROUP_ID%TYPE,
                                            p_res_action_id SYS_GROUP_ACTIONS.RES_ACTION_ID%TYPE,
                                            p_id SYS_GROUP_ACTIONS.ID%TYPE,
                                            p_update_dt SYS_GROUP_ACTIONS.UPDATE_DT%TYPE,
                                            p_create_dt SYS_GROUP_ACTIONS.CREATE_DT%TYPE,
                                            p_create_usr SYS_GROUP_ACTIONS.CREATE_USR%TYPE,
                                            p_update_usr SYS_GROUP_ACTIONS.UPDATE_USR%TYPE,
                                            p_user               IN     VARCHAR2,
                                            p_client_ip          IN     VARCHAR2,
                                            p_user_agent         IN     VARCHAR2,
                                            p_out                   OUT types.ref_cursor)
    IS

    BEGIN
        v_parameter :='p_update_usr:'|| p_update_usr
                        ||', p_create_usr:'|| p_create_usr
                        ||', p_create_dt:'|| p_create_dt
                        ||', p_update_dt:'|| p_update_dt
                        ||', p_id:'|| p_id
                        ||', p_res_action_id:'|| p_res_action_id
                        ||', p_group_id:'|| p_group_id
                        || 'p_user:'
                        || p_user
                        || '|p_client_ip:'
                        || p_client_ip
                        || '|p_user_agent:'
                        || p_user_agent;

--        pkg_system_log.pr_log_info ('pr_update_mm_fp_fn', 'BEGIN', v_parameter);
--        pkg_system_log.pr_log_debug ('pr_update_mm_fp_fn', 'BEGIN', v_parameter);

        UPDATE SYS_GROUP_ACTIONS
           SET GROUP_ID = p_group_id,
               RES_ACTION_ID = p_res_action_id,
               UPDATE_DT = sysdate
         WHERE id = p_id;

        OPEN p_out FOR
            SELECT *
              FROM SYS_GROUP_ACTIONS
             WHERE id = p_id;

--        pkg_system_log.pr_log_info ('pr_update_mm_fp_fn', 'END', v_parameter);
--        pkg_system_log.pr_log_debug ('pr_update_mm_fp_fn', 'END', v_parameter);
--    EXCEPTION                                                                                                                                       -- exception handlers begin
--        WHEN OTHERS
--        THEN                                                                                                                                        -- handles all other errors
--            v_errors := SQL%BULK_EXCEPTIONS.COUNT;
--
--            FOR i IN 1 .. v_errors
--            LOOP
--                pkg_system_log.pr_log_exception ('pr_update_mm_fp_fn',
--                                                 'EXCEPTION',
--                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
--                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));
--
--
--            END LOOP;
--
--            RAISE;
    END;

    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y danh s�ch SYS_GROUP_ACTIONS
    Parameter:
                p_group_id: 
                p_res_action_id: 
                p_id: 
                p_user:
                p_client_ip:
                p_user_agent:

    */
    PROCEDURE pr_get_list_sys_group_actions (p_group_id SYS_GROUP_ACTIONS.GROUP_ID%TYPE,
                                                p_res_action_id SYS_GROUP_ACTIONS.RES_ACTION_ID%TYPE,
                                                p_id SYS_GROUP_ACTIONS.ID%TYPE,
                                                p_user               IN     VARCHAR2,
                                                p_client_ip          IN     VARCHAR2,
                                                p_user_agent         IN     VARCHAR2,
                                                p_out                   OUT types.ref_cursor)   IS

    BEGIN
        v_parameter := ', p_group_id:'
                        || p_group_id
                        || ', p_res_action_id:'
                        || p_res_action_id
                        || ', p_id:'
                        || p_id
                        || 'p_user:'
                        || p_user
                        || '|p_client_ip:'
                        || p_client_ip
                        || '|p_user_agent:'
                        || p_user_agent;

--        pkg_system_log.pr_log_info ('pr_get_list_mm_fp_fn', 'BEGIN', v_parameter);
--        pkg_system_log.pr_log_debug ('pr_get_list_mm_fp_fn', 'BEGIN', v_parameter);


        OPEN p_out FOR
            SELECT *
              FROM SYS_GROUP_ACTIONS
             WHERE (p_id is null or id = p_id) and (p_group_id is null or GROUP_ID = p_group_id);

--        pkg_system_log.pr_log_info ('pr_get_list_mm_fp_fn', 'END', v_parameter);
--        pkg_system_log.pr_log_debug ('pr_get_list_mm_fp_fn', 'END', v_parameter);
--    EXCEPTION                                                                                                                                       -- exception handlers begin
--        WHEN OTHERS
--        THEN                                                                                                                                        -- handles all other errors
--            v_errors := SQL%BULK_EXCEPTIONS.COUNT;
--
--            FOR i IN 1 .. v_errors
--            LOOP
--                pkg_system_log.pr_log_exception ('pr_get_list_mm_fp_fn',
--                                                 'EXCEPTION',
--                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
--                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));
--
--
--            END LOOP;
--
--            RAISE;
    END;

    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: x�a danh s�ch SYS_GROUP_ACTIONS theo p_group_id
    Parameter:
                p_group_id: 
                p_user:
                p_client_ip:
                p_user_agent:

    */
    PROCEDURE pr_delete_sys_group_actions (p_group_id SYS_GROUP_ACTIONS.GROUP_ID%TYPE,
                                            p_user         IN VARCHAR2,
                                            p_client_ip    IN VARCHAR2,
                                            p_user_agent   IN VARCHAR2)
        AS
    BEGIN
        v_parameter := ', p_group_id:'
        || p_group_id
        || 'p_user:'
        || p_user
        || '|p_client_ip:'
        || p_client_ip
        || '|p_user_agent:'
        || p_user_agent;

--        pkg_system_log.pr_log_info('pr_delete_mm_fp_fn','BEGIN',v_parameter);
--        pkg_system_log.pr_log_debug('pr_delete_mm_fp_fn','BEGIN',v_parameter);
        DELETE SYS_GROUP_ACTIONS WHERE GROUP_ID = p_group_id;

--        pkg_system_log.pr_log_info('pr_delete_mm_fp_fn','END',v_parameter);
--        pkg_system_log.pr_log_debug('pr_delete_mm_fp_fn','END',v_parameter);
--
--    EXCEPTION                                                            -- exception handlers begin
--        WHEN OTHERS THEN                                                             -- handles all other errors
--            v_errors := SQL%bulk_exceptions.count;
--            FOR i IN 1..v_errors LOOP
--                pkg_system_log.pr_log_exception('pr_delete_mm_fp_fn','EXCEPTION',SQL%bulk_exceptions(i).error_code,sqlerrm(-SQL%bulk_exceptions(i).error_code) );
--
--
--            END LOOP;

    END;
END;

/
--------------------------------------------------------
--  DDL for Package Body PKG_SYS_RESOURCES
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PKG_SYS_RESOURCES" 
  -- Author  : DONB
  -- Created : 17/06/2019 4:01:04 PM
  -- Purpose :
AS
    v_parameter   NVARCHAR2(1500);
    v_errors      NUMBER(10);

    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y danh s�ch nh�m ng??i d�ng (Application: BO) => th?c ra l� l?y g�i ch?c n?ng
    Parameter:
                 p_group_name:
                 p_description:
                 p_user:
                 p_client_ip:
                 p_user_agent: 

    */
  PROCEDURE pr_get_list_sys_group (p_group_name   SYS_GROUPS.GROUP_NAME%TYPE,
                                     p_description          SYS_GROUPS.DESCRIPTION%TYPE,
                                     p_status               SYS_GROUPS.Status%TYPE,
                                     p_user               IN     VARCHAR2,
                                     p_client_ip          IN     VARCHAR2,
                                     p_user_agent         IN     VARCHAR2,
                                     p_out                   OUT types.ref_cursor) AS
  BEGIN
    v_parameter :=  'p_group_name:' || p_group_name
                       || ', p_description:' || p_description
                       || ', p_status:' || p_status
                       || 'p_user:' || p_user
                       || '|p_client_ip:' || p_client_ip
                       || '|p_user_agent:' || p_user_agent;

--        pkg_system_log.pr_log_info('pr_get_list_function_pack','BEGIN',v_parameter);
--        pkg_system_log.pr_log_debug('pr_get_list_function_pack','BEGIN',v_parameter);
        OPEN p_out FOR 
        SELECT sysGroups.*, sysRef.REF_NAME_VN STATUS_STR
        FROM SYS_GROUPS sysGroups
        LEFT JOIN SYS_REFCODE sysRef on sysGroups.STATUS = sysRef.REF_CODE and sysRef.REF_GROUP = 'LS_STATUS'
         WHERE pkg_utility.removesignvietnamess(sysGroups.GROUP_NAME) LIKE '%' || pkg_utility.removesignvietnamess(p_group_name) || '%'
            AND pkg_utility.removesignvietnamess(sysGroups.DESCRIPTION) LIKE '%' || pkg_utility.removesignvietnamess(p_description) || '%'
            --AND application_code = p_application_code
            AND (p_status is null or sysGroups.STATUS = p_status)
--            order by sysGroups.Create_Date desc;
            order by sysgroups.update_date desc;
            

--        pkg_system_log.pr_log_info('pr_get_list_function_pack','END',v_parameter);
--        pkg_system_log.pr_log_debug('pr_get_list_function_pack','END',v_parameter);
--    EXCEPTION -- exception handlers begin
--        WHEN OTHERS THEN -- handles all other errors
--            v_errors := SQL%bulk_exceptions.count;
--            FOR i IN 1..v_errors LOOP
--                pkg_system_log.pr_log_exception('pr_get_list_function_pack','EXCEPTION',SQL%bulk_exceptions(i).error_code,sqlerrm(-SQL%bulk_exceptions
--(i).error_code) );
--            END LOOP;
--            RAISE;
  END pr_get_list_sys_group;

/*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y danh s�ch menu h? th?ng
    Parameter:
                 p_user:
                 p_client_ip:
                 p_user_agent:
    */
  PROCEDURE pr_get_list_sys_resources (p_application_id          SYS_RESOURCES.APPLICATION_ID%TYPE,
                                        p_status               SYS_RESOURCES.Status%TYPE,
                                        p_user         IN     VARCHAR2,
                                        p_client_ip    IN     VARCHAR2,
                                        p_user_agent   IN     VARCHAR2,
                                        p_out             OUT types.ref_cursor) 
    AS
  BEGIN
    v_parameter := 'p_application_id:' || p_application_id || 'p_status:' || p_status || 'p_user:' || p_user || '|p_client_ip:' || p_client_ip || '|p_user_agent:' || p_user_agent;
    OPEN p_out FOR
        SELECT CASE WHEN SUBMENU.RES_NM IS NULL THEN MENU.RES_NM ELSE SUBMENU.RES_NM END RES_NM ,
               (CASE WHEN SUBMENU.RES_ID IS NOT NULL THEN SUBMENU.RES_ID ELSE MENU.RES_ID END) RES_ID,
               CASE WHEN SUBMENU.RES_NM IS NULL THEN '' ELSE MENU.RES_NM END RES_PARENT_NAME,
               MENU.RES_ID RES_PARENT_ID
        FROM SYS_RESOURCES MENU
        LEFT JOIN SYS_RESOURCES SUBMENU ON MENU.RES_ID = SUBMENU.PARENT_ID
        WHERE MENU.PARENT_ID IS NULL
           AND MENU.APPLICATION_ID=p_application_id
           AND MENU.STATUS = p_status
--           AND SUBMENU.STATUS = p_status
           ORDER BY MENU.PRIORITY,SUBMENU.PRIORITY;
  END pr_get_list_sys_resources;


    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L�y th�ng tin chi ti?t nh�m ng??i d�ng (Nh�m ch?c n?ng)
    Parameter:
                 p_group_name:
                 p_description:
                 p_status:
                 p_user:
                 p_client_ip:
                 p_user_agent:


    */
  PROCEDURE pr_get_sys_group_info (p_group_name   SYS_GROUPS.GROUP_NAME%TYPE,
                                     p_description          SYS_GROUPS.DESCRIPTION%TYPE,
                                     p_status               SYS_GROUPS.Status%TYPE,
                                     p_user         IN     VARCHAR2,
                                     p_client_ip    IN     VARCHAR2,
                                     p_user_agent   IN     VARCHAR2,
                                     p_out             OUT types.ref_cursor) AS
  BEGIN
        v_parameter := 'p_group_name:' || p_group_name
                       || ', p_description:' || p_description
                       || ', p_status:' || p_status
                       || 'p_user:' || p_user
                       || '|p_client_ip:' || p_client_ip
                       || '|p_user_agent:' || p_user_agent;

--        pkg_system_log.pr_log_info('pr_get_function_pack_info','BEGIN',v_parameter);
--        pkg_system_log.pr_log_debug('pr_get_function_pack_info','BEGIN',v_parameter);
        OPEN p_out FOR 
        SELECT *
        FROM SYS_GROUPS 
         WHERE GROUP_NAME = p_group_name
            AND (DESCRIPTION = p_description OR p_description IS NULL)
            AND ( STATUS = p_status OR p_status IS NULL );

--        pkg_system_log.pr_log_info('pr_get_function_pack_info','END',v_parameter);
--        pkg_system_log.pr_log_debug('pr_get_function_pack_info','END',v_parameter);
--    EXCEPTION -- exception handlers begin
--        WHEN OTHERS THEN -- handles all other errors
--            v_errors := SQL%bulk_exceptions.count;
--            FOR i IN 1..v_errors LOOP
--                pkg_system_log.pr_log_exception('pr_get_function_pack_info','EXCEPTION',SQL%bulk_exceptions(i).error_code,sqlerrm(-SQL%bulk_exceptions
--(i).error_code) );
--            END LOOP;
--
--            RAISE;
  END pr_get_sys_group_info;


    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: C?p nh?t th�ng tin chi ti?t nh�m ng??i d�ng
    Parameter:
                p_group_type: 
                p_group_name: 
                p_description: 
                p_create_user: 
                p_update_user: 
                p_create_date: 
                p_update_date: 
                p_status: 
                p_par1: 
                p_par2: 
                p_par3: 
                p_par4: 
                p_par5: 
                p_user:
                p_client_ip:
                p_user_agent:
    */
  PROCEDURE pr_update_sys_group (p_group_type SYS_GROUPS.GROUP_TYPE%TYPE,
                                    p_group_name SYS_GROUPS.GROUP_NAME%TYPE,
                                    p_description SYS_GROUPS.DESCRIPTION%TYPE,
                                    p_create_user SYS_GROUPS.CREATE_USER%TYPE,
                                    p_update_user SYS_GROUPS.UPDATE_USER%TYPE,
                                    p_create_date SYS_GROUPS.CREATE_DATE%TYPE,
                                    p_update_date SYS_GROUPS.UPDATE_DATE%TYPE,
                                    p_status SYS_GROUPS.STATUS%TYPE,
                                    p_par1 SYS_GROUPS.PAR1%TYPE,
                                    p_par2 SYS_GROUPS.PAR2%TYPE,
                                    p_par3 SYS_GROUPS.PAR3%TYPE,
                                    p_par4 SYS_GROUPS.PAR4%TYPE,
                                    p_par5 SYS_GROUPS.PAR5%TYPE,
                                    p_user                   IN     VARCHAR2,
                                    p_client_ip              IN     VARCHAR2,
                                    p_user_agent             IN     VARCHAR2,
                                    p_out                       OUT types.ref_cursor) AS
  BEGIN
        v_parameter := 'p_par5:'|| p_par5
                        ||', p_par4:'|| p_par4
                        ||', p_par3:'|| p_par3
                        ||', p_par2:'|| p_par2
                        ||', p_par1:'|| p_par1
                        ||', p_status:'|| p_status
                        ||', p_update_date:'|| p_update_date
                        ||', p_create_date:'|| p_create_date
                        ||', p_update_user:'|| p_update_user
                        ||', p_create_user:'|| p_create_user
                        ||', p_description:'|| p_description
                        ||', p_group_name:'|| p_group_name
                        ||', p_group_type:'|| p_group_type
                        || 'p_user:'
                        || p_user
                        || '|p_client_ip:'
                        || p_client_ip
                        || '|p_user_agent:'
                        || p_user_agent;
                        
-- Raise_Application_Error (-20000, 'Nh�m quy?n kh�ng t?n t?i. ');
-- return;
--        pkg_system_log.pr_log_info('pr_update_function_pack','BEGIN',v_parameter);
--        pkg_system_log.pr_log_debug('pr_update_function_pack','BEGIN',v_parameter);
        UPDATE SYS_GROUPS
        SET
            GROUP_TYPE=p_group_type,
            DESCRIPTION=p_description, 
            UPDATE_USER=p_update_user, 
            UPDATE_DATE=sysdate, 
            STATUS=p_status, 
            PAR1=p_par1, 
            PAR2=p_par2, 
            PAR3=p_par3, 
            PAR4=p_par4, 
            PAR5=p_par5
        WHERE
            GROUP_NAME = p_group_name;

        OPEN p_out FOR 
        SELECT *
        FROM SYS_GROUPS
         WHERE GROUP_NAME = p_group_name;

--        pkg_system_log.pr_log_info('pr_update_function_pack','END',v_parameter);
--        pkg_system_log.pr_log_debug('pr_update_function_pack','END',v_parameter);
--    EXCEPTION -- exception handlers begin
--        WHEN OTHERS THEN -- handles all other errors
--            v_errors := SQL%bulk_exceptions.count;
--            FOR i IN 1..v_errors LOOP
--                pkg_system_log.pr_log_exception('pr_update_function_pack','EXCEPTION',SQL%bulk_exceptions(i).error_code,sqlerrm(-SQL%bulk_exceptions(i).error_code) );
--            END LOOP;
--
--            RAISE;
  END pr_update_sys_group;

    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: Th�m m?i th�ng tin chi ti?t nh�m ng??i d�ng
    Parameter:
                p_group_type: 
                p_group_name: 
                p_description: 
                p_create_user: 
                p_update_user: 
                p_create_date: 
                p_update_date: 
                p_status: 
                p_par1: 
                p_par2: 
                p_par3: 
                p_par4: 
                p_par5: 
                p_user:
                p_client_ip:
                p_user_agent:


    */
  PROCEDURE pr_create_sys_group (p_group_type SYS_GROUPS.GROUP_TYPE%TYPE,
                                    p_group_name SYS_GROUPS.GROUP_NAME%TYPE,
                                    p_description SYS_GROUPS.DESCRIPTION%TYPE,
                                    p_create_user SYS_GROUPS.CREATE_USER%TYPE,
                                    p_update_user SYS_GROUPS.UPDATE_USER%TYPE,
                                    p_create_date SYS_GROUPS.CREATE_DATE%TYPE,
                                    p_update_date SYS_GROUPS.UPDATE_DATE%TYPE,
                                    p_status SYS_GROUPS.STATUS%TYPE,
                                    p_par1 SYS_GROUPS.PAR1%TYPE,
                                    p_par2 SYS_GROUPS.PAR2%TYPE,
                                    p_par3 SYS_GROUPS.PAR3%TYPE,
                                    p_par4 SYS_GROUPS.PAR4%TYPE,
                                    p_par5 SYS_GROUPS.PAR5%TYPE,
                                    p_user                   IN     VARCHAR2,
                                    p_client_ip              IN     VARCHAR2,
                                    p_user_agent             IN     VARCHAR2,
                                    p_out                       OUT types.ref_cursor) AS
V_ROWCOUNT INT;
  BEGIN
        v_parameter := 'p_par5:'|| p_par5
                        ||', p_par4:'|| p_par4
                        ||', p_par3:'|| p_par3
                        ||', p_par2:'|| p_par2
                        ||', p_par1:'|| p_par1
                        ||', p_status:'|| p_status
                        ||', p_update_date:'|| p_update_date
                        ||', p_create_date:'|| p_create_date
                        ||', p_update_user:'|| p_update_user
                        ||', p_create_user:'|| p_create_user
                        ||', p_description:'|| p_description
                        ||', p_group_name:'|| p_group_name
                        ||', p_group_type:'|| p_group_type
                        || 'p_user:'
                        || p_user
                        || '|p_client_ip:'
                        || p_client_ip
                        || '|p_user_agent:'
                        || p_user_agent;
SELECT COUNT(9)
INTO V_ROWCOUNT
FROM SYS_GROUPS WHERE GROUP_NAME=P_GROUP_NAME;
IF V_ROWCOUNT>0 THEN
    Raise_Application_Error (-20000, 'Nhóm quyền đã tồn tại. ');
    return;
END IF;

        --pkg_system_log.pr_log_info('pr_create_function_pack','BEGIN',v_parameter);
        --pkg_system_log.pr_log_debug('pr_create_function_pack','BEGIN',v_parameter);
        INSERT INTO SYS_GROUPS (
            GROUP_TYPE, 
            GROUP_NAME, 
            DESCRIPTION, 
            CREATE_USER, 
            UPDATE_USER, 
            CREATE_DATE, 
            UPDATE_DATE, 
            STATUS, 
            PAR1, 
            PAR2, 
            PAR3, 
            PAR4, 
            PAR5
        ) VALUES (
            p_group_type , --GROUP_TYPE
            p_group_name , --GROUP_NAME
            p_description , --DESCRIPTION
            p_create_user , --CREATE_USER
            p_update_user , --UPDATE_USER
            sysdate , --CREATE_DATE
            p_update_date , --UPDATE_DATE
            p_status , --STATUS
            p_par1 , --PAR1
            p_par2 , --PAR2
            p_par3 , --PAR3
            p_par4 , --PAR4
            p_par5  --PAR5
        );

        OPEN p_out FOR 
        SELECT *
        FROM SYS_GROUPS
         WHERE GROUP_NAME = p_group_name;

        --pkg_system_log.pr_log_info('pr_create_function_pack','END',v_parameter);
        --pkg_system_log.pr_log_debug('pr_create_function_pack','END',v_parameter);
--    EXCEPTION -- exception handlers begin
--        WHEN OTHERS THEN -- handles all other errors
--            v_errors := SQL%bulk_exceptions.count;
--            FOR i IN 1..v_errors LOOP
--                pkg_system_log.pr_log_exception('pr_create_function_pack','EXCEPTION',SQL%bulk_exceptions(i).error_code,sqlerrm(-SQL%bulk_exceptions
--(i).error_code) );
--            END LOOP;
--
--            RAISE;
  END pr_create_sys_group;
  
    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: check trung ma nguoi dung, ten nguoi dung
    Parameter:
               p_group_type:
               p_group_name:
               p_user:
               p_client_ip:
               p_user_agent:


    */
  PROCEDURE pr_check_sys_group (p_group_type SYS_GROUPS.GROUP_TYPE%TYPE,
                                p_group_name SYS_GROUPS.GROUP_NAME%TYPE,
                                p_user                   IN     VARCHAR2,
                                p_client_ip              IN     VARCHAR2,
                                p_user_agent             IN     VARCHAR2,
                                p_out                       OUT types.ref_cursor) AS
  BEGIN
        v_parameter := ', p_group_type:'
                       || p_group_type
                       || ', p_group_name:'
                       || p_group_name
                       || 'p_user:'
                       || p_user
                       || '|p_client_ip:'
                       || p_client_ip
                       || '|p_user_agent:'
                       || p_user_agent;

--        pkg_system_log.pr_log_info('pr_check_function_pack','BEGIN',v_parameter);
--        pkg_system_log.pr_log_debug('pr_check_function_pack','BEGIN',v_parameter);
        OPEN p_out FOR 
        SELECT *
        FROM SYS_GROUPS
         WHERE (p_group_name IS NULL OR upper(GROUP_NAME) = upper(p_group_name))
            AND GROUP_TYPE = p_group_type;

--        pkg_system_log.pr_log_info('pr_check_function_pack','END',v_parameter);
--        pkg_system_log.pr_log_debug('pr_check_function_pack','END',v_parameter);
--    EXCEPTION -- exception handlers begin
--        WHEN OTHERS THEN -- handles all other errors
--            v_errors := SQL%bulk_exceptions.count;
--            FOR i IN 1..v_errors LOOP
--                pkg_system_log.pr_log_exception('pr_check_function_pack','EXCEPTION',SQL%bulk_exceptions(i).error_code,sqlerrm(-SQL%bulk_exceptions
--(i).error_code) );
--            END LOOP;
--            RAISE;
  END pr_check_sys_group;

    /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y menu theo nh�m ng??i d�ng
    Parameter:
               p_group_name:
               p_user:
               p_client_ip:
               p_user_agent:


    */
  PROCEDURE pr_list_resources_by_sys_group (p_group_name SYS_GROUPS.GROUP_NAME%TYPE,
                                            p_status    SYS_RESOURCES.STATUS%TYPE,
                                            p_user         IN     VARCHAR2,
                                            p_client_ip    IN     VARCHAR2,
                                            p_user_agent   IN     VARCHAR2,
                                            p_out             OUT types.ref_cursor) AS
  BEGIN
        v_parameter := 'p_group_name:'
                       || p_group_name
                       || 'p_status:'
                       || p_status
                       || '|p_user:'
                       || p_user
                       || '|p_client_ip:'
                       || p_client_ip
                       || '|p_user_agent:'
                       || p_user_agent;

        --pkg_system_log.pr_log_info('pr_list_func_by_func_pack','BEGIN',v_parameter);
        --pkg_system_log.pr_log_debug('pr_list_func_by_func_pack','BEGIN',v_parameter);
        OPEN p_out FOR 
        SELECT CASE WHEN SUBMENU.RES_NM IS NULL THEN MENU.RES_NM ELSE SUBMENU.RES_NM END RES_NM ,
               (CASE WHEN SUBMENU.RES_ID IS NOT NULL THEN SUBMENU.RES_ID ELSE MENU.RES_ID END) RES_ID,
               CASE WHEN SUBMENU.RES_NM IS NULL THEN '' ELSE MENU.RES_NM END RES_PARENT_NAME,
               MENU.RES_ID RES_PARENT_ID
        FROM SYS_RESOURCES MENU
        LEFT JOIN SYS_RESOURCES SUBMENU ON MENU.RES_ID = SUBMENU.PARENT_ID
        JOIN SYS_GROUP_ACTIONS on MENU.RES_ID = SYS_GROUP_ACTIONS.RES_ACTION_ID
        WHERE MENU.PARENT_ID IS NULL
           AND SYS_GROUP_ACTIONS.GROUP_ID = p_group_name
           AND MENU.STATUS = p_status
           ORDER BY MENU.PRIORITY,SUBMENU.PRIORITY;

        --pkg_system_log.pr_log_info('pr_list_func_by_func_pack','END',v_parameter);
        --pkg_system_log.pr_log_debug('pr_list_func_by_func_pack','END',v_parameter);
--    EXCEPTION -- exception handlers begin
--        WHEN OTHERS THEN -- handles all other errors
--            v_errors := SQL%bulk_exceptions.count;
--            FOR i IN 1..v_errors LOOP
--                pkg_system_log.pr_log_exception('pr_list_func_by_func_pack','EXCEPTION',SQL%bulk_exceptions(i).error_code,sqlerrm(-SQL%bulk_exceptions
--(i).error_code) );
--            END LOOP;
--
--            RAISE;
  END pr_list_resources_by_sys_group;
  
  
   /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y action c?a menu
    Parameter:
               p_group_name:
               p_user:
               p_client_ip:
               p_user_agent:


    */  
  PROCEDURE pr_list_sys_resources_action (p_application_id SYS_RESOURCE_ACTIONS.APPLICATION_ID%TYPE,
                                            p_resource_id   SYS_RESOURCE_ACTIONS.RESOURCE_ID%TYPE,
                                            p_status SYS_ACTIONS.STATUS%TYPE,
                                            p_user         IN     VARCHAR2,
                                            p_client_ip    IN     VARCHAR2,
                                            p_user_agent   IN     VARCHAR2,
                                            p_out             OUT types.ref_cursor) AS
  BEGIN
        v_parameter := 'p_application_id:'
                       || p_application_id
                       ||'p_resource_id:'
                       || p_resource_id
                       ||'p_status:'
                       || p_status
                       || '|p_user:'
                       || p_user
                       || '|p_client_ip:'
                       || p_client_ip
                       || '|p_user_agent:'
                       || p_user_agent;

        --pkg_system_log.pr_log_info('pr_list_func_by_func_pack','BEGIN',v_parameter);
        --pkg_system_log.pr_log_debug('pr_list_func_by_func_pack','BEGIN',v_parameter);
        OPEN p_out FOR 
        SELECT SYS_RESOURCE_ACTIONS.*, SYS_ACTIONS.ACTION_NM, SYS_ACTIONS.ACTION_CODE, SYS_ACTIONS.STATUS
        FROM SYS_RESOURCE_ACTIONS
        JOIN SYS_ACTIONS on SYS_RESOURCE_ACTIONS.ACTION_ID = SYS_ACTIONS.ACTION_ID
        WHERE APPLICATION_ID = p_application_id
           AND RESOURCE_ID = p_resource_id
           AND SYS_ACTIONS.STATUS = p_status;

        --pkg_system_log.pr_log_info('pr_list_func_by_func_pack','END',v_parameter);
        --pkg_system_log.pr_log_debug('pr_list_func_by_func_pack','END',v_parameter);
--    EXCEPTION -- exception handlers begin
--        WHEN OTHERS THEN -- handles all other errors
--            v_errors := SQL%bulk_exceptions.count;
--            FOR i IN 1..v_errors LOOP
--                pkg_system_log.pr_log_exception('pr_list_func_by_func_pack','EXCEPTION',SQL%bulk_exceptions(i).error_code,sqlerrm(-SQL%bulk_exceptions
--(i).error_code) );
--            END LOOP;
--
--            RAISE;
  END pr_list_sys_resources_action;
  
PROCEDURE pr_list_sys_resources (p_application_id SYS_RESOURCES.APPLICATION_ID%TYPE,
                                            p_status SYS_RESOURCES.STATUS%TYPE,
                                            p_user         IN     VARCHAR2,
                                            p_client_ip    IN     VARCHAR2,
                                            p_user_agent   IN     VARCHAR2,
                                            p_out             OUT types.ref_cursor) AS
  BEGIN
        v_parameter := 'p_application_id:'
                       || p_application_id
                       ||'p_status:'
                       || p_status
                       || '|p_user:'
                       || p_user
                       || '|p_client_ip:'
                       || p_client_ip
                       || '|p_user_agent:'
                       || p_user_agent;

        --pkg_system_log.pr_log_info('pr_list_func_by_func_pack','BEGIN',v_parameter);
        --pkg_system_log.pr_log_debug('pr_list_func_by_func_pack','BEGIN',v_parameter);
        OPEN p_out FOR 
        SELECT *
        FROM  SYS_RESOURCES MENU
        WHERE APPLICATION_ID = p_application_id
           AND STATUS = p_status AND TASK_FLOW_ID IS NOT NULL;

  END pr_list_sys_resources;
END PKG_SYS_RESOURCES;

/
--------------------------------------------------------
--  DDL for Package Body PKG_SYS_TASK_LIST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PKG_SYS_TASK_LIST" 
  -- Author  : DONB
  -- Created : 27/06/2019 4:01:04 PM
  -- Purpose :
AS
    v_parameter   NVARCHAR2 (30000);
    v_errors      NUMBER (38);
    
    /* 
         Creater: DONB
         Created date: 27/06/2019 4:01:04 PM
         Description: Th�m m?i giao d?ch
         Parameter:
                  p_id:
                  p_task_id:
                  p_task_type:
                  p_task_date:
                  p_cif_no:
                  p_cust_name:
                  p_tax_id:
                  p_workflow_status:
                  p_maker:
                  p_approver:
                  p_approved_date:
                  p_branch_code:
                  p_external_data:
                  p_action:
                  p_text_1:
                  p_text_2:
                  p_text_3:
                  p_text_4:
                  p_text_5:
                  p_text_6:
                  p_text_7:
                  p_text_8:
                  p_text_9:
                  p_text_10:
                  p_date_1:
                  p_date_2:
                  p_date_3:
                  p_date_4:
                  p_date_5:
                  p_date_6:
                  p_date_7:
                  p_date_8:
                  p_date_9:
                  p_date_10:
                  p_number_1:
                  p_number_2:
                  p_number_3:
                  p_number_4:
                  p_number_5:
                  p_number_6:
                  p_number_7:
                  p_number_8:
                  p_number_9:
                  p_number_10:
                  p_user_name:
                  p_maker_branch_code:
                  p_status:
                  p_created_date:
                  p_approver_branch_code:
                  p_process_instance_id:

       */
    PROCEDURE PR_CREATE_SYS_TASK_LIST (p_task_id                       SYS_TASK_LIST.TASK_ID%TYPE,
                                           p_task_type                     SYS_TASK_LIST.TASK_TYPE%TYPE,
                                           p_task_date                     SYS_TASK_LIST.TASK_DATE%TYPE,
                                           p_cif_no                        SYS_TASK_LIST.cif_no%TYPE,
                                           p_cust_name                     SYS_TASK_LIST.cust_name%TYPE,
                                           p_tax_id                        SYS_TASK_LIST.tax_id%TYPE,
                                           p_workflow_status               SYS_TASK_LIST.workflow_status%TYPE,
                                           p_maker                         SYS_TASK_LIST.maker%TYPE,
                                           p_approver                      SYS_TASK_LIST.approver%TYPE,
                                           p_approved_date                 SYS_TASK_LIST.approved_date%TYPE,
                                           p_branch_code                   SYS_TASK_LIST.branch_code%TYPE,
                                           p_external_data                 SYS_TASK_LIST.external_data%TYPE,
                                           p_action                        SYS_TASK_LIST.action%TYPE,
                                           p_text_1                        SYS_TASK_LIST.text_1%TYPE,
                                           p_text_2                        SYS_TASK_LIST.text_2%TYPE,
                                           p_text_3                        SYS_TASK_LIST.text_3%TYPE,
                                           p_text_4                        SYS_TASK_LIST.text_4%TYPE,
                                           p_text_5                        SYS_TASK_LIST.text_5%TYPE,
                                           p_text_6                        SYS_TASK_LIST.text_6%TYPE,
                                           p_text_7                        SYS_TASK_LIST.text_7%TYPE,
                                           p_text_8                        SYS_TASK_LIST.text_8%TYPE,
                                           p_text_9                        SYS_TASK_LIST.text_9%TYPE,
                                           p_text_10                       SYS_TASK_LIST.text_10%TYPE,
                                           p_date_1                        SYS_TASK_LIST.date_1%TYPE,
                                           p_date_2                        SYS_TASK_LIST.date_2%TYPE,
                                           p_date_3                        SYS_TASK_LIST.date_3%TYPE,
                                           p_date_4                        SYS_TASK_LIST.date_4%TYPE,
                                           p_date_5                        SYS_TASK_LIST.date_5%TYPE,
                                           p_date_6                        SYS_TASK_LIST.date_6%TYPE,
                                           p_date_7                        SYS_TASK_LIST.date_7%TYPE,
                                           p_date_8                        SYS_TASK_LIST.date_8%TYPE,
                                           p_date_9                        SYS_TASK_LIST.date_9%TYPE,
                                           p_date_10                       SYS_TASK_LIST.date_10%TYPE,
                                           p_number_1                      SYS_TASK_LIST.number_1%TYPE,
                                           p_number_2                      SYS_TASK_LIST.number_2%TYPE,
                                           p_number_3                      SYS_TASK_LIST.number_3%TYPE,
                                           p_number_4                      SYS_TASK_LIST.number_4%TYPE,
                                           p_number_5                      SYS_TASK_LIST.number_5%TYPE,
                                           p_number_6                      SYS_TASK_LIST.number_6%TYPE,
                                           p_number_7                      SYS_TASK_LIST.number_7%TYPE,
                                           p_number_8                      SYS_TASK_LIST.number_8%TYPE,
                                           p_number_9                      SYS_TASK_LIST.number_9%TYPE,
                                           p_number_10                     SYS_TASK_LIST.number_10%TYPE,
                                           p_user_name                     SYS_TASK_LIST.user_name%TYPE,
                                           p_maker_branch_code             SYS_TASK_LIST.maker_branch_code%TYPE,
                                           p_status                        SYS_TASK_LIST.status%TYPE,
                                           p_created_date                  SYS_TASK_LIST.created_date%TYPE,
                                           p_approver_branch_code          SYS_TASK_LIST.approver_branch_code%TYPE,
                                           p_process_instance_id           SYS_TASK_LIST.process_instance_id%TYPE,
                                           p_user                   IN     VARCHAR2,
                                           p_client_ip              IN     VARCHAR2,
                                           p_user_agent             IN     VARCHAR2,
                                           p_out                       OUT types.ref_cursor)
    AS
        p_id   SYS_TASK_LIST.id%TYPE;
        V_TASK_ID SYS_TASK_LIST.TASK_ID%TYPE;
        V_MAKER_BRANCH_CODE SYS_TASK_LIST.MAKER_BRANCH_CODE%TYPE;
    BEGIN
        v_parameter :=
               ', p_approver_branch_code:'
            || p_approver_branch_code
            || ', p_created_date:'
            || p_created_date
            || ', p_status:'
            || p_status
            || ', p_maker_branch_code:'
            || p_maker_branch_code
            || ', p_user_name:'
            || p_user_name
            || ', p_number_10:'
            || p_number_10
            || ', p_number_9:'
            || p_number_9
            || ', p_number_8:'
            || p_number_8
            || ', p_number_7:'
            || p_number_7
            || ', p_number_6:'
            || p_number_6
            || ', p_number_5:'
            || p_number_5
            || ', p_number_4:'
            || p_number_4
            || ', p_number_3:'
            || p_number_3
            || ', p_number_2:'
            || p_number_2
            || ', p_number_1:'
            || p_number_1
            || ', p_date_10:'
            || p_date_10
            || ', p_date_9:'
            || p_date_9
            || ', p_date_8:'
            || p_date_8
            || ', p_date_7:'
            || p_date_7
            || ', p_date_6:'
            || p_date_6
            || ', p_date_5:'
            || p_date_5
            || ', p_date_4:'
            || p_date_4
            || ', p_date_3:'
            || p_date_3
            || ', p_date_2:'
            || p_date_2
            || ', p_date_1:'
            || p_date_1
            || ', p_text_10:'
            || p_text_10
            || ', p_text_9:'
            || p_text_9
            || ', p_text_8:'
            || p_text_8
            || ', p_text_7:'
            || p_text_7
            || ', p_text_6:'
            || p_text_6
            || ', p_text_5:'
            || p_text_5
            || ', p_text_4:'
            || p_text_4
            || ', p_text_3:'
            || p_text_3
            || ', p_text_2:'
            || p_text_2
            || ', p_text_1:'
            || p_text_1
            || ', p_action:'
            || p_action
          --  || ', p_external_data:'
          --  || p_external_data
            || ', p_branch_code:'
            || p_branch_code
            || ', p_approved_date:'
            || p_approved_date
            || ', p_approver:'
            || p_approver
            || ', p_maker:'
            || p_maker
            || ', p_workflow_status:'
            || p_workflow_status
            || ', p_tax_id:'
            || p_tax_id
            || ', p_cust_name:'
            || p_cust_name
            || ', p_cif_no:'
            || p_cif_no
            || ', p_task_date:'
            || p_task_date
            || ', p_task_type:'
            || p_task_type
            || ', p_task_id:'
            || p_task_id
            || ', p_id:'
            || p_id
            || 'p_user_name:'
            || p_user_name
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        p_id := seq_SYS_TASK_LIST.NEXTVAL;
        pkg_system_log.pr_log_info ('PR_CREATE_SYS_TASK_LIST', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('PR_CREATE_SYS_TASK_LIST', 'BEGIN', v_parameter);
        V_TASK_ID:= 'IC_' || TO_CHAR(SYSDATE, 'yyyymmdd') || '_' || TRIM(to_char(p_id, '00000000'));
        
        --DONB_CIS_TODO
        select max(MEMBER_CODE) into V_MAKER_BRANCH_CODE
        from SYS_USER where user_name=p_user;

       /* if(p_task_type='BU_EBANK') then
            if (instr(p_external_data,'"users":[]')>0) then
                raise_application_error(-20000,'B?n ch?a ??ng k� ng??i d�ng. Vui l�ng ??ng k� ng??i d�ng tr??c khi g?i duy?t.');
                return;
            end if;
        end if;*/

        INSERT INTO SYS_TASK_LIST (id,
                                       TASK_ID,
                                       TASK_TYPE,
                                       TASK_DATE,
                                       cif_no,
                                       cust_name,
                                       tax_id,
                                       workflow_status,
                                       maker,
                                       approver,
                                       approved_date,
                                       branch_code,
                                       external_data,
                                       action,
                                       text_1,
                                       text_2,
                                       text_3,
                                       text_4,
                                       text_5,
                                       text_6,
                                       text_7,
                                       text_8,
                                       text_9,
                                       text_10,
                                       date_1,
                                       date_2,
                                       date_3,
                                       date_4,
                                       date_5,
                                       date_6,
                                       date_7,
                                       date_8,
                                       date_9,
                                       date_10,
                                       number_1,
                                       number_2,
                                       number_3,
                                       number_4,
                                       number_5,
                                       number_6,
                                       number_7,
                                       number_8,
                                       number_9,
                                       number_10,
                                       user_name,
                                       maker_branch_code,
                                       status,
                                       created_date,
                                       approver_branch_code)
        VALUES (p_id,                                                                                                                                                      --ID
                V_TASK_ID,                                                                                                                                            --TASK_ID
                p_task_type,                                                                                                                                        --TASK_TYPE
                p_task_date,                                                                                                                                        --TASK_DATE
                p_cif_no,                                                                                                                                              --CIF_NO
                p_cust_name,                                                                                                                                        --CUST_NAME
                p_tax_id,                                                                                                                                              --TAX_ID
                p_workflow_status,                                                                                                                            --WORKFLOW_STATUS
                p_user,                                                                                                                                                --MAKER
                p_approver,                                                                                                                                          --APPROVER
                p_approved_date,                                                                                                                                --APPROVED_DATE
                p_branch_code,                                                                                                                                    --BRANCH_CODE
                p_external_data,                                                                                                                                --EXTERNAL_DATA
                p_action,                                                                                                                                              --ACTION
                p_text_1,                                                                                                                                              --TEXT_1
                p_text_2,                                                                                                                                              --TEXT_2
                p_text_3,                                                                                                                                              --TEXT_3
                p_text_4,                                                                                                                                              --TEXT_4
                p_text_5,                                                                                                                                              --TEXT_5
                p_text_6,                                                                                                                                              --TEXT_6
                p_text_7,                                                                                                                                              --TEXT_7
                p_text_8,                                                                                                                                              --TEXT_8
                p_text_9,                                                                                                                                              --TEXT_9
                p_text_10,                                                                                                                                            --TEXT_10
                p_date_1,                                                                                                                                              --DATE_1
                p_date_2,                                                                                                                                              --DATE_2
                p_date_3,                                                                                                                                              --DATE_3
                p_date_4,                                                                                                                                              --DATE_4
                p_date_5,                                                                                                                                              --DATE_5
                p_date_6,                                                                                                                                              --DATE_6
                p_date_7,                                                                                                                                              --DATE_7
                p_date_8,                                                                                                                                              --DATE_8
                p_date_9,                                                                                                                                              --DATE_9
                p_date_10,                                                                                                                                            --DATE_10
                p_number_1,                                                                                                                                          --NUMBER_1
                p_number_2,                                                                                                                                          --NUMBER_2
                p_number_3,                                                                                                                                          --NUMBER_3
                p_number_4,                                                                                                                                          --NUMBER_4
                p_number_5,                                                                                                                                          --NUMBER_5
                p_number_6,                                                                                                                                          --NUMBER_6
                p_number_7,                                                                                                                                          --NUMBER_7
                p_number_8,                                                                                                                                          --NUMBER_8
                p_number_9,                                                                                                                                          --NUMBER_9
                p_number_10,                                                                                                                                        --NUMBER_10
                p_user_name,                                                                                                                                        --USER_NAME
                V_MAKER_BRANCH_CODE,                                                                                                                        --MAKER_BRANCH_CODE
                p_status,                                                                                                                                              --STATUS
                sysdate,                                                                                                                                  --CREATED_DATE
                p_approver_branch_code                                                                                                                   --APPROVER_BRANCH_CODE
                                      );

        OPEN p_out FOR
            SELECT *
              FROM SYS_TASK_LIST
             WHERE id = p_id;

       pkg_system_log.pr_log_info ('PR_CREATE_SYS_TASK_LIST', 'END', v_parameter);
       pkg_system_log.pr_log_debug ('PR_CREATE_SYS_TASK_LIST', 'END', v_parameter);

    EXCEPTION                                                                                                                                       -- exception handlers begin
        WHEN OTHERS
        THEN                                                                                                                                        -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception ('PR_CREATE_SYS_TASK_LIST',
                                                 'EXCEPTION',
                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));

            END LOOP;
    END;
    
     /*
         Creater: DONB
         Created date: 27/06/2019 4:01:04 PM
         Description: update giao d?ch
         Parameter:
                  p_id:
                  p_task_id:
                  p_task_type:
                  p_task_date:
                  p_cif_no:
                  p_cust_name:
                  p_tax_id:
                  p_workflow_status:
                  p_maker:
                  p_approver:
                  p_approved_date:
                  p_branch_code:
                  p_external_data:
                  p_action:
                  p_text_1:
                  p_text_2:
                  p_text_3:
                  p_text_4:
                  p_text_5:
                  p_text_6:
                  p_text_7:
                  p_text_8:
                  p_text_9:
                  p_text_10:
                  p_date_1:
                  p_date_2:
                  p_date_3:
                  p_date_4:
                  p_date_5:
                  p_date_6:
                  p_date_7:
                  p_date_8:
                  p_date_9:
                  p_date_10:
                  p_number_1:
                  p_number_2:
                  p_number_3:
                  p_number_4:
                  p_number_5:
                  p_number_6:
                  p_number_7:
                  p_number_8:
                  p_number_9:
                  p_number_10:
                  p_user_name:
                  p_maker_branch_code:
                  p_status:
                  p_created_date:
                  p_approver_branch_code:
                  p_process_instance_id:

       */
    PROCEDURE PR_UPDATE_SYS_TASK_LIST (p_id                            SYS_TASK_LIST.id%TYPE,
                                           p_task_id                       SYS_TASK_LIST.TASK_ID%TYPE,
                                           p_task_type                     SYS_TASK_LIST.TASK_TYPE%TYPE,
                                           p_task_date                     SYS_TASK_LIST.TASK_DATE%TYPE,
                                           p_cif_no                        SYS_TASK_LIST.cif_no%TYPE,
                                           p_cust_name                     SYS_TASK_LIST.cust_name%TYPE,
                                           p_tax_id                        SYS_TASK_LIST.tax_id%TYPE,
                                           p_workflow_status               SYS_TASK_LIST.workflow_status%TYPE,
                                           p_maker                         SYS_TASK_LIST.maker%TYPE,
                                           p_approver                      SYS_TASK_LIST.approver%TYPE,
                                           p_approved_date                 SYS_TASK_LIST.approved_date%TYPE,
                                           p_branch_code                   SYS_TASK_LIST.branch_code%TYPE,
                                           p_external_data                 SYS_TASK_LIST.external_data%TYPE,
                                           p_action                        SYS_TASK_LIST.action%TYPE,
                                           p_text_1                        SYS_TASK_LIST.text_1%TYPE,
                                           p_text_2                        SYS_TASK_LIST.text_2%TYPE,
                                           p_text_3                        SYS_TASK_LIST.text_3%TYPE,
                                           p_text_4                        SYS_TASK_LIST.text_4%TYPE,
                                           p_text_5                        SYS_TASK_LIST.text_5%TYPE,
                                           p_text_6                        SYS_TASK_LIST.text_6%TYPE,
                                           p_text_7                        SYS_TASK_LIST.text_7%TYPE,
                                           p_text_8                        SYS_TASK_LIST.text_8%TYPE,
                                           p_text_9                        SYS_TASK_LIST.text_9%TYPE,
                                           p_text_10                       SYS_TASK_LIST.text_10%TYPE,
                                           p_date_1                        SYS_TASK_LIST.date_1%TYPE,
                                           p_date_2                        SYS_TASK_LIST.date_2%TYPE,
                                           p_date_3                        SYS_TASK_LIST.date_3%TYPE,
                                           p_date_4                        SYS_TASK_LIST.date_4%TYPE,
                                           p_date_5                        SYS_TASK_LIST.date_5%TYPE,
                                           p_date_6                        SYS_TASK_LIST.date_6%TYPE,
                                           p_date_7                        SYS_TASK_LIST.date_7%TYPE,
                                           p_date_8                        SYS_TASK_LIST.date_8%TYPE,
                                           p_date_9                        SYS_TASK_LIST.date_9%TYPE,
                                           p_date_10                       SYS_TASK_LIST.date_10%TYPE,
                                           p_number_1                      SYS_TASK_LIST.number_1%TYPE,
                                           p_number_2                      SYS_TASK_LIST.number_2%TYPE,
                                           p_number_3                      SYS_TASK_LIST.number_3%TYPE,
                                           p_number_4                      SYS_TASK_LIST.number_4%TYPE,
                                           p_number_5                      SYS_TASK_LIST.number_5%TYPE,
                                           p_number_6                      SYS_TASK_LIST.number_6%TYPE,
                                           p_number_7                      SYS_TASK_LIST.number_7%TYPE,
                                           p_number_8                      SYS_TASK_LIST.number_8%TYPE,
                                           p_number_9                      SYS_TASK_LIST.number_9%TYPE,
                                           p_number_10                     SYS_TASK_LIST.number_10%TYPE,
                                           p_user_name                     SYS_TASK_LIST.user_name%TYPE,
                                           p_maker_branch_code             SYS_TASK_LIST.maker_branch_code%TYPE,
                                           p_status                        SYS_TASK_LIST.status%TYPE,
                                           p_created_date                  SYS_TASK_LIST.created_date%TYPE,
                                           p_approver_branch_code          SYS_TASK_LIST.approver_branch_code%TYPE,
                                           p_process_instance_id           SYS_TASK_LIST.process_instance_id%TYPE,
                                           p_user                   IN     VARCHAR2,
                                           p_client_ip              IN     VARCHAR2,
                                           p_user_agent             IN     VARCHAR2,
                                           p_out                       OUT types.ref_cursor)AS
    BEGIN
        v_parameter :=
               ', p_approver_branch_code:'
            || p_approver_branch_code
            || ', p_created_date:'
            || p_created_date
            || ', p_status:'
            || p_status
            || ', p_maker_branch_code:'
            || p_maker_branch_code
            || ', p_user_name:'
            || p_user_name
            || ', p_number_10:'
            || p_number_10
            || ', p_number_9:'
            || p_number_9
            || ', p_number_8:'
            || p_number_8
            || ', p_number_7:'
            || p_number_7
            || ', p_number_6:'
            || p_number_6
            || ', p_number_5:'
            || p_number_5
            || ', p_number_4:'
            || p_number_4
            || ', p_number_3:'
            || p_number_3
            || ', p_number_2:'
            || p_number_2
            || ', p_number_1:'
            || p_number_1
            || ', p_date_10:'
            || p_date_10
            || ', p_date_9:'
            || p_date_9
            || ', p_date_8:'
            || p_date_8
            || ', p_date_7:'
            || p_date_7
            || ', p_date_6:'
            || p_date_6
            || ', p_date_5:'
            || p_date_5
            || ', p_date_4:'
            || p_date_4
            || ', p_date_3:'
            || p_date_3
            || ', p_date_2:'
            || p_date_2
            || ', p_date_1:'
            || p_date_1
            || ', p_text_10:'
            || p_text_10
            || ', p_text_9:'
            || p_text_9
            || ', p_text_8:'
            || p_text_8
            || ', p_text_7:'
            || p_text_7
            || ', p_text_6:'
            || p_text_6
            || ', p_text_5:'
            || p_text_5
            || ', p_text_4:'
            || p_text_4
            || ', p_text_3:'
            || p_text_3
            || ', p_text_2:'
            || p_text_2
            || ', p_text_1:'
            || p_text_1
            || ', p_action:'
            || p_action
          --  || ', p_external_data:'
           -- || p_external_data
            || ', p_branch_code:'
            || p_branch_code
            || ', p_approved_date:'
            || p_approved_date
            || ', p_approver:'
            || p_approver
            || ', p_maker:'
            || p_maker
            || ', p_workflow_status:'
            || p_workflow_status
            || ', p_tax_id:'
            || p_tax_id
            || ', p_cust_name:'
            || p_cust_name
            || ', p_cif_no:'
            || p_cif_no
            || ', p_task_date:'
            || p_task_date
            || ', p_task_type:'
            || p_task_type
            || ', p_task_id:'
            || p_task_id
            || ', p_id:'
            || p_id
            || 'p_user_name:'
            || p_user_name
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;
        pkg_system_log.pr_log_info ('PR_UPDATE_SYS_TASK_LIST', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('PR_UPDATE_SYS_TASK_LIST', 'BEGIN', v_parameter);

            UPDATE SYS_TASK_LIST  SET
                TASK_ID = p_task_id,
                TASK_TYPE = p_task_type,
                TASK_DATE = p_task_date,
                cif_no = p_cif_no,
                cust_name = p_cust_name,
                tax_id = p_tax_id,
                workflow_status = p_workflow_status,
                maker = p_maker,
                approver = p_approver,
                approved_date = p_approved_date,
                branch_code = p_branch_code,
                external_data = p_external_data,
                action = p_action,
                text_1 = p_text_1,
                text_2 = p_text_2,
                text_3 = p_text_3,
                text_4 = p_text_4,
                text_5 = p_text_5,
                text_6 = p_text_6,
                text_7 = p_text_7,
                text_8 = p_text_8,
                text_9 = p_text_9,
                text_10 = p_text_10,
                date_1 = p_date_1,
                date_2 = p_date_2,
                date_3 = p_date_3,
                date_4 = p_date_4,
                date_5 = p_date_5,
                date_6 = p_date_6,
                date_7 = p_date_7,
                date_8 = p_date_8,
                date_9 = p_date_9,
                date_10 = p_date_10,
                number_1 = p_number_1,
                number_2 = p_number_2,
                number_3 = p_number_3,
                number_4 = p_number_4,
                number_5 = p_number_5,
                number_6 = p_number_6,
                number_7 = p_number_7,
                number_8 = p_number_8,
                number_9 = p_number_9,
                number_10 = p_number_10,
                user_name = p_user_name,
                maker_branch_code = p_maker_branch_code,
                status = p_status,
                created_date = p_created_date,
                approver_branch_code = p_approver_branch_code,
                process_instance_id = p_process_instance_id
                WHERE id = p_id;

        OPEN p_out FOR
            SELECT *
              FROM SYS_TASK_LIST
             WHERE id = p_id;

       pkg_system_log.pr_log_info ('PR_UPDATE_SYS_TASK_LIST', 'END', v_parameter);
       pkg_system_log.pr_log_debug ('PR_UPDATE_SYS_TASK_LIST', 'END', v_parameter);

    EXCEPTION
        WHEN OTHERS
        THEN
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception ('PR_UPDATE_SYS_TASK_LIST',
                                                 'EXCEPTION',
                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));

            END LOOP;
    END;
    
        /*
        Creater: DONB
        Created date: 27/06/2019 4:01:04 PM
        Description: L?y danh s�ch giao d?ch
        Parameter:
               p_id:
               p_task_id:
               p_task_type:
               p_task_date:
               p_cif_no:
               p_cust_name:
               p_tax_id:
               p_workflow_status:
               p_maker:
               p_approver:
               p_approved_date:
               p_branch_code:
               p_external_data:
               p_action:
               p_text_1:
               p_text_2:
               p_text_3:
               p_text_4:
               p_text_5:
               p_text_6:
               p_text_7:
               p_text_8:
               p_text_9:
               p_text_10:
               p_date_1:
               p_date_2:
               p_date_3:
               p_date_4:
               p_date_5:
               p_date_6:
               p_date_7:
               p_date_8:
               p_date_9:
               p_date_10:
               p_number_1:
               p_number_2:
               p_number_3:
               p_number_4:
               p_number_5:
               p_number_6:
               p_number_7:
               p_number_8:
               p_number_9:
               p_number_10:
               p_user_name:
               p_maker_branch_code:
               p_status:
               p_created_date:
               p_approver_branch_code:
               p_process_instance_id:
               p_task_id:

    */
    PROCEDURE PR_GET_LIST_SYS_TASK_LIST (p_id                            SYS_TASK_LIST.id%TYPE,
                                             p_task_id                       SYS_TASK_LIST.TASK_ID%TYPE,
                                             p_task_type                     SYS_TASK_LIST.TASK_TYPE%TYPE,
                                             p_task_date                     SYS_TASK_LIST.TASK_DATE%TYPE,
                                             p_cif_no                        SYS_TASK_LIST.cif_no%TYPE,
                                             p_cust_name                     SYS_TASK_LIST.cust_name%TYPE,
                                             p_tax_id                        SYS_TASK_LIST.tax_id%TYPE,
                                             p_workflow_status               SYS_TASK_LIST.workflow_status%TYPE,
                                             p_maker                         SYS_TASK_LIST.maker%TYPE,
                                             p_approver                      SYS_TASK_LIST.approver%TYPE,
                                             p_approved_date                 SYS_TASK_LIST.approved_date%TYPE,
                                             p_branch_code                   SYS_TASK_LIST.branch_code%TYPE,
                                             p_external_data                 SYS_TASK_LIST.external_data%TYPE,
                                             p_action                        SYS_TASK_LIST.action%TYPE,
                                             p_text_1                        SYS_TASK_LIST.text_1%TYPE,
                                             p_text_2                        SYS_TASK_LIST.text_2%TYPE,
                                             p_text_3                        SYS_TASK_LIST.text_3%TYPE,
                                             p_text_4                        SYS_TASK_LIST.text_4%TYPE,
                                             p_text_5                        SYS_TASK_LIST.text_5%TYPE,
                                             p_text_6                        SYS_TASK_LIST.text_6%TYPE,
                                             p_text_7                        SYS_TASK_LIST.text_7%TYPE,
                                             p_text_8                        SYS_TASK_LIST.text_8%TYPE,
                                             p_text_9                        SYS_TASK_LIST.text_9%TYPE,
                                             p_text_10                       SYS_TASK_LIST.text_10%TYPE,
                                             p_date_1                        SYS_TASK_LIST.date_1%TYPE,
                                             p_date_2                        SYS_TASK_LIST.date_2%TYPE,
                                             p_date_3                        SYS_TASK_LIST.date_3%TYPE,
                                             p_date_4                        SYS_TASK_LIST.date_4%TYPE,
                                             p_date_5                        SYS_TASK_LIST.date_5%TYPE,
                                             p_date_6                        SYS_TASK_LIST.date_6%TYPE,
                                             p_date_7                        SYS_TASK_LIST.date_7%TYPE,
                                             p_date_8                        SYS_TASK_LIST.date_8%TYPE,
                                             p_date_9                        SYS_TASK_LIST.date_9%TYPE,
                                             p_date_10                       SYS_TASK_LIST.date_10%TYPE,
                                             p_number_1                      SYS_TASK_LIST.number_1%TYPE,
                                             p_number_2                      SYS_TASK_LIST.number_2%TYPE,
                                             p_number_3                      SYS_TASK_LIST.number_3%TYPE,
                                             p_number_4                      SYS_TASK_LIST.number_4%TYPE,
                                             p_number_5                      SYS_TASK_LIST.number_5%TYPE,
                                             p_number_6                      SYS_TASK_LIST.number_6%TYPE,
                                             p_number_7                      SYS_TASK_LIST.number_7%TYPE,
                                             p_number_8                      SYS_TASK_LIST.number_8%TYPE,
                                             p_number_9                      SYS_TASK_LIST.number_9%TYPE,
                                             p_number_10                     SYS_TASK_LIST.number_10%TYPE,
                                             p_user_name                     SYS_TASK_LIST.user_name%TYPE,
                                             p_maker_branch_code             SYS_TASK_LIST.maker_branch_code%TYPE,
                                             p_status                        SYS_TASK_LIST.status%TYPE,
                                             p_created_date                  SYS_TASK_LIST.created_date%TYPE,
                                             p_approver_branch_code          SYS_TASK_LIST.approver_branch_code%TYPE,
                                             p_process_instance_id           SYS_TASK_LIST.process_instance_id%TYPE,
                                             p_user                   IN     VARCHAR2,
                                             p_client_ip              IN     VARCHAR2,
                                             p_user_agent             IN     VARCHAR2,
                                             p_out                       OUT types.ref_cursor)
    AS
    V_MEMBER_CODE VARCHAR2(50);
    BEGIN
        v_parameter :=
               ', p_task_id:'
            || p_task_id
            || ', p_process_instance_id:'
            || p_process_instance_id
            || ', p_approver_branch_code:'
            || p_approver_branch_code
            || ', p_created_date:'
            || p_created_date
            || ', p_status:'
            || p_status
            || ', p_maker_branch_code:'
            || p_maker_branch_code
            || ', p_user_name:'
            || p_user_name
            || ', p_number_10:'
            || p_number_10
            || ', p_number_9:'
            || p_number_9
            || ', p_number_8:'
            || p_number_8
            || ', p_number_7:'
            || p_number_7
            || ', p_number_6:'
            || p_number_6
            || ', p_number_5:'
            || p_number_5
            || ', p_number_4:'
            || p_number_4
            || ', p_number_3:'
            || p_number_3
            || ', p_number_2:'
            || p_number_2
            || ', p_number_1:'
            || p_number_1
            || ', p_date_10:'
            || p_date_10
            || ', p_date_9:'
            || p_date_9
            || ', p_date_8:'
            || p_date_8
            || ', p_date_7:'
            || p_date_7
            || ', p_date_6:'
            || p_date_6
            || ', p_date_5:'
            || p_date_5
            || ', p_date_4:'
            || p_date_4
            || ', p_date_3:'
            || p_date_3
            || ', p_date_2:'
            || p_date_2
            || ', p_date_1:'
            || p_date_1
            || ', p_text_10:'
            || p_text_10
            || ', p_text_9:'
            || p_text_9
            || ', p_text_8:'
            || p_text_8
            || ', p_text_7:'
            || p_text_7
            || ', p_text_6:'
            || p_text_6
            || ', p_text_5:'
            || p_text_5
            || ', p_text_4:'
            || p_text_4
            || ', p_text_3:'
            || p_text_3
            || ', p_text_2:'
            || p_text_2
            || ', p_text_1:'
            || p_text_1
            || ', p_action:'
            || p_action
            || ', p_external_data:'
            || p_external_data
            || ', p_branch_code:'
            || p_branch_code
            || ', p_approved_date:'
            || p_approved_date
            || ', p_approver:'
            || p_approver
            || ', p_maker:'
            || p_maker
            || ', p_workflow_status:'
            || p_workflow_status
            || ', p_tax_id:'
            || p_tax_id
            || ', p_cust_name:'
            || p_cust_name
            || ', p_cif_no:'
            || p_cif_no
            || ', p_task_date:'
            || p_task_date
            || ', p_task_type:'
            || p_task_type
            || ', p_task_id:'
            || p_task_id
            || ', p_id:'
            || p_id
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        select max(MEMBER_CODE) into V_MEMBER_CODE
        from SYS_USER where user_name=p_user;
        
        pkg_system_log.pr_log_info ('PR_GET_LIST_SYS_TASK_LIST', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('PR_GET_LIST_SYS_TASK_LIST', 'BEGIN', v_parameter);


        OPEN p_out FOR
            SELECT SYS_TASK_LIST.ID, SYS_TASK_LIST.TASK_ID, SYS_TASK_LIST.TASK_TYPE, SYS_TASK_LIST.TASK_DATE, SYS_TASK_LIST.CIF_NO, SYS_TASK_LIST.CUST_NAME, 
                SYS_TASK_LIST.TAX_ID, SYS_TASK_LIST.MAKER, SYS_TASK_LIST.BRANCH_CODE,  SYS_TASK_LIST.ACTION, SYS_TASK_LIST.STATUS,SYS_TASK_LIST.CREATED_DATE,
                refTranType.REF_NAME_VN TASK_TYPE_NAME, refWfStatus.REF_NAME_VN WORKFLOW_STATUS_NAME, refTranType.PAR1 SCREEN_LOCATION, SYS_TASK_LIST.APPROVER
              FROM SYS_TASK_LIST
                -- Lay ten task
                JOIN SYS_REFCODE refTranType ON SYS_TASK_LIST.TASK_TYPE = refTranType.REF_CODE AND refTranType.REF_GROUP = 'TASK_LIST_TYPE'
                -- Trang thai task
                JOIN SYS_REFCODE refWfStatus ON SYS_TASK_LIST.STATUS = refWfStatus.REF_CODE AND refWfStatus.REF_GROUP = 'TASK_LIST_STATUS'
             WHERE (p_task_id IS NULL OR SYS_TASK_LIST.TASK_ID = p_task_id) 
              AND (p_task_type IS NULL OR TASK_TYPE like p_task_type||'%')
              AND (p_status IS NULL OR SYS_TASK_LIST.STATUS = p_status) 
              AND (p_cif_no IS NULL OR CIF_NO = p_cif_no)
              AND (p_tax_id IS NULL OR SYS_TASK_LIST.tax_id = p_tax_id)
              AND (p_maker IS NULL OR SYS_TASK_LIST.MAKER = p_maker)
              AND (p_user_name IS NULL OR SYS_TASK_LIST.USER_NAME = p_user_name)
              AND maker_branch_code LIKE  V_MEMBER_CODE||'%' --in (select xx.member_code from sys_user xx where xx.user_name = p_user)--DONB_CIS_TODO
            ORDER BY CREATED_DATE DESC, ID DESC;

        pkg_system_log.pr_log_info ('PR_GET_LIST_SYS_TASK_LIST', 'END', v_parameter);
        pkg_system_log.pr_log_debug ('PR_GET_LIST_SYS_TASK_LIST', 'END', v_parameter);

    EXCEPTION
        WHEN OTHERS
        THEN
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception ('PR_GET_LIST_SYS_TASK_LIST',
                                                 'EXCEPTION',
                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));

            END LOOP;
    END;

    /*
          Creater: DONB
          Created date: 27/06/2019 4:01:04 PM
          Description: L?y th�ng tin chi ti?t giao d?ch c?p nh?t BO theo TASK_ID ?? hi?n th?
          Parameter:
                   p_task_id:

        */
    PROCEDURE PR_GET_SYS_TASK_LIST_INFO (p_task_id             SYS_TASK_LIST.TASK_ID%TYPE,
                                             p_user         IN     VARCHAR2,
                                             p_client_ip    IN     VARCHAR2,
                                             p_user_agent   IN     VARCHAR2,
                                             p_out             OUT types.ref_cursor)
    AS
    BEGIN
        v_parameter := ', p_TASK_ID:' || p_TASK_ID || 'p_user:' || p_user || '|p_client_ip:' || p_client_ip || '|p_user_agent:' || p_user_agent;
        pkg_system_log.pr_log_info ('PR_GET_SYS_TASK_LIST_INFO', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('PR_GET_SYS_TASK_LIST_INFO', 'BEGIN', v_parameter);


        OPEN p_out FOR
            SELECT NFT.*, NFW."COMMENT" "COMMENT" --Ceck l?i
                FROM SYS_TASK_LIST NFT
                LEFT JOIN SYS_TASK_LIST_WF NFW ON NFT.TASK_ID = NFW.TASK_ID AND NFW.WORKFLOW_STATUS = 'REJECTED'
             WHERE NFT.TASK_ID = p_task_id
             --AND maker_branch_code in (select branch_code from sys_bank_user where user_name = p_user)--DONB_CIS_TODO
             ;

        pkg_system_log.pr_log_info ('PR_GET_SYS_TASK_LIST_INFO', 'END', v_parameter);
        pkg_system_log.pr_log_debug ('PR_GET_SYS_TASK_LIST_INFO', 'END', v_parameter);

    EXCEPTION
        WHEN OTHERS
        THEN
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception ('PR_GET_SYS_TASK_LIST_INFO',
                                                 'EXCEPTION',
                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));

            END LOOP;
    END;


    /*
          Creater: DONB
          Created date: 27/06/2019 4:01:04 PM
          Description: C?p nh?t danh s�ch c�c user/email ???c ??ng k�
          Parameter:
                   p_task_id: Giao dich thuc hien
                   p_user_email_reg: User/Email can kiem tra

        */
    PROCEDURE PR_GET_CREATE_USER_REGISTERED (p_task_id             SYS_TASK_LIST.TASK_ID%TYPE,
                                             p_user_email_reg         IN     VARCHAR2,
                                             p_user         IN     VARCHAR2,
                                             p_client_ip    IN     VARCHAR2,
                                             p_user_agent   IN     VARCHAR2)
    AS
    BEGIN
        v_parameter := substr(', p_user_email_reg:' || p_user_email_reg ||', p_TASK_ID:' || p_TASK_ID || 'p_user:' || p_user || '|p_client_ip:' || p_client_ip || '|p_user_agent:' || p_user_agent,1,3900);
        pkg_system_log.pr_log_info ('PR_GET_CREATE_USER_REGISTERED', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('PR_GET_CREATE_USER_REGISTERED', 'BEGIN', v_parameter);
        
        --DONB_CIS_TODO
        --insert into SYS_USER_REGISTERED(USER_NAME,TASK_ID,CREATED_DATE)
        --select distinct regexp_substr(p_user_email_reg,'[^;]+', 1, level) USER_NAME, p_TASK_ID, sysdate
        --from dual
        --connect by regexp_substr(p_user_email_reg, '[^;]+', 1, level) is not null;

        pkg_system_log.pr_log_info ('PR_GET_CREATE_USER_REGISTERED', 'END', v_parameter);
        pkg_system_log.pr_log_debug ('PR_GET_CREATE_USER_REGISTERED', 'END', v_parameter);

    EXCEPTION
        WHEN OTHERS
        THEN
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception ('PR_GET_CREATE_USER_REGISTERED',
                                                 'EXCEPTION',
                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));

            END LOOP;
    END;

        /*
          Creater: DONB
          Created date: 27/06/2019 4:01:04 PM
          Description: Kiem tra xem user/email nay da tung duoc dang ky chua
          Parameter:
                   p_user_email_reg: User/Email can kiem tra

        */
    PROCEDURE PR_GET_CHECK_USER_REGISTERED (p_user_email_reg         IN     VARCHAR2,
                                             p_user         IN     VARCHAR2,
                                             p_client_ip    IN     VARCHAR2,
                                             p_user_agent   IN     VARCHAR2,
                                             p_out             OUT types.ref_cursor)
    AS
    BEGIN
        v_parameter := ', p_user_email_reg:' || p_user_email_reg || 'p_user:' || p_user || '|p_client_ip:' || p_client_ip || '|p_user_agent:' || p_user_agent;
        pkg_system_log.pr_log_info ('PR_GET_CHECK_USER_REGISTERED', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('PR_GET_CHECK_USER_REGISTERED', 'BEGIN', v_parameter);
        
        --DONB_CIS_TODO
        --OPEN p_out FOR
        --select user_name
        --from SYS_USER_REGISTERED
        --where user_name in (select distinct regexp_substr(p_user_email_reg,'[^;]+', 1, level) USER_NAME
        --                    from dual
        --                    connect by regexp_substr(p_user_email_reg, '[^;]+', 1, level) is not null);

        pkg_system_log.pr_log_info ('PR_GET_CHECK_USER_REGISTERED', 'END', v_parameter);
        pkg_system_log.pr_log_debug ('PR_GET_CHECK_USER_REGISTERED', 'END', v_parameter);

    EXCEPTION
        WHEN OTHERS
        THEN
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception ('PR_GET_CHECK_USER_REGISTERED',
                                                 'EXCEPTION',
                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));

            END LOOP;
    END;

       /*
          Creater: DONB
          Created date: 27/06/2019 4:01:04 PM
          Description: Xoa user/email
          Parameter:
                   p_user_email_reg: User/Email can kiem tra

        */
    PROCEDURE PR_DELETE_USER_REGISTERED (p_user_email_reg         IN     VARCHAR2,
                                        p_user         IN     VARCHAR2,
                                        p_client_ip    IN     VARCHAR2,
                                        p_user_agent   IN     VARCHAR2)AS
    BEGIN
        v_parameter := substr(', p_user_email_reg:' || p_user_email_reg || ',p_user:' || p_user || '|p_client_ip:' || p_client_ip || '|p_user_agent:' || p_user_agent,1,3900);
        pkg_system_log.pr_log_info ('PR_DELETE_USER_REGISTERED', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('PR_DELETE_USER_REGISTERED', 'BEGIN', v_parameter);
        
        --DONB_CIS_TODO
        --delete from SYS_USER_REGISTERED where USER_NAME = p_user_email_reg;

        pkg_system_log.pr_log_info ('PR_DELETE_USER_REGISTERED', 'END', v_parameter);
        pkg_system_log.pr_log_debug ('PR_DELETE_USER_REGISTERED', 'END', v_parameter);

    EXCEPTION
        WHEN OTHERS
        THEN
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception ('PR_DELETE_USER_REGISTERED',
                                                 'EXCEPTION',
                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));

            END LOOP;
    END;

    /*
           Creater: DONB
           Created date: 27/06/2019 4:01:04 PM
           Description: Th?c hi?n upadte cac buoc duyet cua task list
           Parameter:
                    p_id:
                    p_task_id:
                    p_workflow_status:
                    p_task_wf_date:
                    p_comment:
                    p_maker:
           */
    PROCEDURE PR_CREATE_SYS_TASK_LIST_WF (p_task_id                  SYS_TASK_LIST_WF.TASK_ID%TYPE,
                                              p_workflow_status          SYS_TASK_LIST_WF.workflow_status%TYPE,
                                              p_task_wf_date                SYS_TASK_LIST_WF.TASK_WF_DATE%TYPE,
                                              p_comment                  SYS_TASK_LIST_WF.comment%TYPE,
                                              p_maker                    SYS_TASK_LIST_WF.maker%TYPE,
                                              p_user              IN     VARCHAR2,
                                              p_client_ip         IN     VARCHAR2,
                                              p_user_agent        IN     VARCHAR2,
                                              p_out                  OUT types.ref_cursor)
    IS
        p_id   SYS_TASK_LIST_WF.id%TYPE;
        v_maker_tran varchar2(50);
        v_rowcount NUMBER(10);
        V_APPROVER_BRANCH_CODE SYS_TASK_LIST.APPROVER_BRANCH_CODE%TYPE;
    BEGIN
        v_parameter :=
               ', p_maker:'
            || p_maker
            || ', p_comment:'
            || p_comment
            || ', p_task_wf_date:'
            || p_task_wf_date
            || ', p_workflow_status:'
            || p_workflow_status
            || ', p_task_id:'
            || p_task_id
            || ', p_id:'
            || p_id
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;
        p_id := SEQ_SYS_TASK_LIST_WF.NEXTVAL;
        pkg_system_log.pr_log_info ('PR_CREATE_SYS_TASK_LIST_WF', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('PR_CREATE_SYS_TASK_LIST_WF', 'BEGIN', v_parameter);

        --CuongNH2: 19/6/2018 Th�m b??c validate
        if p_workflow_status in ('APPROVED1') then
           select max(maker) into v_maker_tran
           from SYS_TASK_LIST a
           where a.TASK_ID=p_task_id;
           if v_maker_tran=p_maker then
             raise_application_error(-20000,'EB50014');
             return;
           end if;
        end if;

        INSERT INTO SYS_TASK_LIST_WF (ID,
                                          TASK_ID,
                                          WORKFLOW_STATUS,
                                          TASK_WF_DATE,
                                          "COMMENT",
                                          MAKER)
        VALUES (p_id,                                                                                                                                                      --ID
                p_task_id,                                                                                                                                            --TASK_ID
                p_workflow_status,                                                                                                                            --WORKFLOW_STATUS
                sysdate,                                                                                                                                        --TASK_DATE
                p_comment,                                                                                                                                            --COMMENT
                p_maker);

        --DONB_CIS_TODO
        --select MAX(BRANCH_CODE) into V_APPROVER_BRANCH_CODE
        --from SYS_BANK_USER where user_name=lower(p_maker);

        UPDATE SYS_TASK_LIST  SET
                STATUS = p_workflow_status,
                APPROVED_DATE = case when p_workflow_status in ('APPROVED','REJECTED') then sysdate else APPROVED_DATE end,
                APPROVER = case when p_workflow_status in ('APPROVED','REJECTED') then p_maker else APPROVER end,
                APPROVER_BRANCH_CODE = case when p_workflow_status in ('APPROVED','REJECTED') then V_APPROVER_BRANCH_CODE else APPROVER_BRANCH_CODE end
        WHERE TASK_ID = p_task_id;
             --AND maker_branch_code in (select branch_code from sys_bank_user where user_name = p_user); --DONB_CIS_TODO
        --X? l� g?i email th�ng b�o        
        IF p_workflow_status in ('APPROVED','REJECTED')  THEN
            PKG_SYS_EMAIL.PR_SEND_EMAIL_TASK(p_task_id, p_workflow_status , P_USER, p_comment);
        END IF;

        OPEN p_out FOR
            SELECT *
              FROM SYS_TASK_LIST_WF
             WHERE id = p_id;

        pkg_system_log.pr_log_info ('PR_CREATE_SYS_TASK_LIST_WF', 'END', v_parameter);
        pkg_system_log.pr_log_debug ('PR_CREATE_SYS_TASK_LIST_WF', 'END', v_parameter);
    EXCEPTION
        WHEN OTHERS
        THEN
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception ('PR_CREATE_SYS_TASK_LIST_WF',
                                                 'EXCEPTION',
                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));
            END LOOP;
            RAISE;
    END;




    /*
           Creater: DONB
           Created date: 27/06/2019 4:01:04 PM
           Description: Lay qua trinh duyet cua task list
           Parameter:
                    p_id:
                    p_task_id:
                    p_workflow_status:
                    p_TASK_DATE:
                    p_comment:
                    p_maker:
           */
    PROCEDURE PR_GET_SYS_TASK_LIST_WF (p_task_id    SYS_TASK_LIST_WF.TASK_ID%TYPE,
                                      p_user              IN     VARCHAR2,
                                      p_client_ip         IN     VARCHAR2,
                                      p_user_agent        IN     VARCHAR2,
                                      p_out                  OUT types.ref_cursor)  IS
    BEGIN
        v_parameter :=
             ', p_TASK_ID:'
            || p_TASK_ID
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        pkg_system_log.pr_log_info ('PR_GET_SYS_TASK_LIST_WF', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('PR_GET_SYS_TASK_LIST_WF', 'BEGIN', v_parameter);

        OPEN p_out FOR
            SELECT *
              FROM SYS_TASK_LIST_WF
             WHERE TASK_ID = p_task_id;

        pkg_system_log.pr_log_info ('PR_GET_SYS_TASK_LIST_WF', 'END', v_parameter);
        pkg_system_log.pr_log_debug ('PR_GET_SYS_TASK_LIST_WF', 'END', v_parameter);
    EXCEPTION
        WHEN OTHERS
        THEN
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception ('PR_GET_SYS_TASK_LIST_WF',
                                                 'EXCEPTION',
                                                 SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                                                 SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));
            END LOOP;
            RAISE;
    END;

END pkg_SYS_TASK_LIST;

/
--------------------------------------------------------
--  DDL for Package Body PKG_SYS_USER
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PKG_SYS_USER" 
  -- Author  : DONB
  -- Created : 17/06/2019 4:01:04 PM
  -- Purpose :
IS
    v_parameter   NVARCHAR2 (1500);
    v_errors      NUMBER (10);
    
    /*
    Creater: DONB 
    Created date: 17/06/2019
    Description: Th�m m?i th�ng tin ng??i d�ng n?i b? 
    */
    PROCEDURE pr_create_user (p_full_name SYS_USER.FULL_NAME%TYPE,
                                p_user_name SYS_USER.USER_NAME%TYPE,
                                --p_cic_code SYS_USER.CIC_CODE%TYPE,
                                --p_contract_no SYS_USER.CONTRACT_NO%TYPE,
                                --p_fee SYS_USER.FEE%TYPE,
                                p_type SYS_USER.TYPE%TYPE,
                                p_status SYS_USER.STATUS%TYPE,
                                p_description SYS_USER.DESCRIPTION%TYPE,
                                p_address SYS_USER.ADDRESS%TYPE,
                                p_phone SYS_USER.PHONE%TYPE,
                                p_email_backup SYS_USER.EMAIL_BACKUP%TYPE,
                                p_job_title SYS_USER.JOB_TITLE%TYPE,
                                p_cic_department SYS_USER.CIC_DEPARTMENT%TYPE,
                                p_open_date SYS_USER.OPEN_DATE%TYPE,
                                p_active_date SYS_USER.ACTIVE_DATE%TYPE,
                                p_expire_date SYS_USER.EXPIRE_DATE%TYPE,
                                p_reason_expired SYS_USER.REASON_EXPIRED%TYPE,
                                --p_contract_date SYS_USER.CONTRACT_DATE%TYPE,
                                p_end_date_contract SYS_USER.END_DATE_CONTRACT%TYPE,
                                --p_province SYS_USER.PROVINCE%TYPE,
                                p_name_of_contract SYS_USER.NAME_OF_CONTRACT%TYPE,
                                p_address_contract SYS_USER.ADDRESS_CONTRACT%TYPE,
                                --p_group_sbv SYS_USER.GROUP_SBV%TYPE,
                                --p_sbv_code SYS_USER.SBV_CODE%TYPE,
                                --p_cic_work_time_from SYS_USER.CIC_WORK_TIME_FROM%TYPE,
                               -- p_cic_work_time_to SYS_USER.CIC_WORK_TIME_TO%TYPE,
                               -- p_ci_user_type SYS_USER.CI_USER_TYPE%TYPE,
                                p_member_code SYS_USER.MEMBER_CODE%TYPE,
                               -- p_member_name SYS_USER.MEMBER_NAME%TYPE,
                              --  p_member_code_ci SYS_USER.MEMBER_CODE_CI%TYPE,
                              --  p_type_contract SYS_USER.TYPE_CONTRACT%TYPE,
                                p_create_date SYS_USER.CREATE_DATE%TYPE,
                                p_create_user SYS_USER.CREATE_USER%TYPE,
                                p_last_update_user SYS_USER.LAST_UPDATE_USER%TYPE,
                                p_last_update_date SYS_USER.LAST_UPDATE_DATE%TYPE,
                                p_group_name SYS_USER.GROUP_NAME%TYPE,
                                p_eff_date_contract SYS_USER.EFF_DATE_CONTRACT%TYPE,
                              --  p_stt_contract SYS_USER.STT_CONTRACT%TYPE,
                              --  p_websites SYS_USER.WEBSITES%TYPE,
                                p_issyn SYS_USER.ISSYN%TYPE,
                                p_email SYS_USER.EMAIL%TYPE,
                                p_language SYS_USER.LANGUAGE%TYPE,
                                p_user_type SYS_USER.USER_TYPE%TYPE,
                             --   p_notification SYS_USER.NOTIFICATION%TYPE,
                             --   p_exp_dt_notification SYS_USER.EXP_DT_NOTIFICATION%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_member_view_report SYS_USER.MEMBER_VIEW_REPORT%TYPE,
                                p_out                             OUT types.ref_cursor)
    AS
    BEGIN
/*
M� l?i	Di?n gi?i
000001	input value is null or invalid
000002	username is existing
000003	value of group name or member code is invalid
000004	error occurred while updating data
*/
IF p_full_name IS NULL
   OR p_user_name IS NULL
   OR p_member_code IS NULL 
   OR p_job_title IS NULL 
   OR p_email IS NULL
   OR p_group_name IS NULL THEN
  raise_application_error(-20000,'000001');
  RETURN;
  
END IF;

SELECT COUNT(9) X
INTO v_errors
FROM SYS_USER 
WHERE USER_NAME=lower(p_user_name );
IF v_errors>0 THEN
  raise_application_error(-20000,'000002');
  RETURN;
END IF;

SELECT COUNT(9) X
INTO v_errors
  FROM (SELECT TRIM(REGEXP_SUBSTR(STR, '[^,]+', 1, LEVEL)) STR
          FROM (SELECT p_group_name STR FROM DUAL)
        CONNECT BY INSTR(STR, ',', 1, LEVEL - 1) > 0) Y
  LEFT JOIN SYS_GROUPS X ON Y.STR = X.GROUP_NAME AND X.STATUS='1'
 WHERE X.GROUP_NAME IS NULL;
IF v_errors>0 THEN
  raise_application_error(-20000,'000003');
  RETURN;
END IF;
-- KET THUC VALIDATE

        INSERT INTO SYS_USER (FULL_NAME, 
                                USER_NAME, 
                                --CIC_CODE, 
                                --CONTRACT_NO, 
                                --FEE, 
                                TYPE, 
                                STATUS, 
                                DESCRIPTION, 
                                ADDRESS, 
                                PHONE, 
                                EMAIL_BACKUP, 
                                JOB_TITLE, 
                                CIC_DEPARTMENT, 
                                OPEN_DATE, 
                                ACTIVE_DATE, 
                                EXPIRE_DATE, 
                                REASON_EXPIRED, 
                                --CONTRACT_DATE, 
                                END_DATE_CONTRACT, 
                                --PROVINCE, 
                                NAME_OF_CONTRACT, 
                                ADDRESS_CONTRACT, 
                                MEMBER_CODE,
                                /*GROUP_SBV, 
                                SBV_CODE, 
                                CIC_WORK_TIME_FROM, 
                                CIC_WORK_TIME_TO, 
                                CI_USER_TYPE, 
                                 
                                MEMBER_NAME, 
                                MEMBER_CODE_CI, 
                                TYPE_CONTRACT, */
                                CREATE_DATE, 
                                CREATE_USER, 
                                --LAST_UPDATE_USER, 
                                --LAST_UPDATE_DATE, 
                                GROUP_NAME, 
                                EFF_DATE_CONTRACT, 
                                --STT_CONTRACT, 
                                --WEBSITES, 
                                ISSYN, 
                                EMAIL, 
                                LANGUAGE, 
                                USER_TYPE, 
                                --NOTIFICATION, 
                                --EXP_DT_NOTIFICATION,
                                MEMBER_VIEW_REPORT)
        VALUES (p_full_name , --FULL_NAME
                lower(p_user_name ), --USER_NAME
               -- p_cic_code , --CIC_CODE
              --  p_contract_no , --CONTRACT_NO
              --  p_fee , --FEE
                p_type , --TYPE
                case when p_status='2' then 2 else 1 end,--p_status , --STATUS Mac dinh 1 20210520 - Neu import thi de trang thai la 2
                p_description , --DESCRIPTION
                p_address , --ADDRESS
                p_phone , --PHONE
                p_email_backup , --EMAIL_BACKUP
               p_job_title , --JOB_TITLE
                p_cic_department , --CIC_DEPARTMENT
                p_open_date , --OPEN_DATE
                p_active_date , --ACTIVE_DATE
                p_expire_date , --EXPIRE_DATE
                p_reason_expired , --REASON_EXPIRED
               -- p_contract_date , --CONTRACT_DATE
                p_end_date_contract , --END_DATE_CONTRACT
                --p_province , --PROVINCE
                p_name_of_contract , --NAME_OF_CONTRACT
                p_address_contract , --ADDRESS_CONTRACT
                p_member_code , --MEMBER_CODE
               /* p_group_sbv , --GROUP_SBV
                p_sbv_code , --SBV_CODE
                p_cic_work_time_from , --CIC_WORK_TIME_FROM
                p_cic_work_time_to , --CIC_WORK_TIME_TO
                p_ci_user_type , --CI_USER_TYPE
                
                p_member_name , --MEMBER_NAME
                p_member_code_ci , --MEMBER_CODE_CI
                p_type_contract , --TYPE_CONTRACT */
                sysdate , --CREATE_DATE
                p_user , --CREATE_USER
                --p_last_update_user , --LAST_UPDATE_USER
                --p_last_update_date , --LAST_UPDATE_DATE
                p_group_name , --GROUP_NAME
                p_eff_date_contract , --EFF_DATE_CONTRACT
                --p_stt_contract , --STT_CONTRACT
                --p_websites , --WEBSITES
                p_issyn , --ISSYN
                p_email , --EMAIL
                p_language , --LANGUAGE
                p_user_type , --USER_TYPE
                --p_notification , --NOTIFICATION
                --p_exp_dt_notification,  --EXP_DT_NOTIFICATION
                p_member_view_report
                );
        PKG_SYS_EMAIL.PR_SEND_EMAIL_USER(p_user_name,'CREATED');
        
        OPEN p_out FOR
            SELECT *
              FROM SYS_USER
             WHERE USER_NAME = p_user_name;
 
    END;

/*
    Creater: DONB
    Created date: 17/06/2019
    Description: C?p nh?t th�ng tin ng??i d�ng n?i b? 
*/
    PROCEDURE pr_update_user (p_full_name SYS_USER.FULL_NAME%TYPE,
                                p_user_name SYS_USER.USER_NAME%TYPE,
                                --p_cic_code SYS_USER.CIC_CODE%TYPE,
                                --p_contract_no SYS_USER.CONTRACT_NO%TYPE,
                                --p_fee SYS_USER.FEE%TYPE,
                                p_type SYS_USER.TYPE%TYPE,
                                p_status SYS_USER.STATUS%TYPE,
                                p_description SYS_USER.DESCRIPTION%TYPE,
                                p_address SYS_USER.ADDRESS%TYPE,
                                p_phone SYS_USER.PHONE%TYPE,
                                p_email_backup SYS_USER.EMAIL_BACKUP%TYPE,
                                p_job_title SYS_USER.JOB_TITLE%TYPE,
                                p_cic_department SYS_USER.CIC_DEPARTMENT%TYPE,
                                p_open_date SYS_USER.OPEN_DATE%TYPE,
                                p_active_date SYS_USER.ACTIVE_DATE%TYPE,
                                p_expire_date SYS_USER.EXPIRE_DATE%TYPE,
                                p_reason_expired SYS_USER.REASON_EXPIRED%TYPE,
                                --p_contract_date SYS_USER.CONTRACT_DATE%TYPE,
                                p_end_date_contract SYS_USER.END_DATE_CONTRACT%TYPE,
                                --p_province SYS_USER.PROVINCE%TYPE,
                                p_name_of_contract SYS_USER.NAME_OF_CONTRACT%TYPE,
                                p_address_contract SYS_USER.ADDRESS_CONTRACT%TYPE,
                                --p_group_sbv SYS_USER.GROUP_SBV%TYPE,
                                --p_sbv_code SYS_USER.SBV_CODE%TYPE,
                                --p_cic_work_time_from SYS_USER.CIC_WORK_TIME_FROM%TYPE,
                               -- p_cic_work_time_to SYS_USER.CIC_WORK_TIME_TO%TYPE,
                               -- p_ci_user_type SYS_USER.CI_USER_TYPE%TYPE,
                                p_member_code SYS_USER.MEMBER_CODE%TYPE,
                               -- p_member_name SYS_USER.MEMBER_NAME%TYPE,
                              --  p_member_code_ci SYS_USER.MEMBER_CODE_CI%TYPE,
                              --  p_type_contract SYS_USER.TYPE_CONTRACT%TYPE,
                                p_create_date SYS_USER.CREATE_DATE%TYPE,
                                p_create_user SYS_USER.CREATE_USER%TYPE,
                                p_last_update_user SYS_USER.LAST_UPDATE_USER%TYPE,
                                p_last_update_date SYS_USER.LAST_UPDATE_DATE%TYPE,
                                p_group_name SYS_USER.GROUP_NAME%TYPE,
                                p_eff_date_contract SYS_USER.EFF_DATE_CONTRACT%TYPE,
                              --  p_stt_contract SYS_USER.STT_CONTRACT%TYPE,
                              --  p_websites SYS_USER.WEBSITES%TYPE,
                                p_issyn SYS_USER.ISSYN%TYPE,
                                p_email SYS_USER.EMAIL%TYPE,
                                p_language SYS_USER.LANGUAGE%TYPE,
                                p_user_type SYS_USER.USER_TYPE%TYPE,
                             --   p_notification SYS_USER.NOTIFICATION%TYPE,
                             --   p_exp_dt_notification SYS_USER.EXP_DT_NOTIFICATION%TYPE,
                                p_user                         IN     VARCHAR2,
                                p_client_ip                    IN     VARCHAR2,
                                p_user_agent                   IN     VARCHAR2,
                                p_member_view_report SYS_USER.MEMBER_VIEW_REPORT%TYPE,
                                p_out                             OUT types.ref_cursor)
    AS
    BEGIN
/*
M� l?i	Di?n gi?i
000001	input value is null or invalid
000002	username is existing
000003	value of group name or member code is invalid
000004	error occurred while updating data
*/
IF p_full_name IS NULL
   OR p_user_name IS NULL
   OR p_member_code IS NULL 
   OR p_job_title IS NULL 
   OR p_email IS NULL
   OR p_group_name IS NULL THEN
  raise_application_error(-20000,'000001');
  RETURN;
  
END IF;

SELECT COUNT(9) X
INTO v_errors
FROM SYS_USER 
WHERE USER_NAME=lower(p_user_name );
IF v_errors=0 THEN
  raise_application_error(-20000,'000002');
  RETURN;
END IF;

SELECT COUNT(9) X
INTO v_errors
  FROM (SELECT TRIM(REGEXP_SUBSTR(STR, '[^,]+', 1, LEVEL)) STR
          FROM (SELECT p_group_name STR FROM DUAL)
        CONNECT BY INSTR(STR, ',', 1, LEVEL - 1) > 0) Y
  LEFT JOIN SYS_GROUPS X ON Y.STR = X.GROUP_NAME AND X.STATUS='1'
 WHERE X.GROUP_NAME IS NULL;
IF v_errors>0 THEN
  raise_application_error(-20000,'000003');
  RETURN;
END IF;
-- KET THUC VALIDATE      
        UPDATE SYS_USER
           SET FULL_NAME=p_full_name,
                --CIC_CODE=p_cic_code, 
               -- CONTRACT_NO=p_contract_no, 
               -- FEE=p_fee, 
                TYPE=p_type, 
                STATUS=p_status, 
                DESCRIPTION=p_description, 
                ADDRESS=p_address, 
                PHONE=p_phone, 
                EMAIL_BACKUP=p_email_backup, 
               JOB_TITLE=p_job_title, 
                CIC_DEPARTMENT=p_cic_department, 
                OPEN_DATE=p_open_date, 
                ACTIVE_DATE=p_active_date, 
                EXPIRE_DATE=p_expire_date, 
                REASON_EXPIRED=p_reason_expired, 
               -- CONTRACT_DATE=p_contract_date, 
                END_DATE_CONTRACT=p_end_date_contract, 
               -- PROVINCE=p_province, 
                NAME_OF_CONTRACT=p_name_of_contract, 
                ADDRESS_CONTRACT=p_address_contract, 
                MEMBER_CODE=p_member_code, 
                /*GROUP_SBV=p_group_sbv, 
                SBV_CODE=p_sbv_code, 
                CIC_WORK_TIME_FROM=p_cic_work_time_from, 
                CIC_WORK_TIME_TO=p_cic_work_time_to, 
                CI_USER_TYPE=p_ci_user_type, 
                
                MEMBER_NAME=p_member_name, 
                MEMBER_CODE_CI=p_member_code_ci, 
                TYPE_CONTRACT=p_type_contract, */
                --CREATE_DATE=p_create_date, 
                --CREATE_USER=p_create_user, 
                LAST_UPDATE_USER=p_user, 
                LAST_UPDATE_DATE=sysdate, 
                GROUP_NAME=p_group_name, 
                EFF_DATE_CONTRACT=p_eff_date_contract, 
                --STT_CONTRACT=p_stt_contract, 
                --WEBSITES=p_websites, 
                ISSYN=p_issyn, 
                EMAIL=p_email, 
                LANGUAGE=p_language, 
                USER_TYPE=p_user_type, 
                --NOTIFICATION=p_notification, 
                --EXP_DT_NOTIFICATION=p_exp_dt_notification,
                MEMBER_VIEW_REPORT =  p_member_view_report,
                NUM_FAILED = case when status='-1' and p_status<>'-1' then 0 else NUM_FAILED end 
         WHERE USER_NAME=lower(p_user_name );

        PKG_SYS_EMAIL.PR_SEND_EMAIL_USER(p_user_name,'UPDATE');

        OPEN p_out FOR
            SELECT *
              FROM SYS_USER
             WHERE USER_NAME = lower(p_user_name );
 
    END;

 /*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y th�ng tin chi ti?t ng??i d�ng n?i b? SHB
    Parameter:
           p_user_name:
*/
    PROCEDURE pr_user_info (p_user_name SYS_USER.USER_NAME%TYPE,
                            p_user         IN     VARCHAR2,
                            p_client_ip    IN     VARCHAR2,
                            p_user_agent   IN     VARCHAR2,
                            p_out             OUT types.ref_cursor)
    AS
    BEGIN
            v_parameter :=
            ' p_user_name:'
            || p_user_name
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

--        pkg_system_log.pr_log_info ('pr_bank_user_info', 'BEGIN', v_parameter);
--        pkg_system_log.pr_log_debug ('pr_bank_user_info', 'BEGIN', v_parameter);

        OPEN p_out FOR
            SELECT *
              FROM SYS_USER
         WHERE  LOWER(USER_NAME) = LOWER(p_user_name);
 
    END;

/*
    Creater: DONB
    Created date: 17/06/2019
    Description: L?y danh s�ch ng??i d�ng n?i b? SHB
    Parameter:
           p_user_name:
*/
    PROCEDURE pr_list_user (p_user_name SYS_USER.USER_NAME%TYPE,
                            p_full_name SYS_USER.FULL_NAME%TYPE,
                            p_user                         IN     VARCHAR2,
                            p_client_ip                    IN     VARCHAR2,
                            p_user_agent                   IN     VARCHAR2,
                            p_out                             OUT types.ref_cursor)
    AS
    BEGIN
        v_parameter :=
             ', p_user_name:'
            || p_user_name
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

--        pkg_system_log.pr_log_info ('pr_list_bank_user', 'BEGIN', v_parameter);
--        pkg_system_log.pr_log_debug ('pr_list_bank_user', 'BEGIN', v_parameter);

        OPEN p_out FOR
        SELECT sysUser.*, sysRef.REF_NAME_VN STATUS_STR
        FROM SYS_USER sysUser
        LEFT JOIN SYS_REFCODE sysRef on sysUser.STATUS = sysRef.REF_CODE and sysRef.REF_GROUP = 'LS_STATUS'
        WHERE PKG_UTILITY.RemoveSignVietnamess(sysUser.USER_NAME) like '%'|| PKG_UTILITY.RemoveSignVietnamess(p_user_name) ||'%'
        AND PKG_UTILITY.RemoveSignVietnamess(sysUser.FULL_NAME) like '%'|| PKG_UTILITY.RemoveSignVietnamess(p_full_name) ||'%'
        AND ROWNUM<100
        order by sysUser.Create_Date desc;


    END;
    
    PROCEDURE pr_list_user_his (p_user_name SYS_USER.USER_NAME%TYPE, 
                            p_user                         IN     VARCHAR2,
                            p_client_ip                    IN     VARCHAR2,
                            p_user_agent                   IN     VARCHAR2,
                            p_out                             OUT types.ref_cursor)
    AS
    BEGIN
        v_parameter :=
             ', p_user_name:'
            || p_user_name
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

--        pkg_system_log.pr_log_info ('pr_list_bank_user', 'BEGIN', v_parameter);
--        pkg_system_log.pr_log_debug ('pr_list_bank_user', 'BEGIN', v_parameter);

        OPEN p_out FOR
        SELECT sysUser.FULL_NAME,
                sysUser.USER_NAME,
                sysUser.CIC_CODE,
                sysUser.CONTRACT_NO,
                sysUser.FEE,
                sysUser.TYPE,
                sysUser.STATUS,
                sysUser.DESCRIPTION,
                sysUser.ADDRESS,
                sysUser.PHONE,
                sysUser.EMAIL_BACKUP,
                sysUser.JOB_TITLE,
                sysUser.CIC_DEPARTMENT,
                sysUser.OPEN_DATE,
                sysUser.ACTIVE_DATE,
                sysUser.EXPIRE_DATE,
                sysUser.REASON_EXPIRED,
                sysUser.CONTRACT_DATE,
                sysUser.END_DATE_CONTRACT,
                sysUser.PROVINCE,
                sysUser.NAME_OF_CONTRACT,
                sysUser.ADDRESS_CONTRACT,
                sysUser.GROUP_SBV,
                sysUser.SBV_CODE,
                sysUser.CIC_WORK_TIME_FROM,
                sysUser.CIC_WORK_TIME_TO,
                sysUser.CI_USER_TYPE,
                sysUser.MEMBER_CODE,
                sysUser.MEMBER_NAME,
                sysUser.MEMBER_CODE_CI,
                sysUser.TYPE_CONTRACT,
                sysUser.CREATE_DATE,
                sysUser.CREATE_USER,
                sysUser.LAST_UPDATE_USER,
                sysUser.CREATED_DT LAST_UPDATE_DATE,
                sysUser.GROUP_NAME,
                sysUser.EFF_DATE_CONTRACT,
                sysUser.STT_CONTRACT,
                sysUser.WEBSITES,
                sysUser.ISSYN,
                sysUser.EMAIL,
                sysUser.LANGUAGE,
                sysUser.USER_TYPE,
                sysUser.NOTIFICATION,
                sysUser.EXP_DT_NOTIFICATION,
                sysUser.MEMBER_VIEW_REPORT,
                sysUser.CREATED_DT,
                sysUser.MACHINES_USR,
                sysUser.MACHINES_IP,
                sysRef.REF_NAME_VN STATUS_STR,
                BR1.PAR2 MEMBER_NAME,
                --BR2.REF_NAME_VN MEMBER_VIEW_REPORT_NAME,
                FN_MULTI_BRANCH_NAME(MEMBER_VIEW_REPORT) MEMBER_VIEW_REPORT_NAME,
                sysRefJob.REF_NAME_VN JOB_TITLE_NAME
        FROM SYS_USER_his sysUser
        
             LEFT JOIN SYS_REFCODE sysRefJob on sysUser.JOB_TITLE = sysRefJob.REF_CODE and sysRefJob.REF_GROUP = 'USER_ROLE'
             LEFT JOIN SYS_REFCODE sysRef on sysUser.STATUS = sysRef.REF_CODE and sysRef.REF_GROUP = 'LS_STATUS'
             LEFT JOIN SYS_REFCODE br1 on sysUser.MEMBER_CODE = BR1.REF_CODE and BR1.REF_GROUP = 'LS_BRANCH'
--             LEFT JOIN SYS_REFCODE br2 on sysUser.MEMBER_VIEW_REPORT = BR2.REF_CODE and BR2.REF_GROUP = 'LS_BRANCH'
        WHERE sysUser.USER_NAME=lower(p_user_name )
        order by CREATED_DT desc;


    END;
    
/*
    Creater: DONB
    Created date: 17/06/2019
    Description: M? kh�a t�i kho?n
    Parameter:
           p_user_name:
*/
    PROCEDURE pr_un_lock_user (p_user_name SYS_USER.USER_NAME%TYPE,
                                p_client_ip    IN     VARCHAR2,
                                p_user_agent   IN     VARCHAR2)
    AS
    BEGIN
        v_parameter :=  
        ', p_user_name:'
        || p_user_name
        ||'p_client_ip:'
        || p_client_ip
        || '|p_user_agent:'
        || p_user_agent;
        update sys_user set status=1 where user_name=p_user_name;--20210520 - Unlock user sau khi -> sau khi dong bo user thi thuc hien mo khoa
    END;

/*
    Creater: CuongNH2
    Created date: 20210520
    Description: L?y danh s�ch ng??i d�ng c?n ??ng b? liferay
    Parameter:
*/
    PROCEDURE pr_list_user_syn   (p_status                   IN     VARCHAR2,
                                  p_out                             OUT types.ref_cursor)
    AS
    BEGIN
        OPEN p_out FOR
        Select * from sys_user where status=2 and rownum<500
        order by create_date;
        
    END;
END;

/
--------------------------------------------------------
--  DDL for Package Body PKG_SYSTEM_LOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PKG_SYSTEM_LOG" AS

V_ERRORS     number(10);
V_EXCEPTION varchar2(25):='EXCEPTION';
V_DEBUG varchar2(25):='DEBUG';
V_INFO varchar2(25):='INFO';
/*
Creater: CuongNH2
Created date: 9/1/2018
Description: Lay thong tin cua user
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_Parameter: chi tiet cac parameter
             P_TASK_TYPE: kieu task
             P_IP_CLIENT: client ip
             P_MACHINE: ten machine
*/
Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob) is
begin

	
   PR_LOG_INFO(P_TASK_NAME, P_STEP_NAME, p_Parameter, 'PR');
/*EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
     ROLLBACK;
      PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME, P_STEP_NAME, SQLCODE, SQLERRM );*/
end;

/*
Creater: CuongNH2
Created date: 18/1/2018
Description: log DEBUG cho cac xu ly DB
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_Parameter: chi tiet cac parameter
*/
Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2) is
begin

   PR_LOG_DEBUG(P_TASK_NAME, P_STEP_NAME, p_Parameter, 'PR');

/*EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME ,
                           P_STEP_NAME ,
                           SQLCODE ,
                           SQLERRM );
      ROLLBACK;*/
end;

/*
Creater: CuongNH2
Created date: 18/1/2018
Description: ghi nhan log EXCEPTION
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_ErrorNumber: ma loi
             p_ErrorMessage: chi tiet noi dung loi
*/
Procedure PR_LOG_EXCEPTION(P_TASK_NAME varchar2,
                           P_STEP_NAME varchar2,
                           p_ErrorNumber varchar2,
                           p_ErrorMessage varchar2) is
begin
   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE,
      ERROR_CODE)
   values
     (SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      'PR',
      SYSDATE,
      P_STEP_NAME,
      p_ErrorNumber || '.' || p_ErrorMessage, 
      V_EXCEPTION,
      p_ErrorNumber);
   --raise_application_error(p_ErrorNumber,p_ErrorMessage);
EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      null;
end;
 

  /*
  Creater: SonTA2
  Created date: 30/1/2018
  Description: log INFO cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               P_TASK_TYPE: kieu task
  */
Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob, P_TASK_TYPE varchar2) is
begin
   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE)
   values
     (SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      P_TASK_TYPE,
      SYSDATE,
      P_STEP_NAME,
      SUBSTR(p_Parameter,1,4000), 
      V_INFO);
EXCEPTION  -- exception handlers begin
     WHEN OTHERS THEN  -- handles all other errors
       V_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;
       FOR I IN 1 .. V_ERRORS
       LOOP
         PR_LOG_EXCEPTION(P_TASK_NAME,P_STEP_NAME,
                         SQL%BULK_EXCEPTIONS (I).ERROR_CODE,
                         SQLERRM (-SQL%BULK_EXCEPTIONS (I).ERROR_CODE) );
       END LOOP;
      raise;
end;

/*
Creater: CuongNH2
Created date: 18/1/2018
Description: log DEBUG cho cac xu ly DB
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_Parameter: chi tiet cac parameter
*/
Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2, P_TASK_TYPE varchar2) is
begin

   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE)
   values
     (SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      P_TASK_TYPE,
      SYSDATE,
      P_STEP_NAME,
      SUBSTR(p_Parameter,1,4000), 
      V_DEBUG);

/*EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME ,
                           P_STEP_NAME ,
                           SQLCODE ,
                           SQLERRM );
      ROLLBACK;*/
end;

/*
Creater: CuongNH2
Created date: 23/1/2018
Description: ghi nhan log EXCEPTION khong throw
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_ErrorNumber: ma loi
             p_ErrorMessage: chi tiet noi dung loi
*/
Procedure PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME varchar2,
                           P_STEP_NAME varchar2,
                           p_ErrorNumber varchar2,
                           p_ErrorMessage clob,
                           P_TASK_TYPE varchar2 ) is
begin

   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE,
      ERROR_CODE)
   values
     (SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      P_TASK_TYPE,
      SYSDATE,
      P_STEP_NAME,
      p_ErrorNumber || '.' || p_ErrorMessage, 
      V_EXCEPTION,
      p_ErrorNumber);
EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      ROLLBACK;
end;


Procedure PR_LOG_ACTIVITY(P_APPLICATION_ID VARCHAR2,
                            P_RESOURCE_URL VARCHAR2,
                            P_ACCESS_USER VARCHAR2,
                            P_ACCESS_STATUS VARCHAR2,
                            P_LOG_MESSAGE CLOB,
                            P_RESOURCE_TYPE VARCHAR2,
                            P_RPT_CODE VARCHAR2,
                            P_RESOURCE_ACTION VARCHAR2,
                            P_CLIENT_IP VARCHAR2,
                            P_USER_AGENT VARCHAR2,
                            p_out OUT types.ref_cursor) IS
BEGIN
   INSERT INTO SYS_RESOURCEACCESSMANAGEMENT
     (ID,
      APPLICATION_ID,
      RESOURCE_URL,
      ACCESS_USER,
      ACCESS_DATE,
      ACCESS_STATUS,
      LOG_MESSAGE,
      RESOURCE_TYPE,
      RPT_CODE,
      RESOURCE_ACTION,
      CLIENT_IP,
      USER_AGENT)
   VALUES
     (SEQ_SYS_RES_ACCESSMANAGEMENT.NEXTVAL,
      P_APPLICATION_ID ,
      P_RESOURCE_URL ,
      P_ACCESS_USER ,
      SYSDATE ,
      P_ACCESS_STATUS ,
      P_LOG_MESSAGE ,
      P_RESOURCE_TYPE ,
      P_RPT_CODE ,
      REPLACE(P_RESOURCE_ACTION ,'.groovy',''),
      P_CLIENT_IP ,
      P_USER_AGENT );
      
      OPEN p_out FOR
      SELECT 'SUCCESS' STATUS FROM DUAL;
EXCEPTION  -- exception handlers begin
     WHEN OTHERS THEN  -- handles all other errors
       V_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;
       FOR I IN 1 .. V_ERRORS
       LOOP
         PR_LOG_EXCEPTION('PR_LOG_ACTIVITY','INSERT',
                         SQL%BULK_EXCEPTIONS (I).ERROR_CODE,
                         SQLERRM (-SQL%BULK_EXCEPTIONS (I).ERROR_CODE) );
       END LOOP;
      raise;
end;
end PKG_SYSTEM_LOG;

/
--------------------------------------------------------
--  DDL for Package Body PKG_UTILITY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_SYS_NCB"."PKG_UTILITY" is

/*
Creater: CuongNH2
Create date: 19/4/2018
Description: Xoa dau va chuyen thanh chu thuong
*/
FUNCTION RemoveSignVietnamess(P_STR IN VARCHAR2) RETURN clob
IS
  V_RESULT clob;
BEGIN

V_RESULT := TRANSLATE(P_STR,
'áàảãạăắằẳẵặâấầẩẫậđéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵÁÀẢÃẠĂẮẰẲẴẶÂẤẦẨẪẬĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ',
'aaaaaaaaaaaaaaaaadeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyyAAAAAAAAAAAAAAAAADEEEEEEEEEEEIIIIIOOOOOOOOOOOOOOOOOUUUUUUUUUUUYYYYY');

  RETURN lower(V_RESULT);
END;

/* 
Creater: CuongNH2
Create date: 11/7/2018
Description: Format number with comma
*/
FUNCTION FORMAT_NUMBER(P_STR IN VARCHAR2) RETURN VARCHAR2
IS
  V_RESULT VARCHAR2(50);
BEGIN

SELECT  TRIM(TO_CHAR(P_STR, '99G999G999G999G999G999G999', 'NLS_NUMERIC_CHARACTERS=",."')) INTO V_RESULT
FROM    dual;

  RETURN V_RESULT;
END;

end PKG_UTILITY;


commit;