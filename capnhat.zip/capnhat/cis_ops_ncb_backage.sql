--------------------------------------------------------
--  File created - Tuesday-February-20-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package PCK_CIS_OTHER_REQUEST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_CIS_OTHER_REQUEST" is

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o y굠c?u t? h? th?ng khᣊ*/
PROCEDURE PR_CREATE_OTHER_REQUEST (p_application_id VARCHAR2,
                                        p_source_request_id VARCHAR2,
                                        p_maker VARCHAR2, 
                                        p_customer_name VARCHAR2,
                                        p_customer_address VARCHAR2,
                                        p_client_ip VARCHAR2,
                                        p_user_agent VARCHAR2, 
                                        p_product_code VARCHAR2, 
                                        p_customer_type VARCHAR2, 
                                        p_batch_id VARCHAR2, 
                                        p_out    OUT SYS_REFCURSOR);

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o chi ti?t y굠c?u t? h? th?ng khᣊ*/
PROCEDURE PR_CREATE_OTHER_REQUEST_DETAIL (P_REQUEST_ID VARCHAR2, 
                                    P_SOURCE_REQUEST_ID VARCHAR2,
                                    P_CUSTOMER_ID_TYPE VARCHAR2,
                                    P_CUSTOMER_ID VARCHAR2, 
                                    p_out    OUT SYS_REFCURSOR);

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o chi ti?t th𮧠tin CIC CODE t? CIC
*/
PROCEDURE PR_CREATE_OTHER_REQUEST_CHECK (P_REQUEST_ID VARCHAR2,
                                        P_CUSTOMER_ID_TYPE VARCHAR2,
                                        P_CUSTOMER_ID VARCHAR2,
                                        P_CUST_CODE VARCHAR2,
                                        P_CIC_CUST_NAME VARCHAR2,
                                        P_CIC_CUST_ADDRESS VARCHAR2,
                                        P_CUST_TYPE VARCHAR2,
                                        P_CUST_TAX VARCHAR2,
                                        P_CUST_ID_NO VARCHAR2,
                                        P_CUST_REG VARCHAR2,
                                        P_CIC_CODE VARCHAR2,
                                        P_CIC_DATA VARCHAR2, 
                                        p_out    OUT SYS_REFCURSOR);     

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o phi?u y굠c?u h?i tin
*/
PROCEDURE PR_GENERATE_REQUEST_TO_CIC (P_REQUEST_ID VARCHAR2,
                                        p_out    OUT SYS_REFCURSOR); 

FUNCTION PR_STATUS_MATRIX_CIC(p_id_no CIS_REQUEST.ID_NO%TYPE,
                              p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
                              p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
                              p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
                              p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
                              p_cic_code varchar2) RETURN VARCHAR2;

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:Th?c hi?n t󺀠toᮠk?t qu? tr? l?i
*/
PROCEDURE PR_GENERATE_RESPONSE (P_REQUEST_ID VARCHAR2,
                                        p_out    OUT SYS_REFCURSOR); 

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:L?y b?n tin tr? l?i
*/
PROCEDURE PR_GET_RESPONSE (P_REQUEST_ID VARCHAR2, p_out    OUT SYS_REFCURSOR); 

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:L?y chi ti?t b?n tin tr? l?i
*/
PROCEDURE PR_GET_RESPONSE_DETAIL (P_RESPONSE_ID VARCHAR2, p_out    OUT SYS_REFCURSOR); 

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des: C?p nh?t tr?ng th᩠b?n tr? l?i tin
*/
PROCEDURE PR_UPDATE_OTHER_RESPONSE (P_RESPONSE_ID VARCHAR2,
                                   P_RESPONSE_STATUS VARCHAR2,
                                   P_RESPONSE_MESSAGE VARCHAR2,
                                   P_RESPONSE_DATA VARCHAR2,
                                   p_out    OUT SYS_REFCURSOR); 

/*
Creater: CuongNH2
Create Date: 6/12/2021
Des: T쭠ki?m cᣠy굠c?u h?i tin theo ?i?u ki?n
*/
PROCEDURE PR_SEARCH_OTHER_REQUEST (p_application_id varchar2,
                                   p_request_id varchar2,
                                   p_other_request_id varchar2, 
                                   p_batch_id varchar2, 
                                   p_from_date varchar2, 
                                   p_to_date varchar2, 
                                   p_out    out sys_refcursor); 

/*
Creater: CuongNH2
Create Date: 25/2/2022
Des: Th?c hi?n ki?m tra v࠴?o l?p b?n tin tr? l?i
*/
PROCEDURE PR_CHECK_OTHER_REQUEST (p_application_id varchar2,
                                   p_request_id varchar2,
                                   p_other_request_id varchar2, 
                                   p_batch_id varchar2, 
                                   p_out    out sys_refcursor); 

PROCEDURE PR_CHECK_OTHER_REQ_RECIVED;
end;

/
--------------------------------------------------------
--  DDL for Package PCK_DATA_REPORT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_DATA_REPORT" 
AS
PROCEDURE PR_GET_PCB_XXXSJF (P_REPORT_MONTH NVARCHAR2, p_out OUT SYS_REFCURSOR);

PROCEDURE PR_GET_PCB_XXXCNF (P_REPORT_MONTH NVARCHAR2, P_DATA_TYPE nvarchar2, p_out OUT SYS_REFCURSOR);

FUNCTION FORMAT_DATA(P_STR IN VARCHAR2,P_LENGTH IN INT) RETURN VARCHAR2;

FUNCTION FORMAT_NGAY_SINH(P_STR IN VARCHAR2) RETURN VARCHAR2;

FUNCTION FORMAT_ROWNUM(P_STR IN VARCHAR2,P_LENGTH IN INT) RETURN VARCHAR2;

PROCEDURE PR_NEW_REPORT_FILE_PCB (P_REPORT_MONTH NVARCHAR2, P_USER NVARCHAR2);

PROCEDURE PR_NEW_REPORT_FILE_CIC (p_report_month nvarchar2, 
                                p_user nvarchar2,
                                p_check_sum_md5 nvarchar2,
                                p_error_code nvarchar2,
                                p_error_msg nvarchar2,
                                p_file_name nvarchar2,
                                p_file_path nvarchar2,
                                p_file_size number , 
                                p_file_type nvarchar2,
                                p_file_path_encode nvarchar2, 
                                p_report_period nvarchar2,
                                p_file_status nvarchar2,
                                p_channel  nvarchar2,
                                p_out out sys_refcursor);

PROCEDURE PR_CREATED_FILE_PCB (P_REPORT_MONTH NVARCHAR2, 
                                P_USER NVARCHAR2,
                                P_CHECK_SUM_MD5 NVARCHAR2,
                                P_ERROR_CODE NVARCHAR2,
                                P_ERROR_MSG NVARCHAR2,
                                P_FILE_NAME NVARCHAR2,
                                P_FILE_PATH NVARCHAR2,
                                P_FILE_SIZE NUMBER,
                                P_FILE_TYPE NVARCHAR2,
                                P_FILE_PATH_ENCODE NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);

PROCEDURE PR_SEND_REPORT_FILE_PCB (P_REPORT_MONTH NVARCHAR2,
                                 P_FILE_STATUS VARCHAR2, 
                                 P_ERROR_CODE NVARCHAR2,
                                 P_ERROR_MSG NVARCHAR2,
                                 P_USER NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);
PROCEDURE PR_SEND_REPORT_FILE_CIC (P_FILE_NAME NVARCHAR2,
                                 P_FILE_STATUS VARCHAR2, 
                                 P_ERROR_CODE NVARCHAR2,
                                 P_ERROR_MSG NVARCHAR2,
                                 P_USER NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);
PROCEDURE PR_SEARCH_DATA (P_KEYWORD NVARCHAR2,
                          P_FROM_DATE DATE,
                          P_TO_DATE DATE,
                          P_FILE_STATUS VARCHAR2,
                           p_channel VARCHAR2,
                          P_USER VARCHAR2,
                          p_file_name varchar2,
                          p_out OUT SYS_REFCURSOR);

PROCEDURE PR_APPROVAL_FILE_PCB (P_REPORT_MONTH NVARCHAR2, P_FILE_STATUS VARCHAR2, p_reject_comment VARCHAR2,P_USER NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);
PROCEDURE PR_APPROVAL_FILE_CIC (P_REPORT_MONTH NVARCHAR2, P_FILE_STATUS VARCHAR2, p_reject_comment VARCHAR2,P_USER NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);
PROCEDURE PR_GET_CIC_DATA_REPORT (P_FILE_NAME NVARCHAR2, P_FILE_TYPE NVARCHAR2, P_FROM NVARCHAR2, P_TO NVARCHAR2 , p_out OUT SYS_REFCURSOR);

PROCEDURE PR_CREATED_FILE_CIC (P_REPORT_MONTH NVARCHAR2, 
                                P_USER NVARCHAR2,
                                P_CHECK_SUM_MD5 NVARCHAR2,
                                P_ERROR_CODE NVARCHAR2,
                                P_ERROR_MSG NVARCHAR2,
                                P_FILE_NAME NVARCHAR2,
                                P_FILE_PATH NVARCHAR2,
                                P_FILE_SIZE NUMBER,
                                P_FILE_TYPE NVARCHAR2,
                                P_FILE_PATH_ENCODE NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);
                                
PROCEDURE PR_UPDATE_CIC_RESPONSE (p_file_name NVARCHAR2,
                                 p_cic_status VARCHAR2, 
                                 p_cic_response clob,
                                 p_error_msg VARCHAR2,
                                 p_user NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);

PROCEDURE PR_GET_LOG_REPORT_FILE (p_file_name NVARCHAR2,
                                 p_user NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);
END PCK_DATA_REPORT;

/
--------------------------------------------------------
--  DDL for Package PCK_CIS_DASHBOARD
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_CIS_DASHBOARD" AS

/*
CREATE: CUONGNH
DESCRIPTION: TOP 10 BAN HOI TIN GAN NHAT
*/
PROCEDURE PR_LIST_TOP_REQUEST ( p_user varchar2,
                                p_client_ip varchar2,
                                p_user_agent varchar2,
                                p_out    OUT SYS_REFCURSOR) ;

/*
CREATE: CUONGNH
DESCRIPTION: SUMMARY ON MONTH
*/
PROCEDURE PR_LIST_REQUEST_MONTHLY ( p_user varchar2,
                                    p_client_ip varchar2,
                                    p_user_agent varchar2,
                                    p_out    OUT SYS_REFCURSOR) ;

/*
CREATE: CUONGNH
DESCRIPTION: SUMMARY ON MONTH
*/
PROCEDURE PR_LIST_REQ_PROD_MONTHLY ( p_user varchar2,
                                    p_client_ip varchar2,
                                    p_user_agent varchar2,
                                    p_out    OUT SYS_REFCURSOR) ;
/*
CREATE: CUONGNH
DESCRIPTION: TINH TOAN BIEU DO
*/
PROCEDURE PR_AGG_DASHBOARD;
/*
CREATE: CUONGNH
DESCRIPTION: VIEW CHAR
*/
PROCEDURE PR_LIST_CHAR ( p_user varchar2,
                          p_client_ip varchar2,
                          p_user_agent varchar2,
                          p_out    OUT SYS_REFCURSOR) ;

/*
CREATE: CUONGNH
DESCRIPTION: VIEW USERINFO
*/
PROCEDURE PR_USERINFO ( p_user varchar2,
                          p_client_ip varchar2,
                          p_user_agent varchar2,
                          p_out    OUT SYS_REFCURSOR) ;
END;

/
--------------------------------------------------------
--  DDL for Package PCK_CIS_REQUEST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_CIS_REQUEST" AS
  /* DoNB 26/03/2019 */
  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

    PROCEDURE PR_CREATE_CIS_REQUEST (
        p_id CIS_REQUEST.ID%TYPE,
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_channel CIS_REQUEST.CHANNEL%TYPE,
        p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
        p_member_code CIS_REQUEST.MEMBER_CODE%TYPE,
        p_cic_code CIS_REQUEST.CIC_CODE%TYPE,
        p_id_no CIS_REQUEST.ID_NO%TYPE,
        p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
        p_username_request CIS_REQUEST.USERNAME_REQUEST%TYPE,
        p_branch_code CIS_REQUEST.BRANCH_CODE%TYPE,
        p_created_date CIS_REQUEST.CREATED_DATE%TYPE,
        p_requested_date CIS_REQUEST.REQUESTED_DATE%TYPE,
        p_request_data CIS_REQUEST.REQUEST_DATA%TYPE,
        p_err_code CIS_REQUEST.ERR_CODE%TYPE,
        p_err_msg CIS_REQUEST.ERR_MSG%TYPE,
        p_address CIS_REQUEST.ADDRESS%TYPE,
        p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
        p_note CIS_REQUEST.NOTE%TYPE,
        p_customer_name CIS_REQUEST.CUSTOMER_NAME%TYPE,
        p_customer_code CIS_REQUEST.CUSTOMER_CODE%TYPE,
        p_response_date CIS_REQUEST.RESPONSE_DATE%TYPE,
        p_email CIS_REQUEST.EMAIL%TYPE,
        p_last_version CIS_REQUEST.LAST_VERSION%TYPE,
        p_flag CIS_REQUEST.FLAG%TYPE,
        p_msg_id CIS_REQUEST.MSG_ID%TYPE,
        p_application_id CIS_REQUEST.APPLICATION_ID%TYPE,
        p_maker CIS_REQUEST.MAKER%TYPE,
        p_task_id CIS_REQUEST.TASK_ID%TYPE,
        p_encode_request cis_request.encode_request%TYPE,
        p_borrower CIS_REQUEST.BORROWER%TYPE,
        p_pcb_code CIS_REQUEST.PCB_CODE%TYPE,
        p_ccy CIS_REQUEST.CCY%TYPE,
        p_amount_fin_capital CIS_REQUEST.AMOUNT_FIN_CAPITAL%TYPE,
        p_total_instalment CIS_REQUEST.TOTAL_INSTALMENT%TYPE,
        p_credit_limit CIS_REQUEST.CREDIT_LIMIT%TYPE,
        p_gender CIS_REQUEST.GENDER%TYPE,
        p_dob CIS_REQUEST.DOB%TYPE,
        p_doc_type CIS_REQUEST.DOC_TYPE%TYPE,
        p_pay_periodicity CIS_REQUEST.PAY_PERIODICITY%TYPE,
        p_operation_type CIS_REQUEST.OPERATION_TYPE%TYPE,
        p_country_of_birth CIS_REQUEST.COUNTRY_OF_BIRTH%TYPE,
        p_request_id CIS_REQUEST.REQUEST_ID%TYPE,
        p_frequent_contacts CIS_REQUEST.FREQUENT_CONTACTS%TYPE,
        p_phone_number CIS_REQUEST.PHONE_NUMBER%TYPE,
        p_user varchar2,
        p_client_ip varchar2,
        p_user_agent varchar2,
        p_nam_tai_chinh varchar2,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_UPDATE_STATUS_CIS_REQUEST (
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_request_data CIS_REQUEST.REQUEST_DATA%TYPE,
        p_msg_id CIS_REQUEST.MSG_ID%TYPE,
        p_err_code CIS_REQUEST.ERR_CODE%TYPE,
        p_err_msg CIS_REQUEST.ERR_MSG%TYPE,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_GET_LIST_CIS_REQUEST (
        p_id_no CIS_REQUEST.ID_NO%TYPE,
        p_member_code CIS_REQUEST.MEMBER_CODE%TYPE,
        p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
        p_customer_name CIS_REQUEST.CUSTOMER_NAME%TYPE,
        p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
        p_address CIS_REQUEST.ADDRESS%TYPE,
        p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
        p_cic_code CIS_REQUEST.CIC_CODE%TYPE,
        p_customer_code CIS_REQUEST.CUSTOMER_CODE%TYPE,
        p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_maker CIS_REQUEST.MAKER%TYPE,
        p_from_date CIS_REQUEST.REQUESTED_DATE%TYPE,
        p_to_date CIS_REQUEST.REQUESTED_DATE%TYPE,
        p_task_id CIS_REQUEST.TASK_ID%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_channel CIS_REQUEST.CHANNEL%TYPE,
        p_user varchar2,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_GET_CIS_REQUEST_INFO (
        p_cis_no CIS_REQUEST.ID_NO%TYPE,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_CHECK_REQUEST_INFO ( p_param1 varchar2,
                                      p_param2 varchar2,
                                      p_param3 varchar2,
                                      p_param4 varchar2,
                                      p_param5 varchar2,
                                      p_param6 varchar2,
                                      p_param7 varchar2,
                                      p_param8 varchar2,
                                      p_channel varchar2,
                                      p_user varchar2,
                                      p_client_ip varchar2,
                                      p_user_agent varchar2,
                                      p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_CHECK_BATCH_REQUEST_INFO (p_param1 varchar2,
                                        p_param2 varchar2,
                                        p_param3 varchar2,
                                        p_param4 varchar2,
                                        p_param5 varchar2,
                                        p_param6 varchar2,
                                        p_param7 varchar2,
                                        p_param8 varchar2,
                                        p_channel varchar2,
                                        p_user varchar2,
                                        p_client_ip varchar2,
                                        p_user_agent varchar2,
                                        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_GET_LOT_NO (
        p_user                         IN     VARCHAR2,
        p_client_ip                    IN     VARCHAR2,
        p_user_agent                   IN     VARCHAR2,
        p_out    OUT SYS_REFCURSOR);

   FUNCTION PR_STATUS_MATRIX_PCB( p_product_code  varchar2,
                                      p_id_no  varchar2,
                                      p_doc_type  varchar2,
                                      P_register_no varchar2 ) RETURN VARCHAR2;

   FUNCTION PR_STATUS_MATRIX_CIC(p_id_no CIS_REQUEST.ID_NO%TYPE,
                              p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
                              p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
                              p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
                              p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
                              p_cic_code varchar2) RETURN VARCHAR2;

   FUNCTION PR_STATUS_MATRIX_TS ( p_phone_number varchar2,
                                      p_product_code varchar2,
                                      p_id_no varchar2) RETURN VARCHAR2;

   FUNCTION PR_CHECK_BLACK_LIST ( p_id_no varchar2) RETURN VARCHAR2;

   PROCEDURE PR_ADD_CIS_REQUEST_EMAIL (
        P_CIS_NO CIS_REQUEST.CIS_NO%TYPE,
        P_USER                         IN     VARCHAR2,
        P_CLIENT_IP                    IN     VARCHAR2,
        P_USER_AGENT                   IN     VARCHAR2,
        P_OUT    OUT SYS_REFCURSOR);

   PROCEDURE PR_GET_LIST_CIS_SENT (
        P_STATUS VARCHAR2,
        P_CHANNEL                         IN     VARCHAR2,
        P_USER                    IN     VARCHAR2,
        P_OUT    OUT SYS_REFCURSOR);
        
   --FIX Loi SENDDING - 7/4/2021
   PROCEDURE PR_GET_LIST_CIS_NEW (
        P_STATUS VARCHAR2,
        P_CHANNEL                         IN     VARCHAR2,
        P_USER                    IN     VARCHAR2,
        P_OUT    OUT SYS_REFCURSOR);

   PROCEDURE PR_AUTO_REJECT_REQUEST;

END PCK_CIS_REQUEST;

/
--------------------------------------------------------
--  DDL for Package PCK_CIC_TOKEN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_CIC_TOKEN" AS 

/*
Created: 05/01/2023
Creater: CuongNH2
Note: L?y token cu?i cùng 
*/
PROCEDURE PR_GET_CIC_TOKEN (p_out    OUT SYS_REFCURSOR);


/*
Created: 05/01/2023
Creater: CuongNH2
Note: T?o m?i token
*/
PROCEDURE PR_UPDATE_CIC_TOKEN (p_token VARCHAR2,
                        p_thoi_gian_bat_dau VARCHAR2,
                        p_token_het_han VARCHAR2,
                        p_mat_khau_het_han   VARCHAR2,
                        p_ghi_chu VARCHAR2,
                        p_out    OUT SYS_REFCURSOR);

END PCK_CIC_TOKEN;

/
--------------------------------------------------------
--  DDL for Package PCK_DATA_REPORT_FROM_CIC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_DATA_REPORT_FROM_CIC" AS 

/*
Select file by file name
*/

PROCEDURE PR_GET_FILE_BY_NAME(P_ID VARCHAR2,
                        P_FILE_NAME VARCHAR2,
                        P_FILE_STATUS VARCHAR2, 
                        P_RESPONSE_DATE VARCHAR2,
                        P_FILE_PATH VARCHAR2,
                        P_CHECK_SUM_MD5 VARCHAR2, 
                        p_out    OUT SYS_REFCURSOR);
                        
PROCEDURE PR_UPDATE_STATUS_FILE(P_ID VARCHAR2,
                        P_FILE_NAME VARCHAR2,
                        P_FILE_STATUS VARCHAR2, 
                        P_RESPONSE_DATE VARCHAR2,
                        P_FILE_PATH VARCHAR2,
                        P_CHECK_SUM_MD5 VARCHAR2, 
                        p_out    OUT SYS_REFCURSOR);

END PCK_DATA_REPORT_FROM_CIC;

/
--------------------------------------------------------
--  DDL for Package PCK_CIS_RESPONSE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_CIS_RESPONSE" AS
  /* DoNB 26/03/2019 */
  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
    PROCEDURE PR_CREATE_CIS_RESPONSE (
        p_id CIS_RESPONSE.ID%TYPE,
        p_cis_no CIS_RESPONSE.CIS_NO%TYPE,
        p_cic_code CIS_RESPONSE.CIC_CODE%TYPE,
        p_member_code CIS_RESPONSE.MEMBER_CODE%TYPE,
        p_tax_code CIS_RESPONSE.TAX_CODE%TYPE,
        p_id_no CIS_RESPONSE.ID_NO%TYPE,
        p_product_code CIS_RESPONSE.PRODUCT_CODE%TYPE,
        p_response_date CIS_RESPONSE.RESPONSE_DATE%TYPE,
        p_status_code_cic CIS_RESPONSE.STATUS_CODE_CIC%TYPE,
        p_created_date CIS_RESPONSE.CREATED_DATE%TYPE,
        p_err_code CIS_RESPONSE.ERR_CODE%TYPE,
        p_err_msg CIS_RESPONSE.ERR_MSG%TYPE,
        p_response_data CIS_RESPONSE.RESPONSE_DATA%TYPE,
        p_status CIS_RESPONSE.STATUS%TYPE,
        p_version_no CIS_RESPONSE.VERSION_NO%TYPE,
        p_execute_date CIS_RESPONSE.EXECUTE_DATE%TYPE,
        p_msg_id CIS_RESPONSE.MSG_ID%TYPE,
        p_out    OUT SYS_REFCURSOR);


    PROCEDURE PR_GET_CIS_RESPONSE_INFO (
        p_id CIS_RESPONSE.ID%TYPE,
        p_cis_no CIS_RESPONSE.CIS_NO%TYPE,
        p_cic_code CIS_RESPONSE.CIC_CODE%TYPE,
        p_member_code CIS_RESPONSE.MEMBER_CODE%TYPE,
        p_tax_code CIS_RESPONSE.TAX_CODE%TYPE,
        p_id_no CIS_RESPONSE.ID_NO%TYPE,
        p_product_code CIS_RESPONSE.PRODUCT_CODE%TYPE,
        p_response_date CIS_RESPONSE.RESPONSE_DATE%TYPE,
        p_status_code_cic CIS_RESPONSE.STATUS_CODE_CIC%TYPE,
        p_created_date CIS_RESPONSE.CREATED_DATE%TYPE,
        p_err_code CIS_RESPONSE.ERR_CODE%TYPE,
        p_err_msg CIS_RESPONSE.ERR_MSG%TYPE,
        p_response_data CIS_RESPONSE.RESPONSE_DATA%TYPE,
        p_status CIS_RESPONSE.STATUS%TYPE,
        p_version_no CIS_RESPONSE.VERSION_NO%TYPE,
        p_execute_date CIS_RESPONSE.EXECUTE_DATE%TYPE,
        p_msg_id CIS_RESPONSE.MSG_ID%TYPE,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_LIST_CIS_RESPONSE_FOR_PASER (
        p_status varchar2, 
        p_channel varchar2, 
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_CIS_RESPONSE_CHANGE_STATUS (
        p_status varchar2, 
        p_cis_no varchar2, 
        p_id varchar2, 
        p_out    OUT SYS_REFCURSOR);

END PCK_CIS_RESPONSE;

/
--------------------------------------------------------
--  DDL for Package PCK_REPORT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_REPORT" is
/*
CREATE: CUONGNH
DESCRIPTION: 5.6.1.  ICR.06.01 - Bᯠcᯠtruy c?p h? th?ng
*/
PROCEDURE RPT_ICR0601 ( p_page VARCHAR2,
                        p_limit VARCHAR2,
                        P_FROM_DATE VARCHAR2,
                        P_TO_DATE   VARCHAR2,
                        P_USER_NAME VARCHAR2,
                        P_BRANCH_CODE    VARCHAR2,
                        P_RESOURCE_URL    VARCHAR2,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) ;

/*
CREATE: CUONGNH
DESCRIPTION: 5.6.2.  ICR.06.02 - Bᯠcᯠqu?n lý ng??i dùng
*/
PROCEDURE RPT_ICR0602 ( P_BRANCH_CODE    VARCHAR2,
                        P_KEYWORD        VARCHAR2,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) ;


/*
CREATE: CUONGNH
DESCRIPTION: 5.6.3.  ICR.06.03 - Bᯠcᯠchi ti?t tra c?u tin theo t?ng b?n h?i tin
*/
PROCEDURE RPT_ICR0603 ( P_BRANCH_CODE    VARCHAR2,
                        P_CHANNEL        VARCHAR2,
                        P_PRODUCT_CODE        VARCHAR2,
                        P_FROM_DATE        DATE,
                        P_TO_DATE        DATE,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_KEYWORD VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) ;

/*
CREATE: CUONGNH
DESCRIPTION: 5.6.4.  ICR.06.04 - Bᯠcᯠchi ti?t tra c?u t?ng h?p theo user h?i tin
*/
PROCEDURE RPT_ICR0604 ( P_BRANCH_CODE    VARCHAR2,
                        P_CHANNEL        VARCHAR2,
                        P_PRODUCT_CODE        VARCHAR2,
                        P_FROM_DATE        DATE,
                        P_TO_DATE        DATE,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_KEYWORD VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) ;
end PCK_REPORT;

/
--------------------------------------------------------
--  DDL for Package PCK_REPORT_FROM_CIC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_REPORT_FROM_CIC" AS 

/*
KHOI TAO FILE MOI
*/
PROCEDURE PR_CREATE_FILE(P_ID VARCHAR2,
                        P_FILE_NAME VARCHAR2,
                        P_FILE_STATUS VARCHAR2, 
                        P_RESPONSE_DATE VARCHAR2,
                        P_FILE_PATH VARCHAR2,
                        P_CHECK_SUM_MD5 VARCHAR2, 
                        p_out    OUT SYS_REFCURSOR);

PROCEDURE PR_UPDATE_FILE(P_ID VARCHAR2,
                        P_FILE_NAME VARCHAR2,
                        P_FILE_STATUS VARCHAR2, 
                        P_RESPONSE_DATE VARCHAR2,
                        P_FILE_PATH VARCHAR2,
                        P_CHECK_SUM_MD5 VARCHAR2, 
                        p_out    OUT SYS_REFCURSOR);

PROCEDURE PR_GET_FILE(P_ID VARCHAR2,
                        P_FILE_NAME VARCHAR2,
                        P_FILE_STATUS VARCHAR2, 
                        P_RESPONSE_DATE VARCHAR2,
                        P_FILE_PATH VARCHAR2,
                        P_CHECK_SUM_MD5 VARCHAR2, 
                        p_out    OUT SYS_REFCURSOR);
                      
END PCK_REPORT_FROM_CIC;

/
--------------------------------------------------------
--  DDL for Package PCK_REQUEST_LOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_REQUEST_LOG" is

  -- Author  : CuongNH
  -- Created : 24/8/2020
  -- Purpose : Luu log g?i request sang partner

  /*
  Creater: CuongNH2
  Created date:  24/8/2020
  Description: Luu log g?i request sang partner  
  */
  Procedure PR_LOG_INFO(P_REQUEST_ID varchar2,
                        P_MSG_TYPE varchar2,
                        P_MSG_DATA clob,
                        P_ERROR_CODE varchar2,
                        P_ERROR_MSG clob,
                        P_END_POINT varchar2, 
                        P_REQUEST_DATE varchar2, 
                        P_ADDITION_INFO varchar2,
                        p_out OUT types.ref_cursor);


end PCK_REQUEST_LOG;

/
--------------------------------------------------------
--  DDL for Package PCK_TOKEN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_TOKEN" AS 

PROCEDURE PR_GET_TOKEN (p_out    OUT SYS_REFCURSOR);

END PCK_TOKEN;

/
--------------------------------------------------------
--  DDL for Package PKG_CIC_GROUP_DEBT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PKG_CIC_GROUP_DEBT" 
AS
    /******************************************************************************
       NAME:       PKG_CIC_GROUP_DEBT
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        31/07/2020      dodti       1. Created this package.
    ******************************************************************************/

    PROCEDURE pr_get_list_cic_group_debt (
        p_text_search             VARCHAR2,
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_rpt_dt10                VARCHAR2,
        p_cst_cd                  VARCHAR2,
        p_cst_nm                  VARCHAR2,
        p_cic_code                VARCHAR2,
        p_bal                     VARCHAR2,
        p_group_debt              VARCHAR2,
        p_low_group_debt          VARCHAR2,
        p_member_code             VARCHAR2,
        p_user             IN     VARCHAR2,
        p_from_date             VARCHAR2,
        p_to_date             VARCHAR2,
        p_out                 OUT types.ref_cursor);
        
PROCEDURE pr_insert_record(
        p_id                      VARCHAR2,
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_rpt_dt10                VARCHAR2,
        p_cst_cd                  VARCHAR2,
        p_cst_nm                  VARCHAR2,
        p_cic_code                VARCHAR2,
        p_bal                     NUMBER,
        p_group_debt              VARCHAR2,
        p_low_group_debt          VARCHAR2,
        p_member_code             VARCHAR2,
        p_cst_id             VARCHAR2,
        p_address             VARCHAR2,
        p_user             IN     VARCHAR2,
        p_out                 OUT types.ref_cursor);

PROCEDURE pr_delete_record(
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_user             IN     VARCHAR2,
        p_out                 OUT types.ref_cursor);
        
END PKG_CIC_GROUP_DEBT;

/
--------------------------------------------------------
--  DDL for Package PKG_FRAUDULENCE_CUSTOMER
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PKG_FRAUDULENCE_CUSTOMER" AS
    PROCEDURE pr_list_fraudulence_customer(p_customer_code cis_fraudulence_customer.customer_code%TYPE ,
                               p_customer_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_report_date_from cis_fraudulence_customer.report_date%TYPE,
                               p_report_date_to cis_fraudulence_customer.report_date%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_cic_code cis_fraudulence_customer.cic_code%TYPE,
                                p_status cis_fraudulence_customer.cic_code%TYPE,
                                p_from_date                DATE,
                               p_to_date                  DATE,
                               p_out OUT types.ref_cursor);

    PROCEDURE pr_create_fraudulence_customer(p_cic_code cis_fraudulence_customer.cic_code%TYPE ,
                               p_customer_type cis_fraudulence_customer.customer_type%TYPE,
                               p_customer_code cis_fraudulence_customer.customer_code%TYPE,
                               p_customer_name cis_fraudulence_customer.customer_name%TYPE,
                               p_customer_full_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_customer_short_name cis_fraudulence_customer.customer_short_name%TYPE,
                               p_customer_add cis_fraudulence_customer.customer_add%TYPE,
                               p_customer_phone cis_fraudulence_customer.customer_phone%TYPE,
                               p_customer_fax cis_fraudulence_customer.customer_fax%TYPE,
                               p_customer_web cis_fraudulence_customer.customer_web%TYPE,
                               p_customer_email cis_fraudulence_customer.customer_email%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_tax_date cis_fraudulence_customer.tax_date%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_register_date cis_fraudulence_customer.register_date%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_industry_code cis_fraudulence_customer.industry_code%TYPE,
                               p_legal_personal cis_fraudulence_customer.legal_personal%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_director_name cis_fraudulence_customer.director_name%TYPE,
                               p_director_id cis_fraudulence_customer.director_id%TYPE,
                               p_source cis_fraudulence_customer.source%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                                p_status cis_fraudulence_customer.status%TYPE,
                               p_out OUT types.ref_cursor);

    PROCEDURE pr_update_fraudulence_customer(p_id cis_fraudulence_customer.id%TYPE ,
                                p_cic_code cis_fraudulence_customer.cic_code%TYPE ,
                               p_customer_type cis_fraudulence_customer.customer_type%TYPE,
                               p_customer_code cis_fraudulence_customer.customer_code%TYPE,
                               p_customer_name cis_fraudulence_customer.customer_name%TYPE,
                               p_customer_full_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_customer_short_name cis_fraudulence_customer.customer_short_name%TYPE,
                               p_customer_add cis_fraudulence_customer.customer_add%TYPE,
                               p_customer_phone cis_fraudulence_customer.customer_phone%TYPE,
                               p_customer_fax cis_fraudulence_customer.customer_fax%TYPE,
                               p_customer_web cis_fraudulence_customer.customer_web%TYPE,
                               p_customer_email cis_fraudulence_customer.customer_email%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_tax_date cis_fraudulence_customer.tax_date%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_register_date cis_fraudulence_customer.register_date%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_industry_code cis_fraudulence_customer.industry_code%TYPE,
                               p_legal_personal cis_fraudulence_customer.legal_personal%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_director_name cis_fraudulence_customer.director_name%TYPE,
                               p_director_id cis_fraudulence_customer.director_id%TYPE,
                               p_source cis_fraudulence_customer.source%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                                p_status cis_fraudulence_customer.status%TYPE,
                               p_out OUT types.ref_cursor);                           

    PROCEDURE pr_info_fraudulence_customer(p_customer_code cis_fraudulence_customer.customer_code%TYPE ,
                               p_customer_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_cic_code cis_fraudulence_customer.cic_code%TYPE,
                               p_out OUT types.ref_cursor);

    PROCEDURE pr_update_inactive_fraudulence(p_fraud_type varchar2);
END PKG_FRAUDULENCE_CUSTOMER;

/
--------------------------------------------------------
--  DDL for Package PKG_SYS_EMAIL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PKG_SYS_EMAIL" 
AS
    /******************************************************************************
       NAME:       PKG_SYS_EMAIL
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        5/3/2018      admin       1. Created this package.
    ******************************************************************************/

    PROCEDURE pr_create_sys_email (
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        --p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        --p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        --p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        --p_status                   SYS_EMAIL.STATUS%TYPE,
        --p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        --p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        --p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor);

    PROCEDURE pr_get_list_sys_email (
        p_text_search              VARCHAR2,
        p_status              VARCHAR2,
        p_from_date                DATE,
        p_to_date                  DATE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor);

    PROCEDURE pr_update_sys_email (
        p_id                       SYS_EMAIL.ID%TYPE,
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        p_status                   SYS_EMAIL.STATUS%TYPE,
        p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor);

    PROCEDURE pr_get_sys_email_by_id (p_id                  SYS_EMAIL.ID%TYPE,
                                      p_user         IN     VARCHAR2,
                                      p_client_ip    IN     VARCHAR2,
                                      p_user_agent   IN     VARCHAR2,
                                      p_out             OUT types.ref_cursor);

--G?i email th𮧠bᯠkh?i t?o/di?u ch?nh user
PROCEDURE PR_SEND_EMAIL_USER (P_USER_ID                 VARCHAR2,
                              P_ACTION                  VARCHAR2);

--G?i email th𮧠bᯠnh?n b?n tin
PROCEDURE PR_SEND_EMAIL_RESPONSE (P_CIS_NO                  VARCHAR2);

--G?i email th𮧠bᯠphꠤuy?t b?n tin
PROCEDURE PR_SEND_EMAIL_TASK(P_TASK_ID VARCHAR2, P_STATUS VARCHAR2, P_USER VARCHAR2, P_COMMENT VARCHAR2);

--G?i email th𮧠bᯠcho ng??i dùng bi?t c󠦩le m?i
PROCEDURE PR_SEND_EMAIL_NEW_FILE(P_FILE_NAME VARCHAR2, P_CHANNEL VARCHAR2, P_STATUS VARCHAR2);

END PKG_SYS_EMAIL;

/
--------------------------------------------------------
--  DDL for Package PKG_SYSTEM_LOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PKG_SYSTEM_LOG" is

  -- Author  : CuongNH
  -- Created : 1/9/2018 4:47:26 PM
  -- Purpose : Luu log he thong

  /*
  Creater: CuongNH2
  Created date: 9/1/2018
  Description: log INFO cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_Parameter: chi tiet cac parameter
  */
  Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob);

  /*
  Creater: CuongNH2
  Created date: 18/1/2018
  Description: log DEBUG cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_Parameter: chi tiet cac parameter
  */
  Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2);


  /*
  Creater: CuongNH2
  Created date: 18/1/2018
  Description: ghi nhan log EXCEPTION
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               p_ErrorMessage: chi tiet noi dung loi
  */
  Procedure PR_LOG_EXCEPTION(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_ErrorNumber varchar2, p_ErrorMessage varchar2);

  /*
  Creater: CuongNH2
  Created date: 22/1/2018
  Description: ghi nhan log EXCEPTION khong throw
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               p_ErrorMessage: chi tiet noi dung loi
  */
Procedure PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME varchar2,
                           P_STEP_NAME varchar2,
                           p_ErrorNumber varchar2,
                           p_ErrorMessage clob,
                           P_TASK_TYPE varchar2 );

  /*
  Creater: SonTA2
  Created date: 30/1/2018
  Description: log INFO cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               P_TASK_TYPE: kieu task
               P_IP_CLIENT: client ip
               P_MACHINE: ten machine
  */
  Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob, P_TASK_TYPE varchar2);

  /*
  Creater: CuongNH2
  Created date: 18/1/2018
  Description: log DEBUG cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_Parameter: chi tiet cac parameter
               P_TASK_TYPE: kieu task
               P_IP_CLIENT: client ip
               P_MACHINE: ten machine
  */
  Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2, P_TASK_TYPE varchar2);

  Procedure PR_LOG_ACTIVITY(P_APPLICATION_ID VARCHAR2,
                            P_RESOURCE_URL VARCHAR2,
                            P_ACCESS_USER VARCHAR2,
                            P_ACCESS_STATUS VARCHAR2,
                            P_LOG_MESSAGE CLOB,
                            P_RESOURCE_TYPE VARCHAR2,
                            P_RPT_CODE VARCHAR2,
                            P_RESOURCE_ACTION VARCHAR2,
                            P_CLIENT_IP VARCHAR2,
                            P_USER_AGENT VARCHAR2,
                            p_out OUT types.ref_cursor);

end PKG_SYSTEM_LOG;

/
--------------------------------------------------------
--  DDL for Package PKG_UTILITY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PKG_UTILITY" is
/*
Creater: CuongNH2
Create date: 19/4/2018
Description: Xoa dau va chuyen thanh chu thuong
*/
FUNCTION RemoveSignVietnamess(P_STR IN VARCHAR2) RETURN clob;

/*
Creater: CuongNH2
Create date: 11/7/2018
Description: Format number with comma
*/
FUNCTION FORMAT_NUMBER(P_STR IN VARCHAR2) RETURN VARCHAR2;

FUNCTION IS_NUMBER(P_STR IN VARCHAR2) RETURN NUMBER;

FUNCTION RemoveSpecialCharactor(P_STR IN clob) RETURN clob;

end PKG_UTILITY;

/
--------------------------------------------------------
--  DDL for Package Body PCK_DATA_REPORT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_DATA_REPORT" 
AS
PROCEDURE PR_GET_PCB_XXXSJF (P_REPORT_MONTH NVARCHAR2, p_out OUT SYS_REFCURSOR)
AS
V_REPORT_DATE VARCHAR2(80);

BEGIN

/*
H 314 31032020 05032020 VIB

Q 314 31032020 05032020 0000200
*/
SELECT MAX(REPORT_DATE) INTO V_REPORT_DATE FROM PCB_CA_NHAN WHERE SUBSTR(REPORT_DATE,3,6) = P_REPORT_MONTH;

        OPEN p_out FOR
            SELECT 'H314'|| V_REPORT_DATE ||''|| TO_CHAR(SYSDATE,'DDMMYYYY') ||'VIB' DATA FROM DUAL
            UNION ALL
            SELECT FORMAT_DATA(LOAI_BAN_GHI,1) ||
                    FORMAT_DATA(MA_NH,3) ||
                    FORMAT_DATA(MA_CN,8) ||
                    FORMAT_DATA(MA_KH_VAY_TAI_NH,16) ||
                    FORMAT_DATA(HO_TEN_KH,100) ||
                    FORMAT_DATA(GIOI_TINH,1) ||
                    FORMAT_NGAY_SINH(NGAY_SINH) ||
                    FORMAT_DATA(NOI_SINH,20) ||
                    FORMAT_DATA(MA_QG_NOI_SINH,2) ||
                    FORMAT_DATA(SO_CMND,12) ||
                    FORMAT_DATA(MS_THUE,10) ||
                    FORMAT_DATA(DIA_CHI_THUONG_TRU,160) ||
                    FORMAT_DATA(DIA_CHI_TAM_CHU,160) ||
                    FORMAT_DATA(LOAI_GTCN,1) ||
                    FORMAT_DATA(SO_GTCN,20) ||
                    FORMAT_DATA(NGAY_CAP_GTCN,8) ||
                    FORMAT_DATA(MA_QG_CAP_GTCN,2) ||
                    FORMAT_DATA(DIEN_THOAI,20) ||
                    FORMAT_DATA(SO_CMND_2,12) DATA
              FROM PCB_CA_NHAN
              WHERE SUBSTR(REPORT_DATE,3,6) = P_REPORT_MONTH
              UNION ALL
              SELECT 'Q314'|| V_REPORT_DATE ||''|| TO_CHAR(SYSDATE,'DDMMYYYY') DATA FROM DUAL
              ;
EXCEPTION
    WHEN ZERO_DIVIDE
    THEN
        DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
END PR_GET_PCB_XXXSJF;

PROCEDURE PR_GET_PCB_XXXCNF (P_REPORT_MONTH NVARCHAR2,P_DATA_TYPE NVARCHAR2, p_out OUT SYS_REFCURSOR)
AS
V_REPORT_DATE VARCHAR2(80);

BEGIN

/*
H 314 31032020 05032020 VIB

Q 314 31032020 05032020 0000200
*/
SELECT MAX(REPORT_DATE) INTO V_REPORT_DATE FROM PCB_CA_NHAN WHERE SUBSTR(REPORT_DATE,3,6) = P_REPORT_MONTH;

IF P_DATA_TYPE='PCB_START' THEN
        OPEN p_out FOR
            SELECT 'H314'|| V_REPORT_DATE ||''|| TO_CHAR(SYSDATE,'DDMMYYYY') ||'VIB' DATA FROM DUAL;
END IF;
IF P_DATA_TYPE='PCB_THE_TIN_DUNG' THEN
        OPEN p_out FOR
            SELECT FORMAT_DATA(LOAI_BAN_GHI,1) ||
                    FORMAT_DATA(MA_NH,3) ||
                    FORMAT_DATA(MA_CN,8) ||
                    FORMAT_DATA(MA_KH_VAY_NH,16) ||
                    FORMAT_DATA(MA_HD_VAY_NH,35) ||
                    FORMAT_DATA(LOAI_HD,2) ||
                    FORMAT_DATA(GIAI_DOAN_HD,2) ||
                    FORMAT_DATA(TINH_TRANG_NO,1) ||
                    FORMAT_DATA(MA_TIEN_TE,3) ||
                    FORMAT_DATA(MA_TIEN_NGUYEN_TE,3) ||
                    FORMAT_DATA(NGAY_BAT_DAU_HD,8) ||
                    FORMAT_DATA(NGAY_YC_CAP_TIN_DUNG,8) ||
                    FORMAT_DATA(NGAY_HET_HAN_HD_KE_HOACH,8) ||
                    FORMAT_DATA(NGAY_HET_HAN_HD_THUC_TE,8) ||
                    FORMAT_DATA(NGAY_THANH_TOAN_LAN_CUOI_CUNG,8) ||
                    FORMAT_DATA(DANH_DAU_TD_TAI_CO_CAU,1) ||
                    FORMAT_ROWNUM(TIEN_BAO_DAM_KHONG_SD_TAI_SAN,12) ||
                    FORMAT_ROWNUM(TIEN_BAO_DAM_SD_TAI_SAN,12) ||
                    FORMAT_ROWNUM(SO_KY_NO_QUA_HAN_MAX,1) ||
                    FORMAT_ROWNUM(SO_THAG_CO_SO_KY_NO_QUA_HAN_MX,1) ||
                    FORMAT_ROWNUM(SO_NGAY_TRA_CHAM_MAX,3) ||
                    FORMAT_DATA(NHOM_NO_XAU_NHAT,1) ||
                    FORMAT_DATA(NGAY_CUOI_CO_NHOM_NO_XAU_NHAT,8) ||
                    FORMAT_DATA(' ',97) ||--Truong trang
                    FORMAT_DATA(CHU_KY_THANH_TOAN,1) ||
                    FORMAT_DATA(PHUONG_TIEN_THANH_TOAN,3) ||
                    FORMAT_ROWNUM(SO_TIEN_TRA_HANG_THANG,12) ||
                    FORMAT_ROWNUM(HAN_MUC_TIN_DUNG,12) ||
                    FORMAT_DATA(NGAY_THANH_TOAN_KE_TIEP,8) ||
                    FORMAT_ROWNUM(SO_TIEN_CON_NO,12) ||
                    FORMAT_ROWNUM(SO_KY_NO_QUA_HAN,3) ||
                    FORMAT_ROWNUM(SO_TIEN_NO_QUA_HAN,12) ||
                    FORMAT_ROWNUM(NGAY_SU_DUNG_GAN_NHAT,8) ||
                    FORMAT_DATA(HINH_THUC_TRA,1) ||
                    FORMAT_ROWNUM(SO_TIEN_DA_SD_TRONG_THANG,12) ||
                    FORMAT_DATA(THE_DUOC_SD_TRONG_THANG,1) ||
                    FORMAT_ROWNUM(SO_LAN_SD_TRONG_THANG,2) ||
                    FORMAT_ROWNUM(SO_NGAY_NO_QUA_HAN,3)  DATA
              FROM PCB_THE_TIN_DUNG  WHERE SUBSTR(REPORT_DATE,3,6) = P_REPORT_MONTH;
END IF;
IF P_DATA_TYPE='PCB_VAY_THONG_THUONG' THEN
        OPEN p_out FOR
              SELECT FORMAT_DATA(LOAI_BAN_GHI,1) ||
                      FORMAT_DATA(MA_NH,3) ||
                      FORMAT_DATA(MA_CN,8) ||
                      FORMAT_DATA(MA_KH_VAY_NH,16) ||
                      FORMAT_DATA(MA_HD_VAY_NH,35) ||
                      FORMAT_DATA(LOAI_HD,2) ||
                      FORMAT_DATA(GIAI_DOAN_HD,2) ||
                      FORMAT_DATA(TINH_TRANG_NO,1) ||
                      FORMAT_DATA(MA_TIEN_TE,3) ||
                      FORMAT_DATA(MA_TIEN_NGUYEN_TE,3) ||
                      FORMAT_DATA(NGAY_BAT_DAU_HD,8) ||
                      FORMAT_DATA(NGAY_YC_CAP_TIN_DUNG,8) ||
                      FORMAT_DATA(NGAY_HET_HAN_HD_KE_HOACH,8) ||
                      FORMAT_DATA(NGAY_HET_HAN_HD_THUC_TE,8) ||
                      FORMAT_DATA(NGAY_THANH_TOAN_LAN_CUOI_CUNG,8) ||
                      FORMAT_DATA(DANH_DAU_TD_TAI_CO_CAU,1) ||
                      FORMAT_ROWNUM(TIEN_BAO_DAM_KHONG_SD_TAI_SAN,12) ||
                      FORMAT_ROWNUM(TIEN_BAO_DAM_SD_TAI_SAN,12) ||
                      FORMAT_ROWNUM(SO_KY_NO_QUA_HAN_MAX,1) ||
                      FORMAT_ROWNUM(SO_THAG_CO_SO_KY_NO_QUA_HAN_MX,1) ||
                      FORMAT_ROWNUM(SO_NGAY_TRA_CHAM_MAX,3) ||
                      FORMAT_ROWNUM(NHOM_NO_XAU_NHAT,1) ||
                      FORMAT_DATA(NGAY_CUOI_CO_NHOM_NO_XAU_NHAT,8) ||
                      FORMAT_DATA(' ',97) ||--Truong trang
                      FORMAT_ROWNUM(TONG_SO_TIEN_VAY,12) ||
                      FORMAT_ROWNUM(SO_KY_THANH_TOAN,3) ||
                      FORMAT_DATA(CHU_KY_THANH_TOAN,1) ||
                      FORMAT_DATA(PHUONG_TIEN_THANH_TOAN,3) ||
                      FORMAT_ROWNUM(SO_TIEN_TRA_HANG_THANG,12) ||
                      FORMAT_DATA(NGAY_THANH_TOAN_KE_TIEP,8) ||
                      FORMAT_ROWNUM(SO_TIEN_THANH_TOAN_KE_TIEP,12) ||
                      FORMAT_ROWNUM(SO_KY_TRA_GOP_CON_LAI,3) ||
                      FORMAT_ROWNUM(SO_TIEN_CON_NO,12) ||
                      FORMAT_ROWNUM(SO_LAN_NO_QUA_HAN,3) ||
                      FORMAT_ROWNUM(SO_TIEN_NO_QUA_HAN,12) ||
                      FORMAT_ROWNUM(SO_NGAY_NO_QUA_HAN,3) ||
                      FORMAT_DATA(LOAI_TAI_SAN_THUE,1) ||
                      FORMAT_DATA(GIA_TRI_TAI_SAN,12) ||
                      FORMAT_DATA(MOI_CU,1) ||
                      FORMAT_DATA(NHAN_HIEU_TAI_SAN,40) ||
                      FORMAT_DATA(SO_DK,40) ||
                      FORMAT_DATA(NGAY_SX,8) DATA
              FROM PCB_VAY_THONG_THUONG WHERE SUBSTR(REPORT_DATE,3,6) = P_REPORT_MONTH;
END IF;
IF P_DATA_TYPE='PCB_VAY_THAU_CHI' THEN
        OPEN p_out FOR
              SELECT FORMAT_DATA(LOAI_BAN_GHI,1) ||
                    FORMAT_DATA(MA_NH,3) ||
                    FORMAT_DATA(MA_CN,8) ||
                    FORMAT_DATA(MA_KH_VAY_NH,16) ||
                    FORMAT_DATA(MA_HD_VAY_NH,35) ||
                    FORMAT_DATA(LOAI_HD,2) ||
                    FORMAT_DATA(GIAI_DOAN_HD,2) ||
                    FORMAT_DATA(TINH_TRANG_NO,1) ||
                    FORMAT_DATA(MA_TIEN_TE,3) ||
                    FORMAT_DATA(MA_TIEN_NGUYEN_TE,3) ||
                    FORMAT_DATA(NGAY_BAT_DAU_HD,8) ||
                    FORMAT_DATA(NGAY_YC_CAP_TIN_DUNG,8) ||
                    FORMAT_DATA(NGAY_HET_HAN_HD_KE_HOACH,8) ||
                    FORMAT_DATA(NGAY_HET_HAN_HD_THUC_TE,8) ||
                    FORMAT_DATA(NGAY_THANH_TOAN_LAN_CUOI_CUNG,8) ||
                    FORMAT_DATA(DANH_DAU_TD_TAI_CO_CAU,1) ||
                    FORMAT_ROWNUM(TIEN_BAO_DAM_KHONG_SD_TAI_SAN,12) ||
                    FORMAT_ROWNUM(TIEN_BAO_DAM_SD_TAI_SAN,12) ||
                    FORMAT_ROWNUM(SO_KY_NO_QUA_HAN_MAX,1) ||
                    FORMAT_ROWNUM(SO_THAG_CO_SO_KY_NO_QUA_HAN_MX,1) ||
                    FORMAT_ROWNUM(SO_NGAY_TRA_CHAM_MAX,3) ||
                    FORMAT_DATA(NHOM_NO_XAU_NHAT,1) ||
                    FORMAT_DATA(NGAY_CUOI_CO_NHOM_NO_XAU_NHAT,8) ||
                    FORMAT_DATA(' ',97) ||--Truong trang
                    FORMAT_ROWNUM(HAN_MUC_TIN_DUNG,12) ||
                    FORMAT_ROWNUM(LUONG_SU_DUNG,12) ||
                    FORMAT_ROWNUM(SO_NGAY_NO_QUA_HAN,3) DATA
              FROM PCB_VAY_THAU_CHI WHERE SUBSTR(REPORT_DATE,3,6) = P_REPORT_MONTH;
END IF;
IF P_DATA_TYPE='PCB_LIEN_KET_HD' THEN
        OPEN p_out FOR
              SELECT FORMAT_DATA(LOAI_BAN_GHI,1) ||
                    FORMAT_DATA(MA_NH,3) ||
                    FORMAT_DATA(MA_CN,8) ||
                    FORMAT_DATA(LOAI_LIEN_KET,1) ||
                    FORMAT_DATA(MA_KH_VAY,16) ||
                    FORMAT_DATA(MA_NGUOI_DONG_VAY_BAO_LANH,16) ||
                    FORMAT_DATA(MA_HD_VAY_NH,35) ||
                    FORMAT_DATA(CO_XOA_LIEN_KET,1) DATA
              FROM PCB_LIEN_KET_HD WHERE SUBSTR(REPORT_DATE,3,6) = P_REPORT_MONTH;
END IF;
IF P_DATA_TYPE='PCB_BD_TAI_SAN' THEN
        OPEN p_out FOR 
              SELECT FORMAT_DATA(LOAI_BAN_GHI,1) ||
                      FORMAT_DATA(MA_NH,3) ||
                      FORMAT_DATA(MA_CN,8) ||
                      FORMAT_DATA(MA_HD_VAY_NH,35) ||
                      FORMAT_DATA(MA_NGUOI_BAO_LANH_NH,16) ||
                      FORMAT_DATA(MA_BD_TIEN_VAY_NH,16) ||
                      FORMAT_DATA(HINH_THUC_BD,3) ||
                      FORMAT_ROWNUM(SO_TIEN_BD,12) ||
                      FORMAT_DATA(MO_TA_NGUOI_BAO_LANH,160) ||
                      FORMAT_DATA(SO_DANG_KY,20) ||
                      FORMAT_DATA(MO_TA_TAI_SAN,160) ||
                      FORMAT_DATA(' ',46) ||--Truong trang
                      FORMAT_DATA(NGAY_THE_CHAP,8) ||
                      FORMAT_DATA(NGAY_GIAI_CHAP,8) DATA
              FROM PCB_BD_TAI_SAN WHERE SUBSTR(REPORT_DATE,3,6) = P_REPORT_MONTH;
END IF;
IF P_DATA_TYPE='PCB_BD_KHONG_TAI_SAN' THEN
        OPEN p_out FOR 
              SELECT FORMAT_DATA(LOAI_BAN_GHI,1) ||
                    FORMAT_DATA(MA_NH,3) ||
                    FORMAT_DATA(MA_CN,8) ||
                    FORMAT_DATA(MA_HD_VAY_NH,35) ||
                    FORMAT_DATA(MA_NGUOI_BAO_LANH_NH,16) ||
                    FORMAT_DATA(MA_BD_TIEN_VAY_NH,16) ||
                    FORMAT_DATA(HINH_THUC_BD,3) ||
                    FORMAT_ROWNUM(SO_TIEN_BD,12) ||
                    FORMAT_DATA(MO_TA_NGUOI_BAO_LANH,160) ||
                    FORMAT_DATA(' ',46) ||--Truong trang
                    FORMAT_DATA(KIEU_KH_VAY,20) ||
                    FORMAT_DATA(NGAY_BAT_DAU,160) ||
                    FORMAT_DATA(NGAY_CHAM_DUT,8) DATA
              FROM PCB_BD_KHONG_TAI_SAN WHERE SUBSTR(REPORT_DATE,3,6) = P_REPORT_MONTH;
END IF;
IF P_DATA_TYPE='PCB_END' THEN
        OPEN p_out FOR 
              SELECT 'Q314'|| V_REPORT_DATE ||''|| TO_CHAR(SYSDATE,'DDMMYYYY') DATA FROM DUAL;
END IF;
EXCEPTION
    WHEN ZERO_DIVIDE
    THEN
        DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
END PR_GET_PCB_XXXCNF;

FUNCTION FORMAT_DATA(P_STR IN VARCHAR2,P_LENGTH IN INT) RETURN VARCHAR2
IS
  V_RESULT VARCHAR2(4000);
BEGIN

SELECT  RPAD(NVL(P_STR,' '), P_LENGTH, ' ') INTO V_RESULT
FROM    dual;

  RETURN V_RESULT;
END;

FUNCTION FORMAT_ROWNUM(P_STR IN VARCHAR2,P_LENGTH IN INT) RETURN VARCHAR2
IS
  V_RESULT VARCHAR2(4000);
BEGIN

SELECT  LPAD(NVL(P_STR,'0'), P_LENGTH, '0') INTO V_RESULT
FROM    dual;

  RETURN V_RESULT;
END;

FUNCTION FORMAT_NGAY_SINH(P_STR IN VARCHAR2) RETURN VARCHAR2
IS
  V_RESULT VARCHAR2(50);
BEGIN

SELECT  case when length(P_STR)=4 then '0000'||P_STR
             when length(P_STR)=8 then P_STR
             else '00000000' end INTO V_RESULT
FROM    dual;

  RETURN V_RESULT;
END;

/*
Description: Th?c hi?n kh?i t?o file m?i cho kꮨ PCB
*/
PROCEDURE PR_NEW_REPORT_FILE_PCB (P_REPORT_MONTH NVARCHAR2,
                                  P_USER NVARCHAR2)
AS
V_CHECK_EXISTS INT;

BEGIN
/*
CREATED  ?㠴?o xong d? li?u
REVIEWING  - ?ang xem x鴠d? li?u: Sau khi ETL xong.
REJECTED  - D? li?u c?n ki?m tra l?i: Tr?ng th᩠sau khi t? ch?i duy?t file.
APPROVED  - D? li?u ???c xᣠnh?n: Tr?ng th᩠sau khi duy?t file.
SENDING  - File ?ang g?i: Tr?ng th᩠?ang g?i file sang CIC sau khi duy?t file.
SENT  - File g?i thந c𮧺 Tr?ng th᩠sau khi g?i file sang CIC thந c𮧮
SEND_ERROR  - File g?i b? l?i: Tr?ng th᩠sau khi g?i file sang CIC b? l?i.
CIC_ERROR  - CIC x? lý c󠬿i: Tr?ng th᩠CIC g?i v? c󠬿i.
*/

  --KIEM TRA KY BAO CAO DA TON TAI
  SELECT COUNT(9) INTO V_CHECK_EXISTS FROM LOG_REPORT_FILE A WHERE A.CHANNEL='PCB' AND REPORT_MONTH=P_REPORT_MONTH AND FILE_STATUS<>'REJECTED';
  IF V_CHECK_EXISTS>0 THEN
    raise_application_error( -20000, 'REPORT MONTH EXISTS!' );
  END IF;

  SELECT COUNT(9) INTO V_CHECK_EXISTS FROM LOG_REPORT_FILE A WHERE A.CHANNEL='PCB' AND REPORT_MONTH=P_REPORT_MONTH AND FILE_STATUS='REJECTED';
  IF V_CHECK_EXISTS>0 THEN
    UPDATE LOG_REPORT_FILE A SET FILE_STATUS='CREATED', CREATED_DATE = SYSDATE, CREATED_USER = P_USER
    WHERE A.CHANNEL='PCB' AND REPORT_MONTH=P_REPORT_MONTH AND FILE_STATUS='REJECTED';
    RETURN;
  END IF;

  INSERT INTO LOG_REPORT_FILE (CHANNEL, CREATED_DATE, CREATED_USER, FILE_STATUS, REPORT_MONTH, FILE_NAME, REPORT_PERIOD, FILE_TYPE)
  VALUES ('PCB', SYSDATE, P_USER,'CREATED', P_REPORT_MONTH, 'N/A', P_REPORT_MONTH, 'ZIP');
  COMMIT;
END;

PROCEDURE PR_NEW_REPORT_FILE_CIC (p_report_month nvarchar2, 
                                p_user nvarchar2,
                                p_check_sum_md5 nvarchar2,
                                p_error_code nvarchar2,
                                p_error_msg nvarchar2,
                                p_file_name nvarchar2,
                                p_file_path nvarchar2,
                                p_file_size number , 
                                p_file_type nvarchar2,
                                p_file_path_encode nvarchar2, 
                                p_report_period nvarchar2,
                                p_file_status nvarchar2,
                                p_channel  nvarchar2,
                                p_out out sys_refcursor)
AS
V_CHECK_EXISTS INT;
V_AUTO_APPROVAL nvarchar2(50);
BEGIN
/*
CREATED  ?㠴?o xong d? li?u
REVIEWING  - ?ang xem x鴠d? li?u: Sau khi ETL xong.
REJECTED  - D? li?u c?n ki?m tra l?i: Tr?ng th᩠sau khi t? ch?i duy?t file.
APPROVED  - D? li?u ???c xᣠnh?n: Tr?ng th᩠sau khi duy?t file.
SENDING  - File ?ang g?i: Tr?ng th᩠?ang g?i file sang CIC sau khi duy?t file.
SENT  - File g?i thந c𮧺 Tr?ng th᩠sau khi g?i file sang CIC thந c𮧮
SEND_ERROR  - File g?i b? l?i: Tr?ng th᩠sau khi g?i file sang CIC b? l?i.
CIC_ERROR  - CIC x? lý c󠬿i: Tr?ng th᩠CIC g?i v? c󠬿i.
*/

  --KIEM TRA KY BAO CAO DA TON TAI
  SELECT COUNT(9) INTO V_CHECK_EXISTS FROM LOG_REPORT_FILE A WHERE A.CHANNEL IN ('CIC','CICU') AND FILE_NAME=P_FILE_NAME AND FILE_STATUS<>'REJECTED';
  IF V_CHECK_EXISTS>0 THEN
    raise_application_error( -20000, 'FILE NAME EXISTS!' );
  END IF;

  SELECT COUNT(9) INTO V_CHECK_EXISTS FROM LOG_REPORT_FILE A WHERE A.CHANNEL IN ('CIC','CICU') AND FILE_NAME=P_FILE_NAME AND FILE_STATUS='REJECTED';
  IF V_CHECK_EXISTS>0 THEN
    UPDATE LOG_REPORT_FILE A 
    SET FILE_STATUS='CREATED'
        ,CREATED_DATE = SYSDATE
        ,CREATED_USER = P_USER
        ,REPORT_MONTH=SUBSTR(P_FILE_NAME,length(P_FILE_NAME)-9,6)
        ,REPORT_PERIOD=SUBSTR(P_FILE_NAME,length(P_FILE_NAME)-9,6)
    WHERE A.CHANNEL IN ('CIC','CICU') AND FILE_NAME=P_FILE_NAME AND FILE_STATUS='REJECTED';
    PKG_SYS_EMAIL.PR_SEND_EMAIL_NEW_FILE(P_FILE_NAME, 'CIC', 'CREATED');
    RETURN;
  END IF;
  
  SELECT NVL(MAX(PAR1),'FALSE') INTO V_AUTO_APPROVAL
  FROM SYS_REFCODE
  WHERE REF_CODE='AUTO_APPROVAL_SEND_FILE' AND REF_GROUP='SYSTEM';

  INSERT INTO LOG_REPORT_FILE (CHANNEL
                               , CREATED_DATE
                               , CREATED_USER
                               , FILE_STATUS
                               , FILE_NAME
                               , FILE_TYPE
                               ,REPORT_MONTH
                               ,REPORT_PERIOD
                               ,file_path
                               ,file_size
                               ,check_sum_md5
                               ,file_path_encode
                               ,CIC_STATUS)
  VALUES (P_CHANNEL
          , SYSDATE
          , P_USER
          ,CASE WHEN V_AUTO_APPROVAL='TRUE' THEN 'APPROVED' ELSE TO_CHAR(p_FILE_STATUS) END
          , P_FILE_NAME
          , P_FILE_TYPE
          ,p_report_month
          ,p_report_period
          ,p_file_path
          ,p_file_size
          ,p_check_sum_md5
          ,p_file_path_encode
          ,'0' -- M?c ??nh lࠃIC ch?a x? lý
          );

OPEN p_out FOR 
select * from LOG_REPORT_FILE
WHERE CHANNEL IN ('CIC','CICU') AND FILE_NAME=P_FILE_NAME;

  PKG_SYS_EMAIL.PR_SEND_EMAIL_NEW_FILE(P_FILE_NAME, 'CIC', 'CREATED');
  COMMIT;
END;


/*
Description: Th?c hi?n c?p nh?t tr?ng th᩠file sau khi ???c kh?i t?o
*/
PROCEDURE PR_CREATED_FILE_PCB (P_REPORT_MONTH NVARCHAR2, 
                                P_USER NVARCHAR2,
                                P_CHECK_SUM_MD5 NVARCHAR2,
                                P_ERROR_CODE NVARCHAR2,
                                P_ERROR_MSG NVARCHAR2,
                                P_FILE_NAME NVARCHAR2,
                                P_FILE_PATH NVARCHAR2,
                                P_FILE_SIZE NUMBER , 
                                P_FILE_TYPE NVARCHAR2,
                                P_FILE_PATH_ENCODE NVARCHAR2,
                                p_out OUT SYS_REFCURSOR)
AS
V_CHECK_EXISTS INT;

BEGIN

  --KIEM TRA KY BAO CAO DA TON TAI V?I TR?NG THÁI CREATED HAY KHԎG
  SELECT COUNT(9) INTO V_CHECK_EXISTS FROM LOG_REPORT_FILE A WHERE A.CHANNEL='PCB' AND REPORT_MONTH=P_REPORT_MONTH AND FILE_STATUS='CREATED';
  IF V_CHECK_EXISTS=0 THEN
    raise_application_error( -20000, 'REPORT MONTH DOESN''T  EXISTS!' );
  END IF;

  UPDATE LOG_REPORT_FILE A
  SET CHECK_SUM_MD5 = P_CHECK_SUM_MD5,
      ERROR_CODE = P_ERROR_CODE,
      ERROR_MSG = P_ERROR_MSG,
      FILE_NAME = P_FILE_NAME,
      FILE_PATH = P_FILE_PATH,
      FILE_SIZE = P_FILE_SIZE,
      FILE_STATUS = 'REVIEWING',
      --FILE_TYPE = P_FILE_TYPE,
      UPDATED_DATE = SYSDATE,
      UPDATED_USER = P_USER,
      FILE_PATH_ENCODE = P_FILE_PATH_ENCODE
  WHERE A.CHANNEL='PCB' AND REPORT_MONTH=P_REPORT_MONTH AND FILE_STATUS='CREATED';

  OPEN p_out FOR
    SELECT A.* , B.REF_NAME_VN STATUS_NAME
    FROM LOG_REPORT_FILE  A LEFT JOIN SYS_REFCODE B ON A.FILE_STATUS=B.REF_CODE AND B.REF_GROUP='STATUS_REPORT'  WHERE A.CHANNEL='PCB' AND A.REPORT_MONTH=P_REPORT_MONTH;

  COMMIT;
END;

/*
Description: Th?c hi?n C?p nh?t file sau khi g?i sang PCB
*/
PROCEDURE PR_SEND_REPORT_FILE_PCB (P_REPORT_MONTH NVARCHAR2,
                                 P_FILE_STATUS VARCHAR2, 
                                 P_ERROR_CODE NVARCHAR2,
                                 P_ERROR_MSG NVARCHAR2,
                                 P_USER NVARCHAR2,
                                 p_out OUT SYS_REFCURSOR)
AS
V_CHECK_EXISTS INT;

BEGIN

  --KIEM TRA KY BAO CAO DA TON TAI V?I TR?NG THÁI APPROVED HAY KHԎG
  SELECT COUNT(9) INTO V_CHECK_EXISTS FROM LOG_REPORT_FILE A WHERE A.CHANNEL='PCB' AND FILE_NAME=P_REPORT_MONTH  AND (FILE_STATUS='APPROVED' OR FILE_STATUS='SENDING');
  IF V_CHECK_EXISTS=0 THEN
    raise_application_error( -20000, 'REPORT MONTH DOESN''T  EXISTS!' );
  END IF;
  IF P_FILE_STATUS NOT IN ('SENDING','SENT','SEND_ERROR') THEN
    raise_application_error( -20000, 'FILE CAN CHANG ONLY TO SENDING, SENT, SEND_ERROR!' );
  END IF;

  UPDATE LOG_REPORT_FILE A
  SET ERROR_CODE = P_ERROR_CODE,
      ERROR_MSG = P_ERROR_MSG,
      FILE_STATUS = P_FILE_STATUS,
      UPDATED_DATE = SYSDATE,
      UPDATED_USER = P_USER,
      SENDED_DATE = SYSDATE
  WHERE A.CHANNEL='PCB' AND FILE_NAME=P_REPORT_MONTH AND (FILE_STATUS='APPROVED' OR FILE_STATUS='SENDING');

   OPEN p_out FOR
     SELECT A.* , B.REF_NAME_VN STATUS_NAME
    FROM LOG_REPORT_FILE A
LEFT JOIN SYS_REFCODE B ON A.FILE_STATUS=B.REF_CODE AND B.REF_GROUP='STATUS_REPORT' WHERE A.CHANNEL='PCB' AND A.FILE_NAME=P_REPORT_MONTH AND A.FILE_STATUS=P_FILE_STATUS;

  COMMIT;
END;
/*
Description: Th?c hi?n C?p nh?t file sau khi g?i sang PCB
*/
PROCEDURE PR_SEND_REPORT_FILE_CIC (P_FILE_NAME NVARCHAR2,
                                 P_FILE_STATUS VARCHAR2, 
                                 P_ERROR_CODE NVARCHAR2,
                                 P_ERROR_MSG NVARCHAR2,
                                 P_USER NVARCHAR2,
                                 p_out OUT SYS_REFCURSOR)
AS
V_CHECK_EXISTS INT;

BEGIN

  --KIEM TRA KY BAO CAO DA TON TAI V?I TR?NG THÁI APPROVED HAY KHԎG
  SELECT COUNT(9) INTO V_CHECK_EXISTS FROM LOG_REPORT_FILE A WHERE A.CHANNEL IN ('CICU','CIC') AND FILE_NAME=P_FILE_NAME AND (FILE_STATUS='APPROVED' OR FILE_STATUS='SENDING');
  IF V_CHECK_EXISTS=0 THEN
    raise_application_error( -20000, 'REPORT MONTH DOESN''T  EXISTS!' );
  END IF;
  IF P_FILE_STATUS NOT IN ('SENDING','SENT','SEND_ERROR') THEN
    raise_application_error( -20000, 'FILE CAN CHANG ONLY TO SENDING, SENT, SEND_ERROR!' );
  END IF;

  UPDATE LOG_REPORT_FILE A
  SET ERROR_CODE = nvl(P_ERROR_CODE,ERROR_CODE),
      ERROR_MSG = nvl(P_ERROR_MSG,ERROR_MSG),
      FILE_STATUS = P_FILE_STATUS,
      UPDATED_DATE = SYSDATE,
      UPDATED_USER = nvl(P_USER,UPDATED_USER),
      SENDED_DATE = SYSDATE
  WHERE A.CHANNEL IN ('CICU','CIC') AND FILE_NAME=P_FILE_NAME AND (FILE_STATUS='APPROVED' OR FILE_STATUS='SENDING')
  AND (P_ERROR_MSG<>'Transport error: 401 Error: Unauthorized' OR P_ERROR_MSG IS NULL);

   OPEN p_out FOR
     SELECT A.* , B.REF_NAME_VN STATUS_NAME
    FROM LOG_REPORT_FILE A
LEFT JOIN SYS_REFCODE B ON A.FILE_STATUS=B.REF_CODE AND B.REF_GROUP='STATUS_REPORT' WHERE A.CHANNEL IN ('CICU','CIC') AND A.FILE_NAME=P_FILE_NAME AND A.FILE_STATUS=P_FILE_STATUS;

  COMMIT;
END;
/*
Desscription: T쭠ki?m danh sᣨ file
*/
PROCEDURE PR_SEARCH_DATA (P_KEYWORD NVARCHAR2,
                          P_FROM_DATE DATE,
                          P_TO_DATE DATE,
                          P_FILE_STATUS VARCHAR2,
                          p_channel VARCHAR2,
                          P_USER VARCHAR2,
                          p_file_name varchar2,
                          p_out OUT SYS_REFCURSOR)
AS
    V_GROUP_NAME VARCHAR2(1000);
    V_FILE_TYPE_LIST VARCHAR2(1000);
    V_KEYWORD VARCHAR2(1000);

BEGIN

SELECT ','|| listagg(','||NVL(GROUP_NAME,'')||',',', ') within group(order by GROUP_NAME) ||','
INTO V_GROUP_NAME
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;

SELECT ','|| listagg(','||NVL(PAR3,'')||',',', ') within group(order by PAR3) ||','  
INTO V_FILE_TYPE_LIST
FROM SYS_GROUPS A
WHERE V_GROUP_NAME LIKE '%,'|| A.GROUP_NAME ||',%';

V_KEYWORD := lower(P_KEYWORD);
          
OPEN p_out FOR
SELECT A.FILE_NAME,
        A.FILE_PATH,
        A.FILE_SIZE,
        A.FILE_STATUS,
        A.CREATED_USER,
        A.CHANNEL,
        A.FILE_TYPE,
        A.CHECK_SUM_MD5,
        A.REJECT_COMMENT,
        A.ERROR_CODE,
        A.ERROR_MSG,
        A.CREATED_DATE,
        A.SENDED_DATE,
        A.UPDATED_DATE,
        A.UPDATED_USER,
        A.REPORT_MONTH,
        A.REPORT_PERIOD,
        A.FILE_PATH_ENCODE,
        A.CIC_STATUS,
        NVL(C.REF_NAME_VN,'N/A') CIC_STATUS_NAME,
        --A.CIC_RESPONSE,
        A.CIC_UPDATE_DATE,
        B.REF_NAME_VN STATUS_NAME

FROM LOG_REPORT_FILE A
LEFT JOIN SYS_REFCODE B ON A.FILE_STATUS=B.REF_CODE AND B.REF_GROUP='STATUS_REPORT'
LEFT JOIN SYS_REFCODE C ON A.CIC_STATUS=C.REF_CODE AND C.REF_GROUP='CIC_REPORT_STATUS'
WHERE lower(A.FILE_TYPE||','||A.FILE_NAME||','||A.CHANNEL||':'||A.REPORT_MONTH||','||A.CHANNEL||':'||A.FILE_NAME||',STS:'||A.FILE_STATUS) LIKE '%'||lower(V_KEYWORD)||'%'
        AND NVL(A.SENDED_DATE,A.CREATED_DATE) BETWEEN NVL(P_FROM_DATE,SYSDATE-100) AND NVL(P_TO_DATE,SYSDATE+100)+1
        AND (A.FILE_STATUS=P_FILE_STATUS OR P_FILE_STATUS IS NULL)
        AND (A.channel=p_channel OR p_channel IS NULL)
        and (file_name=p_file_name or p_file_name is null)
        AND (V_FILE_TYPE_LIST LIKE '%,'||A.FILE_TYPE||',%' OR V_KEYWORD like lower('PCB%') or V_KEYWORD like lower('STS%'))
order by a.created_date desc
;


EXCEPTION
    WHEN ZERO_DIVIDE
    THEN
        DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
END;

/*
Description: Th?c hi?n phꠤuy?t file PCB
*/
PROCEDURE PR_APPROVAL_FILE_PCB (P_REPORT_MONTH NVARCHAR2, P_FILE_STATUS VARCHAR2,  p_reject_comment VARCHAR2,P_USER NVARCHAR2,
                                p_out OUT SYS_REFCURSOR)
AS
V_CHECK_EXISTS INT;

BEGIN
/*
CREATED  ?㠴?o xong d? li?u
REVIEWING  - ?ang xem x鴠d? li?u: Sau khi ETL xong.
REJECTED  - D? li?u c?n ki?m tra l?i: Tr?ng th᩠sau khi t? ch?i duy?t file.
APPROVED  - D? li?u ???c xᣠnh?n: Tr?ng th᩠sau khi duy?t file.
SENDING  - File ?ang g?i: Tr?ng th᩠?ang g?i file sang CIC sau khi duy?t file.
SENT  - File g?i thந c𮧺 Tr?ng th᩠sau khi g?i file sang CIC thந c𮧮
SEND_ERROR  - File g?i b? l?i: Tr?ng th᩠sau khi g?i file sang CIC b? l?i.
CIC_ERROR  - CIC x? lý c󠬿i: Tr?ng th᩠CIC g?i v? c󠬿i.
*/

  --KIEM TRA KY BAO CAO DA TON TAI
  SELECT COUNT(9) INTO V_CHECK_EXISTS FROM LOG_REPORT_FILE A WHERE A.CHANNEL='PCB' AND FILE_NAME=P_REPORT_MONTH AND FILE_STATUS = 'REVIEWING';
  IF V_CHECK_EXISTS=0 THEN
    raise_application_error( -20000, 'REPORT MONTH NOT EXISTS!' );
  END IF;
  IF P_FILE_STATUS NOT IN ('APPROVED','REJECTED') THEN
    raise_application_error( -20000, 'FILE CAN CHANG ONLY TO APPROVED, REJECTED!' );
  END IF;

  UPDATE LOG_REPORT_FILE A
  SET FILE_STATUS=P_FILE_STATUS,
      UPDATED_DATE = SYSDATE,
      UPDATED_USER = P_USER,
      reject_comment=p_reject_comment
  WHERE A.CHANNEL='PCB' AND FILE_NAME=P_REPORT_MONTH AND FILE_STATUS='REVIEWING';
   OPEN p_out FOR
    SELECT A.* , B.REF_NAME_VN STATUS_NAME
    FROM LOG_REPORT_FILE  A
        LEFT JOIN SYS_REFCODE B ON A.FILE_STATUS=B.REF_CODE AND B.REF_GROUP='STATUS_REPORT' 
    WHERE A.CHANNEL='PCB' AND A.FILE_NAME=P_REPORT_MONTH AND A.FILE_STATUS=P_FILE_STATUS;

  COMMIT;
END;
/*
Description: Th?c hi?n phꠤuy?t file CIC
*/
PROCEDURE PR_APPROVAL_FILE_CIC (P_REPORT_MONTH NVARCHAR2, P_FILE_STATUS VARCHAR2,  p_reject_comment VARCHAR2,P_USER NVARCHAR2,
                                p_out OUT SYS_REFCURSOR)
AS
V_CHECK_EXISTS INT;

BEGIN
/*
CREATED  ?㠴?o xong d? li?u
REVIEWING  - ?ang xem x鴠d? li?u: Sau khi ETL xong.
REJECTED  - D? li?u c?n ki?m tra l?i: Tr?ng th᩠sau khi t? ch?i duy?t file.
APPROVED  - D? li?u ???c xᣠnh?n: Tr?ng th᩠sau khi duy?t file.
SENDING  - File ?ang g?i: Tr?ng th᩠?ang g?i file sang CIC sau khi duy?t file.
SENT  - File g?i thந c𮧺 Tr?ng th᩠sau khi g?i file sang CIC thந c𮧮
SEND_ERROR  - File g?i b? l?i: Tr?ng th᩠sau khi g?i file sang CIC b? l?i.
CIC_ERROR  - CIC x? lý c󠬿i: Tr?ng th᩠CIC g?i v? c󠬿i.
*/

  --KIEM TRA KY BAO CAO DA TON TAI
  SELECT COUNT(9) INTO V_CHECK_EXISTS FROM LOG_REPORT_FILE A WHERE A.CHANNEL in ('CIC','CICU') AND FILE_NAME=P_REPORT_MONTH AND FILE_STATUS = 'REVIEWING';
  IF V_CHECK_EXISTS=0 THEN
    raise_application_error( -20000, 'FILE NAME NOT EXISTS! '|| P_REPORT_MONTH );
    return ;
  END IF;

  IF P_FILE_STATUS NOT IN ('APPROVED','REJECTED') THEN
    raise_application_error( -20000, 'FILE CAN CHANG ONLY TO APPROVED, REJECTED!' );
    return;
  END IF;

  IF P_FILE_STATUS='REJECTED' THEN
    PKG_SYS_EMAIL.PR_SEND_EMAIL_NEW_FILE(P_REPORT_MONTH, 'CIC', 'REJECTED');
  END IF;

  UPDATE LOG_REPORT_FILE A
  SET FILE_STATUS=P_FILE_STATUS,
      UPDATED_DATE = SYSDATE,
      UPDATED_USER = P_USER,
      reject_comment=p_reject_comment
  WHERE A.CHANNEL IN ('CIC','CICU') AND FILE_NAME=P_REPORT_MONTH AND FILE_STATUS='REVIEWING';

   OPEN p_out FOR
SELECT A.FILE_NAME,
        A.FILE_PATH,
        A.FILE_SIZE,
        A.FILE_STATUS,
        A.CREATED_USER,
        A.CHANNEL,
        A.FILE_TYPE,
        A.CHECK_SUM_MD5,
        A.REJECT_COMMENT,
        A.ERROR_CODE,
        A.ERROR_MSG,
        A.CREATED_DATE,
        A.SENDED_DATE,
        A.UPDATED_DATE,
        A.UPDATED_USER,
        A.REPORT_MONTH,
        A.REPORT_PERIOD,
        A.FILE_PATH_ENCODE,
        A.CIC_STATUS,
        NVL(C.REF_NAME_VN,'N/A') CIC_STATUS_NAME,
        --A.CIC_RESPONSE,
        A.CIC_UPDATE_DATE,
        B.REF_NAME_VN STATUS_NAME

FROM LOG_REPORT_FILE A
LEFT JOIN SYS_REFCODE B ON A.FILE_STATUS=B.REF_CODE AND B.REF_GROUP='STATUS_REPORT'
LEFT JOIN SYS_REFCODE C ON A.CIC_STATUS=C.REF_CODE AND C.REF_GROUP='CIC_REPORT_STATUS'
WHERE A.CHANNEL IN ('CIC','CICU') AND A.FILE_NAME=P_REPORT_MONTH ;

  COMMIT;
END;

PROCEDURE PR_GET_CIC_DATA_REPORT_RAW (P_FILE_NAME NVARCHAR2, P_FILE_TYPE NVARCHAR2, p_out OUT SYS_REFCURSOR)
AS
--V_REPORT_DATE VARCHAR2(80);
BEGIN

IF P_FILE_TYPE='HEADER' THEN
  OPEN p_out FOR
  SELECT 'KB001|KB002|10000000' DATA
  FROM DUAL; 
END IF;
IF P_FILE_TYPE='SBV_BRANCH' THEN
  OPEN p_out FOR
  SELECT REF_CODE BR_CD, REF_NAME_VN DATA
  FROM SYS_REFCODE 
  WHERE REF_GROUP='LS_SBV_BRANCH'; 
END IF;

IF P_FILE_TYPE='K1021' THEN 
  OPEN p_out FOR
  select * from (
  select '1|'||CST_CD||'|'|| CST_NM||'|'||GENDER
    ||'|'||chr(10)||'2|'||ADDRESS||'|'||PROV_CD||'|'||PHONE||'|'||CTY_CD
    ||'|'||chr(10)||'3|'||ID_NO||'|'||ID_NO_DT||'|'||TAX_NO||'|'||REG_NO||'|'||REG_DT
    ||'|'||chr(10)||'5|'||REP_ID_NO||'|'||REP_NM||'|' DATA
         , BR_CD, RPT_DT, CUSTOMER_KEY DATAKEY
  from cic_customer A WHERE FILE_NAME=P_FILE_NAME
  UNION ALL
  select '4'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY FK_CUSTOMER_KEY ORDER BY REG_NO)))||'|'||REG_NO||'|'||REG_DT||'|' DATA 
         , BR_CD, RPT_DT, FK_CUSTOMER_KEY
  from Cic_Customer_Entity A WHERE FILE_NAME=P_FILE_NAME
  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;

IF P_FILE_TYPE='K1011' THEN 
  OPEN p_out FOR
  select * from (
  select '1|'||CST_CD||'|'|| CST_NM||'|'||FULL_NM||'|'||SORT_NM
    ||'|'||chr(10)||'2|'||ADDRESS||'|'||PROV_CD 
    ||'|'||chr(10)||'3|'||PHONE||'|'||FAX||'|'||WEB||'|'||EMAIL
    ||'|'||chr(10)||'4|'||TAX_NO||'|'||TAX_DT||'|'||DEC_NO||'|'||DEC_DT
    ||'|'||chr(10)||'5|'||REG_NO||'|'||REG_DT||'|'||COM_TP||'|'||COM_BUS_TP
    ||'|'||chr(10)||'6|'||COM_CPTL||'|'||COM_TP_CD||'|'||SPS_NM||'|'||SPS_ID_NO
    ||'|'||chr(10)||'8|'||DIR_NM||'|'||DIR_ID_NO||'|'DATA
         , BR_CD, RPT_DT, CUSTOMER_KEY DATAKEY
  from cic_customer A WHERE FILE_NAME=P_FILE_NAME
  UNION ALL
  select '7'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY FK_CUSTOMER_KEY ORDER BY B.SHRHLR_ID_NO)))
         ||'|'||SHRHLR_NM||'|'||B.SHRHLR_ADDR||'|'||SHRHLR_ID_NO||'|' DATA 
         , BR_CD, RPT_DT, FK_CUSTOMER_KEY
  from CIC_CUSTOMER_DIRECTOR B WHERE FILE_NAME=P_FILE_NAME
  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;

IF P_FILE_TYPE='K113' THEN 
  OPEN p_out FOR
  select * from (
  select '1|'||CST_CD||'|'|| CST_NM
    ||'|'||chr(10)||'2|'||ADDRESS||'|'||PROV_CD||'|'||WORK_ADDRESS||'|'||JOB_TITLE||'|'||SENIORITY||'|'||AGG_SALARY
    ||'|'||chr(10)||'3|'||PHONE||'|'||CTY_CD||'|'||GENDER||'|'||DOB||'|'||ID_NO||'|'||ID_NO_DT||'|'||TAX_NO||'|'||REP_NM||'|'||REP_ID_NO
         ||'|'DATA
         , BR_CD, RPT_DT, CUSTOMER_KEY DATAKEY
  from cic_customer A WHERE FILE_NAME=P_FILE_NAME

  UNION ALL
  select '4'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY FK_CUSTOMER_KEY ORDER BY REG_NO)))||'|'||REG_NO||'|'||REG_DT||'|' DATA 
         , BR_CD, RPT_DT, FK_CUSTOMER_KEY
  from Cic_Customer_Entity B WHERE FILE_NAME=P_FILE_NAME

  UNION ALL
  select '5'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY FK_CUSTOMER_KEY ORDER BY CST_CD)))||'|'||SUB_CST_NM||'|'||SUB_CST_ID_NO||'|' DATA 
         , BR_CD, RPT_DT, FK_CUSTOMER_KEY
  from CIC_CUSTOMER_SUB_CREDIT_CARD A WHERE FILE_NAME=P_FILE_NAME

  UNION ALL
  select '6'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY FK_CUSTOMER_KEY ORDER BY CST_CD)))||'|'||CLT_CD||'|'||CLT_GROUP_CD||'|'||CLT_OWN||'|'||OWN_ID_NO||'|'||OWN_TAX_NO||'|'||OPEN_DT||'|'||CLOSE_DT||'|'||AMT||'|'||AMT_DT
         ||'|'||chr(10)||'7'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY FK_CUSTOMER_KEY ORDER BY CST_CD)))||'|'||CLT_DES||'|' DATA 
         , BR_CD, RPT_DT, FK_CUSTOMER_KEY
  from CIC_COLLATERAL A WHERE FILE_NAME=P_FILE_NAME

  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;

IF P_FILE_TYPE='K3111' THEN 
  OPEN p_out FOR
  select * from (
  select '1|'||CST_CD||'|'||CST_NM||'|'||CTR_NO||'|'||SIGN_OFF_DT||'|'||EXPIRE_DT||'|'||LIMIT_AMT
         ||'|'DATA
         , BR_CD, RPT_DT, LOAN_CONTRACT_KEY DATAKEY
  from CIC_LOAN_CONTRACT A WHERE FILE_NAME=P_FILE_NAME

  UNION ALL
  select '2'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY FK_LOAN_CONTRACT_KEY ORDER BY ACCT_NO)))||'|'||ACCT_NO||'|'||
            AC_DT||'|'||INTERSET_RATE||'|'||LN_PP||'|'||LN_TP||'|'||CCY||'|'||DISBURSED_AMT||'|'||PAID_AMT||'|'||BAL||'|'||DEBT_GROUP||'|'||
            NEXT_PAY_DT||'|'||NEXT_PAY_AMT||'|'||PAST_OVERDUE_NUM||'|'||PAST_OVERDUE_BAL||'|'||DEBT_EXN_NUM||'|'||DEBT_EXN_AMT
         ||'|' DATA 
         , BR_CD, RPT_DT, FK_LOAN_CONTRACT_KEY
  from CIC_LOAN_ACCOUNT A WHERE FILE_NAME=P_FILE_NAME

  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;

IF P_FILE_TYPE='K3113' THEN 
  OPEN p_out FOR
  select * from (
  select '1|'||CST_CD||'|'||CST_NM||'|'||CTR_NO||'|'||CLT_STATUS
         ||'|'DATA
         , BR_CD, RPT_DT, LOAN_CONTRACT_KEY DATAKEY
  from CIC_LOAN_CONTRACT A WHERE FILE_NAME=P_FILE_NAME

  UNION ALL
  select '2'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY FK_LOAN_CONTRACT_KEY ORDER BY ACCT_NO)))||'|'||ACCT_NO||'|'||
            LN_TP||'|'||CCY||'|'||BAL||'|'||DEBT_GROUP
         ||'|' DATA 
         , BR_CD, RPT_DT, FK_LOAN_CONTRACT_KEY
  from CIC_LOAN_ACCOUNT A WHERE FILE_NAME=P_FILE_NAME

  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;

IF P_FILE_TYPE='K3213' THEN 
  OPEN p_out FOR
  select * from (
  select '1|'||CST_CD||'|'||CST_NM||'|'||RPT_DT||'|'||
         chr(10)||'3|'||DNA06||'|'||DNA07||'|'||DNA08||'|'||
         chr(10)||'6|'||DNB10||'|'||DNB11||'|'||DNB12||'|'||DNB13||'|'
         DATA
         , BR_CD, RPT_DT, A.BALANCE_KEY DATAKEY
  from CIC_BALANCE A WHERE FILE_NAME=P_FILE_NAME

  UNION ALL
  select CASE WHEN BAL_TP='DNA05'  THEN '2'||LN_TP||CCY||DEPT_GROUP||'|'||BAL||'|' 
              WHEN BAL_TP='DNA091' THEN '4'||CCY||'|'||BAL||'|'
              WHEN BAL_TP='DNA092' THEN '5'||CCY||DEPT_GROUP||'|'||BAL||'|'
         END DATA
         , BR_CD, RPT_DT, FK_BALANCE_KEY
  from CIC_BALANCE_DETAIL A WHERE FILE_NAME=P_FILE_NAME

  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;

IF P_FILE_TYPE='K3331' THEN 
  OPEN p_out FOR
  select * from (
  select '1|'||CST_CD||'|'||CC_NM||'|'||CTR_NO||'|'||CC_AMT||'|'
         DATA
         , BR_CD, RPT_DT, A.CREDIT_CARD_KEY DATAKEY
  from CIC_CREDIT_CARD A WHERE FILE_NAME=P_FILE_NAME

  UNION ALL
  select '2'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY CREDIT_CARD_KEY,CC_NO ORDER BY CTR_NO)))||'|'
         ||CC_TP_CD||'|'||OPEN_DT||'|'||END_DT||'|'||CLOSE_DT||'|'||STATE_DT||'|'||PAY_AMT||'|'||MIN_AMT
         ||'|'||PAID_AMT||'|'||OVER_AMT||'|'||OVER_DAYS||'|'||OVER_NO
         ||'|' DATA 
         , BR_CD, RPT_DT, CREDIT_CARD_KEY
  from CIC_CREDIT_CARD A WHERE FILE_NAME=P_FILE_NAME

  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;

IF P_FILE_TYPE='K4' THEN 
  OPEN p_out FOR
  select * from (
  select '1|'||CST_CD||'|'||CST_NM||'|'||ADD_WORK||'|'||JOB_TITLE||'|'||SENIORITY||'|'||AGG_SALARY
         ||'|'DATA
         , BR_CD, RPT_DT, A.COLLATERAL_KEY DATAKEY
  FROM CIC_COLLATERAL A WHERE FILE_NAME=P_FILE_NAME AND CLT_TP='TIN_CHAP'

  UNION ALL
  select '2'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY FK_CUSTOMER_KEY,CLT_TP ORDER BY CLT_CD)))||'|'||CLT_CD||'|'||CLT_GROUP_CD||'|'||CLT_OWN||'|'||OWN_ID_NO||'|'||
          OWN_TAX_NO||'|'||OPEN_DT||'|'||CLOSE_DT||'|'||AMT||'|'||AMT_DT||'|'||
          chr(10)||'3'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY FK_CUSTOMER_KEY ORDER BY CST_CD)))||'|'||CLT_DES||'|'

          DATA 
         , BR_CD, RPT_DT, FK_CUSTOMER_KEY
  from CIC_COLLATERAL A WHERE FILE_NAME=P_FILE_NAME AND CLT_TP='THE_CHAP'

  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;

IF P_FILE_TYPE='K2' THEN --TODO: CHECK L?I XEM PH?N N? пU N? CU?I TH? HI?N TH? NÀO
  OPEN p_out FOR
  select * from (
  select DISTINCT '1|'||CST_CD||'|'||CST_NM||'|'||
                 chr(10)||'2|'||FIN_YEAR||'|'||UNIT||'|'||
                 chr(10)||'3|'||CCY_CD||'|'||IS_AUDIT||'|'||
                 chr(10)||'4|'||IS_CONSOLIDATED||'|'DATA
         , BR_CD, RPT_DT, A.FINANCIAL_KEY DATAKEY
  FROM CIC_FINANCIAL A WHERE FILE_NAME=P_FILE_NAME

  UNION ALL
  select ITEM_CD||'|'||OPEN_BAL||'|' DATA
         , BR_CD, RPT_DT, A.FINANCIAL_KEY DATAKEY
  FROM CIC_FINANCIAL A WHERE FILE_NAME=P_FILE_NAME


  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;

IF P_FILE_TYPE='K5' THEN 
  OPEN p_out FOR
  select * from (
  select DISTINCT '1|'||CST_CD||'|'||CST_NM||'|' DATA
         , BR_CD, RPT_DT, A.BOND_INVESTMENT_KEY DATAKEY
  FROM CIC_BOND_INVESTMENT A WHERE FILE_NAME=P_FILE_NAME

  UNION ALL
  select '2'||rpad('0',2,(ROW_NUMBER()OVER (PARTITION BY BOND_INVESTMENT_KEY ORDER BY BOND_DT)))||'|'||CTR_NO||'|'||
          BOND_DT||'|'||BOND_RATE||'|'||BOND_NUM||'|'||MATURITY_DT||'|'||BOND_AMT||'|'||CCY||'|'||BOND_PPS||'|'||TP012||'|'||TP013||'|' DATA 
         , BR_CD, RPT_DT, BOND_INVESTMENT_KEY
  from CIC_BOND_INVESTMENT A WHERE FILE_NAME=P_FILE_NAME
  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;

IF P_FILE_TYPE='T02DS' THEN 
  OPEN p_out FOR
  select * from (
  select DISTINCT '1|'||CST_CD||'|'||CST_NM||'|'||CST_ID_NO||'|'||CST_REG_NO||'|'||CST_TAX_NO||'|' DATA
         , MBR_CD BR_CD, RPT_DT, A.TT02DS_KEY DATAKEY
  FROM CIC_TT02DS A WHERE FILE_NAME=P_FILE_NAME

  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;

IF P_FILE_TYPE='T02G1' THEN 
  OPEN p_out FOR
  select * from (
  select DISTINCT '1|'||CST_CD||'|' DATA
         , MBR_CD BR_CD, RPT_DT, A.TT02G_KEY DATAKEY
  FROM CIC_TT02G A WHERE FILE_NAME=P_FILE_NAME AND FILE_TP='G1'

  UNION ALL
  select CASE WHEN AABBCC='AABBCC' THEN '2'||LN_TP_CD||CCY||DEBT_CD||'|'||BAL||'|'||CL_CD||'|'
              WHEN AABBCC='BB' THEN '3|'||CCY||'|'||BAL||'|'||CL_CD||'|'
              WHEN AABBCC='BBCC' THEN '4|'||CCY||DEBT_CD||'|'||BAL||'|'||CL_CD||'|' END DATA
         , MBR_CD BR_CD, RPT_DT, A.TT02G_KEY DATAKEY
  FROM CIC_TT02G A WHERE FILE_NAME=P_FILE_NAME AND FILE_TP='G1'

  ) XX
  ORDER BY BR_CD, DATAKEY;

END IF;
EXCEPTION
    WHEN ZERO_DIVIDE
    THEN
        DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
END;

PROCEDURE PR_GET_CIC_DATA_REPORT (P_FILE_NAME NVARCHAR2, P_FILE_TYPE NVARCHAR2,P_FROM NVARCHAR2, P_TO NVARCHAR2  , p_out OUT SYS_REFCURSOR)
AS
V_I_FROM NUMBER;
V_I_TO NUMBER;
BEGIN
V_I_FROM := TO_NUMBER(P_FROM);
V_I_TO := TO_NUMBER(P_TO);

IF P_FILE_TYPE='HEADER' THEN
  OPEN p_out FOR
  SELECT 'KB001|KB002|10000000' DATA
  FROM DUAL; 
END IF;
IF P_FILE_TYPE='SBV_BRANCH' THEN
  OPEN p_out FOR
  SELECT REF_CODE BR_CD, REF_NAME_VN DATA
  FROM SYS_REFCODE 
  WHERE REF_GROUP='LS_SBV_BRANCH'; 
END IF;

IF P_FILE_TYPE='K1021' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU1_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM; 
END IF;

IF P_FILE_TYPE='K1011' THEN --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU2_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K113' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU3_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K3111' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU4_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME and khoi = 'WB'
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K3121' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU4_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME and khoi = 'RB'
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K3113' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU5_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME and khoi = 'WB'
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K3123' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU5_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME and khoi = 'RB'
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K3213' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU6_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME and khoi = 'WB'
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K3223' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU6_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME and khoi = 'RB'
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K3331' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU7_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K401' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU8_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME and khoi = 'WB'
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K402' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU8_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME and khoi = 'RB'
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K2' THEN --TODO: CHECK L?I XEM PH?N N? пU N? CU?I TH? HI?N TH? NÀO
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(select * from (
  select DISTINCT '1|'||CST_CD||'|'||CST_NM||'|'||
                 chr(10)||'2|'||FIN_YEAR||'|'||UNIT||'|'||
                 chr(10)||'3|'||CCY_CD||'|'||IS_AUDIT||'|'||
                 chr(10)||'4|'||IS_CONSOLIDATED||'|'DATA
         , BR_CD, RPT_DT, A.FINANCIAL_KEY DATAKEY
  FROM CIC_FINANCIAL A WHERE FILE_NAME=P_FILE_NAME

  UNION ALL
  select ITEM_CD||'|'||OPEN_BAL||'|' DATA
         , BR_CD, RPT_DT, A.FINANCIAL_KEY DATAKEY
  FROM CIC_FINANCIAL A WHERE FILE_NAME=P_FILE_NAME


  ) XX
  ORDER BY BR_CD, DATAKEY)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='K501' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU10_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='T02DS' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU11_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

IF P_FILE_TYPE='T02G1' THEN  --DONE
  OPEN p_out FOR
  SELECT * FROM (SELECT * FROM (
  SELECT ROWNUM STT,XX.*
  FROM(SELECT narrative DATA, '' DATAKEY, A.NGAY_PS
  FROM RPT_CIC_MAU12_TEXT A
  WHERE A.FILE_NAME=P_FILE_NAME
  ORDER BY A.ID)XX) WHERE STT<V_I_TO) WHERE STT>=V_I_FROM;

END IF;

EXCEPTION
    WHEN ZERO_DIVIDE
    THEN
        DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
END;

PROCEDURE PR_CREATED_FILE_CIC (P_REPORT_MONTH NVARCHAR2, 
                                P_USER NVARCHAR2,
                                P_CHECK_SUM_MD5 NVARCHAR2,
                                P_ERROR_CODE NVARCHAR2,
                                P_ERROR_MSG NVARCHAR2,
                                P_FILE_NAME NVARCHAR2,
                                P_FILE_PATH NVARCHAR2,
                                P_FILE_SIZE NUMBER , 
                                P_FILE_TYPE NVARCHAR2,
                                P_FILE_PATH_ENCODE NVARCHAR2,
                                p_out OUT SYS_REFCURSOR)
AS
V_CHECK_EXISTS INT;

BEGIN



  UPDATE LOG_REPORT_FILE A
  SET CHECK_SUM_MD5 = P_CHECK_SUM_MD5,
      ERROR_CODE = P_ERROR_CODE,
      ERROR_MSG = P_ERROR_MSG,
    --  FILE_NAME = P_FILE_NAME,
      FILE_PATH = P_FILE_PATH,
      FILE_SIZE = P_FILE_SIZE,
      FILE_STATUS = 'REVIEWING',
      --FILE_TYPE = P_FILE_TYPE,
      UPDATED_DATE = SYSDATE,
      UPDATED_USER = P_USER,
      FILE_PATH_ENCODE = P_FILE_PATH_ENCODE
  WHERE A.CHANNEL='CIC' AND FILE_NAME = P_FILE_NAME AND FILE_STATUS='CREATED';

  OPEN p_out FOR
    SELECT A.* , B.REF_NAME_VN STATUS_NAME
    FROM LOG_REPORT_FILE  A 
    LEFT JOIN SYS_REFCODE B ON A.FILE_STATUS=B.REF_CODE AND B.REF_GROUP='STATUS_REPORT'  
    WHERE A.CHANNEL in ('CIC','CICU') AND FILE_NAME = P_FILE_NAME;

  COMMIT;
END;


PROCEDURE PR_UPDATE_CIC_RESPONSE (p_file_name NVARCHAR2,
                                 p_cic_status VARCHAR2, 
                                 p_cic_response clob,
                                 p_error_msg VARCHAR2,
                                 p_user NVARCHAR2,
                                p_out OUT SYS_REFCURSOR)
AS
V_CHECK_EXISTS INT;

BEGIN
/*
CREATED  ?㠴?o xong d? li?u
REVIEWING  - ?ang xem x鴠d? li?u: Sau khi ETL xong.
REJECTED  - D? li?u c?n ki?m tra l?i: Tr?ng th᩠sau khi t? ch?i duy?t file.
APPROVED  - D? li?u ???c xᣠnh?n: Tr?ng th᩠sau khi duy?t file.
SENDING  - File ?ang g?i: Tr?ng th᩠?ang g?i file sang CIC sau khi duy?t file.
SENT  - File g?i thந c𮧺 Tr?ng th᩠sau khi g?i file sang CIC thந c𮧮
SEND_ERROR  - File g?i b? l?i: Tr?ng th᩠sau khi g?i file sang CIC b? l?i.
CIC_ERROR  - CIC x? lý c󠬿i: Tr?ng th᩠CIC g?i v? c󠬿i.
*/

  UPDATE LOG_REPORT_FILE A
  SET CIC_STATUS=p_cic_status,
      CIC_UPDATE_DATE = SYSDATE, 
      error_msg=case when p_error_msg is null then error_msg else p_error_msg end,
      cic_response='<PHTepBaoCaoVanTin>'||replace(p_cic_response,'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>','')||'</PHTepBaoCaoVanTin>'      
  WHERE A.CHANNEL='CIC' AND FILE_NAME=p_file_name AND FILE_STATUS='SENT';

   OPEN p_out FOR
    SELECT A.* , B.REF_NAME_VN STATUS_NAME
    FROM LOG_REPORT_FILE  A
    LEFT JOIN SYS_REFCODE B ON A.FILE_STATUS=B.REF_CODE AND B.REF_GROUP='STATUS_REPORT' 
    WHERE A.CHANNEL='CIC' AND FILE_NAME=p_file_name AND FILE_STATUS='SENT';

  COMMIT;
END;


PROCEDURE PR_GET_LOG_REPORT_FILE (p_file_name NVARCHAR2,
                                 p_user NVARCHAR2,
                                p_out OUT SYS_REFCURSOR)
AS
V_CHECK_EXISTS INT;

BEGIN 
 
   OPEN p_out FOR
    SELECT A.* 
            ,B.REF_NAME_VN STATUS_NAME 
            ,NVL(C.REF_NAME_VN,'N/A') CIC_STATUS_NAME
            ,to_char(CIC_UPDATE_DATE,'DD/MM/YYYY HH24:mi') CIC_UPDATE_DATE_STR
            ,to_char(SENDED_DATE,'DD/MM/YYYY HH24:mi') SENDED_DATE_STR
    FROM LOG_REPORT_FILE  A
    LEFT JOIN SYS_REFCODE B ON A.FILE_STATUS=B.REF_CODE AND B.REF_GROUP='STATUS_REPORT' 
    LEFT JOIN SYS_REFCODE C ON A.CIC_STATUS=C.REF_CODE AND C.REF_GROUP='CIC_REPORT_STATUS'
    WHERE FILE_NAME=p_file_name;

  COMMIT;
END;
END PCK_DATA_REPORT;

/
--------------------------------------------------------
--  DDL for Package Body PCK_CIS_OTHER_REQUEST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_CIS_OTHER_REQUEST" AS
--Tinh toan ban tin tra loi
--Create by CuongNH2
--Crated date: 06/12/2021
PROCEDURE PR_CALCULATOR (P_REQUEST_ID NVARCHAR2) IS
V_ROWS_RESPONSE_RECEIVED NUMBER; 
V_ROWS_TOTAL_REQUEST NUMBER; 
V_CIS_OTHER_RESPONSE NUMBER;
V_PRODUCT_CODE varchar2(50);
V_APPLICATION_ID varchar2(50);
BEGIN
--KIEM TRA XEM CAC BAN TRA LOI TIN DA NHAN DUOC HET CHUA
SELECT SUM(CASE WHEN B.STATUS <> 'RECEIVED' OR C.STATUS <> 'DONE' THEN 1 ELSE 0 END) RESPONSE_RECEIVED
    ,COUNT(*) TOTAL_REQUEST
INTO V_ROWS_RESPONSE_RECEIVED, V_ROWS_TOTAL_REQUEST
FROM CIS_MM_OTHER_REQ_REQCIC A
LEFT JOIN CIS_REQUEST B ON A.CIS_NO=B.CIS_NO
LEFT JOIN CIS_RESPONSE C ON C.CIS_NO=B.CIS_NO
WHERE A.REQUEST_ID=P_REQUEST_ID;
-- REQUEST NAY KHONG CO BAN HOI TIN CIC => DU LIEU LOI
IF V_ROWS_TOTAL_REQUEST=0 THEN
    UPDATE CIS_OTHER_REQUEST
    SET STATUS='NO_REQ'
    WHERE REQUEST_ID=P_REQUEST_ID;
END IF;

--VAN CON BAN TIN CHUA PHAN HOI
IF V_ROWS_RESPONSE_RECEIVED>0 THEN 
    RETURN;
END IF;

-- 20210521 - ?ᮨ d?u nh?ng b?n ghi c󠭣 CIC Code ??u tiꮠ?? th?c hi?n t󺀠toᮠ-> Kh? trùng v?i cᣠs?n ph?m cùng CICCode
UPDATE CIS_MM_OTHER_REQ_REQCIC
SET CALCULATOR = 'Y'
WHERE REQUEST_ID = P_REQUEST_ID
    AND ID IN (SELECT ID FROM
                (SELECT
                        A.ID,
                        A.CIS_NO,
                        A.REQUEST_ID OTHER_REQUEST_ID,
                        B.PRODUCT_CODE,
                        C.MA_CIC,
                        ROW_NUMBER() OVER(PARTITION BY A.REQUEST_ID, B.PRODUCT_CODE, C.MA_CIC ORDER BY A.CIS_NO DESC ) ROW_NUMBER,
                        D.STATUS
                    FROM CIS_MM_OTHER_REQ_REQCIC A
                        LEFT JOIN CIS_REQUEST B ON A.CIS_NO = B.CIS_NO
                        LEFT JOIN CIS_RESPONSE D ON D.CIS_NO = B.CIS_NO
                        LEFT JOIN TBL_CIS_THONG_TIN_CHUNG C ON C.RESPONSE_ID = D.ID
                    WHERE A.REQUEST_ID = P_REQUEST_ID
                ) XX
            WHERE ROW_NUMBER = 1);
-- end

INSERT INTO CIS_TEMP_OTHER_REQUEST
SELECT B.ID RESPONSE_ID,A.REQUEST_ID,A.CIS_NO
FROM CIS_MM_OTHER_REQ_REQCIC A
LEFT JOIN CIS_RESPONSE B ON A.CIS_NO=B.CIS_NO
WHERE A.REQUEST_ID=P_REQUEST_ID AND A.CALCULATOR = 'Y';

-- DU LIEU DA TRA TIN DAY DU
IF V_ROWS_RESPONSE_RECEIVED=0 THEN 
--B1: LAM SACH DU LIEU
    DELETE CIS_OTHER_RESPONSE_DETAIL
    WHERE OTHER_RESPONSE_ID IN (SELECT RESPONSE_ID FROM CIS_OTHER_RESPONSE WHERE REQUEST_ID=P_REQUEST_ID);

    -- XOA DU LIEU CU
    DELETE CIS_OTHER_RESPONSE
    WHERE REQUEST_ID=P_REQUEST_ID;
    

--B3: KHOI TAO BAN TIN 
V_CIS_OTHER_RESPONSE := SEQ_CIS_OTHER_RESPONSE.NEXTVAL;
SELECT MAX(PRODUCT_CODE),MAX(A.APPLICATION_ID) INTO V_PRODUCT_CODE,V_APPLICATION_ID
FROM CIS_OTHER_REQUEST A WHERE A.REQUEST_ID=P_REQUEST_ID;

INSERT INTO CIS_OTHER_RESPONSE(RESPONSE_ID	,
                                REQUEST_ID	,
                                PRODUCT_CODE	,
                                RESPONSE_DATE	, 
                                VERSION_NO ,
                                RESPONSE_STATUS  ,
                                RESPONSE_MESSAGE  ,
                                GENERATE_DATE  , 
                                CIC_CODE,
                                APPLICATION_ID
                                )

                         SELECT V_CIS_OTHER_RESPONSE,
                                P_REQUEST_ID  ,
                                V_PRODUCT_CODE PRODUCT_CODE  ,
                                null RESPONSE_DATE  ,
                                '1' VERSION_NO  , 
                                'GENERATED' RESPONSE_STATUS  ,
                                '' RESPONSE_MESSAGE  ,
                                SYSDATE GENERATE_DATE  , 
                                null CIC_CODE,
                                V_APPLICATION_ID
                            FROM DUAL;


INSERT INTO CIS_OTHER_RESPONSE_DETAIL (ID,
                                        OTHER_RESPONSE_ID,
                                        CIS_NO,
                                        RESPONSE_DATE,
                                        RESPONSE_XML_DATA,
                                        RESPONSE_FILE_DATA,
                                        GENERATED_DATE,
                                        PRODUCT_CODE)
SELECT SEQ_CIS_OTHER_REQUEST_DETAIL.NEXTVAL,
        V_CIS_OTHER_RESPONSE,
        A.CIS_NO,
        B.RESPONSE_DATE,
        B.RESPONSE_DATA,
        NULL RESPONSE_FILE_DATA,
        SYSDATE GENERATED_DATE,
        B.PRODUCT_CODE
FROM CIS_MM_OTHER_REQ_REQCIC A
JOIN CIS_RESPONSE B ON A.CIS_NO=B.CIS_NO
WHERE A.REQUEST_ID=P_REQUEST_ID
;

UPDATE CIS_OTHER_REQUEST 
SET STATUS='GENERATED'
WHERE REQUEST_ID=P_REQUEST_ID;

END IF;

END;

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o y굠c?u t? h? th?ng khᣊ*/
PROCEDURE PR_CREATE_OTHER_REQUEST (p_application_id VARCHAR2,
                                        p_source_request_id VARCHAR2,
                                        p_maker VARCHAR2, 
                                        p_customer_name VARCHAR2,
                                        p_customer_address VARCHAR2,
                                        p_client_ip VARCHAR2,
                                        p_user_agent VARCHAR2, 
                                        p_product_code VARCHAR2, 
                                        p_customer_type VARCHAR2, 
                                        p_batch_id VARCHAR2, 
                                        p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);
V_BRANCH_CODE VARCHAR2(50); 
BEGIN

--Ki?m tra xem c󠴠i kho?n trong h? th?ng kh𮧬 n?u kh𮧠c󠨯?c kh𮧠c󠴨𮧠tin chi nhᮨ th젴h𮧠bᯠl?i
SELECT MAX(A.MEMBER_CODE) INTO V_BRANCH_CODE 
FROM SYS_USER A
WHERE LOWER(A.USER_NAME)=LOWER(P_MAKER);
IF V_BRANCH_CODE IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy thông tin tài khoản ['||P_MAKER||'] trong hệ thống!' );
  RETURN;
END IF;


V_REQUEST_ID := SEQ_CIS_OTHER_REQUEST.NEXTVAL;
INSERT INTO CIS_OTHER_REQUEST (REQUEST_ID,
                                APPLICATION_ID,
                                SOURCE_REQUEST_ID,
                                MAKER,
                                BRANCH_CODE,
                                CUSTOMER_NAME,
                                CUSTOMER_ADDRESS,
                                CLIENT_IP,
                                USER_AGENT,
                                STATUS,
                                PRODUCT_CODE,
                                MEMBER_CODE,
                                REQUEST_DATE,
                                CUSTOMER_TYPE,
                                BATCH_ID)

              VALUES (V_REQUEST_ID,
                      P_APPLICATION_ID,
                      P_SOURCE_REQUEST_ID,
                      P_MAKER,
                      V_BRANCH_CODE,
                      P_CUSTOMER_NAME,
                      P_CUSTOMER_ADDRESS,
                      P_CLIENT_IP,
                      P_USER_AGENT,
                      'NEW',
                      P_PRODUCT_CODE,
                      V_BRANCH_CODE,
                      SYSDATE,
                      P_CUSTOMER_TYPE,
                      P_BATCH_ID);
COMMIT;

OPEN p_out FOR
SELECT * FROM CIS_OTHER_REQUEST WHERE REQUEST_ID=V_REQUEST_ID;

END;

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o chi ti?t y굠c?u t? h? th?ng khᣊ*/
PROCEDURE PR_CREATE_OTHER_REQUEST_DETAIL (P_REQUEST_ID VARCHAR2, 
                                    P_SOURCE_REQUEST_ID VARCHAR2,
                                    P_CUSTOMER_ID_TYPE VARCHAR2,
                                    P_CUSTOMER_ID VARCHAR2, 
                                    p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);
V_ID VARCHAR2(50); 
V_APPLICATION_ID VARCHAR2(50);
BEGIN

--Ki?m tra xem c󠴠i kho?n trong h? th?ng kh𮧬 n?u kh𮧠c󠨯?c kh𮧠c󠴨𮧠tin chi nhᮨ th젴h𮧠bᯠl?i
SELECT MAX(A.REQUEST_ID),MAX(APPLICATION_ID) INTO V_REQUEST_ID ,V_APPLICATION_ID
FROM CIS_OTHER_REQUEST A WHERE REQUEST_ID=P_REQUEST_ID;

IF V_REQUEST_ID IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy yêu cầu ['||P_REQUEST_ID||'] trong hệ thống!' );
  RETURN;
END IF;


V_ID := SEQ_CIS_OTHER_REQUEST_DETAIL.NEXTVAL;
INSERT INTO CIS_OTHER_REQUEST_DETAIL (ID,
                                      REQUEST_ID,
                                      APPLICATION_ID,
                                      SOURCE_REQUEST_ID,
                                      CUSTOMER_ID_TYPE,
                                      CUSTOMER_ID)

              VALUES (V_ID,
                      V_REQUEST_ID,
                      V_APPLICATION_ID,
                      P_SOURCE_REQUEST_ID,
                      P_CUSTOMER_ID_TYPE,
                      P_CUSTOMER_ID);
COMMIT;

OPEN p_out FOR
SELECT * FROM CIS_OTHER_REQUEST_DETAIL WHERE ID=V_ID;

END;

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o chi ti?t th𮧠tin CIC CODE t? CIC
*/
PROCEDURE PR_CREATE_OTHER_REQUEST_CHECK (P_REQUEST_ID VARCHAR2,
                                        P_CUSTOMER_ID_TYPE VARCHAR2,
                                        P_CUSTOMER_ID VARCHAR2,
                                        P_CUST_CODE VARCHAR2,
                                        P_CIC_CUST_NAME VARCHAR2,
                                        P_CIC_CUST_ADDRESS VARCHAR2,
                                        P_CUST_TYPE VARCHAR2,
                                        P_CUST_TAX VARCHAR2,
                                        P_CUST_ID_NO VARCHAR2,
                                        P_CUST_REG VARCHAR2,
                                        P_CIC_CODE VARCHAR2,
                                        P_CIC_DATA VARCHAR2, 
                                        p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);
V_ID VARCHAR2(50); 
V_CUSTOMER_ID_TYPE VARCHAR2(50);
V_ROWS_COUNT NUMBER;
BEGIN

--Ki?m tra xem c󠴠i kho?n trong h? th?ng kh𮧬 n?u kh𮧠c󠨯?c kh𮧠c󠴨𮧠tin chi nhᮨ th젴h𮧠bᯠl?i
SELECT MAX(A.REQUEST_ID),MAX(CUSTOMER_ID_TYPE) INTO V_REQUEST_ID ,V_CUSTOMER_ID_TYPE
FROM CIS_OTHER_REQUEST_DETAIL A WHERE REQUEST_ID=P_REQUEST_ID;-- AND CUSTOMER_ID=P_CIC_CUST_ID_NO;

IF V_REQUEST_ID IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy thông tin CUSTOMER ID NO ['||P_CUST_ID_NO||'] trong yêu cầu ['||P_REQUEST_ID||'] trong hệ thống!' );
  RETURN;
END IF;

SELECT COUNT(9) INTO V_ROWS_COUNT
FROM CIS_OTHER_REQUEST_CHECK
WHERE REQUEST_ID=P_REQUEST_ID AND (CIC_CUST_ID_NO=P_CUST_ID_NO OR P_CIC_CODE=CIC_CODE);

IF V_ROWS_COUNT=0 THEN
    V_ID := SEQ_CIS_OTHER_REQUEST_CHECK.NEXTVAL;
    INSERT INTO CIS_OTHER_REQUEST_CHECK (ID  ,
                                          REQUEST_ID  ,
                                          CUSTOMER_ID_TYPE  ,
                                          CUSTOMER_ID  ,
                                          CIC_CUST_CODE  ,
                                          CIC_CUST_NAME  ,
                                          CIC_CUST_ADDRESS  ,
                                          CIC_CUST_TYPE  ,
                                          CIC_CUST_TAX  ,
                                          CIC_CUST_ID_NO  ,
                                          CIC_CUST_REG  ,
                                          CIC_DATA  ,
                                          CIC_CODE,
                                          REQUEST_DATE  )

                  VALUES (V_ID,
                          V_REQUEST_ID,
                          P_CUSTOMER_ID_TYPE,
                          NVL(NVL(P_CUST_ID_NO,P_CIC_CODE),'N/A'),
                          P_CUST_CODE,
                          P_CIC_CUST_NAME,
                          P_CIC_CUST_ADDRESS,
                          P_CUST_TYPE,
                          P_CUST_TAX,
                          P_CUST_ID_NO,
                          P_CUST_REG,
                          P_CIC_DATA,
                          P_CIC_CODE,
                          SYSDATE);
END IF;
COMMIT;

OPEN p_out FOR
SELECT * FROM CIS_OTHER_REQUEST_CHECK WHERE REQUEST_ID=P_REQUEST_ID AND CUSTOMER_ID=P_CUST_ID_NO;

END;


/*
Ki?m tra t쮨 tr?ng d? li?u theo matrix c?a kꮨ CIC
*/
FUNCTION PR_STATUS_MATRIX_CIC(p_id_no CIS_REQUEST.ID_NO%TYPE,
                              p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
                              p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
                              p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
                              p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
                              p_cic_code varchar2) RETURN VARCHAR2
IS
    V_TOTAL_WARNING1 NUMBER;
    V_TOTAL_WARNING2 NUMBER;
    V_TOTAL_ACCEPT NUMBER; 


    V_CIC_NUMBER_OF_DAYS NUMBER;
    V_CIC_DATA_VALIDATION_DAY NUMBER; 
    v_EXISTS_RECORD NUMBER;
    V_STATUS VARCHAR2(100); 
    V_CIS_NO VARCHAR2(100); 
BEGIN
/**/
-- V_BLACK_LIST := PCK_CIS_REQUEST.PR_CHECK_BLACK_LIST(p_id_no);
/*IF V_BLACK_LIST IS NOT NULL THEN
  V_BLACK_LIST := V_BLACK_LIST;
END IF;
*/  
-- Khi s?a PACK n๠c?n update thꭠ? PCK_CIS_REQUEST.PR_STATUS_MATRIX_CIC

select nvl(max(par1),7) into V_CIC_NUMBER_OF_DAYS
from sys_refcode a where a.ref_code='CIC_NUMBER_OF_DAYS';
select nvl(max(par1),15) into V_CIC_DATA_VALIDATION_DAY
from sys_refcode a where a.ref_code='CIC_DATA_VALIDATION_DAY';


SELECT MAX(CIS_NO) INTO V_CIS_NO
FROM CIS_REQUEST A
WHERE CHANNEL='CIC' and PRODUCT_CODE = p_product_code
      AND CUSTOMER_TYPE = p_customer_type
      AND ((case when p_customer_type = '2' and ID_NO = p_id_no then 1 
               when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no) then 1 
               else 0 end = 1) or p_cic_code=a.cic_code)
      AND A.STATUS IN ('SENDED','SENT','WAITING','NEW')
      --AND A.LAST_VERSION='1'
      ;

IF V_CIS_NO IS NOT NULL THEN
  RETURN V_CIS_NO;--NOT UPDATE CIC
END IF;


SELECT SUM(CASE WHEN RESPONSE_STATUS='ACCEPT' THEN 1 ELSE 0 END) TOTAL_ACCEPT
       ,SUM(CASE WHEN RESPONSE_STATUS='WARNING1' THEN 1 ELSE 0 END) TOTAL_WARNING1
       ,SUM(CASE WHEN RESPONSE_STATUS='WARNING2' THEN 1 ELSE 0 END) TOTAL_WARNING2
       ,COUNT(9) EXISTS_RECORD
       ,MAX(
            CASE 
                WHEN REGEXP_LIKE(CIS_NO, '^[0-9]+$') THEN TO_NUMBER(CIS_NO) 
                ELSE 0  -- S? d?ng giᠴr? s? m?c ??nh l࠰ n?u CIS_NO kh𮧠ph?i l࠳?
            END
        ) V_CIS_NO
INTO V_TOTAL_ACCEPT, V_TOTAL_WARNING1,V_TOTAL_WARNING2, V_EXISTS_RECORD, V_CIS_NO
FROM (
      SELECT CASE WHEN V_A>0 THEN CASE WHEN CONDITION_2 = '0' THEN 'ACCEPT'
                                       ELSE CASE WHEN V_C <= V_CIC_DATA_VALIDATION_DAY THEN 'ACCEPT'
                                                 ELSE CASE WHEN V_D >= V_CIC_NUMBER_OF_DAYS THEN 'ACCEPT' 
                                                           ELSE 'WARNING2' 
                                                      END 
                                            END
                                   END
                   ELSE CASE WHEN V_B >= V_CIC_NUMBER_OF_DAYS THEN 'ACCEPT' ELSE 'WARNING1' END
              END RESPONSE_STATUS 
              ,CIS_NO
      FROM (
        SELECT TO_NUMBER(TO_CHAR(SYSDATE,'DD')) HT
               ,TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')) GN
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-V_CIC_DATA_VALIDATION_DAY V_A
               ,CAST((SYSDATE - CAST(A.RESPONSE_DATE AS DATE)) AS INT) V_B
               ,GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_CIC_DATA_VALIDATION_DAY) V_C
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_CIC_DATA_VALIDATION_DAY) V_D
               ,CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,'MM'))=TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'MM')) THEN '1' ELSE '0' END CONDITION_2
               ,A.CIS_NO

        FROM CIS_REQUEST A
        WHERE CHANNEL='CIC' AND CUSTOMER_TYPE = p_customer_type and PRODUCT_CODE = p_product_code
              AND ((case when p_customer_type = '2' and ID_NO = p_id_no then 1 
                       when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no) then 1 
                       else 0 end = 1) or p_cic_code=a.cic_code)
              AND A.STATUS='RECEIVED' AND A.LAST_VERSION='1'
      ) B
); 

SELECT CASE WHEN v_EXISTS_RECORD=0 THEN 'UPDATE CIC' ELSE 
            CASE WHEN V_TOTAL_WARNING1>0 THEN V_CIS_NO WHEN V_TOTAL_WARNING2>0 THEN V_CIS_NO ELSE 'UPDATE CIC' END 
       END
INTO V_STATUS FROM DUAL;

RETURN V_STATUS;
END;


/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o phi?u y굠c?u h?i tin
*/
PROCEDURE PR_GENERATE_REQUEST_TO_CIC (P_REQUEST_ID VARCHAR2,
                                        p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);  
V_COMBO_PRODUCT VARCHAR2(50);  
V_ROWS_COUNT NUMBER;
BEGIN

--Ki?m tra xem c󠴠i kho?n trong h? th?ng kh𮧬 n?u kh𮧠c󠨯?c kh𮧠c󠴨𮧠tin chi nhᮨ th젴h𮧠bᯠl?i
SELECT MAX(A.REQUEST_ID), MAX(A.PRODUCT_CODE) INTO V_REQUEST_ID, V_COMBO_PRODUCT 
FROM CIS_OTHER_REQUEST A WHERE REQUEST_ID=P_REQUEST_ID AND A.STATUS='NEW';


IF V_REQUEST_ID IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy thông tin yêu cầu ['||P_REQUEST_ID||'] trong hệ thống!' );
  RETURN;
END IF;


INSERT INTO CIS_REQUEST_TMP (CIS_NO, CHANNEL,
                          CUSTOMER_TYPE,
                          STATUS,
                          PRODUCT_CODE,
                          CIC_CODE,
                          ID_NO,
                          TAX_CODE,
                          BRANCH_CODE,
                          CREATED_DATE,
                          ADDRESS,
                          REGISTER_NO,
                          CUSTOMER_NAME,
                          CUSTOMER_CODE,
                          APPLICATION_ID,
                          MAKER,
                          REQUEST_ID)
                   SELECT SEQ_CIS_REQUEST.NEXTVAL,
                          C.PAR1 CHANNEL,
                          C.PAR2 CUSTOMER_TYPE,
                          'NEW' STATUS,
                          C.REF_CODE PRODUCT_CODE,
                          A.CIC_CODE,
                          A.CUSTOMER_ID ID_NO,
                          A.CIC_CUST_TAX TAX_CODE,
                          B.MEMBER_CODE BRANCH_CODE,
                          SYSDATE CREATED_DATE,
                          NVL(A.CIC_CUST_ADDRESS,'N/A') ADDRESS,
                          A.CIC_CUST_REG REGISTER_NO,
                          A.CIC_CUST_NAME CUSTOMER_NAME,
                          A.CIC_CUST_CODE CUSTOMER_CODE,
                          B.APPLICATION_ID APPLICATION_ID,
                          B.MAKER MAKER,
                          V_REQUEST_ID
FROM CIS_OTHER_REQUEST_CHECK A
JOIN CIS_OTHER_REQUEST B ON A.REQUEST_ID=B.REQUEST_ID
JOIN SYS_REFCODE C ON C.REF_GROUP='NEW_CREDIT_REQUEST' AND C.PAR3=V_COMBO_PRODUCT
WHERE A.REQUEST_ID=V_REQUEST_ID
      AND PR_STATUS_MATRIX_CIC(A.CIC_CUST_ID_NO, A.CIC_CUST_REG, A.CIC_CUST_TAX, C.PAR2, C.REF_CODE, A.CIC_CODE) = 'UPDATE CIC';


SELECT COUNT(9) INTO V_ROWS_COUNT
FROM CIS_OTHER_REQUEST_CHECK 
WHERE REQUEST_ID=V_REQUEST_ID;

-- N?u kh𮧠c󠤡nh sᣨ m㠃IC CODE du?c update th젳? ti?n hந h?i tin theo CMND
IF NVL(V_ROWS_COUNT,0)=0 THEN
  INSERT INTO CIS_REQUEST_TMP (CIS_NO, CHANNEL,
                            CUSTOMER_TYPE,
                            STATUS,
                            PRODUCT_CODE,
                            CIC_CODE,
                            ID_NO,
                            TAX_CODE,
                            BRANCH_CODE,
                            CREATED_DATE,
                            ADDRESS,
                            REGISTER_NO,
                            CUSTOMER_NAME,
                            CUSTOMER_CODE,
                            APPLICATION_ID,
                            MAKER,
                            REQUEST_ID)
                     SELECT SEQ_CIS_REQUEST.NEXTVAL, C.PAR1 CHANNEL,
                            C.PAR2 CUSTOMER_TYPE,
                            'NEW' STATUS,
                            C.REF_CODE PRODUCT_CODE,
                            '' CIC_CODE,
                            A.CUSTOMER_ID ID_NO,
                            '' TAX_CODE,
                            B.MEMBER_CODE BRANCH_CODE,
                            SYSDATE CREATED_DATE,
                            B.CUSTOMER_ADDRESS ADDRESS,
                            '' REGISTER_NO,
                            B.CUSTOMER_NAME CUSTOMER_NAME,
                            '' CUSTOMER_CODE,
                            B.APPLICATION_ID APPLICATION_ID,
                            B.MAKER MAKER,
                            V_REQUEST_ID
  FROM CIS_OTHER_REQUEST_DETAIL A
  JOIN CIS_OTHER_REQUEST B ON A.REQUEST_ID=B.REQUEST_ID
  JOIN SYS_REFCODE C ON C.REF_GROUP='NEW_CREDIT_REQUEST' AND C.PAR3=V_COMBO_PRODUCT
  WHERE A.REQUEST_ID=V_REQUEST_ID
        AND PR_STATUS_MATRIX_CIC(A.CUSTOMER_ID, '', '', C.PAR2, C.REF_CODE, '') = 'UPDATE CIC';

END IF;
--CAC BAN TIN MOI
INSERT INTO CIS_MM_OTHER_REQ_REQCIC(ID, CIS_NO,REQUEST_ID,CREATED_DATE)
select SEQ_CIS_MM_OTHER_REQ_REQCIC.NEXTVAL, CIS_NO, REQUEST_ID, SYSDATE
from CIS_REQUEST_TMP;

--LAY CAC BAN TIN CU THEO CIC
INSERT INTO CIS_MM_OTHER_REQ_REQCIC(ID, CIS_NO,REQUEST_ID,CREATED_DATE)
SELECT SEQ_CIS_MM_OTHER_REQ_REQCIC.NEXTVAL, CIS_NO, REQUEST_ID,SYSDATE FROM (
  SELECT PR_STATUS_MATRIX_CIC(A.CIC_CUST_ID_NO, A.CIC_CUST_REG, A.CIC_CUST_TAX, C.PAR2, C.REF_CODE, A.CIC_CODE) CIS_NO
         ,A.REQUEST_ID
  FROM CIS_OTHER_REQUEST_CHECK A
  JOIN SYS_REFCODE C ON C.REF_GROUP='NEW_CREDIT_REQUEST' AND C.PAR3=V_COMBO_PRODUCT
  WHERE A.REQUEST_ID=V_REQUEST_ID)
  WHERE CIS_NO <> 'UPDATE CIC';

--LAY CAC BAN TIN CU THEO ID
IF NVL(V_ROWS_COUNT,0)=0 THEN
  INSERT INTO CIS_MM_OTHER_REQ_REQCIC(ID, CIS_NO,REQUEST_ID,CREATED_DATE)
  SELECT SEQ_CIS_MM_OTHER_REQ_REQCIC.NEXTVAL, CIS_NO, REQUEST_ID,SYSDATE FROM (
    SELECT PR_STATUS_MATRIX_CIC(A.CUSTOMER_ID, '', '', C.PAR2, C.REF_CODE, '') CIS_NO
           ,A.REQUEST_ID
  FROM CIS_OTHER_REQUEST_DETAIL A
--  JOIN CIS_OTHER_REQUEST B ON A.REQUEST_ID=B.REQUEST_ID
  JOIN SYS_REFCODE C ON C.REF_GROUP='NEW_CREDIT_REQUEST' AND C.PAR3=V_COMBO_PRODUCT
  WHERE A.REQUEST_ID=V_REQUEST_ID)
    WHERE CIS_NO <> 'UPDATE CIC';

END IF;

-- INSERT DU LIEU VAO BANG HOI TIN
INSERT INTO CIS_REQUEST(ID, CHANNEL,
                            CUSTOMER_TYPE,
                            STATUS,
                            PRODUCT_CODE,
                            CIC_CODE,
                            ID_NO,
                            TAX_CODE,
                            BRANCH_CODE,
                            CREATED_DATE,
                            ADDRESS,
                            REGISTER_NO,
                            CUSTOMER_NAME,
                            CUSTOMER_CODE,
                            APPLICATION_ID,
                            MAKER,
                            REQUEST_ID,
                            KEYWORD, KEYWORD_ID)
SELECT CIS_NO,
        CHANNEL,
        CUSTOMER_TYPE,
        STATUS,
        PRODUCT_CODE,
        CIC_CODE,
        ID_NO,
        TAX_CODE,
        BRANCH_CODE,
        CREATED_DATE,
        ADDRESS,
        TAX_CODE REGISTER_NO,--30/01/2023 Fix loi thieu thong tin dkkd
        CUSTOMER_NAME,
        CUSTOMER_CODE,
        APPLICATION_ID,
        MAKER,
        REQUEST_ID,
        pkg_utility.removesignvietnamess(CIS_NO||','||REGISTER_NO||','||TAX_CODE||','||CIC_CODE||'.'||CUSTOMER_CODE||','||CUSTOMER_NAME||','||PRODUCT_CODE||','||nvl(maker,user)||','|| ','||Id_No),
        pkg_utility.removesignvietnamess(','||REGISTER_NO||','||TAX_CODE||','||CIC_CODE||','||Id_No||',')
        
FROM CIS_REQUEST_TMP;

--Kiem tra xem du lieu phan hoi da day du chua
SELECT COUNT(9) INTO V_ROWS_COUNT
FROM  CIS_MM_OTHER_REQ_REQCIC A
LEFT JOIN CIS_REQUEST B ON A.CIS_NO=B.CIS_NO
WHERE A.REQUEST_ID=V_REQUEST_ID AND B.STATUS<>'RECEIVED';

UPDATE CIS_OTHER_REQUEST
SET STATUS = CASE WHEN NVL(V_ROWS_COUNT,0)=0 THEN 'RECEIVED' ELSE 'WAITING' END
WHERE REQUEST_ID=V_REQUEST_ID;


OPEN p_out FOR
SELECT * 
FROM CIS_OTHER_REQUEST
WHERE REQUEST_ID=V_REQUEST_ID;

COMMIT;
END;

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:Th?c hi?n t󺀠toᮠk?t qu? tr? l?i
*/
PROCEDURE PR_GENERATE_RESPONSE (P_REQUEST_ID VARCHAR2, p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);  
V_RESPONSE_ID NUMBER;
V_CIC_CODE_ROWS NUMBER;
BEGIN

SELECT NVL(MAX(REQUEST_ID),'') INTO V_REQUEST_ID FROM CIS_OTHER_REQUEST WHERE REQUEST_ID=P_REQUEST_ID AND STATUS = 'RECEIVED';
IF V_REQUEST_ID IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy thông tin yêu cầu ['||P_REQUEST_ID||'] trong hệ thống!' );
  RETURN;
END IF;

V_RESPONSE_ID := SEQ_CIS_OTHER_RESPONSE.NEXTVAL;

--TODO: THUC HIEN TINH TOAN KEET QUA TRA LOI
PR_CALCULATOR(V_REQUEST_ID);

UPDATE CIS_OTHER_REQUEST
SET STATUS='GENERATED'
WHERE REQUEST_ID=V_REQUEST_ID;

OPEN p_out FOR
SELECT * 
FROM CIS_OTHER_REQUEST WHERE REQUEST_ID=V_REQUEST_ID;

END;

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:L?y b?n tin tr? l?i
*/
PROCEDURE PR_GET_RESPONSE (P_REQUEST_ID VARCHAR2, p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);  
V_CIC_CODE_ROWS NUMBER;
BEGIN

SELECT NVL(MAX(REQUEST_ID),'') INTO V_REQUEST_ID FROM CIS_OTHER_REQUEST WHERE REQUEST_ID=P_REQUEST_ID;
IF V_REQUEST_ID IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy thông tin yêu cầu ['||P_REQUEST_ID||'] trong hệ thống!' );
  RETURN;
END IF;

--TODO: THUC HIEN L?Y B?N TIN TR? L҉
OPEN p_out FOR
SELECT B.*, A.STATUS REQUEST_STATUS, A.BATCH_ID
FROM CIS_OTHER_REQUEST A
LEFT JOIN CIS_OTHER_RESPONSE B ON A.REQUEST_ID=B.REQUEST_ID
WHERE A.REQUEST_ID = V_REQUEST_ID;

END;


/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:L?y b?n tin tr? l?i
*/
PROCEDURE PR_GET_RESPONSE_DETAIL (P_RESPONSE_ID VARCHAR2, p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);  
V_CIC_CODE_ROWS NUMBER;
BEGIN

--TODO: THUC HIEN L?Y B?N TIN TR? L҉
OPEN p_out FOR
SELECT A.*, B.PRODUCT_CODE
FROM CIS_OTHER_RESPONSE_DETAIL A
JOIN CIS_RESPONSE B ON A.CIS_NO=B.CIS_NO
--JOIN CIS_OTHER_RESPONSE C ON C.RESPONSE_ID=A.OTHER_RESPONSE_ID
--JOIN CIS_OTHER_REQUEST D ON D.REQUEST_ID=C.REQUEST_ID
WHERE A.OTHER_RESPONSE_ID = P_RESPONSE_ID;

END;


/*
Creater: CuongNH2
Create Date: 29/6/2020
Des: C?p nh?t tr?ng th᩠b?n tr? l?i tin
*/
PROCEDURE PR_UPDATE_OTHER_RESPONSE (P_RESPONSE_ID VARCHAR2,
                                   P_RESPONSE_STATUS VARCHAR2,
                                   P_RESPONSE_MESSAGE VARCHAR2,
                                   P_RESPONSE_DATA VARCHAR2,
                                   p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);  
V_CIC_CODE_ROWS NUMBER;
BEGIN

UPDATE CIS_OTHER_RESPONSE
SET RESPONSE_STATUS = P_RESPONSE_STATUS
    ,RESPONSE_MESSAGE = P_RESPONSE_MESSAGE
    ,RESPONSE_DATE = SYSDATE
    --,RESPONSE_DATA = P_RESPONSE_DATA
WHERE RESPONSE_ID = P_RESPONSE_ID;-- AND P_RESPONSE_STATUS IN ('SENT','SENT_ERROR','RECEIVED');

UPDATE CIS_OTHER_REQUEST A
SET A.STATUS=P_RESPONSE_STATUS
WHERE A.REQUEST_ID IN (SELECT REQUEST_ID FROM CIS_OTHER_RESPONSE WHERE RESPONSE_ID = P_RESPONSE_ID AND P_RESPONSE_STATUS IN ('RECEIVED'));

OPEN p_out FOR
SELECT A.*
FROM CIS_OTHER_RESPONSE A
WHERE A.RESPONSE_ID = P_RESPONSE_ID;

END;

/*
Creater: CuongNH2
Create Date: 6/12/2021
Des: T쭠ki?m cᣠy굠c?u h?i tin theo ?i?u ki?n
*/
PROCEDURE PR_SEARCH_OTHER_REQUEST (p_application_id varchar2,
                                   p_request_id varchar2,
                                   p_other_request_id varchar2, 
                                   p_batch_id varchar2,  
                                   p_from_date varchar2, 
                                   p_to_date varchar2, 
                                   p_out    out sys_refcursor) AS
BEGIN

OPEN p_out FOR
SELECT A.*
FROM CIS_OTHER_REQUEST A
WHERE (A.SOURCE_REQUEST_ID = P_REQUEST_ID or P_REQUEST_ID is null)
    AND (A.REQUEST_ID=p_other_request_id OR p_other_request_id IS NULL)
    AND (A.BATCH_ID=P_BATCH_ID OR P_BATCH_ID IS NULL)
    AND (P_BATCH_ID IS NOT NULL OR P_REQUEST_ID IS NOT NULL)
    AND A.APPLICATION_ID=P_APPLICATION_ID
    AND A.REQUEST_DATE BETWEEN TO_DATE(p_from_date,'yyyyMMdd_HH24miss') and TO_DATE(p_to_date,'yyyyMMdd_HH24miss')
;


END;

PROCEDURE PR_CHECK_OTHER_REQ_RECIVED AS
V_REQUEST_ID VARCHAR2(50);  
V_ROWS_COUNT NUMBER;
BEGIN


UPDATE CIS_OTHER_REQUEST A
SET status='WAITING'
where REQUEST_ID not in (select REQUEST_ID from cis_other_response)
and status='GENERATED'
and A.REQUEST_DATE>SYSDATE-5;

DECLARE
  CURSOR c_list_req
  IS
    select * from cis_other_request where status in ('WAITING','RECEIVED');
BEGIN
  FOR r_req IN c_list_req
  LOOP
        --Kiem tra xem du lieu phan hoi da day du chua
        SELECT COUNT(9) INTO V_ROWS_COUNT
        FROM  CIS_MM_OTHER_REQ_REQCIC A
        JOIN CIS_REQUEST B ON A.CIS_NO=B.CIS_NO
        WHERE A.REQUEST_ID=r_req.REQUEST_ID AND B.STATUS<>'RECEIVED';
        
        UPDATE CIS_OTHER_REQUEST
        SET STATUS = CASE WHEN NVL(V_ROWS_COUNT,0)=0 THEN 'GENERATED' ELSE 'WAITING' END
        WHERE REQUEST_ID=r_req.REQUEST_ID;
        
        IF NVL(V_ROWS_COUNT,0)=0 THEN
            PR_CALCULATOR(r_req.REQUEST_ID);
        END IF;
  END LOOP;
END;

END;



/*
Creater: CuongNH2
Create Date: 25/2/2022
Des: Th?c hi?n ki?m tra v࠴?o l?p b?n tin tr? l?i
*/
PROCEDURE PR_CHECK_OTHER_REQUEST (p_application_id varchar2,
                                   p_request_id varchar2,
                                   p_other_request_id varchar2, 
                                   p_batch_id varchar2, 
                                   p_out    out sys_refcursor) AS
BEGIN

--PR_CHECK_OTHER_REQ_RECIVED;

OPEN p_out FOR
SELECT A.*
FROM CIS_OTHER_REQUEST A
WHERE (A.SOURCE_REQUEST_ID = P_REQUEST_ID or P_REQUEST_ID is null)
    AND (A.REQUEST_ID=p_other_request_id OR p_other_request_id IS NULL)
    AND (A.BATCH_ID=P_BATCH_ID OR P_BATCH_ID IS NULL)
    AND (P_BATCH_ID IS NOT NULL OR P_REQUEST_ID IS NOT NULL)
    AND A.APPLICATION_ID=P_APPLICATION_ID 
;


END;
end PCK_CIS_OTHER_REQUEST;

/
--------------------------------------------------------
--  DDL for Package Body PCK_CIC_TOKEN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_CIC_TOKEN" AS

  PROCEDURE PR_GET_CIC_TOKEN (p_out    OUT SYS_REFCURSOR) AS
  BEGIN
    OPEN P_OUT FOR
    SELECT TOKEN,
            THOI_GIAN_BAT_DAU,
            to_number(((CREATED_DATE +numToDSInterval( a.token_het_han, 'second' ))-sysdate)*24*60*60) TOKEN_HET_HAN,
            MAT_KHAU_HET_HAN,
            GHI_CHU,
            CREATED_DATE
    FROM SYS_CIC_TOKEN A
    WHERE CREATED_DATE > SYSDATE-1
    ORDER BY CREATED_DATE DESC;
    
  END PR_GET_CIC_TOKEN;

  PROCEDURE PR_UPDATE_CIC_TOKEN (p_token VARCHAR2,
                        p_thoi_gian_bat_dau VARCHAR2,
                        p_token_het_han VARCHAR2,
                        p_mat_khau_het_han   VARCHAR2,
                        p_ghi_chu VARCHAR2,
                        p_out    OUT SYS_REFCURSOR) AS
  V_COUNT INT;
  BEGIN
    SELECT COUNT(9) INTO V_COUNT
    FROM SYS_CIC_TOKEN
    WHERE TOKEN=p_token;
    
    IF V_COUNT=0 THEN
        insert into SYS_CIC_TOKEN (TOKEN, THOI_GIAN_BAT_DAU, TOKEN_HET_HAN, MAT_KHAU_HET_HAN, GHI_CHU,CREATED_DATE)
        values (p_token, p_thoi_gian_bat_dau, p_token_het_han, p_mat_khau_het_han, SYS_CONTEXT('USERENV','IP_ADDRESS') ||'; '|| nvl(p_ghi_chu,''), sysdate);
        
    END IF;
    
        OPEN P_OUT FOR
        SELECT * 
        FROM SYS_CIC_TOKEN
        WHERE TOKEN=p_token;
    
  END PR_UPDATE_CIC_TOKEN;

END PCK_CIC_TOKEN;

/
--------------------------------------------------------
--  DDL for Package Body PCK_DATA_REPORT_FROM_CIC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_DATA_REPORT_FROM_CIC" AS


PROCEDURE PR_GET_FILE_BY_NAME(P_ID VARCHAR2,
                    P_FILE_NAME VARCHAR2,
                    P_FILE_STATUS VARCHAR2, 
                    P_RESPONSE_DATE VARCHAR2,
                    P_FILE_PATH VARCHAR2,
                    P_CHECK_SUM_MD5 VARCHAR2, 
                    p_out    OUT SYS_REFCURSOR) AS
--V_ROWS NUMBER;
BEGIN
OPEN P_OUT FOR
SELECT *
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE A.FILE_NAME=P_FILE_NAME;

END;

PROCEDURE PR_UPDATE_STATUS_FILE(P_ID VARCHAR2,
                    P_FILE_NAME VARCHAR2,
                    P_FILE_STATUS VARCHAR2, 
                    P_RESPONSE_DATE VARCHAR2,
                    P_FILE_PATH VARCHAR2,
                    P_CHECK_SUM_MD5 VARCHAR2, 
                    p_out    OUT SYS_REFCURSOR) AS
--V_ROWS NUMBER;
BEGIN

UPDATE CIC_DATA_REPORT_FROM_CIC A
SET FILE_STATUS=P_FILE_STATUS
  
WHERE A.FILE_NAME=P_FILE_NAME;


OPEN P_OUT FOR
SELECT *
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE A.FILE_NAME=P_FILE_NAME;

END;

END PCK_DATA_REPORT_FROM_CIC;

/
--------------------------------------------------------
--  DDL for Package Body PCK_CIS_RESPONSE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_CIS_RESPONSE" AS

  PROCEDURE PR_CREATE_CIS_RESPONSE (
        p_id CIS_RESPONSE.ID%TYPE,
        p_cis_no CIS_RESPONSE.CIS_NO%TYPE,
        p_cic_code CIS_RESPONSE.CIC_CODE%TYPE,
        p_member_code CIS_RESPONSE.MEMBER_CODE%TYPE,
        p_tax_code CIS_RESPONSE.TAX_CODE%TYPE,
        p_id_no CIS_RESPONSE.ID_NO%TYPE,
        p_product_code CIS_RESPONSE.PRODUCT_CODE%TYPE,
        p_response_date CIS_RESPONSE.RESPONSE_DATE%TYPE,
        p_status_code_cic CIS_RESPONSE.STATUS_CODE_CIC%TYPE,
        p_created_date CIS_RESPONSE.CREATED_DATE%TYPE,
        p_err_code CIS_RESPONSE.ERR_CODE%TYPE,
        p_err_msg CIS_RESPONSE.ERR_MSG%TYPE,
        p_response_data CIS_RESPONSE.RESPONSE_DATA%TYPE,
        p_status CIS_RESPONSE.STATUS%TYPE,
        p_version_no CIS_RESPONSE.VERSION_NO%TYPE,
        p_execute_date CIS_RESPONSE.EXECUTE_DATE%TYPE,
        p_msg_id CIS_RESPONSE.MSG_ID%TYPE,
        p_out    OUT SYS_REFCURSOR) 
        AS
        V_ID_CIS_RESPONSE VARCHAR2 (2000);
  BEGIN
        V_ID_CIS_RESPONSE:= SEQ_CIS_RESPONSE.NEXTVAL;
        DBMS_OUTPUT.PUT_LINE ('PR_CREATE_CIS_RESPONSE:' || V_ID_CIS_RESPONSE);
        UPDATE CIS_RESPONSE
        SET CIS_NO='BK_'||CIS_NO
        WHERE CIS_NO=P_CIS_NO;

        INSERT INTO CIS_RESPONSE (ID, 
                                CIS_NO, 
                                CIC_CODE, 
                                MEMBER_CODE, 
                                TAX_CODE, 
                                ID_NO, 
                                PRODUCT_CODE, 
                                RESPONSE_DATE, 
                                STATUS_CODE_CIC, 
                                CREATED_DATE, 
                                ERR_CODE, 
                                ERR_MSG, 
                                RESPONSE_DATA, 
                                STATUS, 
                                VERSION_NO, 
                                EXECUTE_DATE,
                                MSG_ID
                                 )
         VALUES (V_ID_CIS_RESPONSE , --ID
                p_cis_no , --ID_REQUEST
                p_cic_code , --CIC_CODE
                p_member_code , --MEMBER_CODE
                p_tax_code , --TAX_CODE
                p_id_no , --ID_NO
                p_product_code , --PRODUCT_CODE
                p_response_date , --RESPONSE_DATE
                p_status_code_cic , --STATUS_CODE_CIC
                p_created_date , --CREATED_DATE
                p_err_code , --ERR_CODE
                p_err_msg , --ERR_MSG
                replace(replace(replace(replace(replace(p_response_data,'&amp;','&'),'&','&amp;'),'<BR>','&lt;BR &gt;') ,'</BR>','&lt;/BR &gt;'),'Ч,'?') , --RESPONSE_DATA
                --PKG_UTILITY.RemoveSpecialCharactor(p_response_data),
                'N/A' , --STATUS
                p_version_no , --VERSION_NO
                p_execute_date,  --EXECUTE_DATE
                p_msg_id --MSG_ID
                );      


    IF p_product_code='S37H' THEN 
        update cis_request
        set IS_DATA='Y'
        where cis_no=p_cis_no;
    END IF;

    OPEN p_out FOR
        SELECT *
        FROM   CIS_RESPONSE
        WHERE  ID = V_ID_CIS_RESPONSE;                             

    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END PR_CREATE_CIS_RESPONSE;



    PROCEDURE PR_GET_CIS_RESPONSE_INFO (
        p_id CIS_RESPONSE.ID%TYPE,
        p_cis_no CIS_RESPONSE.CIS_NO%TYPE,
        p_cic_code CIS_RESPONSE.CIC_CODE%TYPE,
        p_member_code CIS_RESPONSE.MEMBER_CODE%TYPE,
        p_tax_code CIS_RESPONSE.TAX_CODE%TYPE,
        p_id_no CIS_RESPONSE.ID_NO%TYPE,
        p_product_code CIS_RESPONSE.PRODUCT_CODE%TYPE,
        p_response_date CIS_RESPONSE.RESPONSE_DATE%TYPE,
        p_status_code_cic CIS_RESPONSE.STATUS_CODE_CIC%TYPE,
        p_created_date CIS_RESPONSE.CREATED_DATE%TYPE,
        p_err_code CIS_RESPONSE.ERR_CODE%TYPE,
        p_err_msg CIS_RESPONSE.ERR_MSG%TYPE,
        p_response_data CIS_RESPONSE.RESPONSE_DATA%TYPE,
        p_status CIS_RESPONSE.STATUS%TYPE,
        p_version_no CIS_RESPONSE.VERSION_NO%TYPE,
        p_execute_date CIS_RESPONSE.EXECUTE_DATE%TYPE,
        p_msg_id CIS_RESPONSE.MSG_ID%TYPE,
        p_out    OUT SYS_REFCURSOR) 
        AS
  BEGIN        
    OPEN p_out FOR
          SELECT  A.ID	,
                  A.CIS_NO	,
                  A.CIC_CODE	,
                  A.MEMBER_CODE	,
                  A.TAX_CODE	,
                  A.ID_NO	,
                  A.PRODUCT_CODE	,
                  A.RESPONSE_DATE	,
                  A.STATUS_CODE_CIC	,
                  A.CREATED_DATE	,
                  A.ERR_CODE	,
                  A.ERR_MSG	,
                  case when B.CHANNEL='CIC' then
                    regexp_replace(REPLACE(REPLACE(REPLACE(RESPONSE_DATA	,'<TENTRUYCAP>vib_01</TENTRUYCAP>','<TENTRUYCAP>'|| B.MAKER ||'</TENTRUYCAP>'),'"','&quot;'),'''','&apos'),'&($|[^lagq]|(g|l)([^t]|$)|q($|[^u]|u($|[^o]|o($|[^t])))|a($|([^m]|m($|[^p]))&([^p]|p($|[^o]|o($|[^s])))))','&amp;\1') 
                  else 
                    regexp_replace(REPLACE(REPLACE(REPLACE(RESPONSE_DATA	,'<TENTRUYCAP>vib_01</TENTRUYCAP>','<TENTRUYCAP>'|| B.MAKER ||'</TENTRUYCAP>'),'&quot;','"'),'''','&apos'),'&($|[^lagq]|(g|l)([^t]|$)|q($|[^u]|u($|[^o]|o($|[^t])))|a($|([^m]|m($|[^p]))&([^p]|p($|[^o]|o($|[^s])))))','&amp;\1') 
                  end RESPONSE_DATA,
--                  REPLACE(RESPONSE_DATA	,'<TENTRUYCAP>vib_01</TENTRUYCAP>','<TENTRUYCAP>'|| B.MAKER ||'</TENTRUYCAP>') RESPONSE_DATA,
                  A.STATUS	,
                  A.VERSION_NO	,
                  A.EXECUTE_DATE	,
                  A.MSG_ID	,
                  C.REF_NAME_VN BRANCH_NAME, D.FULL_NAME
        FROM   CIS_RESPONSE A
        LEFT JOIN CIS_REQUEST B ON A.CIS_NO=B.CIS_NO
        LEFT JOIN V_BRANCH C ON B.BRANCH_CODE = C.REF_CODE
        LEFT JOIN SYS_USER D ON B.MAKER = D.USER_NAME
    --dodt edit 07/04    WHERE  CIS_NO = p_cis_no AND PRODUCT_CODE = ''||p_product_code||'';
    WHERE  A.CIS_NO = p_cis_no;
    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END PR_GET_CIS_RESPONSE_INFO;

PROCEDURE PR_LIST_CIS_RESPONSE_FOR_PASER (
        p_status varchar2, 
        p_channel varchar2, 
        p_out    OUT SYS_REFCURSOR)
        AS
v_rowcount number;
  BEGIN

  IF P_STATUS='N/A' THEN

    SELECT COUNT(9) INTO v_rowcount
    FROM CIS_RESPONSE A WHERE STATUS='IN_PROGRESS' ;

    IF v_rowcount=0 THEN 

      UPDATE CIS_RESPONSE A 
      SET STATUS='IN_PROGRESS' 
      WHERE ID IN (SELECT AA.ID FROM CIS_RESPONSE AA 
                                LEFT JOIN CIS_REQUEST B ON AA.CIS_NO=B.CIS_NO
                   WHERE AA.STATUS = P_STATUS AND B.CHANNEL=P_CHANNEL)
            AND ROWNUM<400;

    DELETE TBL_CIS_CHI_TIET_LOAI_VAY WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_DU_NO_THE WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_QUAN_HE_TIN_DUNG WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_THONG_TIN_CHUNG WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_TSDB WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_TT_THANH_TOAN_THE WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_TT_TONG_HOP_KHAC_HDTD WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_DU_NO_HIEN_THOI WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_LICH_SU_TRA_CUU WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_LS_QUAN_HE_TIN_DUNG WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
          commit;      
      OPEN P_OUT FOR
          SELECT ID	,
                  CIS_NO	,
                  CIC_CODE	,
                  MEMBER_CODE	,
                  TAX_CODE	,
                  ID_NO	,
                  PRODUCT_CODE	,
                  RESPONSE_DATE	,
                  STATUS_CODE_CIC	,
                  CREATED_DATE	,
                  ERR_CODE	,
                  ERR_MSG	,
                  REPLACE(REPLACE(RESPONSE_DATA	,'<BR1/>','|'),'<br1/>','|') RESPONSE_DATA,
                  STATUS	,
                  VERSION_NO	,
                  EXECUTE_DATE	,
                  MSG_ID	 
          FROM   CIS_RESPONSE A  
      WHERE A.STATUS='IN_PROGRESS' ;    
    END IF;
  END IF;

  IF P_STATUS<>'N/A'  THEN  
    OPEN P_OUT FOR
        SELECT A.* 
        FROM   CIS_RESPONSE A 
        LEFT JOIN CIS_REQUEST B ON A.CIS_NO=B.CIS_NO
    WHERE  A.STATUS = P_STATUS AND B.CHANNEL=P_CHANNEL AND ROWNUM<5;
  END IF;

    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END;

PROCEDURE PR_CIS_RESPONSE_CHANGE_STATUS (
        p_status varchar2, 
        p_cis_no varchar2, 
        p_id varchar2, 
        p_out    OUT SYS_REFCURSOR)
        AS
  BEGIN        
    update CIS_RESPONSE
    set status=p_status, execute_date=sysdate
    where cis_no=p_cis_no and id=p_id;

    OPEN p_out FOR
    select * from CIS_RESPONSE
    where id=p_id;

    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END;
END PCK_CIS_RESPONSE;

/
--------------------------------------------------------
--  DDL for Package Body PCK_CIS_DASHBOARD
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_CIS_DASHBOARD" AS

/*
CREATE: CUONGNH
DESCRIPTION: TOP 10 BAN HOI TIN GAN NHAT
*/
PROCEDURE PR_LIST_TOP_REQUEST ( p_user varchar2,
                                p_client_ip varchar2,
                                p_user_agent varchar2,
                                p_out    OUT SYS_REFCURSOR)
AS
BEGIN

OPEN P_OUT FOR  
select * from (
SELECT A.ID, 
      A.CIS_NO, 
      A.CHANNEL, 
      A.CUSTOMER_TYPE, 
      A.STATUS, 
      A.PRODUCT_CODE, 
      A.MEMBER_CODE, 
      A.CIC_CODE, 
      A.ID_NO, 
      A.TAX_CODE, 
      A.USERNAME_REQUEST, 
      A.BRANCH_CODE, 
      TO_CHAR(A.CREATED_DATE,'DD/MM/YYYY') CREATED_DATE_STR, 
      A.REQUESTED_DATE, 
      A.REQUEST_DATA, 
      A.ERR_CODE, 
      A.ERR_MSG, 
      A.ADDRESS, 
      A.REGISTER_NO, 
      A.NOTE, 
      A.CUSTOMER_NAME, 
      A.CUSTOMER_CODE, 
      TO_CHAR(A.RESPONSE_DATE,'DD/MM/YYYY')  RESPONSE_DATE_STR,
      A.EMAIL, 
      A.LAST_VERSION, 
      A.FLAG, 
      A.MSG_ID, 
      A.APPLICATION_ID, 
      A.MAKER, 
      A.TASK_ID, 
      A.ENCODE_REQUEST, 
      A.BORROWER, 
      A.PCB_CODE, 
      A.CCY, 
      A.AMOUNT_FIN_CAPITAL, 
      A.TOTAL_INSTALMENT, 
      A.CREDIT_LIMIT, 
      A.GENDER, 
      A.DOB, 
      A.DOC_TYPE, 
      A.PAY_PERIODICITY, 
      A.OPERATION_TYPE, 
      A.COUNTRY_OF_BIRTH, 
      A.PHONE_NUMBER, 
      A.FREQUENT_CONTACTS, 
      A.REQUEST_ID, 
      A.USER_, 
      A.CLIENT_IP, 
      A.USER_AGENT, 
      refStatus.REF_NAME_VN STATUS_STR,
      refDocType.REF_NAME_VN DOC_TYPE_STR,
      refCustomerType.REF_NAME_VN CUSTOMER_TYPE_STR,
      B.REF_NAME_VN PRODUCT_NAME
FROM   CIS_REQUEST A
LEFT JOIN SYS_REFCODE refStatus ON A.STATUS = refStatus.REF_CODE AND refStatus.REF_GROUP = 'STATUS_REQUEST'
LEFT JOIN SYS_REFCODE refCustomerType ON A.CUSTOMER_TYPE = refCustomerType.REF_CODE AND refCustomerType.REF_GROUP = 'LOAI_KH'
LEFT JOIN SYS_REFCODE refDocType ON A.DOC_TYPE = refDocType.REF_CODE AND refDocType.REF_GROUP = 'DOC_TYPE'
LEFT JOIN SYS_REFCODE B ON A.PRODUCT_CODE = B.REF_CODE AND B.REF_GROUP = 'LS_PRODUCT'
WHERE A.MAKER = P_USER 
ORDER BY CREATED_DATE DESC,REQUESTED_DATE DESC ) AA
WHERE ROWNUM<=10;
END;

/*
CREATE: CUONGNH
DESCRIPTION: SUMMARY ON MONTH
*/
PROCEDURE PR_LIST_REQUEST_MONTHLY ( p_user varchar2,
                                    p_client_ip varchar2,
                                    p_user_agent varchar2,
                                    p_out    OUT SYS_REFCURSOR)
AS
BEGIN

OPEN P_OUT FOR  
SELECT COUNT(9) TOTAL_REQUEST, TO_NUMBER(TO_CHAR(A.CREATED_DATE,'DD')) DAYS
FROM   CIS_REQUEST A
WHERE A.MAKER = P_USER AND TO_CHAR(A.CREATED_DATE,'MMYYYY')=TO_CHAR(SYSDATE,'MMYYYY')
GROUP BY TO_NUMBER(TO_CHAR(A.CREATED_DATE,'DD'))
ORDER BY DAYS;


END;

/*
CREATE: CUONGNH
DESCRIPTION: SUMMARY ON MONTH
*/
PROCEDURE PR_LIST_REQ_PROD_MONTHLY ( p_user varchar2,
                                    p_client_ip varchar2,
                                    p_user_agent varchar2,
                                    p_out    OUT SYS_REFCURSOR)
AS
BEGIN

OPEN P_OUT FOR  
SELECT PKG_UTILITY.FORMAT_NUMBER(COUNT(9)) TOTAL_REQUEST,
       A.PRODUCT_CODE,
       B.REF_NAME_VN PRODUCT_NAME,
       A.CHANNEL,
       PKG_UTILITY.FORMAT_NUMBER(SUM(CASE WHEN A.IS_DATA='Y' THEN C.NORMAL_PRICE ELSE C.NON_NORMAL_PRICE END)) TOTAL_AMOUNT
FROM   CIS_REQUEST A
LEFT JOIN SYS_PRICE C ON A.PRODUCT_CODE=C.PRICE_CODE AND TRUNC(A.RESPONSE_DATE) BETWEEN TRUNC(C.EFFECTIVE_DATE) AND TRUNC(NVL(C.EXPIRATION_DATE,SYSDATE+100)) AND A.STATUS='RECEIVED'
LEFT JOIN SYS_REFCODE B ON A.PRODUCT_CODE = B.REF_CODE AND B.REF_GROUP = 'LS_PRODUCT'
WHERE A.MAKER = P_USER AND TO_CHAR(A.RESPONSE_DATE,'MMYYYY')=TO_CHAR(SYSDATE,'MMYYYY') AND A.STATUS='RECEIVED'
GROUP BY A.PRODUCT_CODE,
       B.REF_NAME_VN,
       A.CHANNEL
ORDER BY A.CHANNEL,A.PRODUCT_CODE;


END;
/*
CREATE: CUONGNH
DESCRIPTION: TINH TOAN BIEU DO
*/
PROCEDURE PR_AGG_DASHBOARD
AS
V_DAY_ID DATE;

BEGIN
V_DAY_ID := TRUNC(SYSDATE-1);

DELETE CIS_DASHBOARD WHERE to_char(TRUNC(SYSDATE-1),'YYYYMM') = to_char(sysdate,'YYYYMM');

INSERT INTO CIS_DASHBOARD(ID
                          ,USER_NAME
                          ,DAY_ID
                          ,NUMBER_OF_REQUSET
                          ,ESTIMATED_COST
                          ,CREATED_DATE
                          ,CHANNEL
                          ,PRODUCT_CODE)
SELECT SEQ_CIS_DASHBOARD.NEXTVAL ID, AA.*
FROM (SELECT A.MAKER USER_NAME
             ,TRUNC(A.RESPONSE_DATE) DAY_ID
             ,COUNT(9) NUMBER_OF_REQUSET
             ,SUM(C.NORMAL_PRICE) ESTIMATED_COST
             ,SYSDATE CREATED_DATE
             ,A.CHANNEL
             ,A.PRODUCT_CODE
      FROM   CIS_REQUEST A
      LEFT JOIN SYS_PRICE C ON A.PRODUCT_CODE=C.PRICE_CODE AND TRUNC(A.RESPONSE_DATE) BETWEEN TRUNC(C.EFFECTIVE_DATE) AND TRUNC(NVL(C.EXPIRATION_DATE,SYSDATE+100)) AND A.STATUS='RECEIVED'
      WHERE to_char(A.RESPONSE_DATE,'YYYYMM')=to_char(sysdate,'YYYYMM') AND A.STATUS='RECEIVED'
      GROUP BY A.PRODUCT_CODE,
             A.MAKER,
              TRUNC(A.RESPONSE_DATE),
             A.CHANNEL) AA;

COMMIT;
END;

/*
CREATE: CUONGNH
DESCRIPTION: VIEW CHAR
*/
PROCEDURE PR_LIST_CHAR ( p_user varchar2,
                        p_client_ip varchar2,
                        p_user_agent varchar2,
                        p_out    OUT SYS_REFCURSOR)
AS
BEGIN

  OPEN P_OUT FOR  
  select TO_CHAR(DAY_ID,'MM/YY') MONTHID,SUM(A.NUMBER_OF_REQUSET) NUMBER_OF_REQUSET,TO_CHAR(DAY_ID,'YYYYMM') MONTHID_ORDER
  from CIS_DASHBOARD A
  WHERE A.USER_NAME = p_user AND DAY_ID>ADD_MONTHS(SYSDATE,-12)
  GROUP BY TO_CHAR(DAY_ID,'MM/YY'),TO_CHAR(DAY_ID,'YYYYMM')
  ORDER BY MONTHID_ORDER;


END;


/*
CREATE: CUONGNH
DESCRIPTION: SUMMARY ON MONTH
*/
PROCEDURE PR_USERINFO ( p_user varchar2,
                        p_client_ip varchar2,
                        p_user_agent varchar2,
                        p_out    OUT SYS_REFCURSOR)
AS
BEGIN

OPEN P_OUT FOR  
SELECT A.FULL_NAME,A.JOB_TITLE,A.STATUS
FROM   SYS_USER A
WHERE A.USER_NAME = p_user ;


END;
END;

/
--------------------------------------------------------
--  DDL for Package Body PCK_CIS_REQUEST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_CIS_REQUEST" AS

  PROCEDURE PR_CREATE_CIS_REQUEST (
        p_id CIS_REQUEST.ID%TYPE,
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_channel CIS_REQUEST.CHANNEL%TYPE,
        p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
        p_member_code CIS_REQUEST.MEMBER_CODE%TYPE,
        p_cic_code CIS_REQUEST.CIC_CODE%TYPE,
        p_id_no CIS_REQUEST.ID_NO%TYPE,
        p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
        p_username_request CIS_REQUEST.USERNAME_REQUEST%TYPE,
        p_branch_code CIS_REQUEST.BRANCH_CODE%TYPE,
        p_created_date CIS_REQUEST.CREATED_DATE%TYPE,
        p_requested_date CIS_REQUEST.REQUESTED_DATE%TYPE,
        p_request_data CIS_REQUEST.REQUEST_DATA%TYPE,
        p_err_code CIS_REQUEST.ERR_CODE%TYPE,
        p_err_msg CIS_REQUEST.ERR_MSG%TYPE,
        p_address CIS_REQUEST.ADDRESS%TYPE,
        p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
        p_note CIS_REQUEST.NOTE%TYPE,
        p_customer_name CIS_REQUEST.CUSTOMER_NAME%TYPE,
        p_customer_code CIS_REQUEST.CUSTOMER_CODE%TYPE,
        p_response_date CIS_REQUEST.RESPONSE_DATE%TYPE,
        p_email CIS_REQUEST.EMAIL%TYPE,
        p_last_version CIS_REQUEST.LAST_VERSION%TYPE,
        p_flag CIS_REQUEST.FLAG%TYPE,
        p_msg_id CIS_REQUEST.MSG_ID%TYPE,
        p_application_id CIS_REQUEST.APPLICATION_ID%TYPE,
        p_maker CIS_REQUEST.MAKER%TYPE,
        p_task_id CIS_REQUEST.TASK_ID%TYPE,
        p_encode_request cis_request.encode_request%TYPE,
        p_borrower CIS_REQUEST.BORROWER%TYPE,
        p_pcb_code CIS_REQUEST.PCB_CODE%TYPE,
        p_ccy CIS_REQUEST.CCY%TYPE,
        p_amount_fin_capital CIS_REQUEST.AMOUNT_FIN_CAPITAL%TYPE,
        p_total_instalment CIS_REQUEST.TOTAL_INSTALMENT%TYPE,
        p_credit_limit CIS_REQUEST.CREDIT_LIMIT%TYPE,
        p_gender CIS_REQUEST.GENDER%TYPE,
        p_dob CIS_REQUEST.DOB%TYPE,
        p_doc_type CIS_REQUEST.DOC_TYPE%TYPE,
        p_pay_periodicity CIS_REQUEST.PAY_PERIODICITY%TYPE,
        p_operation_type CIS_REQUEST.OPERATION_TYPE%TYPE,
        p_country_of_birth CIS_REQUEST.COUNTRY_OF_BIRTH%TYPE,
        p_request_id CIS_REQUEST.REQUEST_ID%TYPE,
        p_frequent_contacts CIS_REQUEST.FREQUENT_CONTACTS%TYPE,
        p_phone_number CIS_REQUEST.PHONE_NUMBER%TYPE,
        p_user varchar2,
        p_client_ip varchar2,
        p_user_agent varchar2,
        p_nam_tai_chinh varchar2,
        p_out    OUT SYS_REFCURSOR) 
    AS
        V_ID_CIS_REQUEST VARCHAR2 (2000);
        V_STATUS VARCHAR2(100);
        V_REQUEST_STATUS VARCHAR2(100);
        V_CIS_NO VARCHAR2(15);
        V_PARAMETER VARCHAR2(1000);
        V_COUNT NUMBER;
        V_WARNING_RECORDS NUMBER;
        V_MAX_WARNING_RECORDS NUMBER;
        V_BRANCH VARCHAR2(50);
        V_DEPARTMENT VARCHAR2(50);
        V_ERR_MSG  VARCHAR2(500);
        V_MSG_ID  VARCHAR2(500);
    BEGIN
        V_ID_CIS_REQUEST:= SEQ_CIS_REQUEST.NEXTVAL;
        V_MSG_ID:=case when p_msg_id in ('null','undefined') then '' else p_msg_id end;
        
        DBMS_OUTPUT.PUT_LINE ('PR_CREATE_CIS_REQUEST:' || V_ID_CIS_REQUEST);

        SELECT COUNT(9) INTO V_WARNING_RECORDS
        FROM CIS_REQUEST A
        WHERE A.MAKER=nvl(p_maker,p_user) AND TRUNC(A.CREATED_DATE)=TRUNC(SYSDATE) AND A.MSG_ID IS NOT NULL;

        SELECT
	MAX(PKG_UTILITY.IS_NUMBER(A.PAR1)),
	MAX(CIC_DEPARTMENT)
INTO
	V_MAX_WARNING_RECORDS,
	V_DEPARTMENT
FROM
	SYS_GROUPS A
LEFT JOIN SYS_USER B ON
	',' || B.GROUP_NAME || ',' LIKE '%,' || A.GROUP_NAME || ',%'
WHERE
	B.USER_NAME = nvl(p_maker, p_user);

        V_REQUEST_STATUS := P_STATUS;

        IF P_CHANNEL='CIC' THEN--Check dieu kien CIC
           V_STATUS := PCK_CIS_REQUEST.PR_STATUS_MATRIX_CIC(p_id_no, p_register_no, p_tax_code, p_customer_type, p_product_code, p_cic_code);
           IF V_STATUS LIKE 'WAITING:%' THEN
                V_REQUEST_STATUS:='REJECTED_M'; 
                V_ERR_MSG:='Đang đợi bản tin phản hồi';
           END IF;
           IF V_STATUS='WARNING1' OR V_STATUS='WARNING2' OR V_STATUS='WARNING3' OR V_STATUS='WARNING1WARNING3' OR V_STATUS='WARNING2WARNING3' THEN
              IF V_WARNING_RECORDS>=V_MAX_WARNING_RECORDS THEN
                V_REQUEST_STATUS:='REJECTED_M';   
                V_ERR_MSG:='Hỏi tin vượt số lượng cảnh báo';           
              END IF;

              V_PARAMETER := 'channel:CIC,product_code:'|| p_product_code ||',id_no:'||p_id_no ||',tax_code:'||p_tax_code ||',register_no:'||P_register_no ||',customer_type:'||p_customer_type ||',V_WARNING_RECORDS:'||V_WARNING_RECORDS||',V_MAX_WARNING_RECORDS:'||V_MAX_WARNING_RECORDS;
              --pkg_system_log.PR_LOG_EXCEPTION('PR_CREATE_CIS_REQUEST','DEBUG WARNING',V_STATUS,V_PARAMETER);
              
              SELECT COUNT(9) INTO V_COUNT FROM CIS_MSGID A WHERE A.MSGID=V_MSG_ID;
              IF V_COUNT=-1 THEN--Tam thoi bo dieu kien check MSGID
                V_STATUS:=DBMS_RANDOM.STRING('A', 5);
                pkg_system_log.PR_LOG_EXCEPTION('PR_CREATE_CIS_REQUEST','CHECK PR_STATUS_MATRIX_CIC',V_STATUS,'WRONG MSGID: '||V_MSG_ID ||'|'||V_PARAMETER);
                COMMIT;
                V_REQUEST_STATUS:='REJECTED_M';
                V_ERR_MSG:='Không có thông tin MSGID';    
              END IF;
           END IF;
        END IF;

        IF P_CHANNEL='PCB' THEN
           V_STATUS := PCK_CIS_REQUEST.PR_STATUS_MATRIX_PCB(p_product_code,p_id_no, p_doc_type, P_register_no);
           IF V_STATUS='WARNING1' OR V_STATUS='WARNING2' OR V_STATUS='WARNING3' OR V_STATUS='WARNING1WARNING3' OR V_STATUS='WARNING2WARNING3' THEN
              IF V_WARNING_RECORDS>=V_MAX_WARNING_RECORDS THEN
                raise_application_error( -20000, 'Không thể hỏi tin được, đã hỏi vượt số bản tin cảnh báo! ['||V_WARNING_RECORDS||'] ' );
                RETURN;              
              END IF;
              V_PARAMETER := 'channel:PCB,product_code:'|| p_product_code ||',id_no:'||p_id_no ||',doc_type:'||p_doc_type ||',register_no:'||P_register_no ;
              SELECT COUNT(9) INTO V_COUNT FROM CIS_MSGID A WHERE A.MSGID=P_MSG_ID;
              IF V_COUNT=0 THEN
                V_STATUS:=DBMS_RANDOM.STRING('A', 5);
                pkg_system_log.PR_LOG_EXCEPTION('PR_CREATE_CIS_REQUEST','CHECK PR_STATUS_MATRIX_PCB',V_STATUS,'WRONG MSGID: '||P_MSG_ID ||'|'||V_PARAMETER);
                COMMIT;
                raise_application_error( -20000, 'Không thể hỏi tin được, yêu cầu liên hệ quản trị hệ thống dể hỗ trợ! ['||V_STATUS||'] ' );
                RETURN;
              END IF;
           END IF;
        END IF;

        IF P_CHANNEL='TS' THEN
           V_STATUS := PCK_CIS_REQUEST.PR_STATUS_MATRIX_TS(p_phone_number, p_product_code, '');
           IF V_STATUS='WARNING1' OR V_STATUS='WARNING2' OR V_STATUS='WARNING3' OR V_STATUS='WARNING1WARNING3' OR V_STATUS='WARNING2WARNING3' THEN
              IF V_WARNING_RECORDS>=V_MAX_WARNING_RECORDS THEN
                raise_application_error( -20000, 'Không thể hỏi tin được, đã hỏi vượt số bản tin cảnh báo! ['||V_WARNING_RECORDS||'] ' );
                RETURN;              
              END IF;

              V_PARAMETER := 'channel:PCB,product_code:'|| p_product_code ||',p_phone_number:'||p_phone_number ;
              SELECT COUNT(9) INTO V_COUNT FROM CIS_MSGID A WHERE A.MSGID=P_MSG_ID;
              IF V_COUNT=0 THEN
                V_STATUS:=DBMS_RANDOM.STRING('A', 5);
                pkg_system_log.PR_LOG_EXCEPTION('PR_CREATE_CIS_REQUEST','CHECK PR_STATUS_MATRIX_TS',V_STATUS,'WRONG MSGID: '||P_MSG_ID ||'|'||V_PARAMETER);
                COMMIT;
                raise_application_error( -20000, 'Không thể hỏi tin được, yêu cầu liên hệ quản trị hệ thống dể hỗ trợ! ['||V_STATUS||'] ' );
                RETURN;
              END IF;
           END IF;
        END IF;
        SELECT MAX(A.MEMBER_CODE) INTO V_BRANCH
        FROM SYS_USER A
        WHERE A.USER_NAME = nvl(p_maker,p_user);
        
        INSERT INTO CIS_REQUEST (ID,
                                CIS_NO,
                                CHANNEL,
                                CUSTOMER_TYPE,
                                STATUS,
                                PRODUCT_CODE,
                                MEMBER_CODE,
                                CIC_CODE,
                                ID_NO,
                                TAX_CODE,
                                USERNAME_REQUEST,
                                BRANCH_CODE,
                                CREATED_DATE,
                                REQUESTED_DATE,
                                REQUEST_DATA,
                                ERR_CODE,
                                ERR_MSG,
                                ADDRESS,
                                REGISTER_NO,
                                NOTE,
                                CUSTOMER_NAME,
                                CUSTOMER_CODE,
                                RESPONSE_DATE,
                                EMAIL,
                                LAST_VERSION,
                                FLAG,
                                MSG_ID,
                                APPLICATION_ID,
                                MAKER,
                                TASK_ID,
                                encode_request,
                                BORROWER, 
                                PCB_CODE, 
                                CCY, 
                                AMOUNT_FIN_CAPITAL, 
                                TOTAL_INSTALMENT, 
                                CREDIT_LIMIT, 
                                GENDER, 
                                DOB, 
                                DOC_TYPE, 
                                PAY_PERIODICITY, 
                                OPERATION_TYPE, 
                                COUNTRY_OF_BIRTH,
                                REQUEST_ID,
                                FREQUENT_CONTACTS,
                                PHONE_NUMBER,
                                USER_,
                                CLIENT_IP,
                                USER_AGENT,
                                IS_DATA,--14/4/2021 Thiet lap gia tri mac dinh N
                                KEYWORD, KEYWORD_ID,-- 4/5/2021 Them tinh nang tim kiem ko dau
                                nam_tai_chinh,
                                DEPARTMENT) 
         VALUES (V_ID_CIS_REQUEST , --ID
                p_cis_no , --CIS_NO
                p_channel , --CHANNEL
                p_customer_type , --CUSTOMER_TYPE
                V_REQUEST_STATUS , --STATUS
                p_product_code , --PRODUCT_CODE
                p_member_code , --MEMBER_CODE
                p_cic_code , --CIC_CODE
                p_id_no , --ID_NO
                p_tax_code , --TAX_CODE
                p_username_request , --USERNAME_REQUEST
                V_BRANCH , --BRANCH_CODE
                p_created_date , --CREATED_DATE
                p_requested_date , --REQUESTED_DATE
                p_request_data , --REQUEST_DATA
                p_err_code , --ERR_CODE
                trim(p_err_msg ||' '|| V_ERR_MSG) , --ERR_MSG
                nvl(p_address ,'N/A') , --ADDRESS
                p_register_no , --REGISTER_NO
                p_note , --NOTE
                p_customer_name , --CUSTOMER_NAME
                p_customer_code , --CUSTOMER_CODE
                p_response_date , --RESPONSE_DATE
                p_email , --EMAIL
                p_last_version , --LAST_VERSION
                p_flag , --FLAG
                case when p_msg_id in ('null','undefined') then '' else p_msg_id end , --MSG_ID
                p_application_id,  --APPLICATION_ID
                nvl(p_maker,p_user),
                case when p_task_id is not null then 'LO' else '' end || p_task_id,
                p_encode_request,
                p_borrower , --BORROWER
                p_pcb_code , --PCB_CODE
                p_ccy , --CCY
                p_amount_fin_capital , --AMOUNT_FIN_CAPITAL
                p_total_instalment , --TOTAL_INSTALMENT
                p_credit_limit , --CREDIT_LIMIT
                p_gender , --GENDER
                p_dob , --DOB
                p_doc_type , --DOC_TYPE
                p_pay_periodicity , --PAY_PERIODICITY
                p_operation_type , --OPERATION_TYPE
                p_country_of_birth,  --COUNTRY_OF_BIRTH
                p_request_id ,
                p_frequent_contacts,
                p_phone_number ,
                P_USER,
                P_CLIENT_IP,
                P_USER_AGENT,
                'N',--14/4/2021 Thiet lap gia tri mac dinh N
                pkg_utility.removesignvietnamess(p_CIS_NO||','||p_REGISTER_NO||','||p_TAX_CODE||','||p_CIC_CODE||'.'||p_CUSTOMER_CODE||','||p_CUSTOMER_NAME||','||p_PRODUCT_CODE||','||nvl(p_maker,p_user)||','|| case when p_task_id is not null then 'LO' else '' end ||p_TASK_ID||','||p_Phone_Number||','||p_Id_No),  -- 4/5/2021 Them tinh nang tim kiem ko dau
                pkg_utility.removesignvietnamess(p_CIS_NO||','||p_REGISTER_NO||','||p_TAX_CODE||','||p_CIC_CODE||','||p_Id_No||','),  -- 4/5/2021 Them tinh nang tim kiem ko dau
                case when p_nam_tai_chinh in ('null','undefined') then '' else p_nam_tai_chinh end ,
                V_DEPARTMENT
                );

    --IF p_flag='1' THEN
      --??ng ký nh?n th𮧠bᯠemail
      SELECT NVL(MAX(CIS_NO),V_ID_CIS_REQUEST) INTO V_CIS_NO
      FROM CIS_REQUEST WHERE ID = V_ID_CIS_REQUEST;

      INSERT INTO CIS_REQUEST_EMAIL (ID, CIS_NO,CREATED_DATE,CREATED_USER,CLIENT_IP,USER_AGENT)
      VALUES (SEQ_CIS_REQUEST_EMAIL.NEXTVAL ,V_CIS_NO, SYSDATE, P_MAKER, P_CLIENT_IP, P_USER_AGENT);
    --END IF;    

    OPEN p_out FOR
        SELECT CIS_REQUEST.CUSTOMER_NAME, CIS_REQUEST.MSG_ID, CIS_REQUEST.APPLICATION_ID, CIS_REQUEST.REGISTER_NO, CIS_REQUEST.OPERATION_TYPE, CIS_REQUEST.PAY_PERIODICITY,
            CIS_REQUEST.DOC_TYPE, CIS_REQUEST.CUSTOMER_CODE, CIS_REQUEST.CCY, CIS_REQUEST.BORROWER, CIS_REQUEST.ERR_MSG, CIS_REQUEST.NOTE, CIS_REQUEST.ADDRESS,
            CIS_REQUEST.ID, CIS_REQUEST.MAKER, CIS_REQUEST.TASK_ID, CIS_REQUEST.EMAIL, CIS_REQUEST.PCB_CODE, CIS_REQUEST.COUNTRY_OF_BIRTH,
            CIS_REQUEST.GENDER, CIS_REQUEST.FLAG, CIS_REQUEST.LAST_VERSION, CIS_REQUEST.USERNAME_REQUEST, CIS_REQUEST.CIC_CODE, CIS_REQUEST.STATUS,
            CIS_REQUEST.TAX_CODE, CIS_REQUEST.ID_NO, CIS_REQUEST.PRODUCT_CODE, CIS_REQUEST.MEMBER_CODE, CIS_REQUEST.CIS_NO, CIS_REQUEST.CHANNEL,
            CIS_REQUEST.ERR_CODE, CIS_REQUEST.BRANCH_CODE, CIS_REQUEST.CUSTOMER_TYPE, CIS_REQUEST.REQUESTED_DATE, CIS_REQUEST.RESPONSE_DATE, 
            CIS_REQUEST.CREATED_DATE, CIS_REQUEST.AMOUNT_FIN_CAPITAL, CIS_REQUEST.TOTAL_INSTALMENT, CIS_REQUEST.CREDIT_LIMIT, CIS_REQUEST.DOB,CIS_REQUEST.FREQUENT_CONTACTS,CIS_REQUEST.PHONE_NUMBER,
            refStatus.REF_NAME_VN STATUS_STR, refDocType.REF_NAME_VN DOC_TYPE_STR, refCustomerType.REF_NAME_VN CUSTOMER_TYPE_STR,to_char(dob,'DD/MM/YYYY') dob_str,to_char(dob,'DD/MM/YYYY') dobstr
            ,refProduct.REF_NAME_VN PRODUCT_NAME, nam_tai_chinh
            ,DEPARTMENT
        FROM   CIS_REQUEST 
        left JOIN SYS_REFCODE refStatus ON CIS_REQUEST.STATUS = refStatus.REF_CODE AND refStatus.REF_GROUP = 'STATUS_REQUEST'
        left JOIN SYS_REFCODE refCustomerType ON CIS_REQUEST.CUSTOMER_TYPE = refCustomerType.REF_CODE AND refCustomerType.REF_GROUP = 'LOAI_KH'
        LEFT JOIN SYS_REFCODE refDocType ON CIS_REQUEST.DOC_TYPE = refDocType.REF_CODE AND refDocType.REF_GROUP = 'DOC_TYPE'
        LEFT JOIN SYS_REFCODE refProduct ON CIS_REQUEST.PRODUCT_CODE = refProduct.REF_CODE AND refProduct.REF_GROUP = 'LS_PRODUCT'
        WHERE  ID = V_ID_CIS_REQUEST;                             

    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END PR_CREATE_CIS_REQUEST;


    PROCEDURE PR_UPDATE_STATUS_CIS_REQUEST (
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_request_data CIS_REQUEST.REQUEST_DATA%TYPE,
        p_msg_id CIS_REQUEST.MSG_ID%TYPE,
        p_err_code CIS_REQUEST.ERR_CODE%TYPE,
        p_err_msg CIS_REQUEST.ERR_MSG%TYPE,
        p_out    OUT SYS_REFCURSOR) 
    AS
        V_STATUS CIS_REQUEST.STATUS%TYPE;
        V_PRODUCT_CODE CIS_REQUEST.PRODUCT_CODE%TYPE;
        V_CUSTOMER_TYPE CIS_REQUEST.CUSTOMER_TYPE%TYPE;
        V_ID_NO CIS_REQUEST.ID_NO%TYPE;
        V_TAX_CODE CIS_REQUEST.TAX_CODE%TYPE;
        V_REGISTER_NO CIS_REQUEST.REGISTER_NO%TYPE;
        V_LAST_VERSION CIS_REQUEST.LAST_VERSION%TYPE;
        V_ERR_MSG varchar2(4000);
    BEGIN

   -- pkg_system_log.PR_LOG_EXCEPTION('PR_UPDATE_STATUS_CIS_REQUEST',p_cis_no||':'||p_status,'',p_request_data);
    V_ERR_MSG:=substr(p_err_msg,1,3900);

    SELECT a.STATUS,a.PRODUCT_CODE, a.CUSTOMER_TYPE, a.ID_NO, a.TAX_CODE, a.REGISTER_NO
    INTO V_STATUS,V_PRODUCT_CODE,V_CUSTOMER_TYPE,V_ID_NO,V_TAX_CODE,V_REGISTER_NO
    FROM CIS_REQUEST a 
    WHERE a.CIS_NO=p_cis_no;
    if(V_STATUS = 'TEMP' and p_status = 'NEW') then
        V_LAST_VERSION := '1';

        UPDATE CIS_REQUEST
        SET LAST_VERSION='0'
        where PRODUCT_CODE=V_PRODUCT_CODE
        and case when V_CUSTOMER_TYPE = '0' and V_ID_NO=ID_NO then 1
             when V_CUSTOMER_TYPE = '1' and (V_TAX_CODE=TAX_CODE or V_REGISTER_NO=REGISTER_NO) then 0
             else 0 end = 1;
    end if;

        UPDATE CIS_REQUEST 
            SET STATUS = case when p_err_msg like '%QNA_104%' then 'SENT' else p_status end, 
            REQUEST_DATA = nvl(p_request_data, REQUEST_DATA), 
            MSG_ID = nvl(p_msg_id, MSG_ID) ,          
            err_code = nvl(p_err_code, err_code) ,
            err_msg = nvl(p_err_msg, err_msg),
            LAST_VERSION = nvl(V_LAST_VERSION, LAST_VERSION),
            RESPONSE_DATE = CASE WHEN (p_status IN ('RECEIVED_ERROR', 'RECEIVED','ERROR_DATA')) THEN sysdate ELSE null END,
            REQUESTED_DATE = case when p_status='SENT' then SYSDATE else REQUESTED_DATE end
        --WHERE ','||p_cis_no||',' like '%,'||cis_no||',%';
        WHERE CIS_NO = p_cis_no;
        IF p_status IN ('RECEIVED_ERROR', 'RECEIVED','ERROR_DATA') THEN
            PKG_SYS_EMAIL.PR_SEND_EMAIL_RESPONSE (  P_CIS_NO => P_CIS_NO) ;  
        END IF;
    OPEN p_out FOR
        SELECT CIS_REQUEST.CUSTOMER_NAME, CIS_REQUEST.MSG_ID, CIS_REQUEST.APPLICATION_ID, CIS_REQUEST.REGISTER_NO, CIS_REQUEST.OPERATION_TYPE, CIS_REQUEST.PAY_PERIODICITY,
            CIS_REQUEST.DOC_TYPE, CIS_REQUEST.CUSTOMER_CODE, CIS_REQUEST.CCY, CIS_REQUEST.BORROWER, CIS_REQUEST.ERR_MSG, CIS_REQUEST.NOTE, CIS_REQUEST.ADDRESS,
            CIS_REQUEST.ID, CIS_REQUEST.MAKER, CIS_REQUEST.TASK_ID, CIS_REQUEST.EMAIL, CIS_REQUEST.PCB_CODE, CIS_REQUEST.COUNTRY_OF_BIRTH,
            CIS_REQUEST.GENDER, CIS_REQUEST.FLAG, CIS_REQUEST.LAST_VERSION, CIS_REQUEST.USERNAME_REQUEST, CIS_REQUEST.CIC_CODE, CIS_REQUEST.STATUS,
            CIS_REQUEST.TAX_CODE, CIS_REQUEST.ID_NO, CIS_REQUEST.PRODUCT_CODE, CIS_REQUEST.MEMBER_CODE, CIS_REQUEST.CIS_NO, CIS_REQUEST.CHANNEL,
            CIS_REQUEST.ERR_CODE, CIS_REQUEST.BRANCH_CODE, CIS_REQUEST.CUSTOMER_TYPE, CIS_REQUEST.REQUESTED_DATE, CIS_REQUEST.RESPONSE_DATE, 
            CIS_REQUEST.CREATED_DATE, CIS_REQUEST.AMOUNT_FIN_CAPITAL, CIS_REQUEST.TOTAL_INSTALMENT, CIS_REQUEST.CREDIT_LIMIT, CIS_REQUEST.DOB,CIS_REQUEST.FREQUENT_CONTACTS,CIS_REQUEST.PHONE_NUMBER,
            refStatus.REF_NAME_VN STATUS_STR, refDocType.REF_NAME_VN DOC_TYPE_STR, refCustomerType.REF_NAME_VN CUSTOMER_TYPE_STR,to_char(dob,'DD/MM/YYYY') dob_str,to_char(dob,'DD/MM/YYYY') dobstr
            ,refProduct.REF_NAME_VN PRODUCT_NAME, nam_tai_chinh
        FROM   CIS_REQUEST 
        left JOIN SYS_REFCODE refStatus ON CIS_REQUEST.STATUS = refStatus.REF_CODE AND refStatus.REF_GROUP = 'STATUS_REQUEST'
        left JOIN SYS_REFCODE refCustomerType ON CIS_REQUEST.CUSTOMER_TYPE = refCustomerType.REF_CODE AND refCustomerType.REF_GROUP = 'LOAI_KH'
        LEFT JOIN SYS_REFCODE refDocType ON CIS_REQUEST.DOC_TYPE = refDocType.REF_CODE AND refDocType.REF_GROUP = 'DOC_TYPE'
        LEFT JOIN SYS_REFCODE refProduct ON CIS_REQUEST.PRODUCT_CODE = refProduct.REF_CODE AND refProduct.REF_GROUP = 'LS_PRODUCT'
        WHERE  CIS_NO = p_cis_no;                             

    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END PR_UPDATE_STATUS_CIS_REQUEST;

  PROCEDURE PR_GET_LIST_CIS_REQUEST (
        p_id_no CIS_REQUEST.ID_NO%TYPE,
        p_member_code CIS_REQUEST.MEMBER_CODE%TYPE,
        p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
        p_customer_name CIS_REQUEST.CUSTOMER_NAME%TYPE,--Dùng cho KEYWORD
        p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
        p_address CIS_REQUEST.ADDRESS%TYPE,
        p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
        p_cic_code CIS_REQUEST.CIC_CODE%TYPE,
        p_customer_code CIS_REQUEST.CUSTOMER_CODE%TYPE,
        p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_maker CIS_REQUEST.MAKER%TYPE,
        p_from_date CIS_REQUEST.REQUESTED_DATE%TYPE, -- FROM DATE seach  UI
        p_to_date CIS_REQUEST.REQUESTED_DATE%TYPE, -- TO DATE seach UI
        p_task_id CIS_REQUEST.TASK_ID%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_channel CIS_REQUEST.CHANNEL%TYPE,
        p_user varchar2,
        p_out    OUT SYS_REFCURSOR) AS
    v_from_date date;
    v_to_date date;
    V_GROUP_NAME VARCHAR2(1000);
    V_PRODUCT_LIST VARCHAR2(1000);
    V_KEYWORD VARCHAR2(1000);
    V_SEARCH_REQUEST_LIMIT INT;
   
   	V_DATE_BET_FROM_TO INT;--NCB_CIC_PCB_2023_PM-26
    BEGIN
          SELECT ','|| listagg(','||NVL(GROUP_NAME,'')||',',', ') within group(order by GROUP_NAME) ||','
          INTO V_GROUP_NAME
          FROM SYS_USER A
          WHERE A.USER_NAME = P_USER;

          SELECT ','|| listagg(','||NVL(PAR2,'')||',',', ') within group(order by PAR2) ||',' INTO  V_PRODUCT_LIST
          FROM SYS_GROUPS A
          WHERE V_GROUP_NAME LIKE '%,'|| A.GROUP_NAME ||',%';

          V_KEYWORD:=pkg_utility.removesignvietnamess(p_customer_name);
          
          SELECT nvl(MAX(PAR1),0) INTO V_SEARCH_REQUEST_LIMIT
          FROM SYS_REFCODE
          WHERE REF_CODE='SEARCH_REQUEST_LIMIT';

    --v_from_date:=trunc(nvl(p_from_date,add_months(sysdate,-10)));
    --v_to_date:=trunc(nvl(p_to_date,sysdate));
    -- SHB Search theo ?i?u ki?n t?ng tham s?
    /*
    OPEN p_out FOR
        SELECT *
        FROM   CIS_REQUEST
        WHERE (p_id_no IS NULL OR ID_NO = p_id_no) 
              AND (p_member_code IS NULL OR MEMBER_CODE = p_member_code)
              AND (p_register_no IS NULL OR REGISTER_NO = p_register_no) 
              AND (p_customer_name IS NULL OR CUSTOMER_NAME = p_customer_name)
              AND (p_tax_code IS NULL OR TAX_CODE = p_tax_code)
              AND (p_address IS NULL OR ADDRESS like '%'||p_address||'%')
              AND (p_customer_type IS NULL OR CUSTOMER_TYPE = p_customer_type)
              AND (p_cic_code IS NULL OR CIC_CODE = p_cic_code)
              AND (p_customer_code IS NULL OR CUSTOMER_CODE = p_customer_code)
              AND (p_product_code IS NULL OR PRODUCT_CODE = p_product_code)
              AND (p_cis_no IS NULL OR CIS_NO = p_cis_no)
              AND (p_maker IS NULL OR MAKER = p_maker)
              AND (p_from_date IS NULL OR REQUESTED_DATE BETWEEN p_from_date AND p_to_date)
              AND (p_task_id IS NULL OR TASK_ID = p_task_id)
              ORDER BY CREATED_DATE DESC,REQUESTED_DATE DESC;
    */
    -- VIB Search theo KEYWORD
    -- FILTER THEO NGÀY
         --datnd15
    IF V_SEARCH_REQUEST_LIMIT is  null 
        THEN
             v_from_date := null;
             v_to_date := null;
    ELSE
        if p_from_date is null or p_from_date < (sysdate-V_SEARCH_REQUEST_LIMIT)
           then
           v_from_date := sysdate-V_SEARCH_REQUEST_LIMIT;
        else 
            v_from_date:= p_from_date;
        end if; 
        
        if p_to_date is null or p_to_date < (sysdate-V_SEARCH_REQUEST_LIMIT)
         then
           v_to_date := sysdate;
         else 
            v_to_date:= p_to_date;
        end if;   
    end if;
--    ELSIF p_from_date is null and p_to_date is null
--        then v_from_date := sysdate-V_SEARCH_REQUEST_LIMIT;
--             v_to_date := sysdate;
--    ELSIF p_from_date is not null and p_to_date is null and (sysdate-V_SEARCH_REQUEST_LIMIT)>p_from_date
--        then v_from_date := sysdate-V_SEARCH_REQUEST_LIMIT;
--             v_to_date := sysdate;
--    ELSIF p_from_date is not null and p_to_date is null and (sysdate-V_SEARCH_REQUEST_LIMIT)<p_from_date
--        then v_from_date := p_from_date;
--             v_to_date := sysdate;
--    end if;
   
   

    OPEN p_out FOR
        SELECT CIS_REQUEST.CUSTOMER_NAME,
               CASE WHEN CIS_REQUEST.MSG_ID IS NULL THEN 'No' ELSE 'Yes' END MSG_ID,
               CIS_REQUEST.APPLICATION_ID,
               CIS_REQUEST.REGISTER_NO,
               CIS_REQUEST.OPERATION_TYPE,
               CIS_REQUEST.PAY_PERIODICITY,
               CIS_REQUEST.DOC_TYPE,
               nvl(CIS_REQUEST.CUSTOMER_CODE, '') CUSTOMER_CODE,
               CIS_REQUEST.CCY,
               CIS_REQUEST.BORROWER,
               CIS_REQUEST.ERR_MSG,
               CIS_REQUEST.NOTE,
               CIS_REQUEST.ADDRESS,
               CIS_REQUEST.ID,
               CIS_REQUEST.MAKER,
               CIS_REQUEST.TASK_ID,
               CIS_REQUEST.EMAIL,
               CIS_REQUEST.PCB_CODE,
               CIS_REQUEST.COUNTRY_OF_BIRTH,
               CIS_REQUEST.GENDER,
               case when exists(select * from cis_request_email xx where xx.cis_no=CIS_REQUEST.cis_no and xx.created_user=p_user) then '1' else '0' end FLAG,
               CIS_REQUEST.LAST_VERSION,
               CIS_REQUEST.USERNAME_REQUEST,
               CIS_REQUEST.CIC_CODE,
               CIS_REQUEST.STATUS,
               CIS_REQUEST.TAX_CODE,
               CIS_REQUEST.ID_NO,
               CIS_REQUEST.PRODUCT_CODE,
               CIS_REQUEST.MEMBER_CODE,
               CIS_REQUEST.CIS_NO,
               CIS_REQUEST.CHANNEL,
               CIS_REQUEST.ERR_CODE,
               CIS_REQUEST.BRANCH_CODE,
               CIS_REQUEST.CUSTOMER_TYPE,
               nvl(CIS_REQUEST.REQUESTED_DATE,CIS_REQUEST.CREATED_DATE) REQUESTED_DATE,
               CIS_REQUEST.RESPONSE_DATE,
               CIS_REQUEST.CREATED_DATE,
               CIS_REQUEST.AMOUNT_FIN_CAPITAL,
               CIS_REQUEST.TOTAL_INSTALMENT,
               CIS_REQUEST.CREDIT_LIMIT,
               CIS_REQUEST.DOB,
               CIS_REQUEST.FREQUENT_CONTACTS,
               CIS_REQUEST.PHONE_NUMBER,
               refStatus.REF_NAME_VN          STATUS_STR,
               refDocType.REF_NAME_VN         DOC_TYPE_STR,
               refCustomerType.REF_NAME_VN    CUSTOMER_TYPE_STR,
               NAM_TAI_CHINH
        FROM   CIS_REQUEST 
        left JOIN SYS_REFCODE refStatus ON CIS_REQUEST.STATUS = refStatus.REF_CODE AND refStatus.REF_GROUP = 'STATUS_REQUEST'
        left JOIN SYS_REFCODE refCustomerType ON CIS_REQUEST.CUSTOMER_TYPE = refCustomerType.REF_CODE AND refCustomerType.REF_GROUP = 'LOAI_KH'
        LEFT JOIN SYS_REFCODE refDocType ON CIS_REQUEST.DOC_TYPE = refDocType.REF_CODE AND refDocType.REF_GROUP = 'DOC_TYPE'
        WHERE ((V_KEYWORD is not null and p_id_no IS NULL AND CIS_REQUEST.KEYWORD like '%'||V_KEYWORD||'%')
              OR (V_KEYWORD is not null and p_id_no IS NOT NULL AND CIS_REQUEST.KEYWORD_ID like '%,'||p_customer_name||',%'))
              AND (v_from_date is not null and v_to_date is not null and trunc(CIS_REQUEST.REQUESTED_DATE) between trunc(v_from_date) and trunc(v_to_date))
              AND (p_status IS NULL OR p_status = '' OR CIS_REQUEST.STATUS = p_status)
              AND (p_channel IS NULL OR CIS_REQUEST.CHANNEL = p_channel)
              AND (p_maker IS NULL OR MAKER = p_maker)
--               AND CREATED_DATE>SYSDATE-V_SEARCH_REQUEST_LIMIT
--              AND V_PRODUCT_LIST like '%,'|| CIS_REQUEST.PRODUCT_CODE ||',%'
        ORDER BY REQUESTED_DATE DESC;

        -- S? CMT/ H? chi?u, MST, S? ?KKD, M㠫hᣨ h஧ , M㠃IC, Tꮠkhᣨ h஧, Lo?i s?n ph?m, M㠬𬠎g??i h?i tin
        /*
              (p_id_no IS NULL OR ID_NO = p_id_no) 
              AND (p_member_code IS NULL OR MEMBER_CODE = p_member_code)
              AND (p_register_no IS NULL OR REGISTER_NO = p_register_no) 
              AND (p_customer_name IS NULL OR CUSTOMER_NAME = p_customer_name)
              AND (p_tax_code IS NULL OR TAX_CODE = p_tax_code)
              AND (p_address IS NULL OR ADDRESS like '%'||p_address||'%')
              AND (p_customer_type IS NULL OR CUSTOMER_TYPE = p_customer_type)
              AND (p_cic_code IS NULL OR CIC_CODE = p_cic_code)
              AND (p_customer_code IS NULL OR CUSTOMER_CODE = p_customer_code)
              AND (p_product_code IS NULL OR PRODUCT_CODE = p_product_code)
              AND (p_cis_no IS NULL OR CIS_NO = p_cis_no)
              AND (p_maker IS NULL OR MAKER = p_maker)
              AND (p_from_date IS NULL OR REQUESTED_DATE BETWEEN p_from_date AND p_to_date)
              AND (p_task_id IS NULL OR TASK_ID = p_task_id)
              ORDER BY CREATED_DATE DESC,REQUESTED_DATE DESC;
          */                         
    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END PR_GET_LIST_CIS_REQUEST;

  PROCEDURE PR_GET_CIS_REQUEST_INFO (
        p_cis_no CIS_REQUEST.ID_NO%TYPE,
        p_out    OUT SYS_REFCURSOR)
    AS
    BEGIN
    OPEN p_out FOR
        SELECT CIS_REQUEST.CUSTOMER_NAME, CIS_REQUEST.MSG_ID, CIS_REQUEST.APPLICATION_ID, CIS_REQUEST.REGISTER_NO, CIS_REQUEST.OPERATION_TYPE, CIS_REQUEST.PAY_PERIODICITY,
            CIS_REQUEST.DOC_TYPE, CIS_REQUEST.CUSTOMER_CODE, CIS_REQUEST.CCY, CIS_REQUEST.BORROWER, CIS_REQUEST.ERR_MSG, CIS_REQUEST.NOTE, CIS_REQUEST.ADDRESS,
            CIS_REQUEST.ID, CIS_REQUEST.MAKER, CIS_REQUEST.TASK_ID, CIS_REQUEST.EMAIL, CIS_REQUEST.PCB_CODE, CIS_REQUEST.COUNTRY_OF_BIRTH,
            CIS_REQUEST.GENDER, CIS_REQUEST.FLAG, CIS_REQUEST.LAST_VERSION, CIS_REQUEST.USERNAME_REQUEST, CIS_REQUEST.CIC_CODE, CIS_REQUEST.STATUS,
            CIS_REQUEST.TAX_CODE, CIS_REQUEST.ID_NO, CIS_REQUEST.PRODUCT_CODE, CIS_REQUEST.MEMBER_CODE, CIS_REQUEST.CIS_NO, CIS_REQUEST.CHANNEL,
            CIS_REQUEST.ERR_CODE, CIS_REQUEST.BRANCH_CODE, CIS_REQUEST.CUSTOMER_TYPE, CIS_REQUEST.REQUESTED_DATE, CIS_REQUEST.RESPONSE_DATE, 
            CIS_REQUEST.CREATED_DATE, CIS_REQUEST.AMOUNT_FIN_CAPITAL, CIS_REQUEST.TOTAL_INSTALMENT, CIS_REQUEST.CREDIT_LIMIT, CIS_REQUEST.DOB,CIS_REQUEST.FREQUENT_CONTACTS,CIS_REQUEST.PHONE_NUMBER,
            refStatus.REF_NAME_VN STATUS_STR, refDocType.REF_NAME_VN DOC_TYPE_STR, refCustomerType.REF_NAME_VN CUSTOMER_TYPE_STR,to_char(dob,'DD/MM/YYYY') dob_str,to_char(dob,'DD/MM/YYYY') dobstr
        FROM   CIS_REQUEST 
        JOIN SYS_REFCODE refStatus ON CIS_REQUEST.STATUS = refStatus.REF_CODE AND refStatus.REF_GROUP = 'STATUS_REQUEST'
        JOIN SYS_REFCODE refCustomerType ON CIS_REQUEST.CUSTOMER_TYPE = refCustomerType.REF_CODE AND refCustomerType.REF_GROUP = 'LOAI_KH'
        LEFT JOIN SYS_REFCODE refDocType ON CIS_REQUEST.DOC_TYPE = refDocType.REF_CODE AND refDocType.REF_GROUP = 'DOC_TYPE'
        WHERE  CIS_NO = p_cis_no;

    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END PR_GET_CIS_REQUEST_INFO;

--Ki?m tra t󺀠h?p l? b?n tin c?a kꮨ CIC
/*
PROCEDURE PR_CHECK_REQUEST_INFO_CIC (
      p_id_no CIS_REQUEST.ID_NO%TYPE,
      p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
      p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
      p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
      p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
      p_out    OUT SYS_REFCURSOR)
IS
    V_TOTAL_WAITING NUMBER;
    V_TOTAL_POSIABLE NUMBER;
    V_TOTAL_ACTIVE NUMBER;
    V_TOTAL_FRAUD NUMBER;
    V_TOTAL_BLACK_LIST NUMBER;
    V_CONFIG_7 NUMBER;
    V_CONFIG_30 NUMBER;
    v_errors NVARCHAR2 (4000);
    v_flag NUMBER;
BEGIN


    select nvl(max(par1),7) into V_CONFIG_7
    from sys_refcode a where a.ref_code='SO_NGAY_HIEU_LUC_L1';
    select nvl(max(par1),30) into V_CONFIG_30
    from sys_refcode a where a.ref_code='SO_NGAY_HIEU_LUC_L2';

    select sum(case when CIS_REQUEST_STATUS='WAITING' then 1 else 0 end ) WAITING_
           ,sum(case when CIS_REQUEST_STATUS='POSIABLE' then 1 else 0 end ) POSIABLE_
           ,sum(case when CIS_REQUEST_STATUS='ACTIVE' then 1 else 0 end ) ACTIVE_
    into V_TOTAL_WAITING, V_TOTAL_POSIABLE, V_TOTAL_ACTIVE
    from (select case when a.status in ('NEW','SENDED','WAITING','SENDING') then 'WAITING'
                      when trunc(nvl(RESPONSE_DATE,sysdate))>=trunc(sysdate)-V_CONFIG_7 then 'ACTIVE' 
                      when trunc(nvl(RESPONSE_DATE,sysdate))>=trunc(sysdate)-V_CONFIG_30 then 'POSIABLE' 
                      else 'INACTIVE' end CIS_REQUEST_STATUS,
                 a."ID",a."CIS_NO",a."CHANNEL",a."CUSTOMER_TYPE",a."STATUS",a."PRODUCT_CODE",a."MEMBER_CODE",
                 a."CIC_CODE",a."ID_NO",a."TAX_CODE",a."USERNAME_REQUEST",a."BRANCH_CODE",a."CREATED_DATE",
                 a."REQUESTED_DATE",a."REQUEST_DATA",a."ERR_CODE",a."ERR_MSG",a."ADDRESS",a."REGISTER_NO",
                 a."NOTE",a."CUSTOMER_NAME",a."CUSTOMER_CODE",a."RESPONSE_DATE",a."EMAIL",a."LAST_VERSION"
          from CIS_REQUEST a
          where last_version='1' and trunc(nvl(RESPONSE_DATE,sysdate)) >= trunc(sysdate)-V_CONFIG_30) A
    where CUSTOMER_TYPE = p_customer_type and PRODUCT_CODE = ''||p_product_code||''
      and case when p_customer_type = '0' and ID_NO = p_id_no then 1 
           when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no) then 1 
           else 0 end = 1;

    select count(*)
    into V_TOTAL_FRAUD
    from CIS_FRAUDULENCE_CUSTOMER
    where FRAUD_TYPE = 'CUS_FRAUD' and STATUS = '1' --Active
      and case when p_customer_type = '0' and ID_LEGAL_PERSONAL = p_id_no then 1
           when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_CODE = p_register_no) then 1
           else 0 end = 1;

    select count(*)
    into V_TOTAL_BLACK_LIST
    from CIS_FRAUDULENCE_CUSTOMER
    where FRAUD_TYPE = 'CUS_BLACK_LIST' and STATUS = '1' --Active
      and case when p_customer_type = '0' and ID_LEGAL_PERSONAL = p_id_no then 1
           when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_CODE = p_register_no) then 1
           else 0 end = 1;
    v_flag := 0;
    if(V_TOTAL_WAITING > 0) then
        v_errors := 'CIS001';
        v_flag := 1;
    end if;
    if(V_TOTAL_ACTIVE > 0) then
        v_errors := v_errors || ',CIS002';
        if (v_flag = 0) then
            v_flag := 2;
        end if;
    end if;
    if(V_TOTAL_POSIABLE > 0) then
       v_errors := v_errors || ',CIS003';
    end if;

    if(V_TOTAL_FRAUD > 0) then
       v_errors := v_errors || ',CIS004';
    end if;
    if(V_TOTAL_BLACK_LIST > 0) then
       v_errors := v_errors || ',CIS005';
    end if;

    OPEN p_out FOR
        SELECT err.errors, nvl(sysRef.REF_NAME_VN, errors) as errors_mess, v_flag as FLAG -- '1' kh𮧠???c ph鰠h?i b?n tin, '0' kh𮧠qua b??c duy?t,'2' B?n tin b?t bu?c qua b??c duy?t
        FROM (select regexp_substr(v_errors,'[^,]+', 1, level) errors from dual
                    connect by regexp_substr(v_errors, '[^,]+', 1, level) is not null) err
        LEFT JOIN SYS_REFCODE sysRef on err.errors = sysRef.REF_CODE and sysRef.REF_GROUP = 'CIS_MESSAGE'
        where err.errors is not null;


END;
*/
FUNCTION PR_CHECK_BLACK_LIST ( p_id_no varchar2) RETURN VARCHAR2
IS
    V_RETURN VARCHAR2(200);
BEGIN

  SELECT MAX(CUSTOMER_NAME) INTO V_RETURN
  FROM CIS_FRAUDULENCE_CUSTOMER A 
  WHERE STATUS='1' AND (ID_LEGAL_PERSONAL=P_ID_NO or A.TAX_CODE=P_ID_NO or A.REGISTER_CODE=P_ID_NO );

RETURN CASE WHEN V_RETURN IS NULL THEN NULL ELSE 'WARNING3' END;

END;
/*
Ki?m tra t쮨 tr?ng d? li?u theo matrix c?a kꮨ PCB
*/
FUNCTION PR_STATUS_MATRIX_PCB( p_product_code  varchar2,
                                      p_id_no  varchar2,
                                      p_doc_type  varchar2,
                                      P_register_no varchar2 ) RETURN VARCHAR2
IS
    V_TOTAL_WARNING1 NUMBER;
    V_TOTAL_WARNING2 NUMBER;
    V_TOTAL_ACCEPT NUMBER; 

    V_TOTAL_FRAUD NUMBER;
    V_TOTAL_BLACK_LIST NUMBER;

    V_PCB_NUMBER_OF_DAYS NUMBER;
    V_PCB_DATA_VALIDATION_DAY NUMBER; 
    v_EXISTS_RECORD NUMBER;
    V_STATUS VARCHAR2(100);
    V_BLACK_LIST VARCHAR2(100);
BEGIN
/**/
V_BLACK_LIST := PCK_CIS_REQUEST.PR_CHECK_BLACK_LIST(p_id_no);
/*IF V_BLACK_LIST IS NOT NULL THEN
  V_BLACK_LIST := V_BLACK_LIST;
END IF;
*/  

select nvl(max(par1),7) into V_PCB_NUMBER_OF_DAYS
from sys_refcode a where a.ref_code='PCB_NUMBER_OF_DAYS';
select nvl(max(par1),15) into V_PCB_DATA_VALIDATION_DAY
from sys_refcode a where a.ref_code='PCB_DATA_VALIDATION_DAY';


SELECT SUM(CASE WHEN RESPONSE_STATUS='ACCEPT' THEN 1 ELSE 0 END) TOTAL_ACCEPT
       ,SUM(CASE WHEN RESPONSE_STATUS='WARNING1' THEN 1 ELSE 0 END) TOTAL_WARNING1
       ,SUM(CASE WHEN RESPONSE_STATUS='WARNING2' THEN 1 ELSE 0 END) TOTAL_WARNING2
       ,COUNT(9) EXISTS_RECORD
INTO V_TOTAL_ACCEPT, V_TOTAL_WARNING1,V_TOTAL_WARNING2, V_EXISTS_RECORD
FROM (
      SELECT CASE WHEN V_A>0 THEN CASE WHEN CONDITION_2 = '0' THEN 'ACCEPT'
                                       ELSE CASE WHEN V_C <= V_PCB_DATA_VALIDATION_DAY THEN 'ACCEPT'
                                                 ELSE CASE WHEN V_D >= V_PCB_NUMBER_OF_DAYS THEN 'ACCEPT' 
                                                           ELSE 'WARNING2' 
                                                      END 
                                            END
                                   END
                   ELSE CASE WHEN V_B >= V_PCB_NUMBER_OF_DAYS THEN 'ACCEPT' ELSE 'WARNING1' END
              END RESPONSE_STATUS 
      FROM (
        SELECT TO_NUMBER(TO_CHAR(SYSDATE,'DD')) HT
               ,TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')) GN
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-V_PCB_DATA_VALIDATION_DAY V_A
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')) V_B
               ,GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_PCB_DATA_VALIDATION_DAY) V_C
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_PCB_DATA_VALIDATION_DAY) V_D
               ,CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,'MM'))=TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'MM')) THEN '1' ELSE '0' END CONDITION_2

        FROM CIS_REQUEST A
        WHERE CHANNEL='PCB'  
              AND A.STATUS='RECEIVED' --AND A.LAST_VERSION='1' 
              --AND A.PRODUCT_CODE=P_PRODUCT_CODE
              AND (A.ID_NO=P_ID_NO OR (A.DOC_TYPE=P_DOC_TYPE AND REGISTER_NO=P_REGISTER_NO))
      ) B
); 

SELECT CASE WHEN v_EXISTS_RECORD=0 and V_BLACK_LIST is null THEN 'ACCEPT' ELSE 
            CASE WHEN V_TOTAL_WARNING1>0 THEN 'WARNING1' WHEN V_TOTAL_WARNING2>0 THEN 'WARNING2' ELSE (CASE WHEN V_BLACK_LIST is null THEN 'ACCEPT' ELSE '' END) END 
       END
INTO V_STATUS FROM DUAL;

RETURN V_STATUS || V_BLACK_LIST;
END;

/*
Ki?m tra t쮨 tr?ng d? li?u theo matrix c?a kꮨ CIC
*/
FUNCTION PR_STATUS_MATRIX_CIC(p_id_no CIS_REQUEST.ID_NO%TYPE,
                              p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
                              p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
                              p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
                              p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
                              p_cic_code varchar2) RETURN VARCHAR2
IS
    V_TOTAL_WARNING1 NUMBER;
    V_TOTAL_WARNING2 NUMBER;
    V_TOTAL_ACCEPT NUMBER; 

    V_TOTAL_FRAUD NUMBER;
    V_TOTAL_BLACK_LIST NUMBER;

    V_CIC_NUMBER_OF_DAYS NUMBER;
    V_CIC_DATA_VALIDATION_DAY NUMBER; 
    v_EXISTS_RECORD NUMBER;
    V_STATUS VARCHAR2(100);
    V_BLACK_LIST VARCHAR2(100);
    V_CIS_NO VARCHAR2(50);
BEGIN
/**/
V_BLACK_LIST := PCK_CIS_REQUEST.PR_CHECK_BLACK_LIST(case when p_id_no is null then p_tax_code else p_id_no end);
/*IF V_BLACK_LIST IS NOT NULL THEN
  V_BLACK_LIST := V_BLACK_LIST;
END IF;
*/  
-- Khi s?a PACK n๠c?n update thꭠ? PCK_CIS_OTHER_REQUEST.PR_STATUS_MATRIX_CIC
select nvl(max(par1),7) into V_CIC_NUMBER_OF_DAYS
from sys_refcode a where a.ref_code='CIC_NUMBER_OF_DAYS';
select nvl(max(par1),15) into V_CIC_DATA_VALIDATION_DAY
from sys_refcode a where a.ref_code='CIC_DATA_VALIDATION_DAY';

commit;
IF p_cic_code IS NOT NULL THEN
    SELECT MAX(CIS_NO) INTO V_CIS_NO
    FROM CIS_REQUEST A
    WHERE CHANNEL='CIC' and PRODUCT_CODE = p_product_code
          --AND CUSTOMER_TYPE = p_customer_type
          AND p_cic_code=a.cic_code
          AND A.STATUS IN ('SENDED','SENT','WAITING','NEW') ;

--10/5/2021 - CUONGNH2 - Dieu chinh cach thu truy van
INSERT INTO CIS_REQUEST_CHECK_MATRIX_TMP(HT, GN, V_A, V_B, V_C, V_D, CONDITION_2,CONDITION_3)
SELECT * FROM (
SELECT TO_NUMBER(TO_CHAR(SYSDATE,'DD')) HT
               ,TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')) GN
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-V_CIC_DATA_VALIDATION_DAY V_A
               ,CAST((SYSDATE - CAST(A.RESPONSE_DATE AS DATE)) AS INT) V_B
               ,GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_CIC_DATA_VALIDATION_DAY) V_C
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_CIC_DATA_VALIDATION_DAY) V_D
               ,CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,'MM'))=TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'MM')) THEN '1' ELSE '0' END CONDITION_2
               ,CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,'YYYY'))=TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'YYYY')) THEN '1' ELSE '0' END CONDITION_3
        FROM CIS_REQUEST A
        WHERE CHANNEL='CIC' 
              --AND CUSTOMER_TYPE = p_customer_type 
              and PRODUCT_CODE = p_product_code
              AND p_cic_code=a.cic_code
              AND A.STATUS='RECEIVED' AND A.LAST_VERSION='1'
        ORDER BY CREATED_DATE DESC
              )
WHERE ROWNUM=1;

END IF;
IF V_CIS_NO IS NOT NULL THEN
  RETURN 'WAITING:'||V_CIS_NO;
END IF;

IF p_customer_type = '2' THEN
    SELECT MAX(CIS_NO) INTO V_CIS_NO
    FROM CIS_REQUEST A
    WHERE CHANNEL='CIC' and PRODUCT_CODE = p_product_code
          AND CUSTOMER_TYPE = p_customer_type
          AND ID_NO = p_id_no
          AND A.STATUS IN ('SENDED','SENT','WAITING','NEW');

--10/5/2021 - CUONGNH2 - Dieu chinh cach thu truy van
INSERT INTO CIS_REQUEST_CHECK_MATRIX_TMP(HT, GN, V_A, V_B, V_C, V_D, CONDITION_2, CONDITION_3)
SELECT * FROM (
SELECT TO_NUMBER(TO_CHAR(SYSDATE,'DD')) HT
               ,TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')) GN
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-V_CIC_DATA_VALIDATION_DAY V_A
               ,CAST((SYSDATE - CAST(A.RESPONSE_DATE AS DATE)) AS INT) V_B
               ,GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_CIC_DATA_VALIDATION_DAY) V_C
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_CIC_DATA_VALIDATION_DAY) V_D
               ,CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,'MM'))=TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'MM')) THEN '1' ELSE '0' END CONDITION_2
               ,CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,'YYYY'))=TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'YYYY')) THEN '1' ELSE '0' END CONDITION_3
        FROM CIS_REQUEST A
        WHERE CHANNEL='CIC' AND CUSTOMER_TYPE = p_customer_type and PRODUCT_CODE = p_product_code
              AND ID_NO = p_id_no
              AND A.STATUS='RECEIVED' AND A.LAST_VERSION='1'
        ORDER BY CREATED_DATE DESC
              )
WHERE ROWNUM=1;
END IF;

IF V_CIS_NO IS NOT NULL THEN
  RETURN 'WAITING:'||V_CIS_NO;
END IF;

IF p_customer_type = '1' THEN
    SELECT MAX(CIS_NO) INTO V_CIS_NO
    FROM CIS_REQUEST A
    WHERE CHANNEL='CIC' and PRODUCT_CODE = p_product_code
          AND CUSTOMER_TYPE = p_customer_type
          AND (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no)
          AND A.STATUS IN ('SENDED','SENT','WAITING','NEW');

--10/5/2021 - CUONGNH2 - Dieu chinh cach thu truy van
INSERT INTO CIS_REQUEST_CHECK_MATRIX_TMP(HT, GN, V_A, V_B, V_C, V_D, CONDITION_2, CONDITION_3)
SELECT * FROM (
SELECT TO_NUMBER(TO_CHAR(SYSDATE,'DD')) HT
               ,TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')) GN
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-V_CIC_DATA_VALIDATION_DAY V_A
               ,CAST((SYSDATE - CAST(A.RESPONSE_DATE AS DATE)) AS INT) V_B
               ,GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_CIC_DATA_VALIDATION_DAY) V_C
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_CIC_DATA_VALIDATION_DAY) V_D
               ,CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,'MM'))=TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'MM')) THEN '1' ELSE '0' END CONDITION_2
               ,CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,'YYYY'))=TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'YYYY')) THEN '1' ELSE '0' END CONDITION_3
        FROM CIS_REQUEST A
        WHERE CHANNEL='CIC' AND CUSTOMER_TYPE = p_customer_type and PRODUCT_CODE = p_product_code
              AND (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no)
              AND A.STATUS='RECEIVED' AND A.LAST_VERSION='1'
        ORDER BY CREATED_DATE DESC
              )
WHERE ROWNUM=1;
END IF;
--
--SELECT MAX(CIS_NO) INTO V_CIS_NO
--FROM CIS_REQUEST A
--WHERE CHANNEL='CIC' and PRODUCT_CODE = p_product_code
--      AND CUSTOMER_TYPE = p_customer_type
--      AND ((case when p_customer_type = '2' and ID_NO = p_id_no then 1 
--               when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no) then 1 
--               else 0 end = 1) or p_cic_code=a.cic_code)
--      AND A.STATUS IN ('SENDED','SENT','WAITING','NEW')
--      --AND A.LAST_VERSION='1'
--      ;

IF V_CIS_NO IS NOT NULL THEN
  RETURN 'WAITING:'||V_CIS_NO;
END IF;


              

SELECT SUM(CASE WHEN RESPONSE_STATUS='ACCEPT' THEN 1 ELSE 0 END) TOTAL_ACCEPT
       ,SUM(CASE WHEN RESPONSE_STATUS='WARNING1' THEN 1 ELSE 0 END) TOTAL_WARNING1
       ,SUM(CASE WHEN RESPONSE_STATUS='WARNING2' THEN 1 ELSE 0 END) TOTAL_WARNING2
       ,COUNT(9) EXISTS_RECORD
INTO V_TOTAL_ACCEPT, V_TOTAL_WARNING1,V_TOTAL_WARNING2, V_EXISTS_RECORD
FROM (
	 SELECT CASE WHEN CONDITION_3 = '0' THEN 'ACCEPT' 
     ELSE CASE WHEN V_A>0 THEN CASE WHEN CONDITION_2 = '0' THEN 'ACCEPT'
                                       ELSE CASE WHEN V_C <= V_CIC_DATA_VALIDATION_DAY THEN 'ACCEPT'
                                                 ELSE CASE WHEN V_D >= V_CIC_NUMBER_OF_DAYS THEN 'ACCEPT' 
                                                           ELSE 'WARNING2' 
                                                      END 
                                            END
                                   END
                   ELSE CASE WHEN V_B >= V_CIC_NUMBER_OF_DAYS THEN 'ACCEPT' ELSE 'WARNING1' END
      END
              END RESPONSE_STATUS 
      FROM (
        SELECT HT, GN, V_A, V_B, V_C, V_D, CONDITION_2, CONDITION_3
        FROM CIS_REQUEST_CHECK_MATRIX_TMP A
         
      ) B
); 

SELECT CASE WHEN v_EXISTS_RECORD=0 and V_BLACK_LIST is null THEN 'ACCEPT' ELSE 
            CASE WHEN V_TOTAL_WARNING1>0 THEN 'WARNING1' WHEN V_TOTAL_WARNING2>0 THEN 'WARNING2' ELSE (CASE WHEN V_BLACK_LIST is null THEN 'ACCEPT' ELSE '' END) END 
       END
INTO V_STATUS FROM DUAL;

RETURN V_STATUS || V_BLACK_LIST;
END;
--Ki?m tra t󺀠h?p l? b?n tin c?a kꮨ TS
FUNCTION PR_STATUS_MATRIX_TS ( p_phone_number varchar2,
                                      p_product_code varchar2,
                                      p_id_no varchar2) RETURN varchar2
IS
    V_TOTAL_WARNING NUMBER;
    V_TOTAL_ACCEPT NUMBER; 
    V_CONFIG_30 NUMBER;
    v_EXISTS_RECORD NUMBER;
    v_errors NVARCHAR2 (4000);
    v_flag NUMBER;
    V_STATUS VARCHAR2 (40);
    V_BLACK_LIST VARCHAR2 (40);
BEGIN
V_BLACK_LIST := PCK_CIS_REQUEST.PR_CHECK_BLACK_LIST(p_id_no);
/*IF V_BLACK_LIST IS NOT NULL THEN
  RETURN V_BLACK_LIST;
END IF;*/

select nvl(max(par1),30) into V_CONFIG_30
from sys_refcode a where a.ref_code='TS_NUMBER_OF_DAYS';

select sum(case when CIS_REQUEST_STATUS='WARNING1' then 1 else 0 end ) WAITING_
       ,sum(case when CIS_REQUEST_STATUS='ACCEPT' then 1 else 0 end ) ACCEPT_ 
       ,COUNT(9)
into V_TOTAL_WARNING, V_TOTAL_ACCEPT , v_EXISTS_RECORD
from (select case when a.status in ('NEW','SENDED','SENT','WAITING','SENDING') then 'WARNING1'  
                  when trunc(nvl(RESPONSE_DATE,sysdate))>=trunc(sysdate)-V_CONFIG_30 then 'WARNING1' 
                  else 'ACCEPT' end CIS_REQUEST_STATUS,
             a."PRODUCT_CODE",  
             a."RESPONSE_DATE",a."LAST_VERSION", A.PHONE_NUMBER, A.CHANNEL
      from CIS_REQUEST A
      where last_version='1' and trunc(nvl(RESPONSE_DATE,sysdate)) >= trunc(sysdate)-V_CONFIG_30) B
where p_product_code LIKE '%'||B.PRODUCT_CODE||'%'
  and B.PHONE_NUMBER=p_phone_number
  and B.CHANNEL='TS';


/*    OPEN p_out FOR
    SELECT CASE WHEN V_TOTAL_WARNING>0 THEN 'WARNING' ELSE 'ACCEPT' END errors
           ,CASE WHEN V_TOTAL_WARNING>0 THEN V_TOTAL_WARNING ||' row(s)' ELSE '' END  errors_mess, '' FLAG
    FROM DUAL;*/

SELECT CASE WHEN v_EXISTS_RECORD=0 and V_BLACK_LIST IS NULL THEN 'ACCEPT' ELSE 
            CASE WHEN V_TOTAL_WARNING>0 THEN 'WARNING1' ELSE (CASE WHEN V_BLACK_LIST is null THEN 'ACCEPT' ELSE '' END) END 
       END
INTO V_STATUS FROM DUAL;

RETURN V_STATUS||V_BLACK_LIST;


END;

--Ki?m tra t󺀠h?p l? b?n tin c?a kꮨ PCB
PROCEDURE PR_CHECK_REQUEST_INFO_PCB ( p_product_code  varchar2,
                                      p_id_no  varchar2,
                                      p_doc_type  varchar2,
                                      P_register_no varchar2,
                                      p_out    OUT SYS_REFCURSOR)
IS

    V_PARAMETER NVARCHAR2 (4000); 
    V_MSGID VARCHAR2(100);
    V_STATUS VARCHAR2(100);

    V_STATUS_REQUEST VARCHAR2(100);
    V_CIS_NO VARCHAR2(100);
    V_MAKER VARCHAR2(100);
    V_W1 VARCHAR2(1000);
    V_W2 VARCHAR2(1000);
    V_W3 VARCHAR2(1000);
    V_W13 VARCHAR2(1000);
    V_W23 VARCHAR2(1000);
    V_NOTE VARCHAR2(1000);
    V_CIC_NUMBER_OF_DAYS VARCHAR2(100);
BEGIN
V_PARAMETER := 'channel:PCB,product_code:'|| p_product_code ||',id_no:'||p_id_no ||',doc_type:'||p_doc_type ||',register_no:'||P_register_no ;
V_STATUS := PCK_CIS_REQUEST.PR_STATUS_MATRIX_PCB(p_product_code, p_id_no, p_doc_type, P_register_no);

IF V_STATUS='WARNING1' OR V_STATUS='WARNING2' OR V_STATUS='WARNING3' OR V_STATUS='WARNING1WARNING3' OR V_STATUS='WARNING2WARNING3' THEN
   SELECT DBMS_RANDOM.STRING('A', 69) INTO V_MSGID FROM DUAL  ;

   INSERT INTO CIS_MSGID(ID, MSGID,CREATE_DATE,DESCRIPTION)
   VALUES (SEQ_CIS_MSGID.NEXTVAL,V_MSGID,SYSDATE,V_PARAMETER);
END IF;

SELECT MAX(CIS_NO) INTO V_CIS_NO
FROM CIS_REQUEST A
WHERE CHANNEL='PCB' --and PRODUCT_CODE = p_product_code
      --AND CUSTOMER_TYPE = p_customer_type
      --AND p_cic_code=a.cic_code
      AND (a.id_no=p_id_no OR a.register_no=P_register_no)
      AND A.STATUS IN ('SENDED','SENT','WAITING','NEW','RECEIVED') ;

SELECT MAX(STATUS)
    ,MAX('Ng๠h?i: '||TO_CHAR(NVL(A.REQUESTED_DATE,A.CREATED_DATE),'DD/MM/YY hh24:mi') ||' => Ng๠tr? l?i: '|| TO_CHAR(A.RESPONSE_DATE,'DD/MM/YY hh24:mi') || ' => M㠰hi?u ['|| V_CIS_NO ||']')  
INTO V_STATUS_REQUEST, V_NOTE
FROM CIS_REQUEST A 
WHERE CIS_NO=V_CIS_NO ;


    OPEN p_out FOR
    SELECT V_STATUS errors
           ,CASE WHEN V_STATUS='WARNING1' THEN 'Kết quả tra cứu gần đây của Khách hàng đang còn hiệu lực, anh/chị có chắc chắn muốn tra cứu lại không?' 
                 WHEN V_STATUS='WARNING2' THEN 'Kết quả tra cứu gần đây của Khách hàng đang còn hiệu lực, anh/chị có chắc chắn muốn tra cứu lại không?'  
                 WHEN V_STATUS='WARNING3' THEN 'khách hàng thuộc danh sách hạn chế, anh/chị có chắc chắn tiếp tục hỏi tin không?' 
                 WHEN V_STATUS='WARNING1WARNING3' THEN 'Khách hàng đang thuộc danh sách hạn chế đồng thời kết quả tra cứu gần đây đang còn hiệu lực, anh/chị có chắc chắn muốn tra cứu lại không ?'
                 WHEN V_STATUS='WARNING2WARNING3' THEN 'Khách hàng đang thuộc danh sách hạn chế đồng thời kết quả tra cứu gần đây đang còn hiệu lực, anh/chị có chắc chắn muốn tra cứu lại không ?'
                 WHEN V_STATUS='ACCEPT' THEN '' ELSE 'Khách hàng thuộc danh sách gian lận!' END errors_mess
           ,CASE WHEN V_STATUS='WARNING1' OR V_STATUS='WARNING2'  OR V_STATUS='WARNING3' OR V_STATUS='WARNING1WARNING3' OR V_STATUS='WARNING2WARNING3'  THEN V_MSGID ELSE '' END FLAG
           ,V_CIS_NO CIS_NO
           ,V_NOTE NOTE
    FROM DUAL;

END;

PROCEDURE PR_CHECK_REQUEST_INFO_CIC ( p_id_no CIS_REQUEST.ID_NO%TYPE,
                                      p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
                                      p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
                                      p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
                                      p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
                                      p_cic_code varchar2,
                                      p_out    OUT SYS_REFCURSOR)

IS

    V_PARAMETER NVARCHAR2 (4000); 
    V_MSGID VARCHAR2(100);
    V_STATUS VARCHAR2(100);
    V_STATUS_REQUEST VARCHAR2(100);
    V_CIS_NO VARCHAR2(100);
    V_MAKER VARCHAR2(100);
    V_W1 VARCHAR2(1000);
    V_W2 VARCHAR2(1000);
    V_W3 VARCHAR2(1000);
    V_W13 VARCHAR2(1000);
    V_W23 VARCHAR2(1000);
    V_NOTE VARCHAR2(1000);
    V_CIC_NUMBER_OF_DAYS VARCHAR2(100);
BEGIN

SELECT MAX(PAR1) INTO V_CIC_NUMBER_OF_DAYS
FROM SYS_REFCODE A WHERE A.REF_GROUP='SYSTEM' AND REF_CODE='CIC_NUMBER_OF_DAYS';

SELECT REPLACE(MAX(PAR1),'[CIC_NUMBER_OF_DAYS]',V_CIC_NUMBER_OF_DAYS) INTO V_W1
FROM SYS_REFCODE A WHERE A.REF_GROUP='ERROR_CODE' AND REF_CODE='W1';

SELECT REPLACE(MAX(PAR1),'[CIC_NUMBER_OF_DAYS]',V_CIC_NUMBER_OF_DAYS) INTO V_W2
FROM SYS_REFCODE A WHERE A.REF_GROUP='ERROR_CODE' AND REF_CODE='W2';

SELECT REPLACE(MAX(PAR1),'[CIC_NUMBER_OF_DAYS]',V_CIC_NUMBER_OF_DAYS) INTO V_W3
FROM SYS_REFCODE A WHERE A.REF_GROUP='ERROR_CODE' AND REF_CODE='W3';

SELECT REPLACE(MAX(PAR1),'[CIC_NUMBER_OF_DAYS]',V_CIC_NUMBER_OF_DAYS) INTO V_W13
FROM SYS_REFCODE A WHERE A.REF_GROUP='ERROR_CODE' AND REF_CODE='W13';

SELECT REPLACE(MAX(PAR1),'[CIC_NUMBER_OF_DAYS]',V_CIC_NUMBER_OF_DAYS) INTO V_W23
FROM SYS_REFCODE A WHERE A.REF_GROUP='ERROR_CODE' AND REF_CODE='W23';

V_STATUS := PCK_CIS_REQUEST.PR_STATUS_MATRIX_CIC(p_id_no, p_register_no, p_tax_code, p_customer_type, p_product_code, p_cic_code);
V_PARAMETER := 'channel:CIC,product_code:'|| p_product_code ||',id_no:'||p_id_no ||',tax_code:'||p_tax_code ||',register_no:'||P_register_no ||',customer_type:'||p_customer_type||',V_STATUS:'||V_STATUS||',cic code:'||p_cic_code ;

--V_STATUS := 'WARNING1';
IF V_STATUS LIKE 'WAITING%' THEN
    V_CIS_NO := REPLACE(V_STATUS,'WAITING:','');

    SELECT MAX(A.MAKER) MAKER INTO V_MAKER
    FROM CIS_REQUEST A
    WHERE CIS_NO=V_CIS_NO;

    OPEN p_out FOR
    SELECT V_STATUS errors
           ,'B?n tin ?ang ??i CIC ph?n h?i!' errors_mess
           ,'0' FLAG
           ,'WAITING' STATUS
           ,replace(V_STATUS,'WAITING:','')  CIS_NO
           ,(select max(xx.ref_name_vn) x from sys_refcode xx where ref_code=p_product_code and ref_group='LS_PRODUCT' ) product_name
           ,V_MAKER maker
           --,case when exists(select * from cis_request_email xx where xx.cis_no=V_CIS_NO ) then '0' else '0' end FLAG
    FROM DUAL;
    commit;
    RETURN;
END IF;

IF V_STATUS='WARNING1' OR V_STATUS='WARNING2' OR V_STATUS='WARNING3' OR V_STATUS='WARNING1WARNING3' OR V_STATUS='WARNING2WARNING3' THEN
   SELECT DBMS_RANDOM.STRING('A', 69) INTO V_MSGID FROM DUAL  ;

   INSERT INTO CIS_MSGID(ID, MSGID,CREATE_DATE,DESCRIPTION)
   VALUES (SEQ_CIS_MSGID.NEXTVAL,V_MSGID,SYSDATE,V_PARAMETER);
END IF;


IF p_cic_code IS NOT NULL THEN
    SELECT MAX(CIS_NO) INTO V_CIS_NO
    FROM CIS_REQUEST A
    WHERE CHANNEL='CIC' and PRODUCT_CODE = p_product_code
          --AND CUSTOMER_TYPE = p_customer_type
          AND p_cic_code=a.cic_code
          AND A.STATUS IN ('SENDED','SENT','WAITING','NEW','RECEIVED') ;
END IF;

IF p_customer_type = '2' AND V_CIS_NO IS NULL THEN
    SELECT MAX(CIS_NO) INTO V_CIS_NO
    FROM CIS_REQUEST A
    WHERE CHANNEL='CIC' and PRODUCT_CODE = p_product_code
          AND CUSTOMER_TYPE = p_customer_type
          AND ID_NO = p_id_no
          AND A.STATUS IN ('SENDED','SENT','WAITING','NEW','RECEIVED');
END IF;

IF p_customer_type = '1' AND V_CIS_NO IS NULL THEN
    SELECT MAX(CIS_NO) INTO V_CIS_NO
    FROM CIS_REQUEST A
    WHERE CHANNEL='CIC' and PRODUCT_CODE = p_product_code
          AND CUSTOMER_TYPE = p_customer_type
          AND (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no)
          AND A.STATUS IN ('SENDED','SENT','WAITING','NEW','RECEIVED');
END IF;
--
--SELECT MAX(CIS_NO) INTO V_CIS_NO
--FROM CIS_REQUEST A
--WHERE CHANNEL='CIC' AND CUSTOMER_TYPE = p_customer_type and PRODUCT_CODE = ''||p_product_code||''
--      AND ((case when p_customer_type = '2' and ID_NO = p_id_no then 1 
--               when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no) then 1 
--               else 0 end = 1) or p_cic_code=a.cic_code)
--      AND (A.STATUS='RECEIVED' OR A.STATUS='SENT'  OR A.STATUS='WAITING') AND A.LAST_VERSION='1';

--SELECT MAX(STATUS),MAX('Ng๠h?i: '||TO_CHAR(NVL(A.REQUESTED_DATE,A.CREATED_DATE),'DD/MM/YY hh24:mi') ||'<br />Ng๠tr? l?i: '|| TO_CHAR(A.RESPONSE_DATE,'DD/MM/YY hh24:mi'))  INTO V_STATUS_REQUEST, V_NOTE
--FROM CIS_REQUEST A WHERE CIS_NO=V_CIS_NO;
SELECT MAX(STATUS),MAX('Ngày hỏi: '||TO_CHAR(NVL(A.REQUESTED_DATE,A.CREATED_DATE),'DD/MM/YY hh24:mi') ||'<br />Ngày trả lời: '|| TO_CHAR(A.RESPONSE_DATE,'DD/MM/YY hh24:mi'))  INTO V_STATUS_REQUEST, V_NOTE
FROM CIS_REQUEST A WHERE CIS_NO=V_CIS_NO and   (SELECT MAX(NVL(A.REQUESTED_DATE,A.CREATED_DATE)) FROM CIS_REQUEST B WHERE  B.CIS_NO= V_CIS_NO) = NVL(A.REQUESTED_DATE,A.CREATED_DATE);


    OPEN p_out FOR
    SELECT V_STATUS errors
           ,CASE WHEN V_STATUS='WARNING1' THEN V_W1
                 WHEN V_STATUS='WARNING2' THEN V_W2  
                 WHEN V_STATUS='WARNING3' THEN V_W3
                 WHEN V_STATUS='WARNING1WARNING3' THEN V_W13
                 WHEN V_STATUS='WARNING2WARNING3' THEN V_W23
                 WHEN V_STATUS='ACCEPT' THEN '' ELSE 'Khách hàng thuộc danh sách gian lận!' END errors_mess
           ,CASE WHEN V_STATUS='WARNING1' OR V_STATUS='WARNING2'  OR V_STATUS='WARNING3' OR V_STATUS='WARNING1WARNING3' OR V_STATUS='WARNING2WARNING3'  THEN V_MSGID ELSE '' END FLAG
           ,V_CIS_NO CIS_NO
           ,V_STATUS_REQUEST STATUS
           ,V_NOTE NOTE
           ,(select max(ref_name_vn) from sys_refcode where ref_code=p_product_code and ref_group='LS_PRODUCT') PRODUCT_NAME
    FROM DUAL;

commit;
END;



--Ki?m tra t󺀠h?p l? b?n tin c?a kꮨ TS
PROCEDURE PR_CHECK_REQUEST_INFO_TS ( p_phone_number varchar2,
                                      p_product_code varchar2,
                                      p_id_no varchar2,
                                      p_out    OUT SYS_REFCURSOR)
IS
    V_PARAMETER NVARCHAR2 (4000); 
    V_MSGID VARCHAR2(100);
    V_STATUS VARCHAR2(100);
BEGIN


V_PARAMETER := 'channel:TS,product_code:'|| p_product_code ||',phone_number:'||p_phone_number||',p_id_no:'||p_id_no ;
V_STATUS := PCK_CIS_REQUEST.PR_STATUS_MATRIX_TS(p_phone_number, p_product_code, p_id_no);

IF V_STATUS='WARNING1' OR V_STATUS='WARNING3' OR V_STATUS='WARNING1WARNING3' OR V_STATUS='WARNING2WARNING3' THEN
   SELECT DBMS_RANDOM.STRING('A', 69) INTO V_MSGID FROM DUAL  ;

   INSERT INTO CIS_MSGID(ID, MSGID,CREATE_DATE,DESCRIPTION)
   VALUES (SEQ_CIS_MSGID.NEXTVAL,V_MSGID,SYSDATE,V_PARAMETER);
END IF;

    OPEN p_out FOR/*
    SELECT V_STATUS errors
           ,CASE WHEN V_STATUS='WARNING1' THEN 'C?nh bᯠkhi tra c?u khᣨ h஧! (WARNING 1)' 
                 WHEN V_STATUS='WARNING3' THEN 'Khᣨ h஧ thu?c danh sᣨ gian l?n! (WARNING 3)'
                 WHEN V_STATUS='ACCEPT' THEN '' 
                 ELSE 'Khᣨ h஧ thu?c danh sᣨ gian l?n!' 
            END errors_mess
           --,CASE WHEN V_STATUS='WARNING' THEN 'C?nh bᯠkhi tra c?u khᣨ h஧! (WARNING)' ELSE '' END errors_mess
           ,CASE WHEN V_STATUS='WARNING' THEN V_MSGID ELSE '' END FLAG
    FROM DUAL;*/
    SELECT V_STATUS errors
           ,CASE WHEN V_STATUS='WARNING1' THEN 'Kết quả tra cứu gần đây của Khách hàng đang còn hiệu lực, anh/chị có chắc chắn muốn tra cứu lại không?' 
                 WHEN V_STATUS='WARNING2' THEN 'Kết quả tra cứu gần đây của Khách hàng đang còn hiệu lực, anh/chị có chắc chắn muốn tra cứu lại không?'  
                 WHEN V_STATUS='WARNING3' THEN 'khách hàng thuộc danh sách hạn chế, anh/chị có chắc chắn tiếp tục hỏi tin không?' 
                 WHEN V_STATUS='WARNING1WARNING3' THEN 'Khách hàng đang thuộc danh sách hạn chế đồng thời kết quả tra cứu gần đây đang còn hiệu lực, anh/chị có chắc chắn muốn tra cứu lại không ?'
                 WHEN V_STATUS='WARNING2WARNING3' THEN 'Khách hàng đang thuộc danh sách hạn chế đồng thời kết quả tra cứu gần đây đang còn hiệu lực, anh/chị có chắc chắn muốn tra cứu lại không ?'
                 WHEN V_STATUS='ACCEPT' THEN '' ELSE 'Khách hàng thuộc danh sách gian lận!' END errors_mess
           ,CASE WHEN V_STATUS='WARNING1' OR V_STATUS='WARNING2'  OR V_STATUS='WARNING3' OR V_STATUS='WARNING1WARNING3' OR V_STATUS='WARNING2WARNING3'  THEN V_MSGID ELSE '' END FLAG
    FROM DUAL;

END;


--Ki?m tra t󺀠h?p l? b?n tin
PROCEDURE PR_CHECK_REQUEST_INFO (
      p_param1 varchar2,
      p_param2 varchar2,
      p_param3 varchar2,
      p_param4 varchar2,
      p_param5 varchar2,
      p_param6 varchar2,
      p_param7 varchar2,
      p_param8 varchar2,
      p_channel varchar2,
      p_user varchar2,
      p_client_ip varchar2,
      p_user_agent varchar2,
      p_out    OUT SYS_REFCURSOR)
IS
BEGIN
/*
OUTPUT: 
    - ERROR: 
           + WARNING/ACCEPT: Tr? v? 2 tr?ng thᩊ           + ERROR_CODE: M㠬?i c? th?
    - ERROR_MESS: N?u ERROR l࠭㠬?i NOT IN (WARNING/ACCEPT) th젳? c󠮿i dung l?i
    - FLAG: Chua s? d?ng
*/
IF p_channel='CIC' THEN
   PR_CHECK_REQUEST_INFO_CIC ( p_id_no => p_param1 ,
                              p_register_no => p_param2,
                              p_tax_code => p_param3,
                              p_customer_type => p_param4,
                              p_product_code => p_param5,
                              p_cic_code => p_param6,
                              p_out =>p_out);
END IF; 
IF p_channel='PCB' THEN
   PR_CHECK_REQUEST_INFO_PCB ( p_id_no => p_param1 ,
                              p_product_code => p_param2,
                              p_doc_type => p_param3,
                              P_register_no => p_param4, 
                              p_out =>p_out);
END IF;
IF p_channel='TS' THEN
   PR_CHECK_REQUEST_INFO_TS ( p_phone_number => p_param1 ,
                              p_product_code => p_param2,
                              p_id_no => p_param3,
                              p_out =>p_out);
END IF;      
commit;
END;

PROCEDURE PR_CHECK_BATCH_REQUEST_INFO ( p_param1 varchar2,
                                        p_param2 varchar2,
                                        p_param3 varchar2,
                                        p_param4 varchar2,
                                        p_param5 varchar2,
                                        p_param6 varchar2,
                                        p_param7 varchar2,
                                        p_param8 varchar2,
                                        p_channel varchar2,
                                        p_user varchar2,
                                        p_client_ip varchar2,
                                        p_user_agent varchar2,
                                        p_out    OUT SYS_REFCURSOR)
IS
V_MSGID nvarchar2(500);
V_PARAMETER nvarchar2(500);


V_ERROR VARCHAR2(500);
BEGIN

 IF p_channel='CIC' THEN
   PR_CHECK_REQUEST_INFO_CIC ( p_id_no => p_param1 ,
                              p_register_no => p_param2,
                              p_tax_code => p_param3,
                              p_customer_type => p_param4,
                              p_product_code => p_param5,
                              p_cic_code => p_param6,
                              p_out =>p_out);
END IF; 
IF p_channel='PCB' THEN
/*PR_CHECK_REQUEST_INFO_PCB ( p_id_no => p_param1 ,
                          p_product_code => p_param2,
                          p_doc_type => p_param3,
                          P_register_no => p_param4, 
                          p_out =>p_out);
*/
V_PARAMETER := 'channel:PCB,product_code:'|| p_param2 ||',id_no:'||p_param1 ||',doc_type:'||p_param3 ||',register_no:'||p_param4 ;
V_ERROR := PCK_CIS_REQUEST.PR_STATUS_MATRIX_PCB( 'PCB_CN', p_param1, p_param3, p_param4);

--IF V_ERROR='WARNING1' OR V_ERROR='WARNING2' THEN
IF V_ERROR='WARNING1' OR V_ERROR='WARNING2' OR V_ERROR='WARNING3' OR V_ERROR='WARNING1WARNING3' OR V_ERROR='WARNING2WARNING3' THEN
   SELECT DBMS_RANDOM.STRING('A', 69) INTO V_MSGID FROM DUAL  ;

   INSERT INTO CIS_MSGID(ID, MSGID,CREATE_DATE,DESCRIPTION)
   VALUES (SEQ_CIS_MSGID.NEXTVAL,V_MSGID,SYSDATE,V_PARAMETER);
END IF;

OPEN p_out FOR
SELECT a.*, err.errors, nvl(sysRef.REF_NAME_VN, errors) as errors_mess
,CASE WHEN V_ERROR='WARNING1' OR V_ERROR='WARNING2' OR V_ERROR='WARNING3' OR V_ERROR='WARNING1WARNING3' OR V_ERROR='WARNING2WARNING3'  THEN V_MSGID ELSE NULL END FLAG 
,B.REF_NAME_VN STATUS_STR
,C.REF_NAME_VN DOC_TYPE_STR
,D.REF_NAME_VN CUSTOMER_TYPE_STR
FROM (select regexp_substr(V_ERROR,'[^,]+', 1, level) errors from dual
            connect by regexp_substr(V_ERROR, '[^,]+', 1, level) is not null) err 
LEFT JOIN CIS_REQUEST a on 1=1
LEFT JOIN SYS_REFCODE sysRef on err.errors = sysRef.REF_CODE and sysRef.REF_GROUP = 'CIS_MESSAGE'
LEFT JOIN SYS_REFCODE B on A.STATUS = B.REF_CODE and B.REF_GROUP = 'STATUS_REQUEST'
LEFT JOIN SYS_REFCODE C on A.DOC_TYPE = C.REF_CODE and C.REF_GROUP = 'DOC_TYPE'
LEFT JOIN SYS_REFCODE D on A.CUSTOMER_TYPE = D.REF_CODE and D.REF_GROUP = 'LOAI_KH'
where CHANNEL='PCB'  
      AND A.STATUS='RECEIVED' AND A.LAST_VERSION='1' 
      AND A.PRODUCT_CODE='PCB_CN'
      AND (A.ID_NO=p_param1 OR (A.DOC_TYPE=p_param3 AND REGISTER_NO=p_param4));

/*    AND a.CUSTOMER_TYPE = p_customer_type 
    and case when p_customer_type = '0' and a.ID_NO = p_id_no then 1 
    when p_customer_type = '1' and (a.TAX_CODE = p_tax_code or a.REGISTER_NO = p_register_no) then 1 
    else 0 end = 1;*/

/*   PR_CHECK_REQUEST_INFO_PCB ( p_id_no => p_param1 ,
                              p_product_code => 'PCB_CN',
                              p_doc_type => p_param3,
                              P_register_no => p_param4, 
                              p_out =>p_out);
*/
END IF;
IF p_channel='TS' THEN
   PR_CHECK_REQUEST_INFO_TS ( p_phone_number => p_param1 ,
                              p_product_code => p_param2,
                              p_id_no => p_param3,
                              p_out =>p_out);
END IF; 

END PR_CHECK_BATCH_REQUEST_INFO;

PROCEDURE PR_GET_LOT_NO (
      p_user                         IN     VARCHAR2,
      p_client_ip                    IN     VARCHAR2,
      p_user_agent                   IN     VARCHAR2,
      p_out    OUT SYS_REFCURSOR)    AS
  BEGIN
  OPEN p_out FOR
      select 'LOT_'||TO_CHAR(SYSDATE,'DDMMYYYYHHMMSS') TASK_ID from Dual;

  EXCEPTION
      WHEN ZERO_DIVIDE
      THEN
          DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
END PR_GET_LOT_NO;

  PROCEDURE PR_CHECK_BATCH_REQUEST_SHB (
      p_id_no CIS_REQUEST.ID_NO%TYPE,
      p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
      p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
      p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
      p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
      p_channel CIS_REQUEST.CHANNEL%TYPE,
      p_out    OUT SYS_REFCURSOR)
  IS
      V_TOTAL_WAITING NUMBER;
      V_TOTAL_POSIABLE NUMBER;
      V_TOTAL_ACTIVE NUMBER;
      V_TOTAL_FRAUD NUMBER;
      V_TOTAL_BLACK_LIST NUMBER;
      V_CONFIG_20 NUMBER;
      v_errors NVARCHAR2 (4000);
      v_flag NUMBER;
  BEGIN

  select nvl(max(par1),30) into V_CONFIG_20
  from sys_refcode a where a.ref_code='SO_NGAY_HIEU_LUC_LO';

  select sum(case when CIS_REQUEST_STATUS='WAITING' then 1 else 0 end ) WAITING_
         ,sum(case when CIS_REQUEST_STATUS='POSIABLE' then 1 else 0 end ) POSIABLE_
         ,sum(case when CIS_REQUEST_STATUS='ACTIVE' then 1 else 0 end ) ACTIVE_
  into V_TOTAL_WAITING, V_TOTAL_POSIABLE, V_TOTAL_ACTIVE
  from (select case when a.status in ('NEW','SENDED','SENT','WAITING','SENDING') then 'WAITING'
                    when trunc(nvl(RESPONSE_DATE,sysdate))>=trunc(sysdate)-V_CONFIG_20 then 'ACTIVE' 
                    when trunc(nvl(RESPONSE_DATE,sysdate))>=trunc(sysdate)-(V_CONFIG_20+10) then 'POSIABLE' 
                    else 'INACTIVE' end CIS_REQUEST_STATUS,
               a."ID",a."CIS_NO",a."CHANNEL",a."CUSTOMER_TYPE",a."STATUS",a."PRODUCT_CODE",a."MEMBER_CODE",
               a."CIC_CODE",a."ID_NO",a."TAX_CODE",a."USERNAME_REQUEST",a."BRANCH_CODE",a."CREATED_DATE",
               a."REQUESTED_DATE",a."REQUEST_DATA",a."ERR_CODE",a."ERR_MSG",a."ADDRESS",a."REGISTER_NO",
               a."NOTE",a."CUSTOMER_NAME",a."CUSTOMER_CODE",a."RESPONSE_DATE",a."EMAIL",a."LAST_VERSION"
        from CIS_REQUEST a
        where last_version='1' and trunc(nvl(RESPONSE_DATE,sysdate)) >= trunc(sysdate)-(V_CONFIG_20+10)) A
  where CUSTOMER_TYPE = p_customer_type and PRODUCT_CODE = ''||p_product_code||''
    and case when p_customer_type = '2' and ID_NO = p_id_no then 1 
         when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no) then 1 
         else 0 end = 1;

  select count(*)
  into V_TOTAL_FRAUD
  from CIS_FRAUDULENCE_CUSTOMER
  where FRAUD_TYPE = 'CUS_FRAUD' and STATUS = '1' --Active
    and case when p_customer_type = '2' and ID_LEGAL_PERSONAL = p_id_no then 1
         when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_CODE = p_register_no) then 1
         else 0 end = 1;

  select count(*)
  into V_TOTAL_BLACK_LIST
  from CIS_FRAUDULENCE_CUSTOMER
  where FRAUD_TYPE = 'CUS_BLACK_LIST' and STATUS = '1' --Active
    and case when p_customer_type = '2' and ID_LEGAL_PERSONAL = p_id_no then 1
         when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_CODE = p_register_no) then 1
         else 0 end = 1;
  v_flag := 0;
  if(V_TOTAL_WAITING > 0) then
      v_errors := 'CIS001';
      v_flag := 1;
  end if;
  if(V_TOTAL_ACTIVE > 0) then
      v_errors := v_errors || ',CIS006';
      if (v_flag = 0) then
          v_flag := 1;
      end if;
  end if;
  if(V_TOTAL_POSIABLE > 0) then
     v_errors := v_errors || ',CIS003';
  end if;

  if(V_TOTAL_FRAUD > 0) then
     v_errors := v_errors || ',CIS004';
     if (v_flag = 0) then
          v_flag := 1;
      end if;
  end if;
  if(V_TOTAL_BLACK_LIST > 0) then
     v_errors := v_errors || ',CIS005';
     if (v_flag = 0) then
          v_flag := 1;
      end if;
  end if;

  OPEN p_out FOR
      SELECT a.*, err.errors, nvl(sysRef.REF_NAME_VN, errors) as errors_mess, v_flag as FLAG -- '1' kh𮧠???c ph鰠h?i b?n tin, '0' kh𮧠qua b??c duy?t,'2' B?n tin b?t bu?c qua b??c duy?t
      FROM (select regexp_substr(v_errors,'[^,]+', 1, level) errors from dual
                  connect by regexp_substr(v_errors, '[^,]+', 1, level) is not null) err 
      LEFT JOIN CIS_REQUEST a on 1=1
      LEFT JOIN SYS_REFCODE sysRef on err.errors = sysRef.REF_CODE and sysRef.REF_GROUP = 'CIS_MESSAGE'
      where err.errors is not null 
          AND a.CUSTOMER_TYPE = p_customer_type 
          and case when p_customer_type = '2' and a.ID_NO = p_id_no then 1 
          when p_customer_type = '1' and (a.TAX_CODE = p_tax_code or a.REGISTER_NO = p_register_no) then 1 
          else 0 end = 1;

END;

PROCEDURE PR_CHECK_REQUEST_INFO_SHB (
      p_id_no CIS_REQUEST.ID_NO%TYPE,
      p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
      p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
      p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
      p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
      p_channel CIS_REQUEST.CHANNEL%TYPE,
      p_out    OUT SYS_REFCURSOR)
  IS
      V_TOTAL_WAITING NUMBER;
      V_TOTAL_POSIABLE NUMBER;
      V_TOTAL_ACTIVE NUMBER;
      V_TOTAL_FRAUD NUMBER;
      V_TOTAL_BLACK_LIST NUMBER;
      V_CONFIG_7 NUMBER;
      V_CONFIG_30 NUMBER;
      v_errors NVARCHAR2 (4000);
      v_flag NUMBER;
  BEGIN

  select nvl(max(par1),7) into V_CONFIG_7
  from sys_refcode a where a.ref_code='SO_NGAY_HIEU_LUC_L1';
  select nvl(max(par1),30) into V_CONFIG_30
  from sys_refcode a where a.ref_code='SO_NGAY_HIEU_LUC_L2';

  select sum(case when CIS_REQUEST_STATUS='WAITING' then 1 else 0 end ) WAITING_
         ,sum(case when CIS_REQUEST_STATUS='POSIABLE' then 1 else 0 end ) POSIABLE_
         ,sum(case when CIS_REQUEST_STATUS='ACTIVE' then 1 else 0 end ) ACTIVE_
  into V_TOTAL_WAITING, V_TOTAL_POSIABLE, V_TOTAL_ACTIVE
  from (select case when a.status in ('NEW','SENDED','SENT','WAITING','SENDING') then 'WAITING'
                    when trunc(nvl(RESPONSE_DATE,sysdate))>=trunc(sysdate)-V_CONFIG_7 then 'ACTIVE' 
                    when trunc(nvl(RESPONSE_DATE,sysdate))>=trunc(sysdate)-V_CONFIG_30 then 'POSIABLE' 
                    else 'INACTIVE' end CIS_REQUEST_STATUS,
               a."ID",a."CIS_NO",a."CHANNEL",a."CUSTOMER_TYPE",a."STATUS",a."PRODUCT_CODE",a."MEMBER_CODE",
               a."CIC_CODE",a."ID_NO",a."TAX_CODE",a."USERNAME_REQUEST",a."BRANCH_CODE",a."CREATED_DATE",
               a."REQUESTED_DATE",a."REQUEST_DATA",a."ERR_CODE",a."ERR_MSG",a."ADDRESS",a."REGISTER_NO",
               a."NOTE",a."CUSTOMER_NAME",a."CUSTOMER_CODE",a."RESPONSE_DATE",a."EMAIL",a."LAST_VERSION"
        from CIS_REQUEST a
        where last_version='1' and trunc(nvl(RESPONSE_DATE,sysdate)) >= trunc(sysdate)-V_CONFIG_30) A
  where CUSTOMER_TYPE = p_customer_type and PRODUCT_CODE = ''||p_product_code||''
    and case when p_customer_type = '2' and ID_NO = p_id_no then 1 
         when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no) then 1 
         else 0 end = 1;

  select count(*)
  into V_TOTAL_FRAUD
  from CIS_FRAUDULENCE_CUSTOMER
  where FRAUD_TYPE = 'CUS_FRAUD' and STATUS = '1' --Active
    and case when p_customer_type = '2' and ID_LEGAL_PERSONAL = p_id_no then 1
         when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_CODE = p_register_no) then 1
         else 0 end = 1;

  select count(*)
  into V_TOTAL_BLACK_LIST
  from CIS_FRAUDULENCE_CUSTOMER
  where FRAUD_TYPE = 'CUS_BLACK_LIST' and STATUS = '1' --Active
    and case when p_customer_type = '2' and ID_LEGAL_PERSONAL = p_id_no then 1
         when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_CODE = p_register_no) then 1
         else 0 end = 1;
  v_flag := 0;
  if(V_TOTAL_WAITING > 0) then
      v_errors := 'CIS001';
      v_flag := 1;
  end if;
  if(V_TOTAL_ACTIVE > 0) then
      v_errors := v_errors || ',CIS002';
      if (v_flag = 0) then
          v_flag := 2;
      end if;
  end if;
  if(V_TOTAL_POSIABLE > 0) then
     v_errors := v_errors || ',CIS003';
  end if;

  if(V_TOTAL_FRAUD > 0) then
     v_errors := v_errors || ',CIS004';
  end if;
  if(V_TOTAL_BLACK_LIST > 0) then
     v_errors := v_errors || ',CIS005';
  end if;

  OPEN p_out FOR
      SELECT err.errors, nvl(sysRef.REF_NAME_VN, errors) as errors_mess, v_flag as FLAG -- '1' kh𮧠???c ph鰠h?i b?n tin, '0' kh𮧠qua b??c duy?t,'2' B?n tin b?t bu?c qua b??c duy?t
      FROM (select regexp_substr(v_errors,'[^,]+', 1, level) errors from dual
                  connect by regexp_substr(v_errors, '[^,]+', 1, level) is not null) err
      LEFT JOIN SYS_REFCODE sysRef on err.errors = sysRef.REF_CODE and sysRef.REF_GROUP = 'CIS_MESSAGE'
      where err.errors is not null;

END;

PROCEDURE PR_ADD_CIS_REQUEST_EMAIL (
    P_CIS_NO CIS_REQUEST.CIS_NO%TYPE,
    P_USER                         IN     VARCHAR2,
    P_CLIENT_IP                    IN     VARCHAR2,
    P_USER_AGENT                   IN     VARCHAR2,
    P_OUT    OUT SYS_REFCURSOR) IS
    V_ID_CIS_REQUEST_EMAIL VARCHAR2 (2000);
BEGIN
    SELECT NVL(MAX(ID),'0') INTO V_ID_CIS_REQUEST_EMAIL
    FROM CIS_REQUEST_EMAIL WHERE CIS_NO=P_CIS_NO AND CREATED_USER=P_USER;

    IF V_ID_CIS_REQUEST_EMAIL='0' THEN
      V_ID_CIS_REQUEST_EMAIL:= SEQ_CIS_REQUEST_EMAIL.NEXTVAL;
      INSERT INTO CIS_REQUEST_EMAIL(ID, CIS_NO, CREATED_USER,CLIENT_IP,USER_AGENT, CREATED_DATE) 
                            VALUES (V_ID_CIS_REQUEST_EMAIL,P_CIS_NO,P_USER,P_CLIENT_IP,P_USER_AGENT, SYSDATE);
    END IF;

 OPEN P_OUT FOR
  SELECT *
  FROM CIS_REQUEST_EMAIL
  WHERE  ID = V_ID_CIS_REQUEST_EMAIL;

END;


PROCEDURE PR_AUTO_REJECT_REQUEST  IS 
BEGIN

UPDATE CIS_REQUEST 
SET STATUS='REJECT'
WHERE STATUS IN ('SENT','SENDED','WAITING','SENT') 
      AND CREATED_DATE < SYSDATE-200;
COMMIT;           
END;

PROCEDURE PR_GET_LIST_CIS_SENT (
      P_STATUS VARCHAR2,
      P_CHANNEL                         IN     VARCHAR2,
      P_USER                    IN     VARCHAR2,
      P_OUT    OUT SYS_REFCURSOR) AS
BEGIN
  
    
  OPEN p_out FOR
  SELECT * FROM CIS_REQUEST
  WHERE CHANNEL=P_CHANNEL AND STATUS=P_STATUS;

--FIX Loi SENDDING - 7/4/2021
  --update CIS_REQUEST
  --set STATUS='SENDING'
  --WHERE CHANNEL=P_CHANNEL AND STATUS=P_STATUS;
END;

--FIX Loi SENDDING - 7/4/2021
PROCEDURE PR_GET_LIST_CIS_NEW (
      P_STATUS VARCHAR2,
      P_CHANNEL                         IN     VARCHAR2,
      P_USER                    IN     VARCHAR2,
      P_OUT    OUT SYS_REFCURSOR) AS
BEGIN
  
  update CIS_REQUEST
  set STATUS='NEW'
  WHERE CHANNEL=P_CHANNEL 
    AND STATUS='SENDING' 
    AND nvl(REQUESTED_DATE,created_date)+10/24/60<SYSDATE
    AND PRODUCT_CODE<>'S37H'
    AND CHANNEL='CIC'
    AND rownum<10;
    
  INSERT INTO CIS_REQUEST_ID_TEMPORARY (ID)
  SELECT ID FROM CIS_REQUEST
  WHERE CHANNEL=P_CHANNEL AND STATUS='NEW'
    AND PRODUCT_CODE<>'S37H'
    AND CHANNEL='CIC'
	AND rownum<10;

  OPEN p_out FOR SELECT * FROM CIS_REQUEST WHERE ID IN (SELECT ID FROM CIS_REQUEST_ID_TEMPORARY);
  
  update CIS_REQUEST
  set STATUS='SENDING', REQUESTED_DATE=SYSDATE
  WHERE ID IN (SELECT ID FROM CIS_REQUEST_ID_TEMPORARY);
  DELETE CIS_REQUEST_ID_TEMPORARY WHERE 1=1;
END;
END PCK_CIS_REQUEST;

/
--------------------------------------------------------
--  DDL for Package Body PCK_REPORT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_REPORT" AS
V_LIMIT_ROWS NUMBER:=1000;
V_BRANCH_PATH VARCHAR2(1000);
/*
CREATE: CUONGNH
DESCRIPTION: 5.6.1.  ICR.06.01 - Bᯠcᯠtruy c?p h? th?ng
*/ 
PROCEDURE RPT_ICR0601(  p_page VARCHAR2,
                        p_limit VARCHAR2,
                        P_FROM_DATE VARCHAR2,
                        P_TO_DATE   VARCHAR2,
                        P_USER_NAME VARCHAR2,
                        P_BRANCH_CODE    VARCHAR2,
                        P_RESOURCE_URL    VARCHAR2,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) AS
V_FROM_DATE DATE;
V_TO_DATE DATE;
V_TOTAL  NUMBER:=0;
V_BRANCH_REPORT VARCHAR2(1000);
BEGIN
pkg_system_log.PR_LOG_INFO('RPT_ICR0601','CHECK RPT_ICR0601',P_BRANCH_CODE,'PR');

V_FROM_DATE := CASE WHEN P_FROM_DATE IS NULL THEN TRUNC(SYSDATE)-10 ELSE TO_DATE(P_FROM_DATE,'DD/MM/YYYY') END;
V_TO_DATE := CASE WHEN P_TO_DATE IS NULL THEN TRUNC(SYSDATE) ELSE TO_DATE(P_TO_DATE,'DD/MM/YYYY') END;
SELECT MAX(NVL(A.MEMBER_VIEW_REPORT,'N/A')||','||A.MEMBER_CODE)
INTO V_BRANCH_REPORT
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;
--9/8/2021 Fix loi search theo don vi
SELECT NVL(MAX(NVL(A.REF_CODE_PERMISSION,'N/A')),'N/A')
INTO V_BRANCH_PATH
FROM V_BRANCH A
WHERE A.REF_CODE=P_BRANCH_CODE;



-- DATA PERMISSION
INSERT INTO CIS_BRANCH_TMP (BRANCH_CODE, BRANCH_TREE)
WITH TEMP_DATA AS(
    SELECT DISTINCT TRIM(REGEXP_SUBSTR(BRCODE, '[^,]+', 1, LEVEL)) BRANCH
      FROM (SELECT V_BRANCH_REPORT BRCODE FROM DUAL) T
    CONNECT BY INSTR(BRCODE, ',', 1, LEVEL - 1) > 0 )
SELECT refCode.REF_CODE, REF_CODE_PERMISSION
FROM V_BRANCH refCode
WHERE EXISTS (SELECT * FROM TEMP_DATA XX WHERE refCode.REF_CODE_PERMISSION LIKE '%,'||XX.BRANCH||',%') ;

select count(*) INTO V_TOTAL  from SYS_RESOURCEACCESSMANAGEMENT A
    LEFT JOIN SYS_USER B ON A.ACCESS_USER=B.USER_NAME
    LEFT JOIN V_BRANCH C ON B.MEMBER_CODE=C.REF_CODE
    LEFT JOIN SYS_RESOURCES D ON TO_CHAR(D.RES_ID) = A.RESOURCE_URL
    WHERE A.ACCESS_DATE BETWEEN V_FROM_DATE AND V_TO_DATE+1
          AND (A.ACCESS_USER = P_USER_NAME OR P_USER_NAME IS NULL)
          AND (C.ref_code_permission LIKE V_BRANCH_PATH||'%'  OR V_BRANCH_PATH = 'N/A')
          AND (D.TASK_FLOW_ID = P_RESOURCE_URL OR P_RESOURCE_URL IS NULL)
          AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE C.ref_code_permission LIKE XX.BRANCH_TREE||'%');


OPEN P_OUT FOR  
SELECT *  FROM (
SELECT a.*,V_TOTAL TOTAL_RECORD, rownum r__ FROM(
    SELECT A.ACCESS_USER
           ,B.MEMBER_CODE BRANCH_CODE
           ,C.REF_NAME_VN BRANCH_NAME
           ,A.ACCESS_DATE 
           ,E.REF_NAME_VN ACCESS_STATUS
           ,A.CLIENT_IP
           ,A.RESOURCE_URL
           ,NVL(D.RES_NM,A.RESOURCE_URL) || ' -> '|| A.RESOURCE_ACTION RESOURCE_NAME
    FROM SYS_RESOURCEACCESSMANAGEMENT A
    LEFT JOIN SYS_USER B ON A.ACCESS_USER=B.USER_NAME
    LEFT JOIN V_BRANCH C ON B.MEMBER_CODE=C.REF_CODE
    LEFT JOIN SYS_RESOURCES D ON TO_CHAR(D.RES_ID) = A.RESOURCE_URL 
    LEFT JOIN SYS_REFCODE E ON A.ACCESS_STATUS=E.REF_CODE AND E.REF_GROUP= 'ACCESS_STATUS'
    WHERE A.ACCESS_DATE BETWEEN V_FROM_DATE AND V_TO_DATE+1
          AND (A.ACCESS_USER = P_USER_NAME OR P_USER_NAME IS NULL)
          AND (C.ref_code_permission LIKE V_BRANCH_PATH||'%'  OR V_BRANCH_PATH = 'N/A')--9/8/2021 Fix loi search theo don vi
          --AND (','||P_BRANCH_CODE||',' like ','||B.MEMBER_CODE||','  OR P_BRANCH_CODE IS NULL)
          AND (D.TASK_FLOW_ID = P_RESOURCE_URL OR P_RESOURCE_URL IS NULL)
          --AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE XX.BRANCH_TREE LIKE '%,'||B.MEMBER_CODE||',%')
          AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE C.ref_code_permission LIKE XX.BRANCH_TREE||'%')--15-7-2021 fix loi phan quyen du lieu
    ORDER BY ACCESS_DATE DESC)a WHERE p_page is null  OR (rownum < ((p_page * p_limit) + 1 ))  )WHERE p_page is null OR (r__ >= (((p_page-1) * p_limit) + 1));

END;

/*
CREATE: CUONGNH
DESCRIPTION: 5.6.2.  ICR.06.02 - Bᯠcᯠqu?n lý ng??i dùng
*/
PROCEDURE RPT_ICR0602 ( P_BRANCH_CODE    VARCHAR2,
                        P_KEYWORD        VARCHAR2,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) AS
V_BRANCH_REPORT VARCHAR2(1000);
BEGIN
SELECT MAX(NVL(A.MEMBER_VIEW_REPORT,'N/A')||','||A.MEMBER_CODE)
INTO V_BRANCH_REPORT
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;

-- DATA PERMISSION--update 20210511
INSERT INTO CIS_BRANCH_TMP (BRANCH_CODE, BRANCH_TREE)
WITH TEMP_DATA AS(
    SELECT DISTINCT TRIM(REGEXP_SUBSTR(BRCODE, '[^,]+', 1, LEVEL)) BRANCH
      FROM (SELECT V_BRANCH_REPORT BRCODE FROM DUAL) T
    CONNECT BY INSTR(BRCODE, ',', 1, LEVEL - 1) > 0 )
SELECT refCode.REF_CODE, REF_CODE_PERMISSION
FROM V_BRANCH refCode
WHERE EXISTS (SELECT * FROM TEMP_DATA XX WHERE refCode.REF_CODE_PERMISSION LIKE '%,'||XX.BRANCH||',%') ;

--9/8/2021 Fix loi search theo don vi
SELECT NVL(MAX(NVL(A.REF_CODE_PERMISSION,'N/A')),'N/A')
INTO V_BRANCH_PATH
FROM V_BRANCH A
WHERE A.REF_CODE=P_BRANCH_CODE;

OPEN P_OUT FOR 
WITH DATA_PERMISION AS(
    SELECT DISTINCT TRIM(REGEXP_SUBSTR(BRCODE, '[^,]+', 1, LEVEL)) BRANCH
      FROM (SELECT V_BRANCH_REPORT BRCODE FROM DUAL) T
    CONNECT BY INSTR(BRCODE, ',', 1, LEVEL - 1) > 0 ) 
SELECT *
FROM (
    SELECT  A.MEMBER_CODE BRANCH_CODE
           ,C.REF_NAME_VN BRANCH_NAME
           ,A.USER_NAME ||'.'|| A.FULL_NAME FULL_NAME
           ,A.CREATE_DATE
           ,A.STATUS
           ,D.REF_NAME_VN STATUS_NAME
    FROM SYS_USER A
    LEFT JOIN V_BRANCH C ON A.MEMBER_CODE=C.REF_CODE
    LEFT JOIN SYS_REFCODE D ON D.REF_GROUP = 'LS_STATUS' AND A.STATUS = D.REF_CODE
    --AND EXISTS (SELECT * FROM DATA_PERMISION XX WHERE A.MEMBER_CODE LIKE XX.BRANCH||'%')
    WHERE  (C.ref_code_permission LIKE V_BRANCH_PATH||'%'  OR V_BRANCH_PATH = 'N/A')--9/8/2021 Fix loi search theo don vi
          AND PKG_UTILITY.RemoveSignVietnamess(A.USER_NAME ||','|| A.FULL_NAME) like '%'|| PKG_UTILITY.RemoveSignVietnamess(P_KEYWORD) ||'%'
    --AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE XX.BRANCH_TREE LIKE '%,'||A.MEMBER_CODE||',%')--update 20210511
          AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE C.ref_code_permission LIKE XX.BRANCH_TREE||'%')--15-7-2021 fix loi phan quyen du lieu
          
    ORDER BY a.Create_Date DESC)
--WHERE ROWNUM<V_LIMIT_ROWS
;



END;


/*
CREATE: CUONGNH
DESCRIPTION: 5.6.3.	ICR.06.03 - Bᯠcᯠchi ti?t tra c?u tin theo t?ng b?n h?i tin
*/
PROCEDURE RPT_ICR0603 ( P_BRANCH_CODE    VARCHAR2,
                        P_CHANNEL        VARCHAR2,
                        P_PRODUCT_CODE        VARCHAR2,
                        P_FROM_DATE        DATE,
                        P_TO_DATE        DATE,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_KEYWORD VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) AS
V_FROM_DATE DATE;
V_TO_DATE DATE;
V_GROUP_NAME VARCHAR2(1000);
V_BRANCH_REPORT VARCHAR2(1000);
V_PRODUCT_LIST VARCHAR2(1000);
V_KEYWORD VARCHAR2(1000);
BEGIN

V_FROM_DATE := CASE WHEN P_FROM_DATE IS NULL THEN TRUNC(SYSDATE)-10000 ELSE P_FROM_DATE END;
V_TO_DATE := CASE WHEN P_TO_DATE IS NULL THEN TRUNC(SYSDATE) ELSE P_TO_DATE END;
V_KEYWORD:=pkg_utility.removesignvietnamess(P_KEYWORD);
SELECT ','|| listagg(','||NVL(GROUP_NAME,'')||',',', ') within group(order by GROUP_NAME) ||','
INTO V_GROUP_NAME
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;

SELECT MAX(NVL(A.MEMBER_VIEW_REPORT,'N/A')||','||A.MEMBER_CODE)
INTO V_BRANCH_REPORT
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;

SELECT ','|| listagg(','||NVL(PAR2,'')||',',', ') within group(order by PAR2) ||',' INTO  V_PRODUCT_LIST
FROM SYS_GROUPS A
WHERE V_GROUP_NAME LIKE '%,'|| A.GROUP_NAME ||',%';

-- DATA PERMISSION--update 20210511
INSERT INTO CIS_BRANCH_TMP (BRANCH_CODE, BRANCH_TREE)
WITH TEMP_DATA AS(
    SELECT DISTINCT TRIM(REGEXP_SUBSTR(BRCODE, '[^,]+', 1, LEVEL)) BRANCH
      FROM (SELECT V_BRANCH_REPORT BRCODE FROM DUAL) T
    CONNECT BY INSTR(BRCODE, ',', 1, LEVEL - 1) > 0 )
SELECT refCode.REF_CODE, REF_CODE_PERMISSION
FROM V_BRANCH refCode
WHERE EXISTS (SELECT * FROM TEMP_DATA XX WHERE refCode.REF_CODE_PERMISSION LIKE '%,'||XX.BRANCH||',%') ;

--9/8/2021 Fix loi search theo don vi
SELECT NVL(MAX(NVL(A.REF_CODE_PERMISSION,'N/A')),'N/A')
INTO V_BRANCH_PATH
FROM V_BRANCH A
WHERE A.REF_CODE=P_BRANCH_CODE;

OPEN P_OUT FOR  
SELECT *
FROM (
        SELECT A.BRANCH_CODE BRANCH_CODE
               ,C.PAR2 BRANCH_NAME 
               ,A.CHANNEL
               ,A.PRODUCT_CODE
               ,D.REF_NAME_VN PRODUCT_NAME
               ,A.MAKER
                ,CASE WHEN A.CUSTOMER_CODE IS NULL OR LOWER(A.CUSTOMER_CODE) = 'undefined'
                   THEN ''
               ELSE A.CUSTOMER_CODE
               END CUSTOMER_CODE
               ,A.CUSTOMER_NAME
               ,A.ID_NO
               ,A.REGISTER_NO
               ,A.TAX_CODE
               ,A.CREATED_DATE
               ,A.RESPONSE_DATE
               ,CASE WHEN A.IS_DATA='Y' THEN PKG_UTILITY.FORMAT_NUMBER(E.NORMAL_PRICE) ELSE PKG_UTILITY.FORMAT_NUMBER(E.NON_NORMAL_PRICE) END FEE 
               ,CASE WHEN A.MSG_ID IS NULL THEN 'No' ELSE 'Yes' END REQUEST_ID
               ,F.REF_NAME_VN STATUS_STR
               ,A.ID
               ,A.DEPARTMENT
               ,G.REF_NAME_VN DEPARTMENT_NAME
        FROM CIS_REQUEST A
        LEFT JOIN SYS_USER B ON A.MAKER=B.USER_NAME
        LEFT JOIN V_BRANCH C ON A.BRANCH_CODE=C.REF_CODE
        LEFT JOIN SYS_REFCODE D ON D.REF_GROUP = 'LS_PRODUCT' AND A.PRODUCT_CODE = D.REF_CODE
        LEFT JOIN SYS_REFCODE F ON F.REF_GROUP = 'STATUS_REQUEST' AND A.STATUS = F.REF_CODE
        LEFT JOIN SYS_REFCODE G ON G.REF_GROUP = 'LS_DEPARTMENT' AND A.DEPARTMENT = G.REF_CODE
        LEFT JOIN SYS_PRICE E ON A.PRODUCT_CODE=E.PRICE_CODE AND A.RESPONSE_DATE BETWEEN E.EFFECTIVE_DATE AND NVL(E.EXPIRATION_DATE,SYSDATE+100) AND A.STATUS='RECEIVED'

        WHERE A.CREATED_DATE BETWEEN V_FROM_DATE AND V_TO_DATE+1 
              --AND (A.BRANCH_CODE IN (SELECT REF_CODE FROM V_BRANCH XX WHERE XX.REF_CODE_PERMISSION LIKE '%,'||P_BRANCH_CODE||',%') OR P_BRANCH_CODE IS NULL) --update 20210511
              AND (C.ref_code_permission LIKE V_BRANCH_PATH||'%'  OR V_BRANCH_PATH = 'N/A')--9/8/2021 Fix loi search theo don vi
              AND (A.CHANNEL = P_CHANNEL OR P_CHANNEL IS NULL)
              AND (A.PRODUCT_CODE = P_PRODUCT_CODE OR P_PRODUCT_CODE IS NULL)
              AND V_PRODUCT_LIST like '%,'|| A.PRODUCT_CODE ||',%' 
              AND (KEYWORD like '%'||V_KEYWORD||'%' OR V_KEYWORD IS NULL)
--               AND (KEYWORD like '%cuongnh1%')
              --AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE XX.BRANCH_TREE LIKE '%,'||A.BRANCH_CODE||',%')--update 20210511              
          AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE C.ref_code_permission LIKE XX.BRANCH_TREE||'%')--15-7-2021 fix loi phan quyen du lieu
         ORDER BY CREATED_DATE DESC, A.REQUESTED_DATE DESC)
;



END;


/*
CREATE: CUONGNH
DESCRIPTION: 5.6.4.	ICR.06.04 - Bᯠcᯠchi ti?t tra c?u t?ng h?p theo user h?i tin
*/
PROCEDURE RPT_ICR0604 ( P_BRANCH_CODE    VARCHAR2,
                        P_CHANNEL        VARCHAR2,
                        P_PRODUCT_CODE        VARCHAR2,
                        P_FROM_DATE        DATE,
                        P_TO_DATE        DATE,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_KEYWORD VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) AS
V_FROM_DATE DATE;
V_TO_DATE DATE;
V_GROUP_NAME VARCHAR2(1000);
V_BRANCH_REPORT VARCHAR2(1000);
V_PRODUCT_LIST VARCHAR2(1000);
V_KEYWORD VARCHAR2(1000);
BEGIN

V_FROM_DATE := CASE WHEN P_FROM_DATE IS NULL THEN TRUNC(SYSDATE)-30 ELSE P_FROM_DATE END;
V_TO_DATE := CASE WHEN P_FROM_DATE IS NULL THEN TRUNC(SYSDATE) ELSE P_TO_DATE END;
V_KEYWORD:=pkg_utility.removesignvietnamess(P_KEYWORD);

SELECT ','|| listagg(','||NVL(GROUP_NAME,'')||',',', ') within group(order by GROUP_NAME) ||','
INTO V_GROUP_NAME
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;

SELECT MAX(NVL(A.MEMBER_VIEW_REPORT,'N/A')||','||A.MEMBER_CODE)
INTO V_BRANCH_REPORT
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;


SELECT ','|| listagg(','||NVL(PAR2,'')||',',', ') within group(order by PAR2) ||',' INTO  V_PRODUCT_LIST
FROM SYS_GROUPS A
WHERE V_GROUP_NAME LIKE '%,'|| A.GROUP_NAME ||',%';


-- DATA PERMISSION--update 20210511
INSERT INTO CIS_BRANCH_TMP (BRANCH_CODE, BRANCH_TREE)
WITH TEMP_DATA AS(
    SELECT DISTINCT TRIM(REGEXP_SUBSTR(BRCODE, '[^,]+', 1, LEVEL)) BRANCH
      FROM (SELECT V_BRANCH_REPORT BRCODE FROM DUAL) T
    CONNECT BY INSTR(BRCODE, ',', 1, LEVEL - 1) > 0 )
SELECT refCode.REF_CODE, REF_CODE_PERMISSION
FROM V_BRANCH refCode
WHERE EXISTS (SELECT * FROM TEMP_DATA XX WHERE refCode.REF_CODE_PERMISSION LIKE '%,'||XX.BRANCH||',%') ;

--9/8/2021 Fix loi search theo don vi
SELECT NVL(MAX(NVL(A.REF_CODE_PERMISSION,'N/A')),'N/A')
INTO V_BRANCH_PATH
FROM V_BRANCH A
WHERE A.REF_CODE=P_BRANCH_CODE;


OPEN P_OUT FOR  
SELECT *
FROM (
        SELECT A.BRANCH_CODE BRANCH_CODE
               ,C.PAR2 BRANCH_NAME 
               ,A.CHANNEL
               ,A.PRODUCT_CODE
               ,D.REF_NAME_VN PRODUCT_NAME
               ,PKG_UTILITY.FORMAT_NUMBER(COUNT(9)) MAKER_COUNT
               ,A.MAKER
               ,PKG_UTILITY.FORMAT_NUMBER(SUM(CASE WHEN A.IS_DATA='Y' THEN E.NORMAL_PRICE ELSE E.NON_NORMAL_PRICE END)) FEE 
               ,A.DEPARTMENT
               ,G.REF_NAME_VN DEPARTMENT_NAME
        FROM CIS_REQUEST A
        --LEFT JOIN SYS_USER B ON A.MAKER=B.USER_NAME
        LEFT JOIN V_BRANCH C ON A.BRANCH_CODE=C.REF_CODE
        LEFT JOIN SYS_REFCODE D ON D.REF_GROUP = 'LS_PRODUCT' AND A.PRODUCT_CODE = D.REF_CODE
        LEFT JOIN SYS_PRICE E ON A.PRODUCT_CODE=E.PRICE_CODE AND A.REQUESTED_DATE BETWEEN E.EFFECTIVE_DATE AND NVL(E.EXPIRATION_DATE,SYSDATE+100) AND A.STATUS='RECEIVED'
        LEFT JOIN SYS_REFCODE G ON G.REF_GROUP = 'LS_DEPARTMENT' AND A.DEPARTMENT = G.REF_CODE

        WHERE A.CREATED_DATE BETWEEN V_FROM_DATE AND V_TO_DATE+1 
              --AND (A.BRANCH_CODE IN (SELECT REF_CODE FROM V_BRANCH XX WHERE XX.REF_CODE_PERMISSION LIKE '%,'||P_BRANCH_CODE||',%') OR P_BRANCH_CODE IS NULL) --update 20210511
              AND (C.ref_code_permission LIKE V_BRANCH_PATH||'%'  OR V_BRANCH_PATH = 'N/A')--9/8/2021 Fix loi search theo don vi
              AND (A.CHANNEL = P_CHANNEL OR P_CHANNEL IS NULL)
              AND (A.PRODUCT_CODE = P_PRODUCT_CODE OR P_PRODUCT_CODE IS NULL)
              AND A.STATUS='RECEIVED'
              --AND ROWNUM<100
              AND V_PRODUCT_LIST like '%,'|| A.PRODUCT_CODE ||',%'
              AND (A.MAKER LIKE '%'||V_KEYWORD||'%' OR V_KEYWORD is NULL )
              --AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE XX.BRANCH_TREE LIKE '%,'||A.BRANCH_CODE||',%')--update 20210511
          AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE C.ref_code_permission LIKE XX.BRANCH_TREE||'%')--15-7-2021 fix loi phan quyen du lieu

        GROUP BY A.BRANCH_CODE 
               ,C.PAR2  
               ,A.CHANNEL
               ,A.PRODUCT_CODE
               ,D.REF_NAME_VN
               ,A.MAKER
               ,A.DEPARTMENT
               ,G.REF_NAME_VN

        ORDER BY BRANCH_CODE,CHANNEL,PRODUCT_CODE)
--WHERE ROWNUM<V_LIMIT_ROWS
;



END;
end PCK_REPORT;

/
--------------------------------------------------------
--  DDL for Package Body PCK_REPORT_FROM_CIC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_REPORT_FROM_CIC" AS

PROCEDURE PR_CREATE_FILE(P_ID VARCHAR2,
                    P_FILE_NAME VARCHAR2,
                    P_FILE_STATUS VARCHAR2, 
                    P_RESPONSE_DATE VARCHAR2,
                    P_FILE_PATH VARCHAR2,
                    P_CHECK_SUM_MD5 VARCHAR2, 
                    p_out    OUT SYS_REFCURSOR) AS
V_ROWS NUMBER;
V_FILE_TYPE VARCHAR2(30);

BEGIN
V_FILE_TYPE := 'N/A';

SELECT COUNT(9)
INTO V_ROWS
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE A.FILE_NAME=P_FILE_NAME;

SELECT CASE WHEN INSTR(P_FILE_NAME, '.R18.', 1)>0 THEN 'R18' 
            WHEN INSTR(P_FILE_NAME, '.R19.', 1)>0 THEN 'R19' 
            WHEN INSTR(P_FILE_NAME, '.R19_W.', 1)>0 THEN 'R19_W' 
            ELSE 'N/A' END 
INTO V_FILE_TYPE
FROM dual;

IF V_ROWS = 0 THEN
    INSERT INTO CIC_DATA_REPORT_FROM_CIC (ID,FILE_NAME,
                                            FILE_STATUS,
                                            RESPONSE_DATE,
                                            FILE_PATH,
                                            CHECK_SUM_MD5,
                                            FILE_TYPE)
                                VALUES (SEQ_CIC_DATA_REPORT_FROM_CIC.nextval, P_FILE_NAME,
                                       'NEW',
                                       SYSDATE,
                                       P_FILE_PATH,
                                       P_CHECK_SUM_MD5,
                                       V_FILE_TYPE);
END IF;

OPEN P_OUT FOR
SELECT *
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE A.FILE_NAME=P_FILE_NAME;

END;

PROCEDURE PR_UPDATE_FILE(P_ID VARCHAR2,
                    P_FILE_NAME VARCHAR2,
                    P_FILE_STATUS VARCHAR2, 
                    P_RESPONSE_DATE VARCHAR2,
                    P_FILE_PATH VARCHAR2,
                    P_CHECK_SUM_MD5 VARCHAR2, 
                    p_out    OUT SYS_REFCURSOR) AS
V_ROWS NUMBER;
BEGIN

UPDATE CIC_DATA_REPORT_FROM_CIC A
SET FILE_STATUS=NVL(P_FILE_STATUS,FILE_STATUS)
    ,RESPONSE_DATE=SYSDATE
    ,FILE_PATH=NVL(P_FILE_PATH,FILE_PATH)
    ,CHECK_SUM_MD5=NVL(P_CHECK_SUM_MD5,CHECK_SUM_MD5)
    ,PROCESSING_DATE=CASE WHEN P_FILE_STATUS='DONE' THEN SYSDATE ELSE PROCESSING_DATE END
WHERE A.FILE_NAME=P_FILE_NAME;

commit;

OPEN P_OUT FOR
SELECT *
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE A.FILE_NAME=P_FILE_NAME;

END;

PROCEDURE PR_GET_FILE(P_ID VARCHAR2,
                    P_FILE_NAME VARCHAR2,
                    P_FILE_STATUS VARCHAR2, 
                    P_RESPONSE_DATE VARCHAR2,
                    P_FILE_PATH VARCHAR2,
                    P_CHECK_SUM_MD5 VARCHAR2, 
                    p_out    OUT SYS_REFCURSOR) AS
V_ROWS NUMBER;
BEGIN

OPEN P_OUT FOR
SELECT *
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE (A.FILE_STATUS=P_FILE_STATUS OR P_FILE_STATUS IS NULL)
AND (FILE_NAME=P_FILE_NAME OR P_FILE_NAME IS NULL);

END;
END PCK_REPORT_FROM_CIC;

/
--------------------------------------------------------
--  DDL for Package Body PCK_REQUEST_LOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_REQUEST_LOG" AS

 
/*
Creater: CuongNH2
Created date:  24/8/2020
Description: Luu log g?i request sang partner  
*/
Procedure PR_LOG_INFO(P_REQUEST_ID varchar2,
                        P_MSG_TYPE varchar2,
                        P_MSG_DATA clob,
                        P_ERROR_CODE varchar2,
                        P_ERROR_MSG clob,
                        P_END_POINT varchar2, 
                        P_REQUEST_DATE varchar2, 
                        P_ADDITION_INFO varchar2,
                        p_out OUT types.ref_cursor) is
begin
	
INSERT INTO SYS_REQUEST_LOG(REQUEST_ID,
                            MSG_TYPE,
                            MSG_DATA,
                            "ERROR_CODE",
                            ERROR_MSG,
                            END_POINT,
                            REQUEST_DATE,
                            ADDITION_INFO)
VALUES(P_REQUEST_ID||'.'||DBMS_RANDOM.string('x',5),
      P_MSG_TYPE,
      P_MSG_DATA,
      P_ERROR_CODE,
      P_ERROR_MSG,
      P_END_POINT,
      SYSDATE,
      SYS_CONTEXT('USERENV','IP_ADDRESS') ||'.'|| P_ADDITION_INFO);
end;


end PCK_REQUEST_LOG;

/
--------------------------------------------------------
--  DDL for Package Body PCK_TOKEN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_TOKEN" AS

  PROCEDURE PR_GET_TOKEN (p_out    OUT SYS_REFCURSOR) AS
  BEGIN
    -- TODO: Implementation required for PROCEDURE PCK_TOKEN.PR_GET_TOKEN
    OPEN P_OUT FOR
    SELECT * FROM SYS_TOKEN;
    
  END PR_GET_TOKEN;
END PCK_TOKEN;

/
--------------------------------------------------------
--  DDL for Package Body PKG_CIC_GROUP_DEBT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PKG_CIC_GROUP_DEBT" AS
/******************************************************************************
   NAME:       PKG_CIC_GROUP_DEBT
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        31/07/2020      dodti       1. Created this package body.
******************************************************************************/
    V_PARAMETER   NVARCHAR2 (4000);
    V_ERRORS      NUMBER (10);
     PROCEDURE pr_get_list_cic_group_debt (
        p_text_search             VARCHAR2,
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_rpt_dt10                VARCHAR2,
        p_cst_cd                  VARCHAR2,
        p_cst_nm                  VARCHAR2,
        p_cic_code                VARCHAR2,
        p_bal                     VARCHAR2,
        p_group_debt              VARCHAR2,
        p_low_group_debt          VARCHAR2,
        p_member_code             VARCHAR2,
        p_user             IN     VARCHAR2,
        p_from_date             VARCHAR2,
        p_to_date             VARCHAR2,
        p_out                 OUT types.ref_cursor)
    AS
        v_text_search varchar2(4000);
        V_SEARCH_REQUEST_LIMIT int;
        v_from_date date;
        v_to_date date;
    BEGIN
      SELECT nvl(MAX(PAR1),0) INTO V_SEARCH_REQUEST_LIMIT
      FROM SYS_REFCODE
      WHERE REF_CODE='SEARCH_REQUEST_LIMIT';

        v_text_search := '%'||pkg_utility.removesignvietnamess(nvl(p_text_search,''))||'%';
        v_from_date := trunc(nvl(to_date(p_from_date,'dd/MM/yyyy'),sysdate-V_SEARCH_REQUEST_LIMIT));
        v_to_date := trunc(nvl(to_date(p_to_date,'dd/MM/yyyy'),sysdate))+1;

        OPEN p_out FOR   SELECT *
                           FROM cic_group_debt A
                           where (file_tp=p_file_tp or p_file_tp is null)
                                and ( TRIM(BOTH ' ' FROM rpt_dt)=p_rpt_dt or p_rpt_dt is null)
                                and (p_text_search is null or pkg_utility.removesignvietnamess(FILE_NAME ||','|| CST_CD ||','|| CST_NM ||','|| CIC_CODE ||','|| CST_ID||','|| MEMBER_CODE) like v_text_search)
                                and a.created_date between v_from_date and v_to_date
                                and rownum<1000;
    END; 
/*****/
   PROCEDURE pr_insert_record (
        p_id                      VARCHAR2,   
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_rpt_dt10                VARCHAR2,
        p_cst_cd                  VARCHAR2,
        p_cst_nm                  VARCHAR2,
        p_cic_code                VARCHAR2,
        p_bal                     NUMBER,
        p_group_debt              VARCHAR2,
        p_low_group_debt          VARCHAR2,
        p_member_code             VARCHAR2,
        p_cst_id             VARCHAR2,
        p_address             VARCHAR2,
        p_user             IN     VARCHAR2,
        p_out                 OUT types.ref_cursor)
    AS
    v_id number;    
    BEGIN
    v_id := SEQ_CIC_GROUP_DEBT.nextval;
    INSERT INTO CIC_GROUP_DEBT(id, file_name, file_tp, rpt_dt, rpt_dt10, cst_cd, cst_nm, cic_code, bal, group_debt, low_group_debt, member_code,created_date, created_user) 
    VALUES(v_id, p_file_name, p_file_tp, ltrim(rtrim(p_rpt_dt)), p_rpt_dt10, ltrim(rtrim(p_cst_cd)), ltrim(rtrim(p_cst_nm)), ltrim(rtrim(p_cic_code)), p_bal, p_group_debt, p_low_group_debt, p_member_code,sysdate,p_user);
    
    OPEN p_out FOR select v_id ID from dual;
    
    END;
    
    PROCEDURE pr_delete_record(
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_user             IN     VARCHAR2,
        p_out                 OUT types.ref_cursor)
    AS
    v_id number;    
    BEGIN

    DELETE CIC_GROUP_DEBT WHERE rpt_dt=p_rpt_dt;
    
    OPEN p_out FOR select p_rpt_dt ID from dual;
    
    END;
      
END PKG_CIC_GROUP_DEBT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_FRAUDULENCE_CUSTOMER
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PKG_FRAUDULENCE_CUSTOMER" AS

  PROCEDURE pr_list_fraudulence_customer(p_customer_code cis_fraudulence_customer.customer_code%TYPE ,
                               p_customer_name cis_fraudulence_customer.customer_full_name%TYPE,--Dùng cho KEYWORD
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_report_date_from cis_fraudulence_customer.report_date%TYPE,
                               p_report_date_to cis_fraudulence_customer.report_date%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_cic_code cis_fraudulence_customer.cic_code%TYPE,
                               p_status cis_fraudulence_customer.cic_code%TYPE,
                               p_from_date                DATE,
                               p_to_date                  DATE,
                               p_out OUT types.ref_cursor) AS
  BEGIN
    --SHB T쭠ki?m theo di?u ki?n
    /*
     OPEN p_out FOR select * from CIS_FRAUDULENCE_CUSTOMER
        Where (p_customer_code IS NULL OR customer_code LIKE '%' || p_customer_code || '%')
            AND (p_customer_name IS NULL OR customer_name LIKE '%' || p_customer_name || '%')
            AND (p_tax_code IS NULL OR tax_code LIKE '%' || p_tax_code || '%')
            AND (p_register_code IS NULL OR register_code LIKE '%' || p_register_code || '%')
            AND (p_report_date_from IS NULL OR report_date >= to_date(p_report_date_from))
            AND (p_report_date_from IS NULL OR report_date <= to_date(p_report_date_to))
            AND fraud_type = p_fraud_type
            AND (p_id_legal_personal IS NULL OR id_legal_personal = p_id_legal_personal)
            AND (p_type_business IS NULL OR type_business = p_type_business)
            AND (p_cic_code IS NULL OR cic_code = p_cic_code);
*/
     --VIB: Ṱ ki?m theo t? kh󡊠    OPEN p_out FOR select * from CIS_FRAUDULENCE_CUSTOMER a
        Where (','||p_status||',' like '%,'||STATUS||',%' or p_status is null) 
        and register_code||','||tax_code||','||id_legal_personal||','||customer_code||','||customer_name like '%'||p_customer_name||'%' 
        and trunc(REPORT_DATE) between nvl(p_from_date,sysdate-100) and nvl(p_to_date,sysdate+1)
        AND fraud_type = p_fraud_type
        order by a.report_date desc;

      -- T? kh󡠨G?m cᣠtr??ng:  S? CMT/ H? chi?u, MST, S? ?KKD, M㠫hᣨ h஧ , Tꮠkhᣨ h஧)
  END pr_list_fraudulence_customer;
  PROCEDURE pr_create_fraudulence_customer(p_cic_code cis_fraudulence_customer.cic_code%TYPE ,
                               p_customer_type cis_fraudulence_customer.customer_type%TYPE,
                               p_customer_code cis_fraudulence_customer.customer_code%TYPE,
                               p_customer_name cis_fraudulence_customer.customer_name%TYPE,
                               p_customer_full_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_customer_short_name cis_fraudulence_customer.customer_short_name%TYPE,
                               p_customer_add cis_fraudulence_customer.customer_add%TYPE,
                               p_customer_phone cis_fraudulence_customer.customer_phone%TYPE,
                               p_customer_fax cis_fraudulence_customer.customer_fax%TYPE,
                               p_customer_web cis_fraudulence_customer.customer_web%TYPE,
                               p_customer_email cis_fraudulence_customer.customer_email%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_tax_date cis_fraudulence_customer.tax_date%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_register_date cis_fraudulence_customer.register_date%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_industry_code cis_fraudulence_customer.industry_code%TYPE,
                               p_legal_personal cis_fraudulence_customer.legal_personal%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_director_name cis_fraudulence_customer.director_name%TYPE,
                               p_director_id cis_fraudulence_customer.director_id%TYPE,
                               p_source cis_fraudulence_customer.source%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                                p_status cis_fraudulence_customer.status%TYPE,
                               p_out OUT types.ref_cursor) AS
    p_id   cis_fraudulence_customer.id%TYPE;
  BEGIN
     p_id := SEQ_CIS_FRAUDULENCE_CUS.NEXTVAL;
     INSERT INTO cis_fraudulence_customer (id,
                                 cic_code, 
                                 customer_type,
                                 customer_code,
                                 customer_name,
                                 customer_full_name,
                                 customer_short_name,
                                 customer_add,
                                 customer_phone,
                                 customer_fax,
                                 customer_web,
                                 customer_email,
                                 tax_code,
                                 tax_date,
                                 register_code,
                                 register_date,
                                 type_business,
                                 industry_code,
                                 legal_personal,
                                 id_legal_personal,
                                 director_name,
                                 director_id,
                                 source,
                                 report_date,
                                 status,
                                 fraud_type)
        VALUES(p_id,
               p_cic_code,
                p_customer_type,
               p_customer_code,
               p_customer_name,
               p_customer_full_name,
               p_customer_short_name,
               p_customer_add,
               p_customer_phone,
               p_customer_fax,
               p_customer_web,
               p_customer_email,
               p_tax_code,
               p_tax_date,
               p_register_code,
               p_register_date,
               p_type_business,
               p_industry_code,
               p_legal_personal,
               p_id_legal_personal,
               p_director_name,
               p_director_id,
               p_source,
               SYSDATE,
               p_status,
               p_fraud_type);
        OPEN p_out FOR select * from cis_fraudulence_customer
        Where id = p_id;
  END pr_create_fraudulence_customer;
   PROCEDURE pr_update_fraudulence_customer(p_id cis_fraudulence_customer.id%TYPE ,
                                p_cic_code cis_fraudulence_customer.cic_code%TYPE ,
                               p_customer_type cis_fraudulence_customer.customer_type%TYPE,
                               p_customer_code cis_fraudulence_customer.customer_code%TYPE,
                               p_customer_name cis_fraudulence_customer.customer_name%TYPE,
                               p_customer_full_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_customer_short_name cis_fraudulence_customer.customer_short_name%TYPE,
                               p_customer_add cis_fraudulence_customer.customer_add%TYPE,
                               p_customer_phone cis_fraudulence_customer.customer_phone%TYPE,
                               p_customer_fax cis_fraudulence_customer.customer_fax%TYPE,
                               p_customer_web cis_fraudulence_customer.customer_web%TYPE,
                               p_customer_email cis_fraudulence_customer.customer_email%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_tax_date cis_fraudulence_customer.tax_date%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_register_date cis_fraudulence_customer.register_date%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_industry_code cis_fraudulence_customer.industry_code%TYPE,
                               p_legal_personal cis_fraudulence_customer.legal_personal%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_director_name cis_fraudulence_customer.director_name%TYPE,
                               p_director_id cis_fraudulence_customer.director_id%TYPE,
                               p_source cis_fraudulence_customer.source%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                               p_status cis_fraudulence_customer.status%TYPE,
                               p_out OUT types.ref_cursor) AS

  BEGIN

     update cis_fraudulence_customer set 

    cic_code=                     p_cic_code,     
customer_type=     p_customer_type,
status =     p_status,
customer_code=                                  p_customer_code,
customer_name=                                  p_customer_name,
customer_full_name=                             p_customer_full_name,
customer_short_name=                            p_customer_short_name,
customer_add=                                   p_customer_add,
customer_phone=                                 p_customer_phone,
customer_fax=                                   p_customer_fax,
customer_web=                                   p_customer_web,
customer_email=                                 p_customer_email,
tax_code=                                       p_tax_code,
tax_date=                                       p_tax_date,
register_code=                                  p_register_code,
register_date=                                  p_register_date,
type_business=                                  p_type_business,
industry_code=                                  p_industry_code,
legal_personal=                                 p_legal_personal,
id_legal_personal=                              p_id_legal_personal,
director_name=                                  p_director_name,
director_id=                                    p_director_id,
source=                                         p_source,
report_date=                                    SYSDATE,
fraud_type=                                      p_fraud_type where id = p_id;
        OPEN p_out FOR select * from cis_fraudulence_customer
        Where id = p_id;
  END pr_update_fraudulence_customer;
  PROCEDURE pr_info_fraudulence_customer(p_customer_code cis_fraudulence_customer.customer_code%TYPE ,
                               p_customer_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_cic_code cis_fraudulence_customer.cic_code%TYPE,
                               p_out OUT types.ref_cursor) AS
  BEGIN
     OPEN p_out FOR select * from CIS_FRAUDULENCE_CUSTOMER
        Where (p_customer_code IS NULL OR customer_code = p_customer_code)
            AND (p_customer_name IS NULL OR customer_name = p_customer_name)
            AND (p_tax_code IS NULL OR tax_code = p_tax_code)
            AND (p_register_code IS NULL OR register_code = p_register_code)
            AND (p_fraud_type IS NULL OR fraud_type = p_fraud_type)
            AND (p_id_legal_personal IS NULL OR id_legal_personal = p_id_legal_personal)
            AND (p_type_business IS NULL OR type_business = p_type_business)
            AND (p_cic_code IS NULL OR cic_code = p_cic_code);
  END pr_info_fraudulence_customer;

  PROCEDURE pr_update_inactive_fraudulence(p_fraud_type varchar2) AS
  BEGIN
     update cis_fraudulence_customer set status = 0
     where fraud_type=p_fraud_type;
  END pr_update_inactive_fraudulence;

END PKG_FRAUDULENCE_CUSTOMER;

/
--------------------------------------------------------
--  DDL for Package Body PKG_SYS_EMAIL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PKG_SYS_EMAIL" 
AS
    V_PARAMETER   NVARCHAR2 (4000);
    V_ERRORS      NUMBER (10);

    /******************************************************************************
       NAME:       PKG_SYS_EMAIL
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        5/3/2018      admin       1. Created this package body.
    ******************************************************************************/


    PROCEDURE pr_create_sys_email (
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        --p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        --p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        --p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        --p_status                   SYS_EMAIL.STATUS%TYPE,
        --p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        --p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        --p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
        v_id   SYS_EMAIL.id%TYPE;
    BEGIN
        v_parameter := ', p_channel:'
            || p_channel
            || ', p_subject:'
            || p_subject
            || ', p_email_bcc:'
            || p_email_bcc
            || ', p_email_cc:'
            || p_email_cc
            || ', p_email_to:'
            || p_email_to
            || ', p_email_sender:'
            || p_email_sender
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;
        v_id := seq_sys_email.NEXTVAL;
        pkg_system_log.pr_log_info ('pr_create_sys_email',
                                    'BEGIN',
                                    v_parameter); 
                                  
        INSERT INTO SYS_EMAIL (ID,
                               EMAIL_SENDER,
                               EMAIL_TO,
                               EMAIL_CC,
                               EMAIL_BCC,
                               SUBJECT,
                               BODY,
                               --SEND_TIME,
                               --NUMBER_RETRY,
                               --LAST_RETRY,
                               STATUS,
                               CREATED_DATE,
                               MAKER,
                               CHANNEL)
             VALUES (v_id,                                                --ID
                     p_email_sender,                            --EMAIL_SENDER
                     p_email_to,                                    --EMAIL_TO
                     p_email_cc,                                    --EMAIL_CC
                     p_email_bcc,                                  --EMAIL_BCC
                     p_subject,                                      --SUBJECT
                     p_body,                                            --BODY
                     --p_send_time,                                  --SEND_TIME
                     --p_number_retry,                            --NUMBER_RETRY
                     --p_last_retry,                                --LAST_RETRY
                     'NEW',                                        --STATUS
                     SYSDATE,                            --CREATED_DATE
                     p_user,                                          --MAKER
                     p_channel);

        OPEN p_out FOR SELECT ID,
                              EMAIL_SENDER,
                              EMAIL_TO,
                              EMAIL_CC,
                              EMAIL_BCC,
                              SUBJECT,
                              BODY
                         FROM SYS_EMAIL
                        WHERE id = v_id;

        pkg_system_log.pr_log_info ('pr_create_sys_email',
                                    'END',
                                    v_parameter); 

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_create_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;

            RAISE;
    END;


    PROCEDURE pr_get_list_sys_email (
        p_text_search              VARCHAR2,
        p_status              VARCHAR2,
        p_from_date                DATE,
        p_to_date                  DATE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
        v_text_search varchar2(4000);
    BEGIN
        v_parameter := ', p_text_search:'
            || p_text_search
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        pkg_system_log.pr_log_info ('pr_get_list_sys_email', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email', 'BEGIN', v_parameter);
        v_text_search := '%'||pkg_utility.removesignvietnamess(nvl(p_text_search,''))||'%';

        OPEN p_out FOR   SELECT ID,
                                EMAIL_SENDER,
                                EMAIL_TO,
                                EMAIL_CC,
                                EMAIL_BCC,
                                SUBJECT,
                                BODY,
                                SEND_TIME,
                                NUMBER_RETRY,
                                LAST_RETRY,
                                A.STATUS,
                                nvl(B.REF_NAME_VN,'N/A') STATUS_NAME,
                                CREATED_DATE,
                                MAKER,
                                CHANNEL,
                                substr(ERROR_MESSENGER,1,80) ERROR_MESSENGER
                           FROM SYS_EMAIL A
                                LEFT JOIN SYS_refcode B ON A.STATUS=B.REF_CODE AND B.REF_GROUP ='EMAIL_STATUS'
                          WHERE (','||p_status||',' like '%,'||A.STATUS||',%' or p_status is null)
                                and pkg_utility.removesignvietnamess(nvl(maker,'')||','||nvl(EMAIL_TO,'')||','||nvl(SUBJECT,'')) like v_text_search
                                and trunc(nvl(SEND_TIME,CREATED_DATE)) between nvl(p_from_date,sysdate-100) and nvl(p_to_date,sysdate+1)

                       ORDER BY CREATED_DATE DESC;


        pkg_system_log.pr_log_info ('pr_get_list_sys_email',
                                    'END',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email',
                                     'END',
                                     v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_get_list_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;
    END;

    PROCEDURE pr_update_sys_email (
        p_id                       SYS_EMAIL.ID%TYPE,
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        p_status                   SYS_EMAIL.STATUS%TYPE,
        p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
    BEGIN
        v_parameter :=
               ', p_error_messenger:'
            || p_error_messenger
            || ', p_channel:'
            || p_channel
            || ', p_maker:'
            || p_maker
            || ', p_created_date:'
            || p_created_date
            || ', p_status:'
            || p_status
            || ', p_last_retry:'
            || p_last_retry
            || ', p_number_retry:'
            || p_number_retry
            || ', p_send_time:'
            || p_send_time
            || ', p_subject:'
            || p_subject
            || ', p_email_bcc:'
            || p_email_bcc
            || ', p_email_cc:'
            || p_email_cc
            || ', p_email_to:'
            || p_email_to
            || ', p_email_sender:'
            || p_email_sender
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        pkg_system_log.pr_log_info ('pr_update_sys_email',
                                    'BEGIN',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_update_sys_email0',
                                     'BEGIN',
                                     v_parameter);

        UPDATE SYS_EMAIL
           SET --ID = p_id,
               --EMAIL_SENDER = p_email_sender,
               --EMAIL_TO = p_email_to,
               --EMAIL_CC = p_email_cc,
               --EMAIL_BCC = p_email_bcc,
               --SUBJECT = p_subject,
               --BODY = p_body,
               SEND_TIME = p_send_time,
               NUMBER_RETRY = p_number_retry,
               LAST_RETRY = p_last_retry,
               STATUS = case when p_status='SENDED' then 'SENT' else p_status end,
               --CREATED_DATE = p_created_date,
               --MAKER = p_maker,
               --CHANNEL = p_channel,
               ERROR_MESSENGER = p_error_messenger
         WHERE id = p_id;

        OPEN p_out FOR SELECT ID,
                              EMAIL_SENDER,
                              EMAIL_TO,
                              EMAIL_CC,
                              EMAIL_BCC,
                              SUBJECT,
                              BODY
                         FROM SYS_EMAIL
                        WHERE id = p_id;

        pkg_system_log.pr_log_info ('pr_create_sys_email',
                                    'END',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_create_sys_email',
                                     'END',
                                     v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_create_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;

            RAISE;
    END;

    PROCEDURE pr_get_sys_email_by_id (
        p_id                       SYS_EMAIL.ID%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
    BEGIN
        v_parameter :=

             'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        pkg_system_log.pr_log_info ('pr_get_list_sys_email',
                                    'BEGIN',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email',
                                     'BEGIN',
                                     v_parameter);

        OPEN p_out FOR   SELECT ID,
                                EMAIL_SENDER,
                                EMAIL_TO,
                                EMAIL_CC,
                                EMAIL_BCC,
                                SUBJECT,
                                BODY,
                                SEND_TIME,
                                NUMBER_RETRY,
                                LAST_RETRY,
                                STATUS,
                                CREATED_DATE,
                                MAKER,
                                CHANNEL,
                                ERROR_MESSENGER
                           FROM SYS_EMAIL
                          WHERE ID = p_id
                       ORDER BY CREATED_DATE ASC;


        pkg_system_log.pr_log_info ('pr_get_list_sys_email',
                                    'END',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email',
                                     'END',
                                     v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_get_list_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;
    END;



    PROCEDURE pr_create_sys_email_2 (
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        p_status                   SYS_EMAIL.STATUS%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2)
    AS
        v_id   SYS_EMAIL.id%TYPE;
    BEGIN
        v_parameter :=
            'p_status:'
            || p_status
            || ', p_body:'
            || p_body
            || ', p_subject:'
            || p_subject
            || ', p_email_to:'
            || p_email_to
            || ', p_email_sender:'
            || p_email_sender
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;
        v_id := seq_sys_email.NEXTVAL;
        pkg_system_log.pr_log_info ('pr_create_sys_email_2',
                                    'BEGIN',
                                    v_parameter);

        INSERT INTO SYS_EMAIL (ID,
                               EMAIL_SENDER,
                               EMAIL_TO,
                               SUBJECT,
                               BODY,
                               STATUS,
                               CREATED_DATE,
                               MAKER)
             VALUES (v_id,                                                --ID
                     p_email_sender,                            --EMAIL_SENDER
                     p_email_to,                                 --EMAIL_BCC
                     p_subject,                                      --SUBJECT
                     p_body,                              --LAST_RETRY
                     p_status,                                        --STATUS
                     SysDate,                            --CREATED_DATE
                     p_user);

        pkg_system_log.pr_log_info ('pr_create_sys_email_2',
                                    'END',
                                    v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_create_sys_email_2',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));
            END LOOP;

            RAISE;
    END;

--G?i email th𮧠bᯠkh?i t?o/di?u ch?nh user
PROCEDURE PR_SEND_EMAIL_USER (P_USER_ID                 VARCHAR2,
                              P_ACTION                  VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(100);
V_FULL_NAME VARCHAR2(100);
V_DOMAIN_ICREDIT VARCHAR2(1000); 
P_OUT TYPES.REF_CURSOR;
V_BODY CLOB;
BEGIN

--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t੠kho?n' ELSE 'T੠kho?n ???c c?p nh?t' END;

SELECT A.EMAIL
       ,CASE WHEN P_ACTION='CREATE' THEN A.CREATE_USER ELSE A.LAST_UPDATE_USER END USER_THUC_HIEN
       ,A.FULL_NAME 

INTO V_EMAIL_TO,V_USER,V_FULL_NAME
FROM SYS_USER A
WHERE A.USER_NAME=lower(P_USER_ID);

SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! '|| P_ACTION) INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_SYS_USER_BODY_'||P_ACTION;

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! '|| P_ACTION) INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_SYS_USER_SUB_'||P_ACTION;

SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';

V_BODY := REPLACE(REPLACE(V_BODY,'[FULL_NAME]',V_FULL_NAME),'[DOMAIN]',V_DOMAIN_ICREDIT);

PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('USER',
                                  V_EMAIL_TO,
                                  '',
                                  '',
                                  V_SUBJECT,
                                  V_BODY,--BODY
                                  'SYSTEM',
                                  V_USER,
                                  '',
                                  '',
                                  P_OUT);
--COMMIT;
END;

--G?i email th𮧠bᯠkh?i t?o/di?u ch?nh user
PROCEDURE PR_SEND_EMAIL_RESPONSE (P_CIS_NO                  VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(100);
V_FULL_NAME VARCHAR2(100); 
V_DOMAIN_ICREDIT VARCHAR2(1000); 
P_OUT TYPES.REF_CURSOR;
V_BODY CLOB;
BEGIN

--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t੠kho?n' ELSE 'T੠kho?n ???c c?p nh?t' END;

SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! ') INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_RESPONSE_BODY';

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! ') INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_RESPONSE_SUB';


SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';

FOR R_ROW IN (
                  SELECT B.EMAIL
                         ,B.FULL_NAME  
                         , A.CREATED_USER 
                         ,C.CHANNEL
                         ,NVL(D.REF_NAME_VN,C.STATUS) STATUS_NAME
                  --INTO V_EMAIL_TO,V_FULL_NAME, V_USER
                  FROM CIS_REQUEST_EMAIL A
                  LEFT JOIN SYS_USER B ON A.CREATED_USER=B.USER_NAME
                  LEFT JOIN CIS_REQUEST C ON A.CIS_NO=C.CIS_NO
                  LEFT JOIN sys_refcode D ON C.STATUS=D.REF_CODE AND D.REF_GROUP='STATUS_REQUEST'
                  WHERE A.CIS_NO=P_CIS_NO )
LOOP


    --V_BODY := REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME);

    PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('REQUEST',
                                      R_ROW.EMAIL,
                                      '',
                                      '',
                                      REPLACE(V_SUBJECT,'[CIS_NO]', P_CIS_NO),
                                      REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME),'[CIS_NO]', P_CIS_NO),'[CHANNEL]', R_ROW.CHANNEL),'[STATUS_NAME]', R_ROW.STATUS_NAME),'[DOMAIN]',V_DOMAIN_ICREDIT),--BODY
                                      'SYSTEM',
                                      R_ROW.CREATED_USER,
                                      '',
                                      '',
                                      P_OUT);
--COMMIT;
END LOOP;

END;

--G?i email th𮧠bᯠphꠤuy?t b?n tin
PROCEDURE PR_SEND_EMAIL_TASK(P_TASK_ID VARCHAR2, P_STATUS VARCHAR2 , P_USER VARCHAR2, P_COMMENT VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(500);
V_FULL_NAME VARCHAR2(100); 
V_DOMAIN_ICREDIT VARCHAR2(1000); 
P_OUT TYPES.REF_CURSOR;
V_BODY CLOB; 
BEGIN

--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t੠kho?n' ELSE 'T੠kho?n ???c c?p nh?t' END;

SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! ') INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_TASK_'|| P_STATUS;

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! ') INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_TASK_'||P_STATUS||'_SUB';

SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';


FOR R_ROW IN (
                  SELECT A.ID, B.EMAIL
                         ,B.FULL_NAME  
                         , A.MAKER 
                         ,CASE WHEN P_STATUS='APPROVED' THEN 'Bản tin được phê duyệt'
                               WHEN P_STATUS='REJECTED' THEN 'Bản tin bị từ chối'
                               ELSE 'N/A' END STATUS_NAME
                  --INTO V_EMAIL_TO,V_FULL_NAME, V_USER
                  FROM SYS_TASK_LIST A
                  LEFT JOIN SYS_USER B ON A.MAKER=B.USER_NAME 
                  WHERE A.TASK_ID=P_TASK_ID)
LOOP


    --V_BODY := REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME);

    PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('TASK',
                                      R_ROW.EMAIL,
                                      '',
                                      '',
                                      REPLACE(REPLACE(V_SUBJECT,'[TASK_ID]', 'LO'||P_TASK_ID),'[STATUS_NAME]', R_ROW.STATUS_NAME),
                                      REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME),'[TASK_ID]', 'LO'||R_ROW.ID),'[STATUS_NAME]', R_ROW.STATUS_NAME),'[COMMENT]',P_COMMENT),'[DOMAIN]',V_DOMAIN_ICREDIT),--BODY
                                      'SYSTEM',
                                      P_USER,
                                      '',
                                      '',
                                      P_OUT);
--COMMIT;
END LOOP;

END;


--G?i email th𮧠bᯠcho ng??i dùng bi?t c󠦩le m?i
PROCEDURE PR_SEND_EMAIL_NEW_FILE(P_FILE_NAME VARCHAR2, P_CHANNEL VARCHAR2, P_STATUS VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(500);
V_FULL_NAME VARCHAR2(100); 
V_DOMAIN_ICREDIT VARCHAR2(1000); 
P_OUT TYPES.REF_CURSOR;
V_BODY CLOB; 
BEGIN

--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t੠kho?n' ELSE 'T੠kho?n ???c c?p nh?t' END;

SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! ') INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_REPORT_'||P_CHANNEL||'_'||P_STATUS;

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! ') INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_REPORT_'||P_CHANNEL||'_'||P_STATUS||'_SUB';

SELECT NVL(MAX(A.PAR1),'') INTO V_EMAIL_TO
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_REPORT_'||P_CHANNEL||'_'||P_STATUS||'_EMAIL_TO';

SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';
IF V_EMAIL_TO IS NOT NULL THEN

    PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('REPORT_'||P_CHANNEL,
                                      V_EMAIL_TO,
                                      '',
                                      '',
                                      REPLACE(V_SUBJECT,'[FILE_NAME]', P_FILE_NAME),
                                      REPLACE(REPLACE(V_BODY,'[FILE_NAME]', P_FILE_NAME),'[DOMAIN]',V_DOMAIN_ICREDIT),--BODY
                                      'SYSTEM',
                                      'N/A',
                                      '',
                                      '',
                                      P_OUT);
--COMMIT;
END IF;

END;
END PKG_SYS_EMAIL;

/
--------------------------------------------------------
--  DDL for Package Body PKG_SYSTEM_LOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PKG_SYSTEM_LOG" AS

V_ERRORS     number(10);
V_EXCEPTION varchar2(25):='EXCEPTION';
V_DEBUG varchar2(25):='DEBUG';
V_INFO varchar2(25):='INFO';
/*
Creater: CuongNH2
Created date: 9/1/2018
Description: Lay thong tin cua user
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_Parameter: chi tiet cac parameter
             P_TASK_TYPE: kieu task
             P_IP_CLIENT: client ip
             P_MACHINE: ten machine
*/
Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob) is
begin

   PR_LOG_INFO(P_TASK_NAME, P_STEP_NAME, p_Parameter, 'PR');
/*EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
     ROLLBACK;
      PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME, P_STEP_NAME, SQLCODE, SQLERRM );*/
end;

/*
Creater: CuongNH2
Created date: 18/1/2018
Description: log DEBUG cho cac xu ly DB
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_Parameter: chi tiet cac parameter
*/
Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2) is
begin

   PR_LOG_DEBUG(P_TASK_NAME, P_STEP_NAME, p_Parameter, 'PR');

/*EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME ,
                           P_STEP_NAME ,
                           SQLCODE ,
                           SQLERRM );
      ROLLBACK;*/
end;

/*
Creater: CuongNH2
Created date: 18/1/2018
Description: ghi nhan log EXCEPTION
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_ErrorNumber: ma loi
             p_ErrorMessage: chi tiet noi dung loi
*/
Procedure PR_LOG_EXCEPTION(P_TASK_NAME varchar2,
                           P_STEP_NAME varchar2,
                           p_ErrorNumber varchar2,
                           p_ErrorMessage varchar2) is
begin
   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE,
      ERROR_CODE)
   values
     (cis_sys_ncb.SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      'PR',
      SYSDATE,
      P_STEP_NAME,
      p_ErrorNumber || '.' || p_ErrorMessage, 
      V_EXCEPTION,
      p_ErrorNumber);
   --raise_application_error(p_ErrorNumber,p_ErrorMessage);
EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      null;
end;


  /*
  Creater: SonTA2
  Created date: 30/1/2018
  Description: log INFO cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               P_TASK_TYPE: kieu task
  */
Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob, P_TASK_TYPE varchar2) is
begin
   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE)
   values
     (CIS_SYS_NCB.SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      P_TASK_TYPE,
      SYSDATE,
      P_STEP_NAME,
      SUBSTR(p_Parameter,1,4000), 
      V_INFO);
EXCEPTION  -- exception handlers begin
     WHEN OTHERS THEN  -- handles all other errors
       V_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;
       FOR I IN 1 .. V_ERRORS
       LOOP
         PR_LOG_EXCEPTION(P_TASK_NAME,P_STEP_NAME,
                         SQL%BULK_EXCEPTIONS (I).ERROR_CODE,
                         SQLERRM (-SQL%BULK_EXCEPTIONS (I).ERROR_CODE) );
       END LOOP;
      raise;
end;

/*
Creater: CuongNH2
Created date: 18/1/2018
Description: log DEBUG cho cac xu ly DB
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_Parameter: chi tiet cac parameter
*/
Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2, P_TASK_TYPE varchar2) is
begin

   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE)
   values
     (CIS_SYS_NCB.SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      P_TASK_TYPE,
      SYSDATE,
      P_STEP_NAME,
      SUBSTR(p_Parameter,1,4000), 
      V_DEBUG);

/*EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME ,
                           P_STEP_NAME ,
                           SQLCODE ,
                           SQLERRM );
      ROLLBACK;*/
end;

/*
Creater: CuongNH2
Created date: 23/1/2018
Description: ghi nhan log EXCEPTION khong throw
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_ErrorNumber: ma loi
             p_ErrorMessage: chi tiet noi dung loi
*/
Procedure PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME varchar2,
                           P_STEP_NAME varchar2,
                           p_ErrorNumber varchar2,
                           p_ErrorMessage clob,
                           P_TASK_TYPE varchar2 ) is
BEGIN
	
   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE,
      ERROR_CODE)
   values
     (CIS_SYS_NCB.SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      P_TASK_TYPE,
      SYSDATE,
      P_STEP_NAME,
      p_ErrorNumber || '.' || p_ErrorMessage, 
      V_EXCEPTION,
      p_ErrorNumber);
EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      ROLLBACK;
end;


Procedure PR_LOG_ACTIVITY(P_APPLICATION_ID VARCHAR2,
                            P_RESOURCE_URL VARCHAR2,
                            P_ACCESS_USER VARCHAR2,
                            P_ACCESS_STATUS VARCHAR2,
                            P_LOG_MESSAGE CLOB,
                            P_RESOURCE_TYPE VARCHAR2,
                            P_RPT_CODE VARCHAR2,
                            P_RESOURCE_ACTION VARCHAR2,
                            P_CLIENT_IP VARCHAR2,
                            P_USER_AGENT VARCHAR2,
                            p_out OUT types.ref_cursor) IS
BEGIN
   INSERT INTO SYS_RESOURCEACCESSMANAGEMENT
     (ID,
      APPLICATION_ID,
      RESOURCE_URL,
      ACCESS_USER,
      ACCESS_DATE,
      ACCESS_STATUS,
      LOG_MESSAGE,
      RESOURCE_TYPE,
      RPT_CODE,
      RESOURCE_ACTION,
      CLIENT_IP,
      USER_AGENT)
   VALUES
     (CIS_SYS_NCB.SEQ_SYS_RES_ACCESSMANAGEMENT.NEXTVAL,
      P_APPLICATION_ID ,
      P_RESOURCE_URL ,
      P_ACCESS_USER ,
      SYSDATE ,
      P_ACCESS_STATUS ,
      P_LOG_MESSAGE ,
      P_RESOURCE_TYPE ,
      P_RPT_CODE ,
      P_RESOURCE_ACTION ,
      P_CLIENT_IP ,
      P_USER_AGENT );

      OPEN p_out FOR
      SELECT 'SUCCESS' STATUS FROM DUAL;
EXCEPTION  -- exception handlers begin
     WHEN OTHERS THEN  -- handles all other errors
       V_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;
       FOR I IN 1 .. V_ERRORS
       LOOP
         PR_LOG_EXCEPTION('PR_LOG_ACTIVITY','INSERT',
                         SQL%BULK_EXCEPTIONS (I).ERROR_CODE,
                         SQLERRM (-SQL%BULK_EXCEPTIONS (I).ERROR_CODE) );
       END LOOP;
      raise;
end;
end PKG_SYSTEM_LOG;

/
--------------------------------------------------------
--  DDL for Package Body PKG_UTILITY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PKG_UTILITY" is

/*
Creater: CuongNH2
Create date: 19/4/2018
Description: Xoa dau va chuyen thanh chu thuong
*/
FUNCTION RemoveSignVietnamess(P_STR IN VARCHAR2) RETURN clob
IS
  V_RESULT clob;
BEGIN

V_RESULT := TRANSLATE(P_STR,
'áàảãạăắằẳẵặâấầẩẫậđéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵÁÀẢÃẠĂẮẰẲẴẶÂẤẦẨẪẬĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ',
'aaaaaaaaaaaaaaaaadeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyyAAAAAAAAAAAAAAAAADEEEEEEEEEEEIIIIIOOOOOOOOOOOOOOOOOUUUUUUUUUUUYYYYY');

  RETURN lower(V_RESULT);
END;


/*
Creater: CuongNH2
Create date: 11/7/2018
Description: Format number with comma
*/
FUNCTION FORMAT_NUMBER(P_STR IN VARCHAR2) RETURN VARCHAR2
IS
  V_RESULT VARCHAR2(50);
BEGIN

SELECT  TRIM(TO_CHAR(P_STR, '99G999G999G999G999G999G999', 'NLS_NUMERIC_CHARACTERS=",."')) INTO V_RESULT
FROM    dual;

  RETURN V_RESULT;
END;


FUNCTION IS_NUMBER(P_STR IN VARCHAR2) RETURN NUMBER
IS
  v_num NUMBER;
BEGIN
  v_num := TO_NUMBER(P_STR);
  RETURN v_num;
EXCEPTION
WHEN VALUE_ERROR THEN
  RETURN 0;
END;

FUNCTION RemoveSpecialCharactor(P_STR IN clob) RETURN clob
IS
  V_RESULT clob;
BEGIN

V_RESULT := replace(P_STR,'&amp;','__');
V_RESULT := replace(replace(V_RESULT,'&quot;','"'),'"','&quot;');
V_RESULT := replace(replace(V_RESULT,'&apos;',''''),'''','&apos;'); 
V_RESULT := replace(replace(replace(V_RESULT,'<BR>','&lt;BR &gt;') ,'</BR>','&lt;/BR &gt;'),'Ð','Ð');
V_RESULT := replace(V_RESULT,'__','&amp;');

  RETURN V_RESULT;
END;
end PKG_UTILITY;

commit;