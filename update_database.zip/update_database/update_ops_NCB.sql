--------------------------------------------------------
--  File created - Thursday-February-22-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package PCK_CIC_TOKEN
--------------------------------------------------------
SET DEFINE OFF;
  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_CIC_TOKEN" AS 

/*
Created: 05/01/2023
Creater: CuongNH2
Note: L?y token cu?i cùng 
*/
PROCEDURE PR_GET_CIC_TOKEN (p_out    OUT SYS_REFCURSOR);


/*
Created: 05/01/2023
Creater: CuongNH2
Note: T?o m?i token
*/
PROCEDURE PR_UPDATE_CIC_TOKEN (p_token VARCHAR2,
                        p_thoi_gian_bat_dau VARCHAR2,
                        p_token_het_han VARCHAR2,
                        p_mat_khau_het_han   VARCHAR2,
                        p_ghi_chu VARCHAR2,
                        p_out    OUT SYS_REFCURSOR);

END PCK_CIC_TOKEN;


/
--------------------------------------------------------
--  DDL for Package PCK_DATA_REPORT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_DATA_REPORT" 
AS
PROCEDURE PR_GET_PCB_XXXSJF (P_REPORT_MONTH NVARCHAR2, p_out OUT SYS_REFCURSOR);

PROCEDURE PR_GET_PCB_XXXCNF (P_REPORT_MONTH NVARCHAR2, P_DATA_TYPE nvarchar2, p_out OUT SYS_REFCURSOR);

FUNCTION FORMAT_DATA(P_STR IN VARCHAR2,P_LENGTH IN INT) RETURN VARCHAR2;

FUNCTION FORMAT_NGAY_SINH(P_STR IN VARCHAR2) RETURN VARCHAR2;

FUNCTION FORMAT_ROWNUM(P_STR IN VARCHAR2,P_LENGTH IN INT) RETURN VARCHAR2;

PROCEDURE PR_NEW_REPORT_FILE_PCB (P_REPORT_MONTH NVARCHAR2, P_USER NVARCHAR2);

PROCEDURE PR_NEW_REPORT_FILE_CIC (p_report_month nvarchar2, 
                                p_user nvarchar2,
                                p_check_sum_md5 nvarchar2,
                                p_error_code nvarchar2,
                                p_error_msg nvarchar2,
                                p_file_name nvarchar2,
                                p_file_path nvarchar2,
                                p_file_size number , 
                                p_file_type nvarchar2,
                                p_file_path_encode nvarchar2, 
                                p_report_period nvarchar2,
                                p_file_status nvarchar2,
                                p_channel  nvarchar2,
                                p_out out sys_refcursor);

PROCEDURE PR_CREATED_FILE_PCB (P_REPORT_MONTH NVARCHAR2, 
                                P_USER NVARCHAR2,
                                P_CHECK_SUM_MD5 NVARCHAR2,
                                P_ERROR_CODE NVARCHAR2,
                                P_ERROR_MSG NVARCHAR2,
                                P_FILE_NAME NVARCHAR2,
                                P_FILE_PATH NVARCHAR2,
                                P_FILE_SIZE NUMBER,
                                P_FILE_TYPE NVARCHAR2,
                                P_FILE_PATH_ENCODE NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);

PROCEDURE PR_SEND_REPORT_FILE_PCB (P_REPORT_MONTH NVARCHAR2,
                                 P_FILE_STATUS VARCHAR2, 
                                 P_ERROR_CODE NVARCHAR2,
                                 P_ERROR_MSG NVARCHAR2,
                                 P_USER NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);
PROCEDURE PR_SEND_REPORT_FILE_CIC (P_FILE_NAME NVARCHAR2,
                                 P_FILE_STATUS VARCHAR2, 
                                 P_ERROR_CODE NVARCHAR2,
                                 P_ERROR_MSG NVARCHAR2,
                                 P_USER NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);
PROCEDURE PR_SEARCH_DATA (P_KEYWORD NVARCHAR2,
                          P_FROM_DATE DATE,
                          P_TO_DATE DATE,
                          P_FILE_STATUS VARCHAR2,
                           p_channel VARCHAR2,
                          P_USER VARCHAR2,
                          p_file_name varchar2,
                          p_out OUT SYS_REFCURSOR);

PROCEDURE PR_APPROVAL_FILE_PCB (P_REPORT_MONTH NVARCHAR2, P_FILE_STATUS VARCHAR2, p_reject_comment VARCHAR2,P_USER NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);
PROCEDURE PR_APPROVAL_FILE_CIC (P_REPORT_MONTH NVARCHAR2, P_FILE_STATUS VARCHAR2, p_reject_comment VARCHAR2,P_USER NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);
PROCEDURE PR_GET_CIC_DATA_REPORT (P_FILE_NAME NVARCHAR2, P_FILE_TYPE NVARCHAR2, P_FROM NVARCHAR2, P_TO NVARCHAR2 , p_out OUT SYS_REFCURSOR);

PROCEDURE PR_CREATED_FILE_CIC (P_REPORT_MONTH NVARCHAR2, 
                                P_USER NVARCHAR2,
                                P_CHECK_SUM_MD5 NVARCHAR2,
                                P_ERROR_CODE NVARCHAR2,
                                P_ERROR_MSG NVARCHAR2,
                                P_FILE_NAME NVARCHAR2,
                                P_FILE_PATH NVARCHAR2,
                                P_FILE_SIZE NUMBER,
                                P_FILE_TYPE NVARCHAR2,
                                P_FILE_PATH_ENCODE NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);

PROCEDURE PR_UPDATE_CIC_RESPONSE (p_file_name NVARCHAR2,
                                 p_cic_status VARCHAR2, 
                                 p_cic_response clob,
                                 p_error_msg VARCHAR2,
                                 p_user NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);

PROCEDURE PR_GET_LOG_REPORT_FILE (p_file_name NVARCHAR2,
                                 p_user NVARCHAR2,
                                p_out OUT SYS_REFCURSOR);
END PCK_DATA_REPORT;


/
--------------------------------------------------------
--  DDL for Package PCK_CIS_REQUEST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_CIS_REQUEST" AS
  /* DoNB 26/03/2019 */
  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

    PROCEDURE PR_CREATE_CIS_REQUEST (
        p_id CIS_REQUEST.ID%TYPE,
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_channel CIS_REQUEST.CHANNEL%TYPE,
        p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
        p_member_code CIS_REQUEST.MEMBER_CODE%TYPE,
        p_cic_code CIS_REQUEST.CIC_CODE%TYPE,
        p_id_no CIS_REQUEST.ID_NO%TYPE,
        p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
        p_username_request CIS_REQUEST.USERNAME_REQUEST%TYPE,
        p_branch_code CIS_REQUEST.BRANCH_CODE%TYPE,
        p_created_date CIS_REQUEST.CREATED_DATE%TYPE,
        p_requested_date CIS_REQUEST.REQUESTED_DATE%TYPE,
        p_request_data CIS_REQUEST.REQUEST_DATA%TYPE,
        p_err_code CIS_REQUEST.ERR_CODE%TYPE,
        p_err_msg CIS_REQUEST.ERR_MSG%TYPE,
        p_address CIS_REQUEST.ADDRESS%TYPE,
        p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
        p_note CIS_REQUEST.NOTE%TYPE,
        p_customer_name CIS_REQUEST.CUSTOMER_NAME%TYPE,
        p_customer_code CIS_REQUEST.CUSTOMER_CODE%TYPE,
        p_response_date CIS_REQUEST.RESPONSE_DATE%TYPE,
        p_email CIS_REQUEST.EMAIL%TYPE,
        p_last_version CIS_REQUEST.LAST_VERSION%TYPE,
        p_flag CIS_REQUEST.FLAG%TYPE,
        p_msg_id CIS_REQUEST.MSG_ID%TYPE,
        p_application_id CIS_REQUEST.APPLICATION_ID%TYPE,
        p_maker CIS_REQUEST.MAKER%TYPE,
        p_task_id CIS_REQUEST.TASK_ID%TYPE,
        p_encode_request cis_request.encode_request%TYPE,
        p_borrower CIS_REQUEST.BORROWER%TYPE,
        p_pcb_code CIS_REQUEST.PCB_CODE%TYPE,
        p_ccy CIS_REQUEST.CCY%TYPE,
        p_amount_fin_capital CIS_REQUEST.AMOUNT_FIN_CAPITAL%TYPE,
        p_total_instalment CIS_REQUEST.TOTAL_INSTALMENT%TYPE,
        p_credit_limit CIS_REQUEST.CREDIT_LIMIT%TYPE,
        p_gender CIS_REQUEST.GENDER%TYPE,
        p_dob CIS_REQUEST.DOB%TYPE,
        p_doc_type CIS_REQUEST.DOC_TYPE%TYPE,
        p_pay_periodicity CIS_REQUEST.PAY_PERIODICITY%TYPE,
        p_operation_type CIS_REQUEST.OPERATION_TYPE%TYPE,
        p_country_of_birth CIS_REQUEST.COUNTRY_OF_BIRTH%TYPE,
        p_request_id CIS_REQUEST.REQUEST_ID%TYPE,
        p_frequent_contacts CIS_REQUEST.FREQUENT_CONTACTS%TYPE,
        p_phone_number CIS_REQUEST.PHONE_NUMBER%TYPE,
        p_user varchar2,
        p_client_ip varchar2,
        p_user_agent varchar2,
        p_nam_tai_chinh varchar2,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_UPDATE_STATUS_CIS_REQUEST (
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_request_data CIS_REQUEST.REQUEST_DATA%TYPE,
        p_msg_id CIS_REQUEST.MSG_ID%TYPE,
        p_err_code CIS_REQUEST.ERR_CODE%TYPE,
        p_err_msg CIS_REQUEST.ERR_MSG%TYPE,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_GET_LIST_CIS_REQUEST (
        p_id_no CIS_REQUEST.ID_NO%TYPE,
        p_member_code CIS_REQUEST.MEMBER_CODE%TYPE,
        p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
        p_customer_name CIS_REQUEST.CUSTOMER_NAME%TYPE,
        p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
        p_address CIS_REQUEST.ADDRESS%TYPE,
        p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
        p_cic_code CIS_REQUEST.CIC_CODE%TYPE,
        p_customer_code CIS_REQUEST.CUSTOMER_CODE%TYPE,
        p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_maker CIS_REQUEST.MAKER%TYPE,
        p_from_date CIS_REQUEST.REQUESTED_DATE%TYPE,
        p_to_date CIS_REQUEST.REQUESTED_DATE%TYPE,
        p_task_id CIS_REQUEST.TASK_ID%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_channel CIS_REQUEST.CHANNEL%TYPE,
        p_user varchar2,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_GET_CIS_REQUEST_INFO (
        p_cis_no CIS_REQUEST.ID_NO%TYPE,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_CHECK_REQUEST_INFO ( p_param1 varchar2,
                                      p_param2 varchar2,
                                      p_param3 varchar2,
                                      p_param4 varchar2,
                                      p_param5 varchar2,
                                      p_param6 varchar2,
                                      p_param7 varchar2,
                                      p_param8 varchar2,
                                      p_channel varchar2,
                                      p_user varchar2,
                                      p_client_ip varchar2,
                                      p_user_agent varchar2,
                                      p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_CHECK_BATCH_REQUEST_INFO (p_param1 varchar2,
                                        p_param2 varchar2,
                                        p_param3 varchar2,
                                        p_param4 varchar2,
                                        p_param5 varchar2,
                                        p_param6 varchar2,
                                        p_param7 varchar2,
                                        p_param8 varchar2,
                                        p_channel varchar2,
                                        p_user varchar2,
                                        p_client_ip varchar2,
                                        p_user_agent varchar2,
                                        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_GET_LOT_NO (
        p_user                         IN     VARCHAR2,
        p_client_ip                    IN     VARCHAR2,
        p_user_agent                   IN     VARCHAR2,
        p_out    OUT SYS_REFCURSOR);

   FUNCTION PR_STATUS_MATRIX_PCB( p_product_code  varchar2,
                                      p_id_no  varchar2,
                                      p_doc_type  varchar2,
                                      P_register_no varchar2 ) RETURN VARCHAR2;

   FUNCTION PR_STATUS_MATRIX_CIC(p_id_no CIS_REQUEST.ID_NO%TYPE,
                              p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
                              p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
                              p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
                              p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
                              p_cic_code varchar2) RETURN VARCHAR2;

   FUNCTION PR_STATUS_MATRIX_TS ( p_phone_number varchar2,
                                      p_product_code varchar2,
                                      p_id_no varchar2) RETURN VARCHAR2;

   FUNCTION PR_CHECK_BLACK_LIST ( p_id_no varchar2) RETURN VARCHAR2;

   PROCEDURE PR_ADD_CIS_REQUEST_EMAIL (
        P_CIS_NO CIS_REQUEST.CIS_NO%TYPE,
        P_USER                         IN     VARCHAR2,
        P_CLIENT_IP                    IN     VARCHAR2,
        P_USER_AGENT                   IN     VARCHAR2,
        P_OUT    OUT SYS_REFCURSOR);

   PROCEDURE PR_GET_LIST_CIS_SENT (
        P_STATUS VARCHAR2,
        P_CHANNEL                         IN     VARCHAR2,
        P_USER                    IN     VARCHAR2,
        P_OUT    OUT SYS_REFCURSOR);

   --FIX Loi SENDDING - 7/4/2021
   PROCEDURE PR_GET_LIST_CIS_NEW (
        P_STATUS VARCHAR2,
        P_CHANNEL                         IN     VARCHAR2,
        P_USER                    IN     VARCHAR2,
        P_OUT    OUT SYS_REFCURSOR);

   PROCEDURE PR_AUTO_REJECT_REQUEST;

END PCK_CIS_REQUEST;


/
--------------------------------------------------------
--  DDL for Package PCK_CIS_OTHER_REQUEST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_CIS_OTHER_REQUEST" is

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o y굠c?u t? h? th?ng khᣊ*/
PROCEDURE PR_CREATE_OTHER_REQUEST (p_application_id VARCHAR2,
                                        p_source_request_id VARCHAR2,
                                        p_maker VARCHAR2, 
                                        p_customer_name VARCHAR2,
                                        p_customer_address VARCHAR2,
                                        p_client_ip VARCHAR2,
                                        p_user_agent VARCHAR2, 
                                        p_product_code VARCHAR2, 
                                        p_customer_type VARCHAR2, 
                                        p_batch_id VARCHAR2, 
                                        p_out    OUT SYS_REFCURSOR);

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o chi ti?t y굠c?u t? h? th?ng khᣊ*/
PROCEDURE PR_CREATE_OTHER_REQUEST_DETAIL (P_REQUEST_ID VARCHAR2, 
                                    P_SOURCE_REQUEST_ID VARCHAR2,
                                    P_CUSTOMER_ID_TYPE VARCHAR2,
                                    P_CUSTOMER_ID VARCHAR2, 
                                    p_out    OUT SYS_REFCURSOR);

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o chi ti?t th𮧠tin CIC CODE t? CIC
*/
PROCEDURE PR_CREATE_OTHER_REQUEST_CHECK (P_REQUEST_ID VARCHAR2,
                                        P_CUSTOMER_ID_TYPE VARCHAR2,
                                        P_CUSTOMER_ID VARCHAR2,
                                        P_CUST_CODE VARCHAR2,
                                        P_CIC_CUST_NAME VARCHAR2,
                                        P_CIC_CUST_ADDRESS VARCHAR2,
                                        P_CUST_TYPE VARCHAR2,
                                        P_CUST_TAX VARCHAR2,
                                        P_CUST_ID_NO VARCHAR2,
                                        P_CUST_REG VARCHAR2,
                                        P_CIC_CODE VARCHAR2,
                                        P_CIC_DATA VARCHAR2, 
                                        p_out    OUT SYS_REFCURSOR);     

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o phi?u y굠c?u h?i tin
*/
PROCEDURE PR_GENERATE_REQUEST_TO_CIC (P_REQUEST_ID VARCHAR2,
                                        p_out    OUT SYS_REFCURSOR); 

FUNCTION PR_STATUS_MATRIX_CIC(p_id_no CIS_REQUEST.ID_NO%TYPE,
                              p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
                              p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
                              p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
                              p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
                              p_cic_code varchar2) RETURN VARCHAR2;

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:Th?c hi?n t󺀠toᮠk?t qu? tr? l?i
*/
PROCEDURE PR_GENERATE_RESPONSE (P_REQUEST_ID VARCHAR2,
                                        p_out    OUT SYS_REFCURSOR); 

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:L?y b?n tin tr? l?i
*/
PROCEDURE PR_GET_RESPONSE (P_REQUEST_ID VARCHAR2, p_out    OUT SYS_REFCURSOR); 

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:L?y chi ti?t b?n tin tr? l?i
*/
PROCEDURE PR_GET_RESPONSE_DETAIL (P_RESPONSE_ID VARCHAR2, p_out    OUT SYS_REFCURSOR); 

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des: C?p nh?t tr?ng th᩠b?n tr? l?i tin
*/
PROCEDURE PR_UPDATE_OTHER_RESPONSE (P_RESPONSE_ID VARCHAR2,
                                   P_RESPONSE_STATUS VARCHAR2,
                                   P_RESPONSE_MESSAGE VARCHAR2,
                                   P_RESPONSE_DATA VARCHAR2,
                                   p_out    OUT SYS_REFCURSOR); 

/*
Creater: CuongNH2
Create Date: 6/12/2021
Des: T쭠ki?m cᣠy굠c?u h?i tin theo ?i?u ki?n
*/
PROCEDURE PR_SEARCH_OTHER_REQUEST (p_application_id varchar2,
                                   p_request_id varchar2,
                                   p_other_request_id varchar2, 
                                   p_batch_id varchar2, 
                                   p_from_date varchar2, 
                                   p_to_date varchar2, 
                                   p_out    out sys_refcursor); 

/*
Creater: CuongNH2
Create Date: 25/2/2022
Des: Th?c hi?n ki?m tra v࠴?o l?p b?n tin tr? l?i
*/
PROCEDURE PR_CHECK_OTHER_REQUEST (p_application_id varchar2,
                                   p_request_id varchar2,
                                   p_other_request_id varchar2, 
                                   p_batch_id varchar2, 
                                   p_out    out sys_refcursor); 

PROCEDURE PR_CHECK_OTHER_REQ_RECIVED;
end;


/
--------------------------------------------------------
--  DDL for Package PCK_CIS_DASHBOARD
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_CIS_DASHBOARD" AS

/*
CREATE: CUONGNH
DESCRIPTION: TOP 10 BAN HOI TIN GAN NHAT
*/
PROCEDURE PR_LIST_TOP_REQUEST ( p_user varchar2,
                                p_client_ip varchar2,
                                p_user_agent varchar2,
                                p_out    OUT SYS_REFCURSOR) ;

/*
CREATE: CUONGNH
DESCRIPTION: SUMMARY ON MONTH
*/
PROCEDURE PR_LIST_REQUEST_MONTHLY ( p_user varchar2,
                                    p_client_ip varchar2,
                                    p_user_agent varchar2,
                                    p_out    OUT SYS_REFCURSOR) ;

/*
CREATE: CUONGNH
DESCRIPTION: SUMMARY ON MONTH
*/
PROCEDURE PR_LIST_REQ_PROD_MONTHLY ( p_user varchar2,
                                    p_client_ip varchar2,
                                    p_user_agent varchar2,
                                    p_out    OUT SYS_REFCURSOR) ;
/*
CREATE: CUONGNH
DESCRIPTION: TINH TOAN BIEU DO
*/
PROCEDURE PR_AGG_DASHBOARD;
/*
CREATE: CUONGNH
DESCRIPTION: VIEW CHAR
*/
PROCEDURE PR_LIST_CHAR ( p_user varchar2,
                          p_client_ip varchar2,
                          p_user_agent varchar2,
                          p_out    OUT SYS_REFCURSOR) ;

/*
CREATE: CUONGNH
DESCRIPTION: VIEW USERINFO
*/
PROCEDURE PR_USERINFO ( p_user varchar2,
                          p_client_ip varchar2,
                          p_user_agent varchar2,
                          p_out    OUT SYS_REFCURSOR) ;
END;


/
--------------------------------------------------------
--  DDL for Package PCK_CIS_RESPONSE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_CIS_RESPONSE" AS
  /* DoNB 26/03/2019 */
  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
    PROCEDURE PR_CREATE_CIS_RESPONSE (
        p_id CIS_RESPONSE.ID%TYPE,
        p_cis_no CIS_RESPONSE.CIS_NO%TYPE,
        p_cic_code CIS_RESPONSE.CIC_CODE%TYPE,
        p_member_code CIS_RESPONSE.MEMBER_CODE%TYPE,
        p_tax_code CIS_RESPONSE.TAX_CODE%TYPE,
        p_id_no CIS_RESPONSE.ID_NO%TYPE,
        p_product_code CIS_RESPONSE.PRODUCT_CODE%TYPE,
        p_response_date CIS_RESPONSE.RESPONSE_DATE%TYPE,
        p_status_code_cic CIS_RESPONSE.STATUS_CODE_CIC%TYPE,
        p_created_date CIS_RESPONSE.CREATED_DATE%TYPE,
        p_err_code CIS_RESPONSE.ERR_CODE%TYPE,
        p_err_msg CIS_RESPONSE.ERR_MSG%TYPE,
        p_response_data CIS_RESPONSE.RESPONSE_DATA%TYPE,
        p_status CIS_RESPONSE.STATUS%TYPE,
        p_version_no CIS_RESPONSE.VERSION_NO%TYPE,
        p_execute_date CIS_RESPONSE.EXECUTE_DATE%TYPE,
        p_msg_id CIS_RESPONSE.MSG_ID%TYPE,
        p_out    OUT SYS_REFCURSOR);


    PROCEDURE PR_GET_CIS_RESPONSE_INFO (
        p_id CIS_RESPONSE.ID%TYPE,
        p_cis_no CIS_RESPONSE.CIS_NO%TYPE,
        p_cic_code CIS_RESPONSE.CIC_CODE%TYPE,
        p_member_code CIS_RESPONSE.MEMBER_CODE%TYPE,
        p_tax_code CIS_RESPONSE.TAX_CODE%TYPE,
        p_id_no CIS_RESPONSE.ID_NO%TYPE,
        p_product_code CIS_RESPONSE.PRODUCT_CODE%TYPE,
        p_response_date CIS_RESPONSE.RESPONSE_DATE%TYPE,
        p_status_code_cic CIS_RESPONSE.STATUS_CODE_CIC%TYPE,
        p_created_date CIS_RESPONSE.CREATED_DATE%TYPE,
        p_err_code CIS_RESPONSE.ERR_CODE%TYPE,
        p_err_msg CIS_RESPONSE.ERR_MSG%TYPE,
        p_response_data CIS_RESPONSE.RESPONSE_DATA%TYPE,
        p_status CIS_RESPONSE.STATUS%TYPE,
        p_version_no CIS_RESPONSE.VERSION_NO%TYPE,
        p_execute_date CIS_RESPONSE.EXECUTE_DATE%TYPE,
        p_msg_id CIS_RESPONSE.MSG_ID%TYPE,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_LIST_CIS_RESPONSE_FOR_PASER (
        p_status varchar2, 
        p_channel varchar2, 
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_CIS_RESPONSE_CHANGE_STATUS (
        p_status varchar2, 
        p_cis_no varchar2, 
        p_id varchar2, 
        p_out    OUT SYS_REFCURSOR);

END PCK_CIS_RESPONSE;


/
--------------------------------------------------------
--  DDL for Package PCK_DATA_REPORT_FROM_CIC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_DATA_REPORT_FROM_CIC" AS 

/*
Select file by file name
*/

PROCEDURE PR_GET_FILE_BY_NAME(P_ID VARCHAR2,
                        P_FILE_NAME VARCHAR2,
                        P_FILE_STATUS VARCHAR2, 
                        P_RESPONSE_DATE VARCHAR2,
                        P_FILE_PATH VARCHAR2,
                        P_CHECK_SUM_MD5 VARCHAR2, 
                        p_out    OUT SYS_REFCURSOR);

PROCEDURE PR_UPDATE_STATUS_FILE(P_ID VARCHAR2,
                        P_FILE_NAME VARCHAR2,
                        P_FILE_STATUS VARCHAR2, 
                        P_RESPONSE_DATE VARCHAR2,
                        P_FILE_PATH VARCHAR2,
                        P_CHECK_SUM_MD5 VARCHAR2, 
                        p_out    OUT SYS_REFCURSOR);

END PCK_DATA_REPORT_FROM_CIC;


/
--------------------------------------------------------
--  DDL for Package PCK_REPORT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_REPORT" is
/*
CREATE: CUONGNH
DESCRIPTION: 5.6.1.  ICR.06.01 - Bᯠcᯠtruy c?p h? th?ng
*/
PROCEDURE RPT_ICR0601 ( p_page VARCHAR2,
                        p_limit VARCHAR2,
                        P_FROM_DATE VARCHAR2,
                        P_TO_DATE   VARCHAR2,
                        P_USER_NAME VARCHAR2,
                        P_BRANCH_CODE    VARCHAR2,
                        P_RESOURCE_URL    VARCHAR2,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) ;

/*
CREATE: CUONGNH
DESCRIPTION: 5.6.2.  ICR.06.02 - Bᯠcᯠqu?n lý ng??i dùng
*/
PROCEDURE RPT_ICR0602 ( P_BRANCH_CODE    VARCHAR2,
                        P_KEYWORD        VARCHAR2,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) ;


/*
CREATE: CUONGNH
DESCRIPTION: 5.6.3.  ICR.06.03 - Bᯠcᯠchi ti?t tra c?u tin theo t?ng b?n h?i tin
*/
PROCEDURE RPT_ICR0603 ( P_BRANCH_CODE    VARCHAR2,
                        P_CHANNEL        VARCHAR2,
                        P_PRODUCT_CODE        VARCHAR2,
                        P_FROM_DATE        DATE,
                        P_TO_DATE        DATE,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_KEYWORD VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) ;

/*
CREATE: CUONGNH
DESCRIPTION: 5.6.4.  ICR.06.04 - Bᯠcᯠchi ti?t tra c?u t?ng h?p theo user h?i tin
*/
PROCEDURE RPT_ICR0604 ( P_BRANCH_CODE    VARCHAR2,
                        P_CHANNEL        VARCHAR2,
                        P_PRODUCT_CODE        VARCHAR2,
                        P_FROM_DATE        DATE,
                        P_TO_DATE        DATE,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_KEYWORD VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) ;
end PCK_REPORT;


/
--------------------------------------------------------
--  DDL for Package PCK_REPORT_FROM_CIC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_REPORT_FROM_CIC" AS 

/*
KHOI TAO FILE MOI
*/
PROCEDURE PR_CREATE_FILE(P_ID VARCHAR2,
                        P_FILE_NAME VARCHAR2,
                        P_FILE_STATUS VARCHAR2, 
                        P_RESPONSE_DATE VARCHAR2,
                        P_FILE_PATH VARCHAR2,
                        P_CHECK_SUM_MD5 VARCHAR2, 
                        p_out    OUT SYS_REFCURSOR);

PROCEDURE PR_UPDATE_FILE(P_ID VARCHAR2,
                        P_FILE_NAME VARCHAR2,
                        P_FILE_STATUS VARCHAR2, 
                        P_RESPONSE_DATE VARCHAR2,
                        P_FILE_PATH VARCHAR2,
                        P_CHECK_SUM_MD5 VARCHAR2, 
                        p_out    OUT SYS_REFCURSOR);

PROCEDURE PR_GET_FILE(P_ID VARCHAR2,
                        P_FILE_NAME VARCHAR2,
                        P_FILE_STATUS VARCHAR2, 
                        P_RESPONSE_DATE VARCHAR2,
                        P_FILE_PATH VARCHAR2,
                        P_CHECK_SUM_MD5 VARCHAR2, 
                        p_out    OUT SYS_REFCURSOR);

END PCK_REPORT_FROM_CIC;


/
--------------------------------------------------------
--  DDL for Package PCK_REQUEST_LOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_REQUEST_LOG" is

  -- Author  : CuongNH
  -- Created : 24/8/2020
  -- Purpose : Luu log g?i request sang partner

  /*
  Creater: CuongNH2
  Created date:  24/8/2020
  Description: Luu log g?i request sang partner  
  */
  Procedure PR_LOG_INFO(P_REQUEST_ID varchar2,
                        P_MSG_TYPE varchar2,
                        P_MSG_DATA clob,
                        P_ERROR_CODE varchar2,
                        P_ERROR_MSG clob,
                        P_END_POINT varchar2, 
                        P_REQUEST_DATE varchar2, 
                        P_ADDITION_INFO varchar2,
                        p_out OUT types.ref_cursor);


end PCK_REQUEST_LOG;


/
--------------------------------------------------------
--  DDL for Package PCK_TOKEN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PCK_TOKEN" AS 

PROCEDURE PR_GET_TOKEN (p_out    OUT SYS_REFCURSOR);

END PCK_TOKEN;


/
--------------------------------------------------------
--  DDL for Package PKG_CIC_GROUP_DEBT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PKG_CIC_GROUP_DEBT" 
AS
    /******************************************************************************
       NAME:       PKG_CIC_GROUP_DEBT
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        31/07/2020      dodti       1. Created this package.
    ******************************************************************************/

    PROCEDURE pr_get_list_cic_group_debt (
        p_text_search             VARCHAR2,
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_rpt_dt10                VARCHAR2,
        p_cst_cd                  VARCHAR2,
        p_cst_nm                  VARCHAR2,
        p_cic_code                VARCHAR2,
        p_bal                     VARCHAR2,
        p_group_debt              VARCHAR2,
        p_low_group_debt          VARCHAR2,
        p_member_code             VARCHAR2,
        p_user             IN     VARCHAR2,
        p_from_date             VARCHAR2,
        p_to_date             VARCHAR2,
        p_out                 OUT types.ref_cursor);

PROCEDURE pr_insert_record(
        p_id                      VARCHAR2,
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_rpt_dt10                VARCHAR2,
        p_cst_cd                  VARCHAR2,
        p_cst_nm                  VARCHAR2,
        p_cic_code                VARCHAR2,
        p_bal                     NUMBER,
        p_group_debt              VARCHAR2,
        p_low_group_debt          VARCHAR2,
        p_member_code             VARCHAR2,
        p_cst_id             VARCHAR2,
        p_address             VARCHAR2,
        p_user             IN     VARCHAR2,
        p_out                 OUT types.ref_cursor);

PROCEDURE pr_delete_record(
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_user             IN     VARCHAR2,
        p_out                 OUT types.ref_cursor);

END PKG_CIC_GROUP_DEBT;


/
--------------------------------------------------------
--  DDL for Package PKG_FRAUDULENCE_CUSTOMER
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PKG_FRAUDULENCE_CUSTOMER" AS
    PROCEDURE pr_list_fraudulence_customer(p_customer_code cis_fraudulence_customer.customer_code%TYPE ,
                               p_customer_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_report_date_from cis_fraudulence_customer.report_date%TYPE,
                               p_report_date_to cis_fraudulence_customer.report_date%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_cic_code cis_fraudulence_customer.cic_code%TYPE,
                                p_status cis_fraudulence_customer.cic_code%TYPE,
                                p_from_date                DATE,
                               p_to_date                  DATE,
                               p_out OUT types.ref_cursor);

    PROCEDURE pr_create_fraudulence_customer(p_cic_code cis_fraudulence_customer.cic_code%TYPE ,
                               p_customer_type cis_fraudulence_customer.customer_type%TYPE,
                               p_customer_code cis_fraudulence_customer.customer_code%TYPE,
                               p_customer_name cis_fraudulence_customer.customer_name%TYPE,
                               p_customer_full_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_customer_short_name cis_fraudulence_customer.customer_short_name%TYPE,
                               p_customer_add cis_fraudulence_customer.customer_add%TYPE,
                               p_customer_phone cis_fraudulence_customer.customer_phone%TYPE,
                               p_customer_fax cis_fraudulence_customer.customer_fax%TYPE,
                               p_customer_web cis_fraudulence_customer.customer_web%TYPE,
                               p_customer_email cis_fraudulence_customer.customer_email%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_tax_date cis_fraudulence_customer.tax_date%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_register_date cis_fraudulence_customer.register_date%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_industry_code cis_fraudulence_customer.industry_code%TYPE,
                               p_legal_personal cis_fraudulence_customer.legal_personal%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_director_name cis_fraudulence_customer.director_name%TYPE,
                               p_director_id cis_fraudulence_customer.director_id%TYPE,
                               p_source cis_fraudulence_customer.source%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                                p_status cis_fraudulence_customer.status%TYPE,
                               p_out OUT types.ref_cursor);

    PROCEDURE pr_update_fraudulence_customer(p_id cis_fraudulence_customer.id%TYPE ,
                                p_cic_code cis_fraudulence_customer.cic_code%TYPE ,
                               p_customer_type cis_fraudulence_customer.customer_type%TYPE,
                               p_customer_code cis_fraudulence_customer.customer_code%TYPE,
                               p_customer_name cis_fraudulence_customer.customer_name%TYPE,
                               p_customer_full_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_customer_short_name cis_fraudulence_customer.customer_short_name%TYPE,
                               p_customer_add cis_fraudulence_customer.customer_add%TYPE,
                               p_customer_phone cis_fraudulence_customer.customer_phone%TYPE,
                               p_customer_fax cis_fraudulence_customer.customer_fax%TYPE,
                               p_customer_web cis_fraudulence_customer.customer_web%TYPE,
                               p_customer_email cis_fraudulence_customer.customer_email%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_tax_date cis_fraudulence_customer.tax_date%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_register_date cis_fraudulence_customer.register_date%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_industry_code cis_fraudulence_customer.industry_code%TYPE,
                               p_legal_personal cis_fraudulence_customer.legal_personal%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_director_name cis_fraudulence_customer.director_name%TYPE,
                               p_director_id cis_fraudulence_customer.director_id%TYPE,
                               p_source cis_fraudulence_customer.source%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                                p_status cis_fraudulence_customer.status%TYPE,
                               p_out OUT types.ref_cursor);                           

    PROCEDURE pr_info_fraudulence_customer(p_customer_code cis_fraudulence_customer.customer_code%TYPE ,
                               p_customer_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_cic_code cis_fraudulence_customer.cic_code%TYPE,
                               p_out OUT types.ref_cursor);

    PROCEDURE pr_update_inactive_fraudulence(p_fraud_type varchar2);
END PKG_FRAUDULENCE_CUSTOMER;


/
--------------------------------------------------------
--  DDL for Package PKG_SYS_EMAIL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PKG_SYS_EMAIL" 
AS
    /******************************************************************************
       NAME:       PKG_SYS_EMAIL
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        5/3/2018      admin       1. Created this package.
    ******************************************************************************/

    PROCEDURE pr_create_sys_email (
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        --p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        --p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        --p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        --p_status                   SYS_EMAIL.STATUS%TYPE,
        --p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        --p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        --p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor);

    PROCEDURE pr_get_list_sys_email (
        p_text_search              VARCHAR2,
        p_status              VARCHAR2,
        p_from_date                DATE,
        p_to_date                  DATE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor);

    PROCEDURE pr_update_sys_email (
        p_id                       SYS_EMAIL.ID%TYPE,
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        p_status                   SYS_EMAIL.STATUS%TYPE,
        p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor);

    PROCEDURE pr_get_sys_email_by_id (p_id                  SYS_EMAIL.ID%TYPE,
                                      p_user         IN     VARCHAR2,
                                      p_client_ip    IN     VARCHAR2,
                                      p_user_agent   IN     VARCHAR2,
                                      p_out             OUT types.ref_cursor);

--G?i email th𮧠bᯠkh?i t?o/di?u ch?nh user
PROCEDURE PR_SEND_EMAIL_USER (P_USER_ID                 VARCHAR2,
                              P_ACTION                  VARCHAR2);

--G?i email th𮧠bᯠnh?n b?n tin
PROCEDURE PR_SEND_EMAIL_RESPONSE (P_CIS_NO                  VARCHAR2);

--G?i email th𮧠bᯠphꠤuy?t b?n tin
PROCEDURE PR_SEND_EMAIL_TASK(P_TASK_ID VARCHAR2, P_STATUS VARCHAR2, P_USER VARCHAR2, P_COMMENT VARCHAR2);

--G?i email th𮧠bᯠcho ng??i dùng bi?t c󠦩le m?i
PROCEDURE PR_SEND_EMAIL_NEW_FILE(P_FILE_NAME VARCHAR2, P_CHANNEL VARCHAR2, P_STATUS VARCHAR2);

END PKG_SYS_EMAIL;


/
--------------------------------------------------------
--  DDL for Package PKG_SYSTEM_LOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PKG_SYSTEM_LOG" is

  -- Author  : CuongNH
  -- Created : 1/9/2018 4:47:26 PM
  -- Purpose : Luu log he thong

  /*
  Creater: CuongNH2
  Created date: 9/1/2018
  Description: log INFO cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_Parameter: chi tiet cac parameter
  */
  Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob);

  /*
  Creater: CuongNH2
  Created date: 18/1/2018
  Description: log DEBUG cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_Parameter: chi tiet cac parameter
  */
  Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2);


  /*
  Creater: CuongNH2
  Created date: 18/1/2018
  Description: ghi nhan log EXCEPTION
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               p_ErrorMessage: chi tiet noi dung loi
  */
  Procedure PR_LOG_EXCEPTION(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_ErrorNumber varchar2, p_ErrorMessage varchar2);

  /*
  Creater: CuongNH2
  Created date: 22/1/2018
  Description: ghi nhan log EXCEPTION khong throw
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               p_ErrorMessage: chi tiet noi dung loi
  */
Procedure PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME varchar2,
                           P_STEP_NAME varchar2,
                           p_ErrorNumber varchar2,
                           p_ErrorMessage clob,
                           P_TASK_TYPE varchar2 );

  /*
  Creater: SonTA2
  Created date: 30/1/2018
  Description: log INFO cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               P_TASK_TYPE: kieu task
               P_IP_CLIENT: client ip
               P_MACHINE: ten machine
  */
  Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob, P_TASK_TYPE varchar2);

  /*
  Creater: CuongNH2
  Created date: 18/1/2018
  Description: log DEBUG cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_Parameter: chi tiet cac parameter
               P_TASK_TYPE: kieu task
               P_IP_CLIENT: client ip
               P_MACHINE: ten machine
  */
  Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2, P_TASK_TYPE varchar2);

  Procedure PR_LOG_ACTIVITY(P_APPLICATION_ID VARCHAR2,
                            P_RESOURCE_URL VARCHAR2,
                            P_ACCESS_USER VARCHAR2,
                            P_ACCESS_STATUS VARCHAR2,
                            P_LOG_MESSAGE CLOB,
                            P_RESOURCE_TYPE VARCHAR2,
                            P_RPT_CODE VARCHAR2,
                            P_RESOURCE_ACTION VARCHAR2,
                            P_CLIENT_IP VARCHAR2,
                            P_USER_AGENT VARCHAR2,
                            p_out OUT types.ref_cursor);

end PKG_SYSTEM_LOG;


/
--------------------------------------------------------
--  DDL for Package PKG_UTILITY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CIS_OPS_NCB"."PKG_UTILITY" is
/*
Creater: CuongNH2
Create date: 19/4/2018
Description: Xoa dau va chuyen thanh chu thuong
*/
FUNCTION RemoveSignVietnamess(P_STR IN VARCHAR2) RETURN clob;

/*
Creater: CuongNH2
Create date: 11/7/2018
Description: Format number with comma
*/
FUNCTION FORMAT_NUMBER(P_STR IN VARCHAR2) RETURN VARCHAR2;

FUNCTION IS_NUMBER(P_STR IN VARCHAR2) RETURN NUMBER;

FUNCTION RemoveSpecialCharactor(P_STR IN clob) RETURN clob;

end PKG_UTILITY;


/
--------------------------------------------------------
--  DDL for Package Body PCK_CIS_DASHBOARD
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_CIS_DASHBOARD" AS

/*
CREATE: CUONGNH
DESCRIPTION: TOP 10 BAN HOI TIN GAN NHAT
*/
PROCEDURE PR_LIST_TOP_REQUEST ( p_user varchar2,
                                p_client_ip varchar2,
                                p_user_agent varchar2,
                                p_out    OUT SYS_REFCURSOR)
AS
BEGIN

OPEN P_OUT FOR  
select * from (
SELECT A.ID, 
      A.CIS_NO, 
      A.CHANNEL, 
      A.CUSTOMER_TYPE, 
      A.STATUS, 
      A.PRODUCT_CODE, 
      A.MEMBER_CODE, 
      A.CIC_CODE, 
      A.ID_NO, 
      A.TAX_CODE, 
      A.USERNAME_REQUEST, 
      A.BRANCH_CODE, 
      TO_CHAR(A.CREATED_DATE,'DD/MM/YYYY') CREATED_DATE_STR, 
      A.REQUESTED_DATE, 
      A.REQUEST_DATA, 
      A.ERR_CODE, 
      A.ERR_MSG, 
      A.ADDRESS, 
      A.REGISTER_NO, 
      A.NOTE, 
      A.CUSTOMER_NAME, 
      A.CUSTOMER_CODE, 
      TO_CHAR(A.RESPONSE_DATE,'DD/MM/YYYY')  RESPONSE_DATE_STR,
      A.EMAIL, 
      A.LAST_VERSION, 
      A.FLAG, 
      A.MSG_ID, 
      A.APPLICATION_ID, 
      A.MAKER, 
      A.TASK_ID, 
      A.ENCODE_REQUEST, 
      A.BORROWER, 
      A.PCB_CODE, 
      A.CCY, 
      A.AMOUNT_FIN_CAPITAL, 
      A.TOTAL_INSTALMENT, 
      A.CREDIT_LIMIT, 
      A.GENDER, 
      A.DOB, 
      A.DOC_TYPE, 
      A.PAY_PERIODICITY, 
      A.OPERATION_TYPE, 
      A.COUNTRY_OF_BIRTH, 
      A.PHONE_NUMBER, 
      A.FREQUENT_CONTACTS, 
      A.REQUEST_ID, 
      A.USER_, 
      A.CLIENT_IP, 
      A.USER_AGENT, 
      refStatus.REF_NAME_VN STATUS_STR,
      refDocType.REF_NAME_VN DOC_TYPE_STR,
      refCustomerType.REF_NAME_VN CUSTOMER_TYPE_STR,
      B.REF_NAME_VN PRODUCT_NAME
FROM   CIS_REQUEST A
LEFT JOIN SYS_REFCODE refStatus ON A.STATUS = refStatus.REF_CODE AND refStatus.REF_GROUP = 'STATUS_REQUEST'
LEFT JOIN SYS_REFCODE refCustomerType ON A.CUSTOMER_TYPE = refCustomerType.REF_CODE AND refCustomerType.REF_GROUP = 'LOAI_KH'
LEFT JOIN SYS_REFCODE refDocType ON A.DOC_TYPE = refDocType.REF_CODE AND refDocType.REF_GROUP = 'DOC_TYPE'
LEFT JOIN SYS_REFCODE B ON A.PRODUCT_CODE = B.REF_CODE AND B.REF_GROUP = 'LS_PRODUCT'
WHERE A.MAKER = P_USER 
ORDER BY CREATED_DATE DESC,REQUESTED_DATE DESC ) AA
WHERE ROWNUM<=10;
END;

/*
CREATE: CUONGNH
DESCRIPTION: SUMMARY ON MONTH
*/
PROCEDURE PR_LIST_REQUEST_MONTHLY ( p_user varchar2,
                                    p_client_ip varchar2,
                                    p_user_agent varchar2,
                                    p_out    OUT SYS_REFCURSOR)
AS
BEGIN

OPEN P_OUT FOR  
SELECT COUNT(9) TOTAL_REQUEST, TO_NUMBER(TO_CHAR(A.CREATED_DATE,'DD')) DAYS
FROM   CIS_REQUEST A
WHERE A.MAKER = P_USER AND TO_CHAR(A.CREATED_DATE,'MMYYYY')=TO_CHAR(SYSDATE,'MMYYYY')
GROUP BY TO_NUMBER(TO_CHAR(A.CREATED_DATE,'DD'))
ORDER BY DAYS;


END;

/*
CREATE: CUONGNH
DESCRIPTION: SUMMARY ON MONTH
*/
PROCEDURE PR_LIST_REQ_PROD_MONTHLY ( p_user varchar2,
                                    p_client_ip varchar2,
                                    p_user_agent varchar2,
                                    p_out    OUT SYS_REFCURSOR)
AS
BEGIN

OPEN P_OUT FOR  
SELECT PKG_UTILITY.FORMAT_NUMBER(COUNT(9)) TOTAL_REQUEST,
       A.PRODUCT_CODE,
       B.REF_NAME_VN PRODUCT_NAME,
       A.CHANNEL,
       PKG_UTILITY.FORMAT_NUMBER(SUM(CASE WHEN A.IS_DATA='Y' THEN C.NORMAL_PRICE ELSE C.NON_NORMAL_PRICE END)) TOTAL_AMOUNT
FROM   CIS_REQUEST A
LEFT JOIN SYS_PRICE C ON A.PRODUCT_CODE=C.PRICE_CODE AND TRUNC(A.RESPONSE_DATE) BETWEEN TRUNC(C.EFFECTIVE_DATE) AND TRUNC(NVL(C.EXPIRATION_DATE,SYSDATE+100)) AND A.STATUS='RECEIVED'
LEFT JOIN SYS_REFCODE B ON A.PRODUCT_CODE = B.REF_CODE AND B.REF_GROUP = 'LS_PRODUCT'
WHERE A.MAKER = P_USER AND TO_CHAR(A.RESPONSE_DATE,'MMYYYY')=TO_CHAR(SYSDATE,'MMYYYY') AND A.STATUS='RECEIVED'
GROUP BY A.PRODUCT_CODE,
       B.REF_NAME_VN,
       A.CHANNEL
ORDER BY A.CHANNEL,A.PRODUCT_CODE;


END;
/*
CREATE: CUONGNH
DESCRIPTION: TINH TOAN BIEU DO
*/
PROCEDURE PR_AGG_DASHBOARD
AS
V_DAY_ID DATE;

BEGIN
V_DAY_ID := TRUNC(SYSDATE-1);

DELETE CIS_DASHBOARD WHERE to_char(TRUNC(SYSDATE-1),'YYYYMM') = to_char(sysdate,'YYYYMM');

INSERT INTO CIS_DASHBOARD(ID
                          ,USER_NAME
                          ,DAY_ID
                          ,NUMBER_OF_REQUSET
                          ,ESTIMATED_COST
                          ,CREATED_DATE
                          ,CHANNEL
                          ,PRODUCT_CODE)
SELECT SEQ_CIS_DASHBOARD.NEXTVAL ID, AA.*
FROM (SELECT A.MAKER USER_NAME
             ,TRUNC(A.RESPONSE_DATE) DAY_ID
             ,COUNT(9) NUMBER_OF_REQUSET
             ,SUM(C.NORMAL_PRICE) ESTIMATED_COST
             ,SYSDATE CREATED_DATE
             ,A.CHANNEL
             ,A.PRODUCT_CODE
      FROM   CIS_REQUEST A
      LEFT JOIN SYS_PRICE C ON A.PRODUCT_CODE=C.PRICE_CODE AND TRUNC(A.RESPONSE_DATE) BETWEEN TRUNC(C.EFFECTIVE_DATE) AND TRUNC(NVL(C.EXPIRATION_DATE,SYSDATE+100)) AND A.STATUS='RECEIVED'
      WHERE to_char(A.RESPONSE_DATE,'YYYYMM')=to_char(sysdate,'YYYYMM') AND A.STATUS='RECEIVED'
      GROUP BY A.PRODUCT_CODE,
             A.MAKER,
              TRUNC(A.RESPONSE_DATE),
             A.CHANNEL) AA;

COMMIT;
END;

/*
CREATE: CUONGNH
DESCRIPTION: VIEW CHAR
*/
PROCEDURE PR_LIST_CHAR ( p_user varchar2,
                        p_client_ip varchar2,
                        p_user_agent varchar2,
                        p_out    OUT SYS_REFCURSOR)
AS
BEGIN

  OPEN P_OUT FOR  
  select TO_CHAR(DAY_ID,'MM/YY') MONTHID,SUM(A.NUMBER_OF_REQUSET) NUMBER_OF_REQUSET,TO_CHAR(DAY_ID,'YYYYMM') MONTHID_ORDER
  from CIS_DASHBOARD A
  WHERE A.USER_NAME = p_user AND DAY_ID>ADD_MONTHS(SYSDATE,-12)
  GROUP BY TO_CHAR(DAY_ID,'MM/YY'),TO_CHAR(DAY_ID,'YYYYMM')
  ORDER BY MONTHID_ORDER;


END;


/*
CREATE: CUONGNH
DESCRIPTION: SUMMARY ON MONTH
*/
PROCEDURE PR_USERINFO ( p_user varchar2,
                        p_client_ip varchar2,
                        p_user_agent varchar2,
                        p_out    OUT SYS_REFCURSOR)
AS
BEGIN

OPEN P_OUT FOR  
SELECT A.FULL_NAME,A.JOB_TITLE,A.STATUS
FROM   SYS_USER A
WHERE A.USER_NAME = p_user ;


END;
END;


/
--------------------------------------------------------
--  DDL for Package Body PCK_CIS_RESPONSE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_CIS_RESPONSE" AS

  PROCEDURE PR_CREATE_CIS_RESPONSE (
        p_id CIS_RESPONSE.ID%TYPE,
        p_cis_no CIS_RESPONSE.CIS_NO%TYPE,
        p_cic_code CIS_RESPONSE.CIC_CODE%TYPE,
        p_member_code CIS_RESPONSE.MEMBER_CODE%TYPE,
        p_tax_code CIS_RESPONSE.TAX_CODE%TYPE,
        p_id_no CIS_RESPONSE.ID_NO%TYPE,
        p_product_code CIS_RESPONSE.PRODUCT_CODE%TYPE,
        p_response_date CIS_RESPONSE.RESPONSE_DATE%TYPE,
        p_status_code_cic CIS_RESPONSE.STATUS_CODE_CIC%TYPE,
        p_created_date CIS_RESPONSE.CREATED_DATE%TYPE,
        p_err_code CIS_RESPONSE.ERR_CODE%TYPE,
        p_err_msg CIS_RESPONSE.ERR_MSG%TYPE,
        p_response_data CIS_RESPONSE.RESPONSE_DATA%TYPE,
        p_status CIS_RESPONSE.STATUS%TYPE,
        p_version_no CIS_RESPONSE.VERSION_NO%TYPE,
        p_execute_date CIS_RESPONSE.EXECUTE_DATE%TYPE,
        p_msg_id CIS_RESPONSE.MSG_ID%TYPE,
        p_out    OUT SYS_REFCURSOR) 
        AS
        V_ID_CIS_RESPONSE VARCHAR2 (2000);
  BEGIN
        V_ID_CIS_RESPONSE:= SEQ_CIS_RESPONSE.NEXTVAL;
        DBMS_OUTPUT.PUT_LINE ('PR_CREATE_CIS_RESPONSE:' || V_ID_CIS_RESPONSE);
        UPDATE CIS_RESPONSE
        SET CIS_NO='BK_'||CIS_NO
        WHERE CIS_NO=P_CIS_NO;

        INSERT INTO CIS_RESPONSE (ID, 
                                CIS_NO, 
                                CIC_CODE, 
                                MEMBER_CODE, 
                                TAX_CODE, 
                                ID_NO, 
                                PRODUCT_CODE, 
                                RESPONSE_DATE, 
                                STATUS_CODE_CIC, 
                                CREATED_DATE, 
                                ERR_CODE, 
                                ERR_MSG, 
                                RESPONSE_DATA, 
                                STATUS, 
                                VERSION_NO, 
                                EXECUTE_DATE,
                                MSG_ID
                                 )
         VALUES (V_ID_CIS_RESPONSE , --ID
                p_cis_no , --ID_REQUEST
                p_cic_code , --CIC_CODE
                p_member_code , --MEMBER_CODE
                p_tax_code , --TAX_CODE
                p_id_no , --ID_NO
                p_product_code , --PRODUCT_CODE
                p_response_date , --RESPONSE_DATE
                p_status_code_cic , --STATUS_CODE_CIC
                p_created_date , --CREATED_DATE
                p_err_code , --ERR_CODE
                p_err_msg , --ERR_MSG
                replace(replace(replace(replace(replace(p_response_data,'&amp;','&'),'&','&amp;'),'<BR>','&lt;BR &gt;') ,'</BR>','&lt;/BR &gt;'),'Đ','Đ') , --RESPONSE_DATA
                --PKG_UTILITY.RemoveSpecialCharactor(p_response_data),
                'N/A' , --STATUS
                p_version_no , --VERSION_NO
                p_execute_date,  --EXECUTE_DATE
                p_msg_id --MSG_ID
                );      


    IF p_product_code='S37H' THEN 
        update cis_request
        set IS_DATA='Y'
        where cis_no=p_cis_no;
    END IF;

    OPEN p_out FOR
        SELECT *
        FROM   CIS_RESPONSE
        WHERE  ID = V_ID_CIS_RESPONSE;                             

    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END PR_CREATE_CIS_RESPONSE;



    PROCEDURE PR_GET_CIS_RESPONSE_INFO (
        p_id CIS_RESPONSE.ID%TYPE,
        p_cis_no CIS_RESPONSE.CIS_NO%TYPE,
        p_cic_code CIS_RESPONSE.CIC_CODE%TYPE,
        p_member_code CIS_RESPONSE.MEMBER_CODE%TYPE,
        p_tax_code CIS_RESPONSE.TAX_CODE%TYPE,
        p_id_no CIS_RESPONSE.ID_NO%TYPE,
        p_product_code CIS_RESPONSE.PRODUCT_CODE%TYPE,
        p_response_date CIS_RESPONSE.RESPONSE_DATE%TYPE,
        p_status_code_cic CIS_RESPONSE.STATUS_CODE_CIC%TYPE,
        p_created_date CIS_RESPONSE.CREATED_DATE%TYPE,
        p_err_code CIS_RESPONSE.ERR_CODE%TYPE,
        p_err_msg CIS_RESPONSE.ERR_MSG%TYPE,
        p_response_data CIS_RESPONSE.RESPONSE_DATA%TYPE,
        p_status CIS_RESPONSE.STATUS%TYPE,
        p_version_no CIS_RESPONSE.VERSION_NO%TYPE,
        p_execute_date CIS_RESPONSE.EXECUTE_DATE%TYPE,
        p_msg_id CIS_RESPONSE.MSG_ID%TYPE,
        p_out    OUT SYS_REFCURSOR) 
        AS
  BEGIN        
    OPEN p_out FOR
          SELECT  A.ID	,
                  A.CIS_NO	,
                  A.CIC_CODE	,
                  A.MEMBER_CODE	,
                  A.TAX_CODE	,
                  A.ID_NO	,
                  A.PRODUCT_CODE	,
                  A.RESPONSE_DATE	,
                  A.STATUS_CODE_CIC	,
                  A.CREATED_DATE	,
                  A.ERR_CODE	,
                  A.ERR_MSG	,
                  case when B.CHANNEL='CIC' then
                    regexp_replace(REPLACE(REPLACE(REPLACE(RESPONSE_DATA	,'<TENTRUYCAP>vib_01</TENTRUYCAP>','<TENTRUYCAP>'|| B.MAKER ||'</TENTRUYCAP>'),'"','&quot;'),'''','&apos'),'&($|[^lagq]|(g|l)([^t]|$)|q($|[^u]|u($|[^o]|o($|[^t])))|a($|([^m]|m($|[^p]))&([^p]|p($|[^o]|o($|[^s])))))','&amp;\1') 
                  else 
                    regexp_replace(REPLACE(REPLACE(REPLACE(RESPONSE_DATA	,'<TENTRUYCAP>vib_01</TENTRUYCAP>','<TENTRUYCAP>'|| B.MAKER ||'</TENTRUYCAP>'),'&quot;','"'),'''','&apos'),'&($|[^lagq]|(g|l)([^t]|$)|q($|[^u]|u($|[^o]|o($|[^t])))|a($|([^m]|m($|[^p]))&([^p]|p($|[^o]|o($|[^s])))))','&amp;\1') 
                  end RESPONSE_DATA,
--                  REPLACE(RESPONSE_DATA	,'<TENTRUYCAP>vib_01</TENTRUYCAP>','<TENTRUYCAP>'|| B.MAKER ||'</TENTRUYCAP>') RESPONSE_DATA,
                  A.STATUS	,
                  A.VERSION_NO	,
                  A.EXECUTE_DATE	,
                  A.MSG_ID	,
                  C.REF_NAME_VN BRANCH_NAME, D.FULL_NAME
        FROM   CIS_RESPONSE A
        LEFT JOIN CIS_REQUEST B ON A.CIS_NO=B.CIS_NO
        LEFT JOIN V_BRANCH C ON B.BRANCH_CODE = C.REF_CODE
        LEFT JOIN SYS_USER D ON B.MAKER = D.USER_NAME
    --dodt edit 07/04    WHERE  CIS_NO = p_cis_no AND PRODUCT_CODE = ''||p_product_code||'';
    WHERE  A.CIS_NO = p_cis_no;
    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END PR_GET_CIS_RESPONSE_INFO;

PROCEDURE PR_LIST_CIS_RESPONSE_FOR_PASER (
        p_status varchar2, 
        p_channel varchar2, 
        p_out    OUT SYS_REFCURSOR)
        AS
v_rowcount number;
  BEGIN

  IF P_STATUS='N/A' THEN

    SELECT COUNT(9) INTO v_rowcount
    FROM CIS_RESPONSE A WHERE STATUS='IN_PROGRESS' ;

    IF v_rowcount=0 THEN 

      UPDATE CIS_RESPONSE A 
      SET STATUS='IN_PROGRESS' 
      WHERE ID IN (SELECT AA.ID FROM CIS_RESPONSE AA 
                                LEFT JOIN CIS_REQUEST B ON AA.CIS_NO=B.CIS_NO
                   WHERE AA.STATUS = P_STATUS AND B.CHANNEL=P_CHANNEL)
            AND ROWNUM<400;

    DELETE TBL_CIS_CHI_TIET_LOAI_VAY WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_DU_NO_THE WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_QUAN_HE_TIN_DUNG WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_THONG_TIN_CHUNG WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_TSDB WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_TT_THANH_TOAN_THE WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_TT_TONG_HOP_KHAC_HDTD WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_DU_NO_HIEN_THOI WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_LICH_SU_TRA_CUU WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
    DELETE TBL_CIS_LS_QUAN_HE_TIN_DUNG WHERE RESPONSE_ID IN (SELECT ID FROM CIS_RESPONSE WHERE STATUS='IN_PROGRESS');
          commit;      
      OPEN P_OUT FOR
          SELECT ID	,
                  CIS_NO	,
                  CIC_CODE	,
                  MEMBER_CODE	,
                  TAX_CODE	,
                  ID_NO	,
                  PRODUCT_CODE	,
                  RESPONSE_DATE	,
                  STATUS_CODE_CIC	,
                  CREATED_DATE	,
                  ERR_CODE	,
                  ERR_MSG	,
                  REPLACE(REPLACE(RESPONSE_DATA	,'<BR1/>','|'),'<br1/>','|') RESPONSE_DATA,
                  STATUS	,
                  VERSION_NO	,
                  EXECUTE_DATE	,
                  MSG_ID	 
          FROM   CIS_RESPONSE A  
      WHERE A.STATUS='IN_PROGRESS' ;    
    END IF;
  END IF;

  IF P_STATUS<>'N/A'  THEN  
    OPEN P_OUT FOR
        SELECT A.* 
        FROM   CIS_RESPONSE A 
        LEFT JOIN CIS_REQUEST B ON A.CIS_NO=B.CIS_NO
    WHERE  A.STATUS = P_STATUS AND B.CHANNEL=P_CHANNEL AND ROWNUM<5;
  END IF;

    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END;

PROCEDURE PR_CIS_RESPONSE_CHANGE_STATUS (
        p_status varchar2, 
        p_cis_no varchar2, 
        p_id varchar2, 
        p_out    OUT SYS_REFCURSOR)
        AS
  BEGIN        
    update CIS_RESPONSE
    set status=p_status, execute_date=sysdate
    where cis_no=p_cis_no and id=p_id;

    OPEN p_out FOR
    select * from CIS_RESPONSE
    where id=p_id;

    EXCEPTION
        WHEN ZERO_DIVIDE
        THEN
            DBMS_OUTPUT.PUT_LINE ('Attempt to divide by 0');
  END;
END PCK_CIS_RESPONSE;


/
--------------------------------------------------------
--  DDL for Package Body PCK_CIC_TOKEN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_CIC_TOKEN" AS

  PROCEDURE PR_GET_CIC_TOKEN (p_out    OUT SYS_REFCURSOR) AS
  BEGIN
    OPEN P_OUT FOR
    SELECT TOKEN,
            THOI_GIAN_BAT_DAU,
            to_number(((CREATED_DATE +numToDSInterval( a.token_het_han, 'second' ))-sysdate)*24*60*60) TOKEN_HET_HAN,
            MAT_KHAU_HET_HAN,
            GHI_CHU,
            CREATED_DATE
    FROM SYS_CIC_TOKEN A
    WHERE CREATED_DATE > SYSDATE-1
    ORDER BY CREATED_DATE DESC;

  END PR_GET_CIC_TOKEN;

  PROCEDURE PR_UPDATE_CIC_TOKEN (p_token VARCHAR2,
                        p_thoi_gian_bat_dau VARCHAR2,
                        p_token_het_han VARCHAR2,
                        p_mat_khau_het_han   VARCHAR2,
                        p_ghi_chu VARCHAR2,
                        p_out    OUT SYS_REFCURSOR) AS
  V_COUNT INT;
  BEGIN
    SELECT COUNT(9) INTO V_COUNT
    FROM SYS_CIC_TOKEN
    WHERE TOKEN=p_token;

    IF V_COUNT=0 THEN
        insert into SYS_CIC_TOKEN (TOKEN, THOI_GIAN_BAT_DAU, TOKEN_HET_HAN, MAT_KHAU_HET_HAN, GHI_CHU,CREATED_DATE)
        values (p_token, p_thoi_gian_bat_dau, p_token_het_han, p_mat_khau_het_han, SYS_CONTEXT('USERENV','IP_ADDRESS') ||'; '|| nvl(p_ghi_chu,''), sysdate);

    END IF;

        OPEN P_OUT FOR
        SELECT * 
        FROM SYS_CIC_TOKEN
        WHERE TOKEN=p_token;

  END PR_UPDATE_CIC_TOKEN;

END PCK_CIC_TOKEN;


/
--------------------------------------------------------
--  DDL for Package Body PCK_CIS_OTHER_REQUEST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_CIS_OTHER_REQUEST" AS
--Tinh toan ban tin tra loi
--Create by CuongNH2
--Crated date: 06/12/2021
PROCEDURE PR_CALCULATOR (P_REQUEST_ID NVARCHAR2) IS
V_ROWS_RESPONSE_RECEIVED NUMBER; 
V_ROWS_TOTAL_REQUEST NUMBER; 
V_CIS_OTHER_RESPONSE NUMBER;
V_PRODUCT_CODE varchar2(50);
V_APPLICATION_ID varchar2(50);
BEGIN
--KIEM TRA XEM CAC BAN TRA LOI TIN DA NHAN DUOC HET CHUA
SELECT SUM(CASE WHEN B.STATUS <> 'RECEIVED' OR C.STATUS <> 'DONE' THEN 1 ELSE 0 END) RESPONSE_RECEIVED
    ,COUNT(*) TOTAL_REQUEST
INTO V_ROWS_RESPONSE_RECEIVED, V_ROWS_TOTAL_REQUEST
FROM CIS_MM_OTHER_REQ_REQCIC A
LEFT JOIN CIS_REQUEST B ON A.CIS_NO=B.CIS_NO
LEFT JOIN CIS_RESPONSE C ON C.CIS_NO=B.CIS_NO
WHERE A.REQUEST_ID=P_REQUEST_ID;
-- REQUEST NAY KHONG CO BAN HOI TIN CIC => DU LIEU LOI
IF V_ROWS_TOTAL_REQUEST=0 THEN
    UPDATE CIS_OTHER_REQUEST
    SET STATUS='NO_REQ'
    WHERE REQUEST_ID=P_REQUEST_ID;
END IF;

--VAN CON BAN TIN CHUA PHAN HOI
IF V_ROWS_RESPONSE_RECEIVED>0 THEN 
    RETURN;
END IF;

-- 20210521 - ?ᮨ d?u nh?ng b?n ghi c󠭣 CIC Code ??u tiꮠ?? th?c hi?n t󺀠toᮠ-> Kh? trùng v?i cᣠs?n ph?m cùng CICCode
UPDATE CIS_MM_OTHER_REQ_REQCIC
SET CALCULATOR = 'Y'
WHERE REQUEST_ID = P_REQUEST_ID
    AND ID IN (SELECT ID FROM
                (SELECT
                        A.ID,
                        A.CIS_NO,
                        A.REQUEST_ID OTHER_REQUEST_ID,
                        B.PRODUCT_CODE,
                        C.MA_CIC,
                        ROW_NUMBER() OVER(PARTITION BY A.REQUEST_ID, B.PRODUCT_CODE, C.MA_CIC ORDER BY A.CIS_NO DESC ) ROW_NUMBER,
                        D.STATUS
                    FROM CIS_MM_OTHER_REQ_REQCIC A
                        LEFT JOIN CIS_REQUEST B ON A.CIS_NO = B.CIS_NO
                        LEFT JOIN CIS_RESPONSE D ON D.CIS_NO = B.CIS_NO
                        LEFT JOIN TBL_CIS_THONG_TIN_CHUNG C ON C.RESPONSE_ID = D.ID
                    WHERE A.REQUEST_ID = P_REQUEST_ID
                ) XX
            WHERE ROW_NUMBER = 1);
-- end

INSERT INTO CIS_TEMP_OTHER_REQUEST
SELECT B.ID RESPONSE_ID,A.REQUEST_ID,A.CIS_NO
FROM CIS_MM_OTHER_REQ_REQCIC A
LEFT JOIN CIS_RESPONSE B ON A.CIS_NO=B.CIS_NO
WHERE A.REQUEST_ID=P_REQUEST_ID AND A.CALCULATOR = 'Y';

-- DU LIEU DA TRA TIN DAY DU
IF V_ROWS_RESPONSE_RECEIVED=0 THEN 
--B1: LAM SACH DU LIEU
    DELETE CIS_OTHER_RESPONSE_DETAIL
    WHERE OTHER_RESPONSE_ID IN (SELECT RESPONSE_ID FROM CIS_OTHER_RESPONSE WHERE REQUEST_ID=P_REQUEST_ID);

    -- XOA DU LIEU CU
    DELETE CIS_OTHER_RESPONSE
    WHERE REQUEST_ID=P_REQUEST_ID;


--B3: KHOI TAO BAN TIN 
V_CIS_OTHER_RESPONSE := SEQ_CIS_OTHER_RESPONSE.NEXTVAL;
SELECT MAX(PRODUCT_CODE),MAX(A.APPLICATION_ID) INTO V_PRODUCT_CODE,V_APPLICATION_ID
FROM CIS_OTHER_REQUEST A WHERE A.REQUEST_ID=P_REQUEST_ID;

INSERT INTO CIS_OTHER_RESPONSE(RESPONSE_ID	,
                                REQUEST_ID	,
                                PRODUCT_CODE	,
                                RESPONSE_DATE	, 
                                VERSION_NO ,
                                RESPONSE_STATUS  ,
                                RESPONSE_MESSAGE  ,
                                GENERATE_DATE  , 
                                CIC_CODE,
                                APPLICATION_ID
                                )

                         SELECT V_CIS_OTHER_RESPONSE,
                                P_REQUEST_ID  ,
                                V_PRODUCT_CODE PRODUCT_CODE  ,
                                null RESPONSE_DATE  ,
                                '1' VERSION_NO  , 
                                'GENERATED' RESPONSE_STATUS  ,
                                '' RESPONSE_MESSAGE  ,
                                SYSDATE GENERATE_DATE  , 
                                null CIC_CODE,
                                V_APPLICATION_ID
                            FROM DUAL;


INSERT INTO CIS_OTHER_RESPONSE_DETAIL (ID,
                                        OTHER_RESPONSE_ID,
                                        CIS_NO,
                                        RESPONSE_DATE,
                                        RESPONSE_XML_DATA,
                                        RESPONSE_FILE_DATA,
                                        GENERATED_DATE,
                                        PRODUCT_CODE)
SELECT SEQ_CIS_OTHER_REQUEST_DETAIL.NEXTVAL,
        V_CIS_OTHER_RESPONSE,
        A.CIS_NO,
        B.RESPONSE_DATE,
        B.RESPONSE_DATA,
        NULL RESPONSE_FILE_DATA,
        SYSDATE GENERATED_DATE,
        B.PRODUCT_CODE
FROM CIS_MM_OTHER_REQ_REQCIC A
JOIN CIS_RESPONSE B ON A.CIS_NO=B.CIS_NO
WHERE A.REQUEST_ID=P_REQUEST_ID
;

UPDATE CIS_OTHER_REQUEST 
SET STATUS='GENERATED'
WHERE REQUEST_ID=P_REQUEST_ID;

END IF;

END;

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o y굠c?u t? h? th?ng khᣊ*/
PROCEDURE PR_CREATE_OTHER_REQUEST (p_application_id VARCHAR2,
                                        p_source_request_id VARCHAR2,
                                        p_maker VARCHAR2, 
                                        p_customer_name VARCHAR2,
                                        p_customer_address VARCHAR2,
                                        p_client_ip VARCHAR2,
                                        p_user_agent VARCHAR2, 
                                        p_product_code VARCHAR2, 
                                        p_customer_type VARCHAR2, 
                                        p_batch_id VARCHAR2, 
                                        p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);
V_BRANCH_CODE VARCHAR2(50); 
BEGIN

--Ki?m tra xem c󠴠i kho?n trong h? th?ng kh𮧬 n?u kh𮧠c󠨯?c kh𮧠c󠴨𮧠tin chi nhᮨ th젴h𮧠bᯠl?i
SELECT MAX(A.MEMBER_CODE) INTO V_BRANCH_CODE 
FROM SYS_USER A
WHERE LOWER(A.USER_NAME)=LOWER(P_MAKER);
IF V_BRANCH_CODE IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy thông tin tài khoản ['||P_MAKER||'] trong hệ thống!' );
  RETURN;
END IF;


V_REQUEST_ID := SEQ_CIS_OTHER_REQUEST.NEXTVAL;
INSERT INTO CIS_OTHER_REQUEST (REQUEST_ID,
                                APPLICATION_ID,
                                SOURCE_REQUEST_ID,
                                MAKER,
                                BRANCH_CODE,
                                CUSTOMER_NAME,
                                CUSTOMER_ADDRESS,
                                CLIENT_IP,
                                USER_AGENT,
                                STATUS,
                                PRODUCT_CODE,
                                MEMBER_CODE,
                                REQUEST_DATE,
                                CUSTOMER_TYPE,
                                BATCH_ID)

              VALUES (V_REQUEST_ID,
                      P_APPLICATION_ID,
                      P_SOURCE_REQUEST_ID,
                      P_MAKER,
                      V_BRANCH_CODE,
                      P_CUSTOMER_NAME,
                      P_CUSTOMER_ADDRESS,
                      P_CLIENT_IP,
                      P_USER_AGENT,
                      'NEW',
                      P_PRODUCT_CODE,
                      V_BRANCH_CODE,
                      SYSDATE,
                      P_CUSTOMER_TYPE,
                      P_BATCH_ID);
COMMIT;

OPEN p_out FOR
SELECT * FROM CIS_OTHER_REQUEST WHERE REQUEST_ID=V_REQUEST_ID;

END;

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o chi ti?t y굠c?u t? h? th?ng khᣊ*/
PROCEDURE PR_CREATE_OTHER_REQUEST_DETAIL (P_REQUEST_ID VARCHAR2, 
                                    P_SOURCE_REQUEST_ID VARCHAR2,
                                    P_CUSTOMER_ID_TYPE VARCHAR2,
                                    P_CUSTOMER_ID VARCHAR2, 
                                    p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);
V_ID VARCHAR2(50); 
V_APPLICATION_ID VARCHAR2(50);
BEGIN

--Ki?m tra xem c󠴠i kho?n trong h? th?ng kh𮧬 n?u kh𮧠c󠨯?c kh𮧠c󠴨𮧠tin chi nhᮨ th젴h𮧠bᯠl?i
SELECT MAX(A.REQUEST_ID),MAX(APPLICATION_ID) INTO V_REQUEST_ID ,V_APPLICATION_ID
FROM CIS_OTHER_REQUEST A WHERE REQUEST_ID=P_REQUEST_ID;

IF V_REQUEST_ID IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy yêu cầu ['||P_REQUEST_ID||'] trong hệ thống!' );
  RETURN;
END IF;


V_ID := SEQ_CIS_OTHER_REQUEST_DETAIL.NEXTVAL;
INSERT INTO CIS_OTHER_REQUEST_DETAIL (ID,
                                      REQUEST_ID,
                                      APPLICATION_ID,
                                      SOURCE_REQUEST_ID,
                                      CUSTOMER_ID_TYPE,
                                      CUSTOMER_ID)

              VALUES (V_ID,
                      V_REQUEST_ID,
                      V_APPLICATION_ID,
                      P_SOURCE_REQUEST_ID,
                      P_CUSTOMER_ID_TYPE,
                      P_CUSTOMER_ID);
COMMIT;

OPEN p_out FOR
SELECT * FROM CIS_OTHER_REQUEST_DETAIL WHERE ID=V_ID;

END;

/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o chi ti?t th𮧠tin CIC CODE t? CIC
*/
PROCEDURE PR_CREATE_OTHER_REQUEST_CHECK (P_REQUEST_ID VARCHAR2,
                                        P_CUSTOMER_ID_TYPE VARCHAR2,
                                        P_CUSTOMER_ID VARCHAR2,
                                        P_CUST_CODE VARCHAR2,
                                        P_CIC_CUST_NAME VARCHAR2,
                                        P_CIC_CUST_ADDRESS VARCHAR2,
                                        P_CUST_TYPE VARCHAR2,
                                        P_CUST_TAX VARCHAR2,
                                        P_CUST_ID_NO VARCHAR2,
                                        P_CUST_REG VARCHAR2,
                                        P_CIC_CODE VARCHAR2,
                                        P_CIC_DATA VARCHAR2, 
                                        p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);
V_ID VARCHAR2(50); 
V_CUSTOMER_ID_TYPE VARCHAR2(50);
V_ROWS_COUNT NUMBER;
BEGIN

--Ki?m tra xem c󠴠i kho?n trong h? th?ng kh𮧬 n?u kh𮧠c󠨯?c kh𮧠c󠴨𮧠tin chi nhᮨ th젴h𮧠bᯠl?i
SELECT MAX(A.REQUEST_ID),MAX(CUSTOMER_ID_TYPE) INTO V_REQUEST_ID ,V_CUSTOMER_ID_TYPE
FROM CIS_OTHER_REQUEST_DETAIL A WHERE REQUEST_ID=P_REQUEST_ID;-- AND CUSTOMER_ID=P_CIC_CUST_ID_NO;

IF V_REQUEST_ID IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy thông tin CUSTOMER ID NO ['||P_CUST_ID_NO||'] trong yêu cầu ['||P_REQUEST_ID||'] trong hệ thống!' );
  RETURN;
END IF;

SELECT COUNT(9) INTO V_ROWS_COUNT
FROM CIS_OTHER_REQUEST_CHECK
WHERE REQUEST_ID=P_REQUEST_ID AND (CIC_CUST_ID_NO=P_CUST_ID_NO OR P_CIC_CODE=CIC_CODE);

IF V_ROWS_COUNT=0 THEN
    V_ID := SEQ_CIS_OTHER_REQUEST_CHECK.NEXTVAL;
    INSERT INTO CIS_OTHER_REQUEST_CHECK (ID  ,
                                          REQUEST_ID  ,
                                          CUSTOMER_ID_TYPE  ,
                                          CUSTOMER_ID  ,
                                          CIC_CUST_CODE  ,
                                          CIC_CUST_NAME  ,
                                          CIC_CUST_ADDRESS  ,
                                          CIC_CUST_TYPE  ,
                                          CIC_CUST_TAX  ,
                                          CIC_CUST_ID_NO  ,
                                          CIC_CUST_REG  ,
                                          CIC_DATA  ,
                                          CIC_CODE,
                                          REQUEST_DATE  )

                  VALUES (V_ID,
                          V_REQUEST_ID,
                          P_CUSTOMER_ID_TYPE,
                          NVL(NVL(P_CUST_ID_NO,P_CIC_CODE),'N/A'),
                          P_CUST_CODE,
                          P_CIC_CUST_NAME,
                          P_CIC_CUST_ADDRESS,
                          P_CUST_TYPE,
                          P_CUST_TAX,
                          P_CUST_ID_NO,
                          P_CUST_REG,
                          P_CIC_DATA,
                          P_CIC_CODE,
                          SYSDATE);
END IF;
COMMIT;

OPEN p_out FOR
SELECT * FROM CIS_OTHER_REQUEST_CHECK WHERE REQUEST_ID=P_REQUEST_ID AND CUSTOMER_ID=P_CUST_ID_NO;

END;


/*
Ki?m tra t쮨 tr?ng d? li?u theo matrix c?a kꮨ CIC
*/
FUNCTION PR_STATUS_MATRIX_CIC(p_id_no CIS_REQUEST.ID_NO%TYPE,
                              p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
                              p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
                              p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
                              p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
                              p_cic_code varchar2) RETURN VARCHAR2
IS
    V_TOTAL_WARNING1 NUMBER;
    V_TOTAL_WARNING2 NUMBER;
    V_TOTAL_ACCEPT NUMBER; 


    V_CIC_NUMBER_OF_DAYS NUMBER;
    V_CIC_DATA_VALIDATION_DAY NUMBER; 
    v_EXISTS_RECORD NUMBER;
    V_STATUS VARCHAR2(100); 
    V_CIS_NO VARCHAR2(100); 
BEGIN
/**/
-- V_BLACK_LIST := PCK_CIS_REQUEST.PR_CHECK_BLACK_LIST(p_id_no);
/*IF V_BLACK_LIST IS NOT NULL THEN
  V_BLACK_LIST := V_BLACK_LIST;
END IF;
*/  
-- Khi s?a PACK n๠c?n update thꭠ? PCK_CIS_REQUEST.PR_STATUS_MATRIX_CIC

select nvl(max(par1),7) into V_CIC_NUMBER_OF_DAYS
from sys_refcode a where a.ref_code='CIC_NUMBER_OF_DAYS';
select nvl(max(par1),15) into V_CIC_DATA_VALIDATION_DAY
from sys_refcode a where a.ref_code='CIC_DATA_VALIDATION_DAY';


SELECT MAX(CIS_NO) INTO V_CIS_NO
FROM CIS_REQUEST A
WHERE CHANNEL='CIC' and PRODUCT_CODE = p_product_code
      AND CUSTOMER_TYPE = p_customer_type
      AND ((case when p_customer_type = '2' and ID_NO = p_id_no then 1 
               when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no) then 1 
               else 0 end = 1) or p_cic_code=a.cic_code)
      AND A.STATUS IN ('SENDED','SENT','WAITING','NEW')
      --AND A.LAST_VERSION='1'
      ;

IF V_CIS_NO IS NOT NULL THEN
  RETURN V_CIS_NO;--NOT UPDATE CIC
END IF;


SELECT SUM(CASE WHEN RESPONSE_STATUS='ACCEPT' THEN 1 ELSE 0 END) TOTAL_ACCEPT
       ,SUM(CASE WHEN RESPONSE_STATUS='WARNING1' THEN 1 ELSE 0 END) TOTAL_WARNING1
       ,SUM(CASE WHEN RESPONSE_STATUS='WARNING2' THEN 1 ELSE 0 END) TOTAL_WARNING2
       ,COUNT(9) EXISTS_RECORD
       ,MAX(
            CASE 
                WHEN REGEXP_LIKE(CIS_NO, '^[0-9]+$') THEN TO_NUMBER(CIS_NO) 
                ELSE 0  -- S? d?ng giᠴr? s? m?c ??nh l࠰ n?u CIS_NO kh𮧠ph?i l࠳?
            END
        ) V_CIS_NO
INTO V_TOTAL_ACCEPT, V_TOTAL_WARNING1,V_TOTAL_WARNING2, V_EXISTS_RECORD, V_CIS_NO
FROM (
      SELECT CASE WHEN V_A>0 THEN CASE WHEN CONDITION_2 = '0' THEN 'ACCEPT'
                                       ELSE CASE WHEN V_C <= V_CIC_DATA_VALIDATION_DAY THEN 'ACCEPT'
                                                 ELSE CASE WHEN V_D >= V_CIC_NUMBER_OF_DAYS THEN 'ACCEPT' 
                                                           ELSE 'WARNING2' 
                                                      END 
                                            END
                                   END
                   ELSE CASE WHEN V_B >= V_CIC_NUMBER_OF_DAYS THEN 'ACCEPT' ELSE 'WARNING1' END
              END RESPONSE_STATUS 
              ,CIS_NO
      FROM (
        SELECT TO_NUMBER(TO_CHAR(SYSDATE,'DD')) HT
               ,TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')) GN
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-V_CIC_DATA_VALIDATION_DAY V_A
               ,CAST((SYSDATE - CAST(A.RESPONSE_DATE AS DATE)) AS INT) V_B
               ,GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_CIC_DATA_VALIDATION_DAY) V_C
               ,TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-GREATEST(TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'DD')),V_CIC_DATA_VALIDATION_DAY) V_D
               ,CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,'MM'))=TO_NUMBER(TO_CHAR(A.RESPONSE_DATE,'MM')) THEN '1' ELSE '0' END CONDITION_2
               ,A.CIS_NO

        FROM CIS_REQUEST A
        WHERE CHANNEL='CIC' AND CUSTOMER_TYPE = p_customer_type and PRODUCT_CODE = p_product_code
              AND ((case when p_customer_type = '2' and ID_NO = p_id_no then 1 
                       when p_customer_type = '1' and (TAX_CODE = p_tax_code or REGISTER_NO = p_register_no) then 1 
                       else 0 end = 1) or p_cic_code=a.cic_code)
              AND A.STATUS='RECEIVED' AND A.LAST_VERSION='1'
      ) B
); 

SELECT CASE WHEN v_EXISTS_RECORD=0 THEN 'UPDATE CIC' ELSE 
            CASE WHEN V_TOTAL_WARNING1>0 THEN V_CIS_NO WHEN V_TOTAL_WARNING2>0 THEN V_CIS_NO ELSE 'UPDATE CIC' END 
       END
INTO V_STATUS FROM DUAL;

RETURN V_STATUS;
END;


/*
Creater: CuongNH2
Create Date: 23/6/2020
Des: Kh?i t?o phi?u y굠c?u h?i tin
*/
PROCEDURE PR_GENERATE_REQUEST_TO_CIC (P_REQUEST_ID VARCHAR2,
                                        p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);  
V_COMBO_PRODUCT VARCHAR2(50);  
V_ROWS_COUNT NUMBER;
BEGIN

--Ki?m tra xem c󠴠i kho?n trong h? th?ng kh𮧬 n?u kh𮧠c󠨯?c kh𮧠c󠴨𮧠tin chi nhᮨ th젴h𮧠bᯠl?i
SELECT MAX(A.REQUEST_ID), MAX(A.PRODUCT_CODE) INTO V_REQUEST_ID, V_COMBO_PRODUCT 
FROM CIS_OTHER_REQUEST A WHERE REQUEST_ID=P_REQUEST_ID AND A.STATUS='NEW';


IF V_REQUEST_ID IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy thông tin yêu cầu ['||P_REQUEST_ID||'] trong hệ thống!' );
  RETURN;
END IF;


INSERT INTO CIS_REQUEST_TMP (CIS_NO, CHANNEL,
                          CUSTOMER_TYPE,
                          STATUS,
                          PRODUCT_CODE,
                          CIC_CODE,
                          ID_NO,
                          TAX_CODE,
                          BRANCH_CODE,
                          CREATED_DATE,
                          ADDRESS,
                          REGISTER_NO,
                          CUSTOMER_NAME,
                          CUSTOMER_CODE,
                          APPLICATION_ID,
                          MAKER,
                          REQUEST_ID)
                   SELECT SEQ_CIS_REQUEST.NEXTVAL,
                          C.PAR1 CHANNEL,
                          C.PAR2 CUSTOMER_TYPE,
                          'NEW' STATUS,
                          C.REF_CODE PRODUCT_CODE,
                          A.CIC_CODE,
                          A.CUSTOMER_ID ID_NO,
                          A.CIC_CUST_TAX TAX_CODE,
                          B.MEMBER_CODE BRANCH_CODE,
                          SYSDATE CREATED_DATE,
                          NVL(A.CIC_CUST_ADDRESS,'N/A') ADDRESS,
                          A.CIC_CUST_REG REGISTER_NO,
                          A.CIC_CUST_NAME CUSTOMER_NAME,
                          A.CIC_CUST_CODE CUSTOMER_CODE,
                          B.APPLICATION_ID APPLICATION_ID,
                          B.MAKER MAKER,
                          V_REQUEST_ID
FROM CIS_OTHER_REQUEST_CHECK A
JOIN CIS_OTHER_REQUEST B ON A.REQUEST_ID=B.REQUEST_ID
JOIN SYS_REFCODE C ON C.REF_GROUP='NEW_CREDIT_REQUEST' AND C.PAR3=V_COMBO_PRODUCT
WHERE A.REQUEST_ID=V_REQUEST_ID
      AND PR_STATUS_MATRIX_CIC(A.CIC_CUST_ID_NO, A.CIC_CUST_REG, A.CIC_CUST_TAX, C.PAR2, C.REF_CODE, A.CIC_CODE) = 'UPDATE CIC';


SELECT COUNT(9) INTO V_ROWS_COUNT
FROM CIS_OTHER_REQUEST_CHECK 
WHERE REQUEST_ID=V_REQUEST_ID;

-- N?u kh𮧠c󠤡nh sᣨ m㠃IC CODE du?c update th젳? ti?n hந h?i tin theo CMND
IF NVL(V_ROWS_COUNT,0)=0 THEN
  INSERT INTO CIS_REQUEST_TMP (CIS_NO, CHANNEL,
                            CUSTOMER_TYPE,
                            STATUS,
                            PRODUCT_CODE,
                            CIC_CODE,
                            ID_NO,
                            TAX_CODE,
                            BRANCH_CODE,
                            CREATED_DATE,
                            ADDRESS,
                            REGISTER_NO,
                            CUSTOMER_NAME,
                            CUSTOMER_CODE,
                            APPLICATION_ID,
                            MAKER,
                            REQUEST_ID)
                     SELECT SEQ_CIS_REQUEST.NEXTVAL, C.PAR1 CHANNEL,
                            C.PAR2 CUSTOMER_TYPE,
                            'NEW' STATUS,
                            C.REF_CODE PRODUCT_CODE,
                            '' CIC_CODE,
                            A.CUSTOMER_ID ID_NO,
                            '' TAX_CODE,
                            B.MEMBER_CODE BRANCH_CODE,
                            SYSDATE CREATED_DATE,
                            B.CUSTOMER_ADDRESS ADDRESS,
                            '' REGISTER_NO,
                            B.CUSTOMER_NAME CUSTOMER_NAME,
                            '' CUSTOMER_CODE,
                            B.APPLICATION_ID APPLICATION_ID,
                            B.MAKER MAKER,
                            V_REQUEST_ID
  FROM CIS_OTHER_REQUEST_DETAIL A
  JOIN CIS_OTHER_REQUEST B ON A.REQUEST_ID=B.REQUEST_ID
  JOIN SYS_REFCODE C ON C.REF_GROUP='NEW_CREDIT_REQUEST' AND C.PAR3=V_COMBO_PRODUCT
  WHERE A.REQUEST_ID=V_REQUEST_ID
        AND PR_STATUS_MATRIX_CIC(A.CUSTOMER_ID, '', '', C.PAR2, C.REF_CODE, '') = 'UPDATE CIC';

END IF;
--CAC BAN TIN MOI
INSERT INTO CIS_MM_OTHER_REQ_REQCIC(ID, CIS_NO,REQUEST_ID,CREATED_DATE)
select SEQ_CIS_MM_OTHER_REQ_REQCIC.NEXTVAL, CIS_NO, REQUEST_ID, SYSDATE
from CIS_REQUEST_TMP;

--LAY CAC BAN TIN CU THEO CIC
INSERT INTO CIS_MM_OTHER_REQ_REQCIC(ID, CIS_NO,REQUEST_ID,CREATED_DATE)
SELECT SEQ_CIS_MM_OTHER_REQ_REQCIC.NEXTVAL, CIS_NO, REQUEST_ID,SYSDATE FROM (
  SELECT PR_STATUS_MATRIX_CIC(A.CIC_CUST_ID_NO, A.CIC_CUST_REG, A.CIC_CUST_TAX, C.PAR2, C.REF_CODE, A.CIC_CODE) CIS_NO
         ,A.REQUEST_ID
  FROM CIS_OTHER_REQUEST_CHECK A
  JOIN SYS_REFCODE C ON C.REF_GROUP='NEW_CREDIT_REQUEST' AND C.PAR3=V_COMBO_PRODUCT
  WHERE A.REQUEST_ID=V_REQUEST_ID)
  WHERE CIS_NO <> 'UPDATE CIC';

--LAY CAC BAN TIN CU THEO ID
IF NVL(V_ROWS_COUNT,0)=0 THEN
  INSERT INTO CIS_MM_OTHER_REQ_REQCIC(ID, CIS_NO,REQUEST_ID,CREATED_DATE)
  SELECT SEQ_CIS_MM_OTHER_REQ_REQCIC.NEXTVAL, CIS_NO, REQUEST_ID,SYSDATE FROM (
    SELECT PR_STATUS_MATRIX_CIC(A.CUSTOMER_ID, '', '', C.PAR2, C.REF_CODE, '') CIS_NO
           ,A.REQUEST_ID
  FROM CIS_OTHER_REQUEST_DETAIL A
--  JOIN CIS_OTHER_REQUEST B ON A.REQUEST_ID=B.REQUEST_ID
  JOIN SYS_REFCODE C ON C.REF_GROUP='NEW_CREDIT_REQUEST' AND C.PAR3=V_COMBO_PRODUCT
  WHERE A.REQUEST_ID=V_REQUEST_ID)
    WHERE CIS_NO <> 'UPDATE CIC';

END IF;

-- INSERT DU LIEU VAO BANG HOI TIN
INSERT INTO CIS_REQUEST(ID, CHANNEL,
                            CUSTOMER_TYPE,
                            STATUS,
                            PRODUCT_CODE,
                            CIC_CODE,
                            ID_NO,
                            TAX_CODE,
                            BRANCH_CODE,
                            CREATED_DATE,
                            ADDRESS,
                            REGISTER_NO,
                            CUSTOMER_NAME,
                            CUSTOMER_CODE,
                            APPLICATION_ID,
                            MAKER,
                            REQUEST_ID,
                            KEYWORD, KEYWORD_ID)
SELECT CIS_NO,
        CHANNEL,
        CUSTOMER_TYPE,
        STATUS,
        PRODUCT_CODE,
        CIC_CODE,
        ID_NO,
        TAX_CODE,
        BRANCH_CODE,
        CREATED_DATE,
        ADDRESS,
        TAX_CODE REGISTER_NO,--30/01/2023 Fix loi thieu thong tin dkkd
        CUSTOMER_NAME,
        CUSTOMER_CODE,
        APPLICATION_ID,
        MAKER,
        REQUEST_ID,
        pkg_utility.removesignvietnamess(CIS_NO||','||REGISTER_NO||','||TAX_CODE||','||CIC_CODE||'.'||CUSTOMER_CODE||','||CUSTOMER_NAME||','||PRODUCT_CODE||','||nvl(maker,user)||','|| ','||Id_No),
        pkg_utility.removesignvietnamess(','||REGISTER_NO||','||TAX_CODE||','||CIC_CODE||','||Id_No||',')

FROM CIS_REQUEST_TMP;

--Kiem tra xem du lieu phan hoi da day du chua
SELECT COUNT(9) INTO V_ROWS_COUNT
FROM  CIS_MM_OTHER_REQ_REQCIC A
LEFT JOIN CIS_REQUEST B ON A.CIS_NO=B.CIS_NO
WHERE A.REQUEST_ID=V_REQUEST_ID AND B.STATUS<>'RECEIVED';

UPDATE CIS_OTHER_REQUEST
SET STATUS = CASE WHEN NVL(V_ROWS_COUNT,0)=0 THEN 'RECEIVED' ELSE 'WAITING' END
WHERE REQUEST_ID=V_REQUEST_ID;


OPEN p_out FOR
SELECT * 
FROM CIS_OTHER_REQUEST
WHERE REQUEST_ID=V_REQUEST_ID;

COMMIT;
END;

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:Th?c hi?n t󺀠toᮠk?t qu? tr? l?i
*/
PROCEDURE PR_GENERATE_RESPONSE (P_REQUEST_ID VARCHAR2, p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);  
V_RESPONSE_ID NUMBER;
V_CIC_CODE_ROWS NUMBER;
BEGIN

SELECT NVL(MAX(REQUEST_ID),'') INTO V_REQUEST_ID FROM CIS_OTHER_REQUEST WHERE REQUEST_ID=P_REQUEST_ID AND STATUS = 'RECEIVED';
IF V_REQUEST_ID IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy thông tin yêu cầu ['||P_REQUEST_ID||'] trong hệ thống!' );
  RETURN;
END IF;

V_RESPONSE_ID := SEQ_CIS_OTHER_RESPONSE.NEXTVAL;

--TODO: THUC HIEN TINH TOAN KEET QUA TRA LOI
PR_CALCULATOR(V_REQUEST_ID);

UPDATE CIS_OTHER_REQUEST
SET STATUS='GENERATED'
WHERE REQUEST_ID=V_REQUEST_ID;

OPEN p_out FOR
SELECT * 
FROM CIS_OTHER_REQUEST WHERE REQUEST_ID=V_REQUEST_ID;

END;

/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:L?y b?n tin tr? l?i
*/
PROCEDURE PR_GET_RESPONSE (P_REQUEST_ID VARCHAR2, p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);  
V_CIC_CODE_ROWS NUMBER;
BEGIN

SELECT NVL(MAX(REQUEST_ID),'') INTO V_REQUEST_ID FROM CIS_OTHER_REQUEST WHERE REQUEST_ID=P_REQUEST_ID;
IF V_REQUEST_ID IS NULL THEN
  raise_application_error( -20000, 'Không tìm thấy thông tin yêu cầu ['||P_REQUEST_ID||'] trong hệ thống!' );
  RETURN;
END IF;

--TODO: THUC HIEN L?Y B?N TIN TR? L҉
OPEN p_out FOR
SELECT B.*, A.STATUS REQUEST_STATUS, A.BATCH_ID
FROM CIS_OTHER_REQUEST A
LEFT JOIN CIS_OTHER_RESPONSE B ON A.REQUEST_ID=B.REQUEST_ID
WHERE A.REQUEST_ID = V_REQUEST_ID;

END;


/*
Creater: CuongNH2
Create Date: 29/6/2020
Des:L?y b?n tin tr? l?i
*/
PROCEDURE PR_GET_RESPONSE_DETAIL (P_RESPONSE_ID VARCHAR2, p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);  
V_CIC_CODE_ROWS NUMBER;
BEGIN

--TODO: THUC HIEN L?Y B?N TIN TR? L҉
OPEN p_out FOR
SELECT A.*, B.PRODUCT_CODE
FROM CIS_OTHER_RESPONSE_DETAIL A
JOIN CIS_RESPONSE B ON A.CIS_NO=B.CIS_NO
--JOIN CIS_OTHER_RESPONSE C ON C.RESPONSE_ID=A.OTHER_RESPONSE_ID
--JOIN CIS_OTHER_REQUEST D ON D.REQUEST_ID=C.REQUEST_ID
WHERE A.OTHER_RESPONSE_ID = P_RESPONSE_ID;

END;


/*
Creater: CuongNH2
Create Date: 29/6/2020
Des: C?p nh?t tr?ng th᩠b?n tr? l?i tin
*/
PROCEDURE PR_UPDATE_OTHER_RESPONSE (P_RESPONSE_ID VARCHAR2,
                                   P_RESPONSE_STATUS VARCHAR2,
                                   P_RESPONSE_MESSAGE VARCHAR2,
                                   P_RESPONSE_DATA VARCHAR2,
                                   p_out    OUT SYS_REFCURSOR) AS
V_REQUEST_ID VARCHAR2(50);  
V_CIC_CODE_ROWS NUMBER;
BEGIN

UPDATE CIS_OTHER_RESPONSE
SET RESPONSE_STATUS = P_RESPONSE_STATUS
    ,RESPONSE_MESSAGE = P_RESPONSE_MESSAGE
    ,RESPONSE_DATE = SYSDATE
    --,RESPONSE_DATA = P_RESPONSE_DATA
WHERE RESPONSE_ID = P_RESPONSE_ID;-- AND P_RESPONSE_STATUS IN ('SENT','SENT_ERROR','RECEIVED');

UPDATE CIS_OTHER_REQUEST A
SET A.STATUS=P_RESPONSE_STATUS
WHERE A.REQUEST_ID IN (SELECT REQUEST_ID FROM CIS_OTHER_RESPONSE WHERE RESPONSE_ID = P_RESPONSE_ID AND P_RESPONSE_STATUS IN ('RECEIVED'));

OPEN p_out FOR
SELECT A.*
FROM CIS_OTHER_RESPONSE A
WHERE A.RESPONSE_ID = P_RESPONSE_ID;

END;

/*
Creater: CuongNH2
Create Date: 6/12/2021
Des: T쭠ki?m cᣠy굠c?u h?i tin theo ?i?u ki?n
*/
PROCEDURE PR_SEARCH_OTHER_REQUEST (p_application_id varchar2,
                                   p_request_id varchar2,
                                   p_other_request_id varchar2, 
                                   p_batch_id varchar2,  
                                   p_from_date varchar2, 
                                   p_to_date varchar2, 
                                   p_out    out sys_refcursor) AS
BEGIN

OPEN p_out FOR
SELECT A.*
FROM CIS_OTHER_REQUEST A
WHERE (A.SOURCE_REQUEST_ID = P_REQUEST_ID or P_REQUEST_ID is null)
    AND (A.REQUEST_ID=p_other_request_id OR p_other_request_id IS NULL)
    AND (A.BATCH_ID=P_BATCH_ID OR P_BATCH_ID IS NULL)
    AND (P_BATCH_ID IS NOT NULL OR P_REQUEST_ID IS NOT NULL)
    AND A.APPLICATION_ID=P_APPLICATION_ID
    AND A.REQUEST_DATE BETWEEN TO_DATE(p_from_date,'yyyyMMdd_HH24miss') and TO_DATE(p_to_date,'yyyyMMdd_HH24miss')
;


END;

PROCEDURE PR_CHECK_OTHER_REQ_RECIVED AS
V_REQUEST_ID VARCHAR2(50);  
V_ROWS_COUNT NUMBER;
BEGIN


UPDATE CIS_OTHER_REQUEST A
SET status='WAITING'
where REQUEST_ID not in (select REQUEST_ID from cis_other_response)
and status='GENERATED'
and A.REQUEST_DATE>SYSDATE-5;

DECLARE
  CURSOR c_list_req
  IS
    select * from cis_other_request where status in ('WAITING','RECEIVED');
BEGIN
  FOR r_req IN c_list_req
  LOOP
        --Kiem tra xem du lieu phan hoi da day du chua
        SELECT COUNT(9) INTO V_ROWS_COUNT
        FROM  CIS_MM_OTHER_REQ_REQCIC A
        JOIN CIS_REQUEST B ON A.CIS_NO=B.CIS_NO
        WHERE A.REQUEST_ID=r_req.REQUEST_ID AND B.STATUS<>'RECEIVED';

        UPDATE CIS_OTHER_REQUEST
        SET STATUS = CASE WHEN NVL(V_ROWS_COUNT,0)=0 THEN 'GENERATED' ELSE 'WAITING' END
        WHERE REQUEST_ID=r_req.REQUEST_ID;

        IF NVL(V_ROWS_COUNT,0)=0 THEN
            PR_CALCULATOR(r_req.REQUEST_ID);
        END IF;
  END LOOP;
END;

END;



/*
Creater: CuongNH2
Create Date: 25/2/2022
Des: Th?c hi?n ki?m tra v࠴?o l?p b?n tin tr? l?i
*/
PROCEDURE PR_CHECK_OTHER_REQUEST (p_application_id varchar2,
                                   p_request_id varchar2,
                                   p_other_request_id varchar2, 
                                   p_batch_id varchar2, 
                                   p_out    out sys_refcursor) AS
BEGIN

--PR_CHECK_OTHER_REQ_RECIVED;

OPEN p_out FOR
SELECT A.*
FROM CIS_OTHER_REQUEST A
WHERE (A.SOURCE_REQUEST_ID = P_REQUEST_ID or P_REQUEST_ID is null)
    AND (A.REQUEST_ID=p_other_request_id OR p_other_request_id IS NULL)
    AND (A.BATCH_ID=P_BATCH_ID OR P_BATCH_ID IS NULL)
    AND (P_BATCH_ID IS NOT NULL OR P_REQUEST_ID IS NOT NULL)
    AND A.APPLICATION_ID=P_APPLICATION_ID 
;


END;
end PCK_CIS_OTHER_REQUEST;


/
--------------------------------------------------------
--  DDL for Package Body PCK_DATA_REPORT_FROM_CIC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_DATA_REPORT_FROM_CIC" AS


PROCEDURE PR_GET_FILE_BY_NAME(P_ID VARCHAR2,
                    P_FILE_NAME VARCHAR2,
                    P_FILE_STATUS VARCHAR2, 
                    P_RESPONSE_DATE VARCHAR2,
                    P_FILE_PATH VARCHAR2,
                    P_CHECK_SUM_MD5 VARCHAR2, 
                    p_out    OUT SYS_REFCURSOR) AS
--V_ROWS NUMBER;
BEGIN
OPEN P_OUT FOR
SELECT *
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE A.FILE_NAME=P_FILE_NAME;

END;

PROCEDURE PR_UPDATE_STATUS_FILE(P_ID VARCHAR2,
                    P_FILE_NAME VARCHAR2,
                    P_FILE_STATUS VARCHAR2, 
                    P_RESPONSE_DATE VARCHAR2,
                    P_FILE_PATH VARCHAR2,
                    P_CHECK_SUM_MD5 VARCHAR2, 
                    p_out    OUT SYS_REFCURSOR) AS
--V_ROWS NUMBER;
BEGIN

UPDATE CIC_DATA_REPORT_FROM_CIC A
SET FILE_STATUS=P_FILE_STATUS

WHERE A.FILE_NAME=P_FILE_NAME;


OPEN P_OUT FOR
SELECT *
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE A.FILE_NAME=P_FILE_NAME;

END;

END PCK_DATA_REPORT_FROM_CIC;


/
--------------------------------------------------------
--  DDL for Package Body PCK_REPORT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_REPORT" AS
V_LIMIT_ROWS NUMBER:=1000;
V_BRANCH_PATH VARCHAR2(1000);
/*
CREATE: CUONGNH
DESCRIPTION: 5.6.1.  ICR.06.01 - Bᯠcᯠtruy c?p h? th?ng
*/ 
PROCEDURE RPT_ICR0601(  p_page VARCHAR2,
                        p_limit VARCHAR2,
                        P_FROM_DATE VARCHAR2,
                        P_TO_DATE   VARCHAR2,
                        P_USER_NAME VARCHAR2,
                        P_BRANCH_CODE    VARCHAR2,
                        P_RESOURCE_URL    VARCHAR2,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) AS
V_FROM_DATE DATE;
V_TO_DATE DATE;
V_TOTAL  NUMBER:=0;
V_BRANCH_REPORT VARCHAR2(1000);
BEGIN
pkg_system_log.PR_LOG_INFO('RPT_ICR0601','CHECK RPT_ICR0601',P_BRANCH_CODE,'PR');

V_FROM_DATE := CASE WHEN P_FROM_DATE IS NULL THEN TRUNC(SYSDATE)-10 ELSE TO_DATE(P_FROM_DATE,'DD/MM/YYYY') END;
V_TO_DATE := CASE WHEN P_TO_DATE IS NULL THEN TRUNC(SYSDATE) ELSE TO_DATE(P_TO_DATE,'DD/MM/YYYY') END;
SELECT MAX(NVL(A.MEMBER_VIEW_REPORT,'N/A')||','||A.MEMBER_CODE)
INTO V_BRANCH_REPORT
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;
--9/8/2021 Fix loi search theo don vi
SELECT NVL(MAX(NVL(A.REF_CODE_PERMISSION,'N/A')),'N/A')
INTO V_BRANCH_PATH
FROM V_BRANCH A
WHERE A.REF_CODE=P_BRANCH_CODE;



-- DATA PERMISSION
INSERT INTO CIS_BRANCH_TMP (BRANCH_CODE, BRANCH_TREE)
WITH TEMP_DATA AS(
    SELECT DISTINCT TRIM(REGEXP_SUBSTR(BRCODE, '[^,]+', 1, LEVEL)) BRANCH
      FROM (SELECT V_BRANCH_REPORT BRCODE FROM DUAL) T
    CONNECT BY INSTR(BRCODE, ',', 1, LEVEL - 1) > 0 )
SELECT refCode.REF_CODE, REF_CODE_PERMISSION
FROM V_BRANCH refCode
WHERE EXISTS (SELECT * FROM TEMP_DATA XX WHERE refCode.REF_CODE_PERMISSION LIKE '%,'||XX.BRANCH||',%') ;

select count(*) INTO V_TOTAL  from SYS_RESOURCEACCESSMANAGEMENT A
    LEFT JOIN SYS_USER B ON A.ACCESS_USER=B.USER_NAME
    LEFT JOIN V_BRANCH C ON B.MEMBER_CODE=C.REF_CODE
    LEFT JOIN SYS_RESOURCES D ON TO_CHAR(D.RES_ID) = A.RESOURCE_URL
    WHERE A.ACCESS_DATE BETWEEN V_FROM_DATE AND V_TO_DATE+1
          AND (A.ACCESS_USER = P_USER_NAME OR P_USER_NAME IS NULL)
          AND (C.ref_code_permission LIKE V_BRANCH_PATH||'%'  OR V_BRANCH_PATH = 'N/A')
          AND (D.TASK_FLOW_ID = P_RESOURCE_URL OR P_RESOURCE_URL IS NULL)
          AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE C.ref_code_permission LIKE XX.BRANCH_TREE||'%');


OPEN P_OUT FOR  
SELECT *  FROM (
SELECT a.*,V_TOTAL TOTAL_RECORD, rownum r__ FROM(
    SELECT A.ACCESS_USER
           ,B.MEMBER_CODE BRANCH_CODE
           ,C.REF_NAME_VN BRANCH_NAME
           ,A.ACCESS_DATE 
           ,E.REF_NAME_VN ACCESS_STATUS
           ,A.CLIENT_IP
           ,A.RESOURCE_URL
           ,NVL(D.RES_NM,A.RESOURCE_URL) || ' -> '|| A.RESOURCE_ACTION RESOURCE_NAME
    FROM SYS_RESOURCEACCESSMANAGEMENT A
    LEFT JOIN SYS_USER B ON A.ACCESS_USER=B.USER_NAME
    LEFT JOIN V_BRANCH C ON B.MEMBER_CODE=C.REF_CODE
    LEFT JOIN SYS_RESOURCES D ON TO_CHAR(D.RES_ID) = A.RESOURCE_URL 
    LEFT JOIN SYS_REFCODE E ON A.ACCESS_STATUS=E.REF_CODE AND E.REF_GROUP= 'ACCESS_STATUS'
    WHERE A.ACCESS_DATE BETWEEN V_FROM_DATE AND V_TO_DATE+1
          AND (A.ACCESS_USER = P_USER_NAME OR P_USER_NAME IS NULL)
          AND (C.ref_code_permission LIKE V_BRANCH_PATH||'%'  OR V_BRANCH_PATH = 'N/A')--9/8/2021 Fix loi search theo don vi
          --AND (','||P_BRANCH_CODE||',' like ','||B.MEMBER_CODE||','  OR P_BRANCH_CODE IS NULL)
          AND (D.TASK_FLOW_ID = P_RESOURCE_URL OR P_RESOURCE_URL IS NULL)
          --AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE XX.BRANCH_TREE LIKE '%,'||B.MEMBER_CODE||',%')
          AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE C.ref_code_permission LIKE XX.BRANCH_TREE||'%')--15-7-2021 fix loi phan quyen du lieu
    ORDER BY ACCESS_DATE DESC)a WHERE p_page is null  OR (rownum < ((p_page * p_limit) + 1 ))  )WHERE p_page is null OR (r__ >= (((p_page-1) * p_limit) + 1));

END;

/*
CREATE: CUONGNH
DESCRIPTION: 5.6.2.  ICR.06.02 - Bᯠcᯠqu?n lý ng??i dùng
*/
PROCEDURE RPT_ICR0602 ( P_BRANCH_CODE    VARCHAR2,
                        P_KEYWORD        VARCHAR2,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) AS
V_BRANCH_REPORT VARCHAR2(1000);
BEGIN
SELECT MAX(NVL(A.MEMBER_VIEW_REPORT,'N/A')||','||A.MEMBER_CODE)
INTO V_BRANCH_REPORT
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;

-- DATA PERMISSION--update 20210511
INSERT INTO CIS_BRANCH_TMP (BRANCH_CODE, BRANCH_TREE)
WITH TEMP_DATA AS(
    SELECT DISTINCT TRIM(REGEXP_SUBSTR(BRCODE, '[^,]+', 1, LEVEL)) BRANCH
      FROM (SELECT V_BRANCH_REPORT BRCODE FROM DUAL) T
    CONNECT BY INSTR(BRCODE, ',', 1, LEVEL - 1) > 0 )
SELECT refCode.REF_CODE, REF_CODE_PERMISSION
FROM V_BRANCH refCode
WHERE EXISTS (SELECT * FROM TEMP_DATA XX WHERE refCode.REF_CODE_PERMISSION LIKE '%,'||XX.BRANCH||',%') ;

--9/8/2021 Fix loi search theo don vi
SELECT NVL(MAX(NVL(A.REF_CODE_PERMISSION,'N/A')),'N/A')
INTO V_BRANCH_PATH
FROM V_BRANCH A
WHERE A.REF_CODE=P_BRANCH_CODE;

OPEN P_OUT FOR 
WITH DATA_PERMISION AS(
    SELECT DISTINCT TRIM(REGEXP_SUBSTR(BRCODE, '[^,]+', 1, LEVEL)) BRANCH
      FROM (SELECT V_BRANCH_REPORT BRCODE FROM DUAL) T
    CONNECT BY INSTR(BRCODE, ',', 1, LEVEL - 1) > 0 ) 
SELECT *
FROM (
    SELECT  A.MEMBER_CODE BRANCH_CODE
           ,C.REF_NAME_VN BRANCH_NAME
           ,A.USER_NAME ||'.'|| A.FULL_NAME FULL_NAME
           ,A.CREATE_DATE
           ,A.STATUS
           ,D.REF_NAME_VN STATUS_NAME
    FROM SYS_USER A
    LEFT JOIN V_BRANCH C ON A.MEMBER_CODE=C.REF_CODE
    LEFT JOIN SYS_REFCODE D ON D.REF_GROUP = 'LS_STATUS' AND A.STATUS = D.REF_CODE
    --AND EXISTS (SELECT * FROM DATA_PERMISION XX WHERE A.MEMBER_CODE LIKE XX.BRANCH||'%')
    WHERE  (C.ref_code_permission LIKE V_BRANCH_PATH||'%'  OR V_BRANCH_PATH = 'N/A')--9/8/2021 Fix loi search theo don vi
          AND PKG_UTILITY.RemoveSignVietnamess(A.USER_NAME ||','|| A.FULL_NAME) like '%'|| PKG_UTILITY.RemoveSignVietnamess(P_KEYWORD) ||'%'
    --AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE XX.BRANCH_TREE LIKE '%,'||A.MEMBER_CODE||',%')--update 20210511
          AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE C.ref_code_permission LIKE XX.BRANCH_TREE||'%')--15-7-2021 fix loi phan quyen du lieu

    ORDER BY a.Create_Date DESC)
--WHERE ROWNUM<V_LIMIT_ROWS
;



END;


/*
CREATE: CUONGNH
DESCRIPTION: 5.6.3.	ICR.06.03 - Bᯠcᯠchi ti?t tra c?u tin theo t?ng b?n h?i tin
*/
PROCEDURE RPT_ICR0603 ( P_BRANCH_CODE    VARCHAR2,
                        P_CHANNEL        VARCHAR2,
                        P_PRODUCT_CODE        VARCHAR2,
                        P_FROM_DATE        DATE,
                        P_TO_DATE        DATE,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_KEYWORD VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) AS
V_FROM_DATE DATE;
V_TO_DATE DATE;
V_GROUP_NAME VARCHAR2(1000);
V_BRANCH_REPORT VARCHAR2(1000);
V_PRODUCT_LIST VARCHAR2(1000);
V_KEYWORD VARCHAR2(1000);
BEGIN

V_FROM_DATE := CASE WHEN P_FROM_DATE IS NULL THEN TRUNC(SYSDATE)-10000 ELSE P_FROM_DATE END;
V_TO_DATE := CASE WHEN P_TO_DATE IS NULL THEN TRUNC(SYSDATE) ELSE P_TO_DATE END;
V_KEYWORD:=pkg_utility.removesignvietnamess(P_KEYWORD);
SELECT ','|| listagg(','||NVL(GROUP_NAME,'')||',',', ') within group(order by GROUP_NAME) ||','
INTO V_GROUP_NAME
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;

SELECT MAX(NVL(A.MEMBER_VIEW_REPORT,'N/A')||','||A.MEMBER_CODE)
INTO V_BRANCH_REPORT
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;

SELECT ','|| listagg(','||NVL(PAR2,'')||',',', ') within group(order by PAR2) ||',' INTO  V_PRODUCT_LIST
FROM SYS_GROUPS A
WHERE V_GROUP_NAME LIKE '%,'|| A.GROUP_NAME ||',%';

-- DATA PERMISSION--update 20210511
INSERT INTO CIS_BRANCH_TMP (BRANCH_CODE, BRANCH_TREE)
WITH TEMP_DATA AS(
    SELECT DISTINCT TRIM(REGEXP_SUBSTR(BRCODE, '[^,]+', 1, LEVEL)) BRANCH
      FROM (SELECT V_BRANCH_REPORT BRCODE FROM DUAL) T
    CONNECT BY INSTR(BRCODE, ',', 1, LEVEL - 1) > 0 )
SELECT refCode.REF_CODE, REF_CODE_PERMISSION
FROM V_BRANCH refCode
WHERE EXISTS (SELECT * FROM TEMP_DATA XX WHERE refCode.REF_CODE_PERMISSION LIKE '%,'||XX.BRANCH||',%') ;

--9/8/2021 Fix loi search theo don vi
SELECT NVL(MAX(NVL(A.REF_CODE_PERMISSION,'N/A')),'N/A')
INTO V_BRANCH_PATH
FROM V_BRANCH A
WHERE A.REF_CODE=P_BRANCH_CODE;

OPEN P_OUT FOR  
SELECT *
FROM (
        SELECT A.BRANCH_CODE BRANCH_CODE
               ,C.PAR2 BRANCH_NAME 
               ,A.CHANNEL
               ,A.PRODUCT_CODE
               ,D.REF_NAME_VN PRODUCT_NAME
               ,A.MAKER
                ,CASE WHEN A.CUSTOMER_CODE IS NULL OR LOWER(A.CUSTOMER_CODE) = 'undefined'
                   THEN ''
               ELSE A.CUSTOMER_CODE
               END CUSTOMER_CODE
               ,A.CUSTOMER_NAME
               ,A.ID_NO
               ,A.REGISTER_NO
               ,A.TAX_CODE
               ,A.CREATED_DATE
               ,A.RESPONSE_DATE
               ,CASE WHEN A.IS_DATA='Y' THEN PKG_UTILITY.FORMAT_NUMBER(E.NORMAL_PRICE) ELSE PKG_UTILITY.FORMAT_NUMBER(E.NON_NORMAL_PRICE) END FEE 
               ,CASE WHEN A.MSG_ID IS NULL THEN 'No' ELSE 'Yes' END REQUEST_ID
               ,F.REF_NAME_VN STATUS_STR
               ,A.ID
               ,A.DEPARTMENT
               ,G.REF_NAME_VN DEPARTMENT_NAME
        FROM CIS_REQUEST A
        LEFT JOIN SYS_USER B ON A.MAKER=B.USER_NAME
        LEFT JOIN V_BRANCH C ON A.BRANCH_CODE=C.REF_CODE
        LEFT JOIN SYS_REFCODE D ON D.REF_GROUP = 'LS_PRODUCT' AND A.PRODUCT_CODE = D.REF_CODE
        LEFT JOIN SYS_REFCODE F ON F.REF_GROUP = 'STATUS_REQUEST' AND A.STATUS = F.REF_CODE
        LEFT JOIN SYS_REFCODE G ON G.REF_GROUP = 'LS_DEPARTMENT' AND A.DEPARTMENT = G.REF_CODE
        LEFT JOIN SYS_PRICE E ON A.PRODUCT_CODE=E.PRICE_CODE AND A.RESPONSE_DATE BETWEEN E.EFFECTIVE_DATE AND NVL(E.EXPIRATION_DATE,SYSDATE+100) AND A.STATUS='RECEIVED'

        WHERE A.CREATED_DATE BETWEEN V_FROM_DATE AND V_TO_DATE+1 
              --AND (A.BRANCH_CODE IN (SELECT REF_CODE FROM V_BRANCH XX WHERE XX.REF_CODE_PERMISSION LIKE '%,'||P_BRANCH_CODE||',%') OR P_BRANCH_CODE IS NULL) --update 20210511
              AND (C.ref_code_permission LIKE V_BRANCH_PATH||'%'  OR V_BRANCH_PATH = 'N/A')--9/8/2021 Fix loi search theo don vi
              AND (A.CHANNEL = P_CHANNEL OR P_CHANNEL IS NULL)
              AND (A.PRODUCT_CODE = P_PRODUCT_CODE OR P_PRODUCT_CODE IS NULL)
              AND V_PRODUCT_LIST like '%,'|| A.PRODUCT_CODE ||',%' 
              AND (KEYWORD like '%'||V_KEYWORD||'%' OR V_KEYWORD IS NULL)
--               AND (KEYWORD like '%cuongnh1%')
              --AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE XX.BRANCH_TREE LIKE '%,'||A.BRANCH_CODE||',%')--update 20210511              
          AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE C.ref_code_permission LIKE XX.BRANCH_TREE||'%')--15-7-2021 fix loi phan quyen du lieu
         ORDER BY CREATED_DATE DESC, A.REQUESTED_DATE DESC)
;



END;


/*
CREATE: CUONGNH
DESCRIPTION: 5.6.4.	ICR.06.04 - Bᯠcᯠchi ti?t tra c?u t?ng h?p theo user h?i tin
*/
PROCEDURE RPT_ICR0604 ( P_BRANCH_CODE    VARCHAR2,
                        P_CHANNEL        VARCHAR2,
                        P_PRODUCT_CODE        VARCHAR2,
                        P_FROM_DATE        DATE,
                        P_TO_DATE        DATE,
                        P_USER VARCHAR2,
                        P_CLIENT_IP VARCHAR2,
                        P_USER_AGENT VARCHAR2,
                        P_KEYWORD VARCHAR2,
                        P_OUT    OUT SYS_REFCURSOR) AS
V_FROM_DATE DATE;
V_TO_DATE DATE;
V_GROUP_NAME VARCHAR2(1000);
V_BRANCH_REPORT VARCHAR2(1000);
V_PRODUCT_LIST VARCHAR2(1000);
V_KEYWORD VARCHAR2(1000);
BEGIN

V_FROM_DATE := CASE WHEN P_FROM_DATE IS NULL THEN TRUNC(SYSDATE)-30 ELSE P_FROM_DATE END;
V_TO_DATE := CASE WHEN P_FROM_DATE IS NULL THEN TRUNC(SYSDATE) ELSE P_TO_DATE END;
V_KEYWORD:=pkg_utility.removesignvietnamess(P_KEYWORD);

SELECT ','|| listagg(','||NVL(GROUP_NAME,'')||',',', ') within group(order by GROUP_NAME) ||','
INTO V_GROUP_NAME
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;

SELECT MAX(NVL(A.MEMBER_VIEW_REPORT,'N/A')||','||A.MEMBER_CODE)
INTO V_BRANCH_REPORT
FROM SYS_USER A
WHERE A.USER_NAME = P_USER;


SELECT ','|| listagg(','||NVL(PAR2,'')||',',', ') within group(order by PAR2) ||',' INTO  V_PRODUCT_LIST
FROM SYS_GROUPS A
WHERE V_GROUP_NAME LIKE '%,'|| A.GROUP_NAME ||',%';


-- DATA PERMISSION--update 20210511
INSERT INTO CIS_BRANCH_TMP (BRANCH_CODE, BRANCH_TREE)
WITH TEMP_DATA AS(
    SELECT DISTINCT TRIM(REGEXP_SUBSTR(BRCODE, '[^,]+', 1, LEVEL)) BRANCH
      FROM (SELECT V_BRANCH_REPORT BRCODE FROM DUAL) T
    CONNECT BY INSTR(BRCODE, ',', 1, LEVEL - 1) > 0 )
SELECT refCode.REF_CODE, REF_CODE_PERMISSION
FROM V_BRANCH refCode
WHERE EXISTS (SELECT * FROM TEMP_DATA XX WHERE refCode.REF_CODE_PERMISSION LIKE '%,'||XX.BRANCH||',%') ;

--9/8/2021 Fix loi search theo don vi
SELECT NVL(MAX(NVL(A.REF_CODE_PERMISSION,'N/A')),'N/A')
INTO V_BRANCH_PATH
FROM V_BRANCH A
WHERE A.REF_CODE=P_BRANCH_CODE;


OPEN P_OUT FOR  
SELECT *
FROM (
        SELECT A.BRANCH_CODE BRANCH_CODE
               ,C.PAR2 BRANCH_NAME 
               ,A.CHANNEL
               ,A.PRODUCT_CODE
               ,D.REF_NAME_VN PRODUCT_NAME
               ,PKG_UTILITY.FORMAT_NUMBER(COUNT(9)) MAKER_COUNT
               ,A.MAKER
               ,PKG_UTILITY.FORMAT_NUMBER(SUM(CASE WHEN A.IS_DATA='Y' THEN E.NORMAL_PRICE ELSE E.NON_NORMAL_PRICE END)) FEE 
               ,A.DEPARTMENT
               ,G.REF_NAME_VN DEPARTMENT_NAME
        FROM CIS_REQUEST A
        --LEFT JOIN SYS_USER B ON A.MAKER=B.USER_NAME
        LEFT JOIN V_BRANCH C ON A.BRANCH_CODE=C.REF_CODE
        LEFT JOIN SYS_REFCODE D ON D.REF_GROUP = 'LS_PRODUCT' AND A.PRODUCT_CODE = D.REF_CODE
        LEFT JOIN SYS_PRICE E ON A.PRODUCT_CODE=E.PRICE_CODE AND A.REQUESTED_DATE BETWEEN E.EFFECTIVE_DATE AND NVL(E.EXPIRATION_DATE,SYSDATE+100) AND A.STATUS='RECEIVED'
        LEFT JOIN SYS_REFCODE G ON G.REF_GROUP = 'LS_DEPARTMENT' AND A.DEPARTMENT = G.REF_CODE

        WHERE A.CREATED_DATE BETWEEN V_FROM_DATE AND V_TO_DATE+1 
              --AND (A.BRANCH_CODE IN (SELECT REF_CODE FROM V_BRANCH XX WHERE XX.REF_CODE_PERMISSION LIKE '%,'||P_BRANCH_CODE||',%') OR P_BRANCH_CODE IS NULL) --update 20210511
              AND (C.ref_code_permission LIKE V_BRANCH_PATH||'%'  OR V_BRANCH_PATH = 'N/A')--9/8/2021 Fix loi search theo don vi
              AND (A.CHANNEL = P_CHANNEL OR P_CHANNEL IS NULL)
              AND (A.PRODUCT_CODE = P_PRODUCT_CODE OR P_PRODUCT_CODE IS NULL)
              AND A.STATUS='RECEIVED'
              --AND ROWNUM<100
              AND V_PRODUCT_LIST like '%,'|| A.PRODUCT_CODE ||',%'
              AND (A.MAKER LIKE '%'||V_KEYWORD||'%' OR V_KEYWORD is NULL )
              --AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE XX.BRANCH_TREE LIKE '%,'||A.BRANCH_CODE||',%')--update 20210511
          AND EXISTS (SELECT * FROM CIS_BRANCH_TMP XX WHERE C.ref_code_permission LIKE XX.BRANCH_TREE||'%')--15-7-2021 fix loi phan quyen du lieu

        GROUP BY A.BRANCH_CODE 
               ,C.PAR2  
               ,A.CHANNEL
               ,A.PRODUCT_CODE
               ,D.REF_NAME_VN
               ,A.MAKER
               ,A.DEPARTMENT
               ,G.REF_NAME_VN

        ORDER BY BRANCH_CODE,CHANNEL,PRODUCT_CODE)
--WHERE ROWNUM<V_LIMIT_ROWS
;



END;
end PCK_REPORT;


/
--------------------------------------------------------
--  DDL for Package Body PCK_REPORT_FROM_CIC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_REPORT_FROM_CIC" AS

PROCEDURE PR_CREATE_FILE(P_ID VARCHAR2,
                    P_FILE_NAME VARCHAR2,
                    P_FILE_STATUS VARCHAR2, 
                    P_RESPONSE_DATE VARCHAR2,
                    P_FILE_PATH VARCHAR2,
                    P_CHECK_SUM_MD5 VARCHAR2, 
                    p_out    OUT SYS_REFCURSOR) AS
V_ROWS NUMBER;
V_FILE_TYPE VARCHAR2(30);

BEGIN
V_FILE_TYPE := 'N/A';

SELECT COUNT(9)
INTO V_ROWS
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE A.FILE_NAME=P_FILE_NAME;

SELECT CASE WHEN INSTR(P_FILE_NAME, '.R18.', 1)>0 THEN 'R18' 
            WHEN INSTR(P_FILE_NAME, '.R19.', 1)>0 THEN 'R19' 
            WHEN INSTR(P_FILE_NAME, '.R19_W.', 1)>0 THEN 'R19_W' 
            ELSE 'N/A' END 
INTO V_FILE_TYPE
FROM dual;

IF V_ROWS = 0 THEN
    INSERT INTO CIC_DATA_REPORT_FROM_CIC (ID,FILE_NAME,
                                            FILE_STATUS,
                                            RESPONSE_DATE,
                                            FILE_PATH,
                                            CHECK_SUM_MD5,
                                            FILE_TYPE)
                                VALUES (SEQ_CIC_DATA_REPORT_FROM_CIC.nextval, P_FILE_NAME,
                                       'NEW',
                                       SYSDATE,
                                       P_FILE_PATH,
                                       P_CHECK_SUM_MD5,
                                       V_FILE_TYPE);
END IF;

OPEN P_OUT FOR
SELECT *
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE A.FILE_NAME=P_FILE_NAME;

END;

PROCEDURE PR_UPDATE_FILE(P_ID VARCHAR2,
                    P_FILE_NAME VARCHAR2,
                    P_FILE_STATUS VARCHAR2, 
                    P_RESPONSE_DATE VARCHAR2,
                    P_FILE_PATH VARCHAR2,
                    P_CHECK_SUM_MD5 VARCHAR2, 
                    p_out    OUT SYS_REFCURSOR) AS
V_ROWS NUMBER;
BEGIN

UPDATE CIC_DATA_REPORT_FROM_CIC A
SET FILE_STATUS=NVL(P_FILE_STATUS,FILE_STATUS)
    ,RESPONSE_DATE=SYSDATE
    ,FILE_PATH=NVL(P_FILE_PATH,FILE_PATH)
    ,CHECK_SUM_MD5=NVL(P_CHECK_SUM_MD5,CHECK_SUM_MD5)
    ,PROCESSING_DATE=CASE WHEN P_FILE_STATUS='DONE' THEN SYSDATE ELSE PROCESSING_DATE END
WHERE A.FILE_NAME=P_FILE_NAME;

commit;

OPEN P_OUT FOR
SELECT *
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE A.FILE_NAME=P_FILE_NAME;

END;

PROCEDURE PR_GET_FILE(P_ID VARCHAR2,
                    P_FILE_NAME VARCHAR2,
                    P_FILE_STATUS VARCHAR2, 
                    P_RESPONSE_DATE VARCHAR2,
                    P_FILE_PATH VARCHAR2,
                    P_CHECK_SUM_MD5 VARCHAR2, 
                    p_out    OUT SYS_REFCURSOR) AS
V_ROWS NUMBER;
BEGIN

OPEN P_OUT FOR
SELECT *
FROM CIC_DATA_REPORT_FROM_CIC A
WHERE (A.FILE_STATUS=P_FILE_STATUS OR P_FILE_STATUS IS NULL)
AND (FILE_NAME=P_FILE_NAME OR P_FILE_NAME IS NULL);

END;
END PCK_REPORT_FROM_CIC;


/
--------------------------------------------------------
--  DDL for Package Body PCK_REQUEST_LOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_REQUEST_LOG" AS

 
/*
Creater: CuongNH2
Created date:  24/8/2020
Description: Luu log g?i request sang partner  
*/
Procedure PR_LOG_INFO(P_REQUEST_ID varchar2,
                        P_MSG_TYPE varchar2,
                        P_MSG_DATA clob,
                        P_ERROR_CODE varchar2,
                        P_ERROR_MSG clob,
                        P_END_POINT varchar2, 
                        P_REQUEST_DATE varchar2, 
                        P_ADDITION_INFO varchar2,
                        p_out OUT types.ref_cursor) is
begin

INSERT INTO SYS_REQUEST_LOG(REQUEST_ID,
                            MSG_TYPE,
                            MSG_DATA,
                            "ERROR_CODE",
                            ERROR_MSG,
                            END_POINT,
                            REQUEST_DATE,
                            ADDITION_INFO)
VALUES(P_REQUEST_ID||'.'||DBMS_RANDOM.string('x',5),
      P_MSG_TYPE,
      P_MSG_DATA,
      P_ERROR_CODE,
      P_ERROR_MSG,
      P_END_POINT,
      SYSDATE,
      SYS_CONTEXT('USERENV','IP_ADDRESS') ||'.'|| P_ADDITION_INFO);
end;


end PCK_REQUEST_LOG;


/
--------------------------------------------------------
--  DDL for Package Body PCK_TOKEN
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PCK_TOKEN" AS

  PROCEDURE PR_GET_TOKEN (p_out    OUT SYS_REFCURSOR) AS
  BEGIN
    -- TODO: Implementation required for PROCEDURE PCK_TOKEN.PR_GET_TOKEN
    OPEN P_OUT FOR
    SELECT * FROM SYS_TOKEN;

  END PR_GET_TOKEN;
END PCK_TOKEN;


/
--------------------------------------------------------
--  DDL for Package Body PKG_CIC_GROUP_DEBT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PKG_CIC_GROUP_DEBT" AS
/******************************************************************************
   NAME:       PKG_CIC_GROUP_DEBT
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        31/07/2020      dodti       1. Created this package body.
******************************************************************************/
    V_PARAMETER   NVARCHAR2 (4000);
    V_ERRORS      NUMBER (10);
     PROCEDURE pr_get_list_cic_group_debt (
        p_text_search             VARCHAR2,
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_rpt_dt10                VARCHAR2,
        p_cst_cd                  VARCHAR2,
        p_cst_nm                  VARCHAR2,
        p_cic_code                VARCHAR2,
        p_bal                     VARCHAR2,
        p_group_debt              VARCHAR2,
        p_low_group_debt          VARCHAR2,
        p_member_code             VARCHAR2,
        p_user             IN     VARCHAR2,
        p_from_date             VARCHAR2,
        p_to_date             VARCHAR2,
        p_out                 OUT types.ref_cursor)
    AS
        v_text_search varchar2(4000);
        V_SEARCH_REQUEST_LIMIT int;
        v_from_date date;
        v_to_date date;
    BEGIN
      SELECT nvl(MAX(PAR1),0) INTO V_SEARCH_REQUEST_LIMIT
      FROM SYS_REFCODE
      WHERE REF_CODE='SEARCH_REQUEST_LIMIT';

        v_text_search := '%'||pkg_utility.removesignvietnamess(nvl(p_text_search,''))||'%';
        v_from_date := trunc(nvl(to_date(p_from_date,'dd/MM/yyyy'),sysdate-V_SEARCH_REQUEST_LIMIT));
        v_to_date := trunc(nvl(to_date(p_to_date,'dd/MM/yyyy'),sysdate))+1;

        OPEN p_out FOR   SELECT *
                           FROM cic_group_debt A
                           where (file_tp=p_file_tp or p_file_tp is null)
                                and ( TRIM(BOTH ' ' FROM rpt_dt)=p_rpt_dt or p_rpt_dt is null)
                                and (p_text_search is null or pkg_utility.removesignvietnamess(FILE_NAME ||','|| CST_CD ||','|| CST_NM ||','|| CIC_CODE ||','|| CST_ID||','|| MEMBER_CODE) like v_text_search)
                                and a.created_date between v_from_date and v_to_date
                                and rownum<1000;
    END; 
/*****/
   PROCEDURE pr_insert_record (
        p_id                      VARCHAR2,   
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_rpt_dt10                VARCHAR2,
        p_cst_cd                  VARCHAR2,
        p_cst_nm                  VARCHAR2,
        p_cic_code                VARCHAR2,
        p_bal                     NUMBER,
        p_group_debt              VARCHAR2,
        p_low_group_debt          VARCHAR2,
        p_member_code             VARCHAR2,
        p_cst_id             VARCHAR2,
        p_address             VARCHAR2,
        p_user             IN     VARCHAR2,
        p_out                 OUT types.ref_cursor)
    AS
    v_id number;    
    BEGIN
    v_id := SEQ_CIC_GROUP_DEBT.nextval;
    INSERT INTO CIC_GROUP_DEBT(id, file_name, file_tp, rpt_dt, rpt_dt10, cst_cd, cst_nm, cic_code, bal, group_debt, low_group_debt, member_code,created_date, created_user) 
    VALUES(v_id, p_file_name, p_file_tp, ltrim(rtrim(p_rpt_dt)), p_rpt_dt10, ltrim(rtrim(p_cst_cd)), ltrim(rtrim(p_cst_nm)), ltrim(rtrim(p_cic_code)), p_bal, p_group_debt, p_low_group_debt, p_member_code,sysdate,p_user);

    OPEN p_out FOR select v_id ID from dual;

    END;

    PROCEDURE pr_delete_record(
        p_file_name               VARCHAR2,
        p_file_tp                 VARCHAR2,
        p_rpt_dt                  VARCHAR2,
        p_user             IN     VARCHAR2,
        p_out                 OUT types.ref_cursor)
    AS
    v_id number;    
    BEGIN

    DELETE CIC_GROUP_DEBT WHERE rpt_dt=p_rpt_dt;

    OPEN p_out FOR select p_rpt_dt ID from dual;

    END;

END PKG_CIC_GROUP_DEBT;


/
--------------------------------------------------------
--  DDL for Package Body PKG_FRAUDULENCE_CUSTOMER
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PKG_FRAUDULENCE_CUSTOMER" AS

  PROCEDURE pr_list_fraudulence_customer(p_customer_code cis_fraudulence_customer.customer_code%TYPE ,
                               p_customer_name cis_fraudulence_customer.customer_full_name%TYPE,--Dùng cho KEYWORD
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_report_date_from cis_fraudulence_customer.report_date%TYPE,
                               p_report_date_to cis_fraudulence_customer.report_date%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_cic_code cis_fraudulence_customer.cic_code%TYPE,
                               p_status cis_fraudulence_customer.cic_code%TYPE,
                               p_from_date                DATE,
                               p_to_date                  DATE,
                               p_out OUT types.ref_cursor) AS
  BEGIN
    --SHB T쭠ki?m theo di?u ki?n
    /*
     OPEN p_out FOR select * from CIS_FRAUDULENCE_CUSTOMER
        Where (p_customer_code IS NULL OR customer_code LIKE '%' || p_customer_code || '%')
            AND (p_customer_name IS NULL OR customer_name LIKE '%' || p_customer_name || '%')
            AND (p_tax_code IS NULL OR tax_code LIKE '%' || p_tax_code || '%')
            AND (p_register_code IS NULL OR register_code LIKE '%' || p_register_code || '%')
            AND (p_report_date_from IS NULL OR report_date >= to_date(p_report_date_from))
            AND (p_report_date_from IS NULL OR report_date <= to_date(p_report_date_to))
            AND fraud_type = p_fraud_type
            AND (p_id_legal_personal IS NULL OR id_legal_personal = p_id_legal_personal)
            AND (p_type_business IS NULL OR type_business = p_type_business)
            AND (p_cic_code IS NULL OR cic_code = p_cic_code);
*/
     --VIB: Ṱ ki?m theo t? kh󡊠    
	 OPEN p_out FOR select * from CIS_FRAUDULENCE_CUSTOMER a
        Where (','||p_status||',' like '%,'||STATUS||',%' or p_status is null) 
        and register_code||','||tax_code||','||id_legal_personal||','||customer_code||','||customer_name like '%'||p_customer_name||'%' 
        and trunc(REPORT_DATE) between nvl(p_from_date,sysdate-100) and nvl(p_to_date,sysdate+1)
        AND fraud_type = p_fraud_type
        order by a.report_date desc;

      -- T? kh󡠨G?m cᣠtr??ng:  S? CMT/ H? chi?u, MST, S? ?KKD, M㠫hᣨ h஧ , Tꮠkhᣨ h஧)
  END pr_list_fraudulence_customer;
  PROCEDURE pr_create_fraudulence_customer(p_cic_code cis_fraudulence_customer.cic_code%TYPE ,
                               p_customer_type cis_fraudulence_customer.customer_type%TYPE,
                               p_customer_code cis_fraudulence_customer.customer_code%TYPE,
                               p_customer_name cis_fraudulence_customer.customer_name%TYPE,
                               p_customer_full_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_customer_short_name cis_fraudulence_customer.customer_short_name%TYPE,
                               p_customer_add cis_fraudulence_customer.customer_add%TYPE,
                               p_customer_phone cis_fraudulence_customer.customer_phone%TYPE,
                               p_customer_fax cis_fraudulence_customer.customer_fax%TYPE,
                               p_customer_web cis_fraudulence_customer.customer_web%TYPE,
                               p_customer_email cis_fraudulence_customer.customer_email%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_tax_date cis_fraudulence_customer.tax_date%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_register_date cis_fraudulence_customer.register_date%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_industry_code cis_fraudulence_customer.industry_code%TYPE,
                               p_legal_personal cis_fraudulence_customer.legal_personal%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_director_name cis_fraudulence_customer.director_name%TYPE,
                               p_director_id cis_fraudulence_customer.director_id%TYPE,
                               p_source cis_fraudulence_customer.source%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                                p_status cis_fraudulence_customer.status%TYPE,
                               p_out OUT types.ref_cursor) AS
    p_id   cis_fraudulence_customer.id%TYPE;
  BEGIN
     p_id := SEQ_CIS_FRAUDULENCE_CUS.NEXTVAL;
     INSERT INTO cis_fraudulence_customer (id,
                                 cic_code, 
                                 customer_type,
                                 customer_code,
                                 customer_name,
                                 customer_full_name,
                                 customer_short_name,
                                 customer_add,
                                 customer_phone,
                                 customer_fax,
                                 customer_web,
                                 customer_email,
                                 tax_code,
                                 tax_date,
                                 register_code,
                                 register_date,
                                 type_business,
                                 industry_code,
                                 legal_personal,
                                 id_legal_personal,
                                 director_name,
                                 director_id,
                                 source,
                                 report_date,
                                 status,
                                 fraud_type)
        VALUES(p_id,
               p_cic_code,
                p_customer_type,
               p_customer_code,
               p_customer_name,
               p_customer_full_name,
               p_customer_short_name,
               p_customer_add,
               p_customer_phone,
               p_customer_fax,
               p_customer_web,
               p_customer_email,
               p_tax_code,
               p_tax_date,
               p_register_code,
               p_register_date,
               p_type_business,
               p_industry_code,
               p_legal_personal,
               p_id_legal_personal,
               p_director_name,
               p_director_id,
               p_source,
               SYSDATE,
               p_status,
               p_fraud_type);
        OPEN p_out FOR select * from cis_fraudulence_customer
        Where id = p_id;
  END pr_create_fraudulence_customer;
   PROCEDURE pr_update_fraudulence_customer(p_id cis_fraudulence_customer.id%TYPE ,
                                p_cic_code cis_fraudulence_customer.cic_code%TYPE ,
                               p_customer_type cis_fraudulence_customer.customer_type%TYPE,
                               p_customer_code cis_fraudulence_customer.customer_code%TYPE,
                               p_customer_name cis_fraudulence_customer.customer_name%TYPE,
                               p_customer_full_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_customer_short_name cis_fraudulence_customer.customer_short_name%TYPE,
                               p_customer_add cis_fraudulence_customer.customer_add%TYPE,
                               p_customer_phone cis_fraudulence_customer.customer_phone%TYPE,
                               p_customer_fax cis_fraudulence_customer.customer_fax%TYPE,
                               p_customer_web cis_fraudulence_customer.customer_web%TYPE,
                               p_customer_email cis_fraudulence_customer.customer_email%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_tax_date cis_fraudulence_customer.tax_date%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_register_date cis_fraudulence_customer.register_date%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_industry_code cis_fraudulence_customer.industry_code%TYPE,
                               p_legal_personal cis_fraudulence_customer.legal_personal%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_director_name cis_fraudulence_customer.director_name%TYPE,
                               p_director_id cis_fraudulence_customer.director_id%TYPE,
                               p_source cis_fraudulence_customer.source%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                               p_status cis_fraudulence_customer.status%TYPE,
                               p_out OUT types.ref_cursor) AS

  BEGIN

     update cis_fraudulence_customer set 

    cic_code=                     p_cic_code,     
customer_type=     p_customer_type,
status =     p_status,
customer_code=                                  p_customer_code,
customer_name=                                  p_customer_name,
customer_full_name=                             p_customer_full_name,
customer_short_name=                            p_customer_short_name,
customer_add=                                   p_customer_add,
customer_phone=                                 p_customer_phone,
customer_fax=                                   p_customer_fax,
customer_web=                                   p_customer_web,
customer_email=                                 p_customer_email,
tax_code=                                       p_tax_code,
tax_date=                                       p_tax_date,
register_code=                                  p_register_code,
register_date=                                  p_register_date,
type_business=                                  p_type_business,
industry_code=                                  p_industry_code,
legal_personal=                                 p_legal_personal,
id_legal_personal=                              p_id_legal_personal,
director_name=                                  p_director_name,
director_id=                                    p_director_id,
source=                                         p_source,
report_date=                                    SYSDATE,
fraud_type=                                      p_fraud_type where id = p_id;
        OPEN p_out FOR select * from cis_fraudulence_customer
        Where id = p_id;
  END pr_update_fraudulence_customer;
  PROCEDURE pr_info_fraudulence_customer(p_customer_code cis_fraudulence_customer.customer_code%TYPE ,
                               p_customer_name cis_fraudulence_customer.customer_full_name%TYPE,
                               p_tax_code cis_fraudulence_customer.tax_code%TYPE,
                               p_register_code cis_fraudulence_customer.register_code%TYPE,
                               p_fraud_type cis_fraudulence_customer.fraud_type%TYPE,
                               p_id_legal_personal cis_fraudulence_customer.id_legal_personal%TYPE,
                               p_type_business cis_fraudulence_customer.type_business%TYPE,
                               p_cic_code cis_fraudulence_customer.cic_code%TYPE,
                               p_out OUT types.ref_cursor) AS
  BEGIN
     OPEN p_out FOR select * from CIS_FRAUDULENCE_CUSTOMER
        Where (p_customer_code IS NULL OR customer_code = p_customer_code)
            AND (p_customer_name IS NULL OR customer_name = p_customer_name)
            AND (p_tax_code IS NULL OR tax_code = p_tax_code)
            AND (p_register_code IS NULL OR register_code = p_register_code)
            AND (p_fraud_type IS NULL OR fraud_type = p_fraud_type)
            AND (p_id_legal_personal IS NULL OR id_legal_personal = p_id_legal_personal)
            AND (p_type_business IS NULL OR type_business = p_type_business)
            AND (p_cic_code IS NULL OR cic_code = p_cic_code);
  END pr_info_fraudulence_customer;

  PROCEDURE pr_update_inactive_fraudulence(p_fraud_type varchar2) AS
  BEGIN
     update cis_fraudulence_customer set status = 0
     where fraud_type=p_fraud_type;
  END pr_update_inactive_fraudulence;

END PKG_FRAUDULENCE_CUSTOMER;

/
--------------------------------------------------------
--  DDL for Package Body PKG_SYS_EMAIL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PKG_SYS_EMAIL" 
AS
    V_PARAMETER   NVARCHAR2 (4000);
    V_ERRORS      NUMBER (10);

    /******************************************************************************
       NAME:       PKG_SYS_EMAIL
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        5/3/2018      admin       1. Created this package body.
    ******************************************************************************/


    PROCEDURE pr_create_sys_email (
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        --p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        --p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        --p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        --p_status                   SYS_EMAIL.STATUS%TYPE,
        --p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        --p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        --p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
        v_id   SYS_EMAIL.id%TYPE;
    BEGIN
        v_parameter := ', p_channel:'
            || p_channel
            || ', p_subject:'
            || p_subject
            || ', p_email_bcc:'
            || p_email_bcc
            || ', p_email_cc:'
            || p_email_cc
            || ', p_email_to:'
            || p_email_to
            || ', p_email_sender:'
            || p_email_sender
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;
        v_id := seq_sys_email.NEXTVAL;
        pkg_system_log.pr_log_info ('pr_create_sys_email',
                                    'BEGIN',
                                    v_parameter); 

        INSERT INTO SYS_EMAIL (ID,
                               EMAIL_SENDER,
                               EMAIL_TO,
                               EMAIL_CC,
                               EMAIL_BCC,
                               SUBJECT,
                               BODY,
                               --SEND_TIME,
                               --NUMBER_RETRY,
                               --LAST_RETRY,
                               STATUS,
                               CREATED_DATE,
                               MAKER,
                               CHANNEL)
             VALUES (v_id,                                                --ID
                     p_email_sender,                            --EMAIL_SENDER
                     p_email_to,                                    --EMAIL_TO
                     p_email_cc,                                    --EMAIL_CC
                     p_email_bcc,                                  --EMAIL_BCC
                     p_subject,                                      --SUBJECT
                     p_body,                                            --BODY
                     --p_send_time,                                  --SEND_TIME
                     --p_number_retry,                            --NUMBER_RETRY
                     --p_last_retry,                                --LAST_RETRY
                     'NEW',                                        --STATUS
                     SYSDATE,                            --CREATED_DATE
                     p_user,                                          --MAKER
                     p_channel);

        OPEN p_out FOR SELECT ID,
                              EMAIL_SENDER,
                              EMAIL_TO,
                              EMAIL_CC,
                              EMAIL_BCC,
                              SUBJECT,
                              BODY
                         FROM SYS_EMAIL
                        WHERE id = v_id;

        pkg_system_log.pr_log_info ('pr_create_sys_email',
                                    'END',
                                    v_parameter); 

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_create_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;

            RAISE;
    END;


    PROCEDURE pr_get_list_sys_email (
        p_text_search              VARCHAR2,
        p_status              VARCHAR2,
        p_from_date                DATE,
        p_to_date                  DATE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
        v_text_search varchar2(4000);
    BEGIN
        v_parameter := ', p_text_search:'
            || p_text_search
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        pkg_system_log.pr_log_info ('pr_get_list_sys_email', 'BEGIN', v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email', 'BEGIN', v_parameter);
        v_text_search := '%'||pkg_utility.removesignvietnamess(nvl(p_text_search,''))||'%';

        OPEN p_out FOR   SELECT ID,
                                EMAIL_SENDER,
                                EMAIL_TO,
                                EMAIL_CC,
                                EMAIL_BCC,
                                SUBJECT,
                                BODY,
                                SEND_TIME,
                                NUMBER_RETRY,
                                LAST_RETRY,
                                A.STATUS,
                                nvl(B.REF_NAME_VN,'N/A') STATUS_NAME,
                                CREATED_DATE,
                                MAKER,
                                CHANNEL,
                                substr(ERROR_MESSENGER,1,80) ERROR_MESSENGER
                           FROM SYS_EMAIL A
                                LEFT JOIN SYS_refcode B ON A.STATUS=B.REF_CODE AND B.REF_GROUP ='EMAIL_STATUS'
                          WHERE (','||p_status||',' like '%,'||A.STATUS||',%' or p_status is null)
                                and pkg_utility.removesignvietnamess(nvl(maker,'')||','||nvl(EMAIL_TO,'')||','||nvl(SUBJECT,'')) like v_text_search
                                and trunc(nvl(SEND_TIME,CREATED_DATE)) between nvl(p_from_date,sysdate-100) and nvl(p_to_date,sysdate+1)

                       ORDER BY CREATED_DATE DESC;


        pkg_system_log.pr_log_info ('pr_get_list_sys_email',
                                    'END',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email',
                                     'END',
                                     v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_get_list_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;
    END;

    PROCEDURE pr_update_sys_email (
        p_id                       SYS_EMAIL.ID%TYPE,
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_email_cc                 SYS_EMAIL.EMAIL_CC%TYPE,
        p_email_bcc                SYS_EMAIL.EMAIL_BCC%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        p_send_time                SYS_EMAIL.SEND_TIME%TYPE,
        p_number_retry             SYS_EMAIL.NUMBER_RETRY%TYPE,
        p_last_retry               SYS_EMAIL.LAST_RETRY%TYPE,
        p_status                   SYS_EMAIL.STATUS%TYPE,
        p_created_date             SYS_EMAIL.CREATED_DATE%TYPE,
        p_maker                    SYS_EMAIL.MAKER%TYPE,
        p_channel                  SYS_EMAIL.CHANNEL%TYPE,
        p_error_messenger          SYS_EMAIL.ERROR_MESSENGER%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
    BEGIN
        v_parameter :=
               ', p_error_messenger:'
            || p_error_messenger
            || ', p_channel:'
            || p_channel
            || ', p_maker:'
            || p_maker
            || ', p_created_date:'
            || p_created_date
            || ', p_status:'
            || p_status
            || ', p_last_retry:'
            || p_last_retry
            || ', p_number_retry:'
            || p_number_retry
            || ', p_send_time:'
            || p_send_time
            || ', p_subject:'
            || p_subject
            || ', p_email_bcc:'
            || p_email_bcc
            || ', p_email_cc:'
            || p_email_cc
            || ', p_email_to:'
            || p_email_to
            || ', p_email_sender:'
            || p_email_sender
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        pkg_system_log.pr_log_info ('pr_update_sys_email',
                                    'BEGIN',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_update_sys_email0',
                                     'BEGIN',
                                     v_parameter);

        UPDATE SYS_EMAIL
           SET --ID = p_id,
               --EMAIL_SENDER = p_email_sender,
               --EMAIL_TO = p_email_to,
               --EMAIL_CC = p_email_cc,
               --EMAIL_BCC = p_email_bcc,
               --SUBJECT = p_subject,
               --BODY = p_body,
               SEND_TIME = p_send_time,
               NUMBER_RETRY = p_number_retry,
               LAST_RETRY = p_last_retry,
               STATUS = case when p_status='SENDED' then 'SENT' else p_status end,
               --CREATED_DATE = p_created_date,
               --MAKER = p_maker,
               --CHANNEL = p_channel,
               ERROR_MESSENGER = p_error_messenger
         WHERE id = p_id;

        OPEN p_out FOR SELECT ID,
                              EMAIL_SENDER,
                              EMAIL_TO,
                              EMAIL_CC,
                              EMAIL_BCC,
                              SUBJECT,
                              BODY
                         FROM SYS_EMAIL
                        WHERE id = p_id;

        pkg_system_log.pr_log_info ('pr_create_sys_email',
                                    'END',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_create_sys_email',
                                     'END',
                                     v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_create_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;

            RAISE;
    END;

    PROCEDURE pr_get_sys_email_by_id (
        p_id                       SYS_EMAIL.ID%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2,
        p_out                  OUT types.ref_cursor)
    AS
    BEGIN
        v_parameter :=

             'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;

        pkg_system_log.pr_log_info ('pr_get_list_sys_email',
                                    'BEGIN',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email',
                                     'BEGIN',
                                     v_parameter);

        OPEN p_out FOR   SELECT ID,
                                EMAIL_SENDER,
                                EMAIL_TO,
                                EMAIL_CC,
                                EMAIL_BCC,
                                SUBJECT,
                                BODY,
                                SEND_TIME,
                                NUMBER_RETRY,
                                LAST_RETRY,
                                STATUS,
                                CREATED_DATE,
                                MAKER,
                                CHANNEL,
                                ERROR_MESSENGER
                           FROM SYS_EMAIL
                          WHERE ID = p_id
                       ORDER BY CREATED_DATE ASC;


        pkg_system_log.pr_log_info ('pr_get_list_sys_email',
                                    'END',
                                    v_parameter);
        pkg_system_log.pr_log_debug ('pr_get_list_sys_email',
                                     'END',
                                     v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_get_list_sys_email',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));


            END LOOP;
    END;



    PROCEDURE pr_create_sys_email_2 (
        p_email_sender             SYS_EMAIL.EMAIL_SENDER%TYPE,
        p_email_to                 SYS_EMAIL.EMAIL_TO%TYPE,
        p_subject                  SYS_EMAIL.SUBJECT%TYPE,
        p_body                     SYS_EMAIL.BODY%TYPE,
        p_status                   SYS_EMAIL.STATUS%TYPE,
        p_user              IN     VARCHAR2,
        p_client_ip         IN     VARCHAR2,
        p_user_agent        IN     VARCHAR2)
    AS
        v_id   SYS_EMAIL.id%TYPE;
    BEGIN
        v_parameter :=
            'p_status:'
            || p_status
            || ', p_body:'
            || p_body
            || ', p_subject:'
            || p_subject
            || ', p_email_to:'
            || p_email_to
            || ', p_email_sender:'
            || p_email_sender
            || 'p_user:'
            || p_user
            || '|p_client_ip:'
            || p_client_ip
            || '|p_user_agent:'
            || p_user_agent;
        v_id := seq_sys_email.NEXTVAL;
        pkg_system_log.pr_log_info ('pr_create_sys_email_2',
                                    'BEGIN',
                                    v_parameter);

        INSERT INTO SYS_EMAIL (ID,
                               EMAIL_SENDER,
                               EMAIL_TO,
                               SUBJECT,
                               BODY,
                               STATUS,
                               CREATED_DATE,
                               MAKER)
             VALUES (v_id,                                                --ID
                     p_email_sender,                            --EMAIL_SENDER
                     p_email_to,                                 --EMAIL_BCC
                     p_subject,                                      --SUBJECT
                     p_body,                              --LAST_RETRY
                     p_status,                                        --STATUS
                     SysDate,                            --CREATED_DATE
                     p_user);

        pkg_system_log.pr_log_info ('pr_create_sys_email_2',
                                    'END',
                                    v_parameter);

    EXCEPTION                                      -- exception handlers begin
        WHEN OTHERS
        THEN                                       -- handles all other errors
            v_errors := SQL%BULK_EXCEPTIONS.COUNT;

            FOR i IN 1 .. v_errors
            LOOP
                pkg_system_log.pr_log_exception (
                    'pr_create_sys_email_2',
                    'EXCEPTION',
                    SQL%BULK_EXCEPTIONS (i).ERROR_CODE,
                    SQLERRM (-SQL%BULK_EXCEPTIONS (i).ERROR_CODE));
            END LOOP;

            RAISE;
    END;

--G?i email th𮧠bᯠkh?i t?o/di?u ch?nh user
PROCEDURE PR_SEND_EMAIL_USER (P_USER_ID                 VARCHAR2,
                              P_ACTION                  VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(100);
V_FULL_NAME VARCHAR2(100);
V_DOMAIN_ICREDIT VARCHAR2(1000); 
P_OUT TYPES.REF_CURSOR;
V_BODY CLOB;
BEGIN

--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t੠kho?n' ELSE 'T੠kho?n ???c c?p nh?t' END;

SELECT A.EMAIL
       ,CASE WHEN P_ACTION='CREATE' THEN A.CREATE_USER ELSE A.LAST_UPDATE_USER END USER_THUC_HIEN
       ,A.FULL_NAME 

INTO V_EMAIL_TO,V_USER,V_FULL_NAME
FROM SYS_USER A
WHERE A.USER_NAME=lower(P_USER_ID);

SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! '|| P_ACTION) INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_SYS_USER_BODY_'||P_ACTION;

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! '|| P_ACTION) INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_SYS_USER_SUB_'||P_ACTION;

SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';

V_BODY := REPLACE(REPLACE(V_BODY,'[FULL_NAME]',V_FULL_NAME),'[DOMAIN]',V_DOMAIN_ICREDIT);

PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('USER',
                                  V_EMAIL_TO,
                                  '',
                                  '',
                                  V_SUBJECT,
                                  V_BODY,--BODY
                                  'SYSTEM',
                                  V_USER,
                                  '',
                                  '',
                                  P_OUT);
--COMMIT;
END;

--G?i email th𮧠bᯠkh?i t?o/di?u ch?nh user
PROCEDURE PR_SEND_EMAIL_RESPONSE (P_CIS_NO                  VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(100);
V_FULL_NAME VARCHAR2(100); 
V_DOMAIN_ICREDIT VARCHAR2(1000); 
P_OUT TYPES.REF_CURSOR;
V_BODY CLOB;
BEGIN

--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t੠kho?n' ELSE 'T੠kho?n ???c c?p nh?t' END;

SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! ') INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_RESPONSE_BODY';

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! ') INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_RESPONSE_SUB';


SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';

FOR R_ROW IN (
                  SELECT B.EMAIL
                         ,B.FULL_NAME  
                         , A.CREATED_USER 
                         ,C.CHANNEL
                         ,NVL(D.REF_NAME_VN,C.STATUS) STATUS_NAME
                  --INTO V_EMAIL_TO,V_FULL_NAME, V_USER
                  FROM CIS_REQUEST_EMAIL A
                  LEFT JOIN SYS_USER B ON A.CREATED_USER=B.USER_NAME
                  LEFT JOIN CIS_REQUEST C ON A.CIS_NO=C.CIS_NO
                  LEFT JOIN sys_refcode D ON C.STATUS=D.REF_CODE AND D.REF_GROUP='STATUS_REQUEST'
                  WHERE A.CIS_NO=P_CIS_NO )
LOOP


    --V_BODY := REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME);

    PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('REQUEST',
                                      R_ROW.EMAIL,
                                      '',
                                      '',
                                      REPLACE(V_SUBJECT,'[CIS_NO]', P_CIS_NO),
                                      REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME),'[CIS_NO]', P_CIS_NO),'[CHANNEL]', R_ROW.CHANNEL),'[STATUS_NAME]', R_ROW.STATUS_NAME),'[DOMAIN]',V_DOMAIN_ICREDIT),--BODY
                                      'SYSTEM',
                                      R_ROW.CREATED_USER,
                                      '',
                                      '',
                                      P_OUT);
--COMMIT;
END LOOP;

END;

--G?i email th𮧠bᯠphꠤuy?t b?n tin
PROCEDURE PR_SEND_EMAIL_TASK(P_TASK_ID VARCHAR2, P_STATUS VARCHAR2 , P_USER VARCHAR2, P_COMMENT VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(500);
V_FULL_NAME VARCHAR2(100); 
V_DOMAIN_ICREDIT VARCHAR2(1000); 
P_OUT TYPES.REF_CURSOR;
V_BODY CLOB; 
BEGIN

--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t੠kho?n' ELSE 'T੠kho?n ???c c?p nh?t' END;

SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! ') INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_TASK_'|| P_STATUS;

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! ') INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_TASK_'||P_STATUS||'_SUB';

SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';


FOR R_ROW IN (
                  SELECT A.ID, B.EMAIL
                         ,B.FULL_NAME  
                         , A.MAKER 
                         ,CASE WHEN P_STATUS='APPROVED' THEN 'Bản tin được phê duyệt'
                               WHEN P_STATUS='REJECTED' THEN 'Bản tin bị từ chối'
                               ELSE 'N/A' END STATUS_NAME
                  --INTO V_EMAIL_TO,V_FULL_NAME, V_USER
                  FROM SYS_TASK_LIST A
                  LEFT JOIN SYS_USER B ON A.MAKER=B.USER_NAME 
                  WHERE A.TASK_ID=P_TASK_ID)
LOOP


    --V_BODY := REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME);

    PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('TASK',
                                      R_ROW.EMAIL,
                                      '',
                                      '',
                                      REPLACE(REPLACE(V_SUBJECT,'[TASK_ID]', 'LO'||P_TASK_ID),'[STATUS_NAME]', R_ROW.STATUS_NAME),
                                      REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(V_BODY,'[FULL_NAME]', R_ROW.FULL_NAME),'[TASK_ID]', 'LO'||R_ROW.ID),'[STATUS_NAME]', R_ROW.STATUS_NAME),'[COMMENT]',P_COMMENT),'[DOMAIN]',V_DOMAIN_ICREDIT),--BODY
                                      'SYSTEM',
                                      P_USER,
                                      '',
                                      '',
                                      P_OUT);
--COMMIT;
END LOOP;

END;


--G?i email th𮧠bᯠcho ng??i dùng bi?t c󠦩le m?i
PROCEDURE PR_SEND_EMAIL_NEW_FILE(P_FILE_NAME VARCHAR2, P_CHANNEL VARCHAR2, P_STATUS VARCHAR2)
AS
V_EMAIL_TO VARCHAR2(100);
V_USER VARCHAR2(100);
V_SUBJECT VARCHAR2(500);
V_FULL_NAME VARCHAR2(100); 
V_DOMAIN_ICREDIT VARCHAR2(1000); 
P_OUT TYPES.REF_CURSOR;
V_BODY CLOB; 
BEGIN

--V_SUBJECT := CASE WHEN P_ACTION='CREATE' THEN 'Kh?i t?o t੠kho?n' ELSE 'T੠kho?n ???c c?p nh?t' END;

SELECT NVL(MAX(A.PAR1),'BODY NOT FOUND! ') INTO V_BODY
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_REPORT_'||P_CHANNEL||'_'||P_STATUS;

SELECT NVL(MAX(A.PAR1),'SUBJECT NOT FOUND! ') INTO V_SUBJECT
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_REPORT_'||P_CHANNEL||'_'||P_STATUS||'_SUB';

SELECT NVL(MAX(A.PAR1),'') INTO V_EMAIL_TO
FROM SYS_REFCODE A
WHERE A.REF_CODE='TEMPLATE_EMAIL_REPORT_'||P_CHANNEL||'_'||P_STATUS||'_EMAIL_TO';

SELECT NVL(MAX(A.PAR1),'NOT FOUND! ') INTO V_DOMAIN_ICREDIT
FROM SYS_REFCODE A
WHERE A.REF_CODE='DOMAIN_ICREDIT_TEMPLATE_EMAIL';
IF V_EMAIL_TO IS NOT NULL THEN

    PKG_SYS_EMAIL.PR_CREATE_SYS_EMAIL('REPORT_'||P_CHANNEL,
                                      V_EMAIL_TO,
                                      '',
                                      '',
                                      REPLACE(V_SUBJECT,'[FILE_NAME]', P_FILE_NAME),
                                      REPLACE(REPLACE(V_BODY,'[FILE_NAME]', P_FILE_NAME),'[DOMAIN]',V_DOMAIN_ICREDIT),--BODY
                                      'SYSTEM',
                                      'N/A',
                                      '',
                                      '',
                                      P_OUT);
--COMMIT;
END IF;

END;
END PKG_SYS_EMAIL;


/
--------------------------------------------------------
--  DDL for Package Body PKG_SYSTEM_LOG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PKG_SYSTEM_LOG" AS

V_ERRORS     number(10);
V_EXCEPTION varchar2(25):='EXCEPTION';
V_DEBUG varchar2(25):='DEBUG';
V_INFO varchar2(25):='INFO';
/*
Creater: CuongNH2
Created date: 9/1/2018
Description: Lay thong tin cua user
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_Parameter: chi tiet cac parameter
             P_TASK_TYPE: kieu task
             P_IP_CLIENT: client ip
             P_MACHINE: ten machine
*/
Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob) is
begin

   PR_LOG_INFO(P_TASK_NAME, P_STEP_NAME, p_Parameter, 'PR');
/*EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
     ROLLBACK;
      PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME, P_STEP_NAME, SQLCODE, SQLERRM );*/
end;

/*
Creater: CuongNH2
Created date: 18/1/2018
Description: log DEBUG cho cac xu ly DB
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_Parameter: chi tiet cac parameter
*/
Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2) is
begin

   PR_LOG_DEBUG(P_TASK_NAME, P_STEP_NAME, p_Parameter, 'PR');

/*EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME ,
                           P_STEP_NAME ,
                           SQLCODE ,
                           SQLERRM );
      ROLLBACK;*/
end;

/*
Creater: CuongNH2
Created date: 18/1/2018
Description: ghi nhan log EXCEPTION
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_ErrorNumber: ma loi
             p_ErrorMessage: chi tiet noi dung loi
*/
Procedure PR_LOG_EXCEPTION(P_TASK_NAME varchar2,
                           P_STEP_NAME varchar2,
                           p_ErrorNumber varchar2,
                           p_ErrorMessage varchar2) is
begin
   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE,
      ERROR_CODE)
   values
     (cis_sys_ncb.SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      'PR',
      SYSDATE,
      P_STEP_NAME,
      p_ErrorNumber || '.' || p_ErrorMessage, 
      V_EXCEPTION,
      p_ErrorNumber);
   --raise_application_error(p_ErrorNumber,p_ErrorMessage);
EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      null;
end;


  /*
  Creater: SonTA2
  Created date: 30/1/2018
  Description: log INFO cho cac xu ly DB
  Parameter:
               P_TASK_NAME: Ten task
               P_STEP_NAME: Ten job
               p_ErrorNumber: ma loi
               P_TASK_TYPE: kieu task
  */
Procedure PR_LOG_INFO(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter clob, P_TASK_TYPE varchar2) is
begin
   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE)
   values
     (CIS_SYS_NCB.SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      P_TASK_TYPE,
      SYSDATE,
      P_STEP_NAME,
      SUBSTR(p_Parameter,1,4000), 
      V_INFO);
EXCEPTION  -- exception handlers begin
     WHEN OTHERS THEN  -- handles all other errors
       V_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;
       FOR I IN 1 .. V_ERRORS
       LOOP
         PR_LOG_EXCEPTION(P_TASK_NAME,P_STEP_NAME,
                         SQL%BULK_EXCEPTIONS (I).ERROR_CODE,
                         SQLERRM (-SQL%BULK_EXCEPTIONS (I).ERROR_CODE) );
       END LOOP;
      raise;
end;

/*
Creater: CuongNH2
Created date: 18/1/2018
Description: log DEBUG cho cac xu ly DB
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_Parameter: chi tiet cac parameter
*/
Procedure PR_LOG_DEBUG(P_TASK_NAME varchar2, P_STEP_NAME varchar2, p_Parameter varchar2, P_TASK_TYPE varchar2) is
begin

   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE)
   values
     (CIS_SYS_NCB.SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      P_TASK_TYPE,
      SYSDATE,
      P_STEP_NAME,
      SUBSTR(p_Parameter,1,4000), 
      V_DEBUG);

/*EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME ,
                           P_STEP_NAME ,
                           SQLCODE ,
                           SQLERRM );
      ROLLBACK;*/
end;

/*
Creater: CuongNH2
Created date: 23/1/2018
Description: ghi nhan log EXCEPTION khong throw
Parameter:
             p_Task_Name: Ten task
             p_Job_Code: Ten job
             p_ErrorNumber: ma loi
             p_ErrorMessage: chi tiet noi dung loi
*/
Procedure PR_LOG_EXCEPTION_UNTHROW(P_TASK_NAME varchar2,
                           P_STEP_NAME varchar2,
                           p_ErrorNumber varchar2,
                           p_ErrorMessage clob,
                           P_TASK_TYPE varchar2 ) is
BEGIN

   insert into SYS_LOG
     (ID,
      TASK_ID,
      TASK_NAME,
      TASK_TYPE,
      EXECUTE_DATE,
      STEP_NAME,
      DESCRIPTION, 
      LOG_TYPE,
      ERROR_CODE)
   values
     (CIS_SYS_NCB.SEQ_SYS_LOG.NEXTVAL,
      P_TASK_NAME,
      P_TASK_NAME,
      P_TASK_TYPE,
      SYSDATE,
      P_STEP_NAME,
      p_ErrorNumber || '.' || p_ErrorMessage, 
      V_EXCEPTION,
      p_ErrorNumber);
EXCEPTION  -- exception handlers begin
   WHEN OTHERS THEN  -- handles all other errors
      ROLLBACK;
end;


Procedure PR_LOG_ACTIVITY(P_APPLICATION_ID VARCHAR2,
                            P_RESOURCE_URL VARCHAR2,
                            P_ACCESS_USER VARCHAR2,
                            P_ACCESS_STATUS VARCHAR2,
                            P_LOG_MESSAGE CLOB,
                            P_RESOURCE_TYPE VARCHAR2,
                            P_RPT_CODE VARCHAR2,
                            P_RESOURCE_ACTION VARCHAR2,
                            P_CLIENT_IP VARCHAR2,
                            P_USER_AGENT VARCHAR2,
                            p_out OUT types.ref_cursor) IS
BEGIN
   INSERT INTO SYS_RESOURCEACCESSMANAGEMENT
     (ID,
      APPLICATION_ID,
      RESOURCE_URL,
      ACCESS_USER,
      ACCESS_DATE,
      ACCESS_STATUS,
      LOG_MESSAGE,
      RESOURCE_TYPE,
      RPT_CODE,
      RESOURCE_ACTION,
      CLIENT_IP,
      USER_AGENT)
   VALUES
     (CIS_SYS_NCB.SEQ_SYS_RES_ACCESSMANAGEMENT.NEXTVAL,
      P_APPLICATION_ID ,
      P_RESOURCE_URL ,
      P_ACCESS_USER ,
      SYSDATE ,
      P_ACCESS_STATUS ,
      P_LOG_MESSAGE ,
      P_RESOURCE_TYPE ,
      P_RPT_CODE ,
      P_RESOURCE_ACTION ,
      P_CLIENT_IP ,
      P_USER_AGENT );

      OPEN p_out FOR
      SELECT 'SUCCESS' STATUS FROM DUAL;
EXCEPTION  -- exception handlers begin
     WHEN OTHERS THEN  -- handles all other errors
       V_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;
       FOR I IN 1 .. V_ERRORS
       LOOP
         PR_LOG_EXCEPTION('PR_LOG_ACTIVITY','INSERT',
                         SQL%BULK_EXCEPTIONS (I).ERROR_CODE,
                         SQLERRM (-SQL%BULK_EXCEPTIONS (I).ERROR_CODE) );
       END LOOP;
      raise;
end;
end PKG_SYSTEM_LOG;


/
--------------------------------------------------------
--  DDL for Package Body PKG_UTILITY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CIS_OPS_NCB"."PKG_UTILITY" is

/*
Creater: CuongNH2
Create date: 19/4/2018
Description: Xoa dau va chuyen thanh chu thuong
*/
FUNCTION RemoveSignVietnamess(P_STR IN VARCHAR2) RETURN clob
IS
  V_RESULT clob;
BEGIN

V_RESULT := TRANSLATE(P_STR,
'áàảãạăắằẳẵặâấầẩẫậđéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵÁÀẢÃẠĂẮẰẲẴẶÂẤẦẨẪẬĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ',
'aaaaaaaaaaaaaaaaadeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyyAAAAAAAAAAAAAAAAADEEEEEEEEEEEIIIIIOOOOOOOOOOOOOOOOOUUUUUUUUUUUYYYYY');

  RETURN lower(V_RESULT);
END;


/*
Creater: CuongNH2
Create date: 11/7/2018
Description: Format number with comma
*/
FUNCTION FORMAT_NUMBER(P_STR IN VARCHAR2) RETURN VARCHAR2
IS
  V_RESULT VARCHAR2(50);
BEGIN

SELECT  TRIM(TO_CHAR(P_STR, '99G999G999G999G999G999G999', 'NLS_NUMERIC_CHARACTERS=",."')) INTO V_RESULT
FROM    dual;

  RETURN V_RESULT;
END;


FUNCTION IS_NUMBER(P_STR IN VARCHAR2) RETURN NUMBER
IS
  v_num NUMBER;
BEGIN
  v_num := TO_NUMBER(P_STR);
  RETURN v_num;
EXCEPTION
WHEN VALUE_ERROR THEN
  RETURN 0;
END;

FUNCTION RemoveSpecialCharactor(P_STR IN clob) RETURN clob
IS
  V_RESULT clob;
BEGIN

V_RESULT := replace(P_STR,'&amp;','__');
V_RESULT := replace(replace(V_RESULT,'&quot;','"'),'"','&quot;');
V_RESULT := replace(replace(V_RESULT,'&apos;',''''),'''','&apos;'); 
V_RESULT := replace(replace(replace(V_RESULT,'<BR>','&lt;BR &gt;') ,'</BR>','&lt;/BR &gt;'),'Ð','Ð');
V_RESULT := replace(V_RESULT,'__','&amp;');

  RETURN V_RESULT;
END;
end PKG_UTILITY;

/
